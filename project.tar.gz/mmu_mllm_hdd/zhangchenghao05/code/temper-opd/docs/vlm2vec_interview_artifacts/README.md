# VLM2Vec Interview Artifacts

生成日期: 2026-06-12 UTC

用途: 面试前快速复盘本地 VLM2Vec / Goods unified embedding / Better SID / XSeq 的关键代码、脚本、YAML 和数据 case。这里是当前 `temper-opd` 项目内的只读文档快照，不是可直接运行的完整源码仓库。

## Source State

| 项目 | 原始路径 | 分支 / HEAD | 快照说明 |
|---|---|---|---|
| Goods / unified embedding | `/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec` | `goods-strong300-emb-compare` / `968b9ab` | 复制当前工作树中的关键文件；原仓库有本地 dirty docs/plan 变更。 |
| Better SID / XSeq | `/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec-better-sid` | `musid` / `4e25f06` | 复制当前工作树中的关键文件；`experiments/musid/scripts/train_musid_multitask.sh` 为 dirty 版本。 |

运行脚本中的 WandB key、HF token 占位、内部 proxy/no_proxy 字面量已在本快照中替换为 `[REDACTED_*]`。原始外部项目没有被修改。

## Layout

| 目录 / 文件 | 内容 |
|---|---|
| `source_snapshots/vlm2vec/` | Goods 主线关键代码、训练/eval 脚本、YAML、cached projector、公开 baseline 配置。 |
| `source_snapshots/vlm2vec-better-sid/` | Better SID / MuSID / XSeq 关键代码、训练脚本和 YAML。 |
| `data_cases/` | 面试解释用的结构化数据样例和 schema。 |
| `FILE_LIST.txt` | 当前快照文件清单。 |

当前快照大小约 2.7M，首次生成时文件清单为 177 项；新增 README 后以 `FILE_LIST.txt` 为准。

## Key Code Map

| 链路 | 快照内关键文件 |
|---|---|
| 训练入口 | `source_snapshots/vlm2vec/train.py`, `source_snapshots/vlm2vec/src/arguments.py` |
| 模型与 compression tokens | `source_snapshots/vlm2vec/src/model/model.py`, `source_snapshots/vlm2vec/src/model/processor.py` |
| pooling / projector / 低维头 | `source_snapshots/vlm2vec/src/model/projector.py`, `source_snapshots/vlm2vec/src/cached_projector/*.py` |
| retrieval loss / 多槽位相似度 | `source_snapshots/vlm2vec/src/loss.py` |
| retrieval + OpenQA 混训 | `source_snapshots/vlm2vec/src/trainer.py`, `source_snapshots/vlm2vec/src/data/loader/mixed_dataset.py` |
| 数据 parser | `source_snapshots/vlm2vec/src/data/dataset/hetu_ret_dataset.py`, `source_snapshots/vlm2vec/src/data/dataset/hetu_compress_dataset.py` |
| encode-only / eval parser | `source_snapshots/vlm2vec/src/data/eval_dataset/hetu_items_dataset.py`, `source_snapshots/vlm2vec/src/data/collator/eval_collator.py` |
| Qwen2.5-Omni / token selection 适配 | `source_snapshots/vlm2vec/src/model/vlm_backbone/qwen2_5_omni/`, `source_snapshots/vlm2vec/src/model/vlm_backbone/qwen2_5_vl_tokenselection/` |
| XSeq | `source_snapshots/vlm2vec-better-sid/src/xseq.py`, `source_snapshots/vlm2vec-better-sid/src/trainer.py` |

## Key Recipes

| 场景 | 快照内文件 |
|---|---|
| Goods 0429 Stage1 | `source_snapshots/vlm2vec/experiments/hetu/train_goods_0429_stage1_retqa_curated.yaml` |
| Goods 0429 Stage2 | `source_snapshots/vlm2vec/experiments/hetu/train_goods_0429_stage2_retqa_curated.yaml` |
| 0402 two-stage 训练入口 | `source_snapshots/vlm2vec/experiments/hetu/train_goods_0402_twostage.sh` |
| Strong300 + OpenQA | `source_snapshots/vlm2vec/experiments/hetu/train_goods_strong300_onerec_openqa.yaml` |
| 全量商品 embedding | `source_snapshots/vlm2vec/experiments/hetu/eval_goods_inference_items_emb.yaml` |
| XL/IA 测试 embedding | `source_snapshots/vlm2vec/experiments/hetu/eval_goods_0402_test3_emb.yaml` |
| Cached projector | `source_snapshots/vlm2vec/experiments/hetu/cached_projector/*.sh` |
| MuSID / XSeq | `source_snapshots/vlm2vec-better-sid/experiments/musid/yaml/*.yaml`, `source_snapshots/vlm2vec-better-sid/experiments/musid/scripts/*.sh` |
| 公开 VLM2Vec baseline | `source_snapshots/vlm2vec/experiments/public/train/`, `source_snapshots/vlm2vec/experiments/public/eval/` |

## Data Cases

| Case | 说明 |
|---|---|
| `data_cases/retrieval_goods_pair.schema.json` | `hetu_ret` pair: query/positive 两侧图文输入，训练 in-batch contrastive retrieval。 |
| `data_cases/hetu_goods_openqa_long.case.json` | 商品长分析 OpenQA: 商品语义压缩、属性分析、目标人群、负反馈。 |
| `data_cases/hetu_goods_short_title.case.json` | 商品短标题结构化抽取: 用 QA 格式做标题规整/属性抽取监督。 |
| `data_cases/parallel_sid_photo_item.case.json` | 短视频/图片 + 商品 SID: video frames/OCR/ASR/audio + item 信息。 |
| `data_cases/hetu_items_encode_only.schema.json` | encode-only 输入输出 schema: 只产 embedding，不直接产业务指标。 |

## Interview Boundary

- 这份快照记录的是本地 Goods / Better SID 工程资产，不要讲成“参与官方 VLM2Vec 论文项目”。
- Goods 主线可以讲 retrieval_goods + OpenQA/SID 混训、多槽位 embedding、slot_aligned / maxsim_topk、orthogonal/HSIC 诊断、cached projector。
- Better SID / XSeq 可以讲训练期相似样本 slot 注入和生成 loss 对 embedding 的反向约束，不要说推理期依赖外部 memory。
- encode-only 产物只说明 embedding 生产链路；没有统一固定的全量 recall / NDCG / AUC 表时，不要把它说成离线效果结论。
