from typing import List, Tuple
import ast
import datasets
import numpy as np
from datasets import load_dataset, concatenate_datasets
from PIL import Image
import os
from datasets.features.image import image_to_bytes

from torch.jit import isinstance
from src.data.eval_dataset.base_i2i_dataset import AutoEvalI2IDataset, MULTIMODAL_FEATURES, add_metainfo_hook, RESOLUTION_MAPPING
from src.model.processor import PHI3V, VLM_IMAGE_TOKENS, VLM_COMPRESS_TOKENS, TOTAL_COMPRESS_TOKENS, VLM_AUDIO_TOKENS
from src.utils import print_master, print_rank
from torch.utils.data import Dataset


summarize_prompt = "".join(VLM_COMPRESS_TOKENS) if TOTAL_COMPRESS_TOKENS > 0 else ""

def process_text(text, image_token, audio_token):
    text = text.replace('<image>', image_token).replace('<audio>', audio_token)
    
    return text

@add_metainfo_hook
def data_prepare(batch_dict, *args, **kwargs):
    model_backbone = kwargs['model_backbone']
    image_resolution = kwargs['image_resolution']
    audio_dir = kwargs['audio_dir']
    image_dir = kwargs['image_dir']
    mlp_idx = int(kwargs['mlp_idx'])
    batch_size = len(batch_dict['id'])
    
    ids, textss, imagess, audioss, labelss = [], [], [], [], []
    mlp_idxs = []

    for data_idx, (data_id, text, images, audios, labels) in enumerate(zip(batch_dict['id'], batch_dict['text'], batch_dict['images'], batch_dict['audios'], batch_dict['labels'])):
        try:

            text = process_text(text, image_token=VLM_IMAGE_TOKENS[model_backbone], audio_token=VLM_AUDIO_TOKENS[model_backbone])
            text = text + summarize_prompt

            images = {"bytes": len(images) * [None], "paths": [os.path.join(image_dir, path) for path in images], "resolutions": len(images) * [RESOLUTION_MAPPING.get(image_resolution, None)]}
            audios = {"bytes": len(audios) * [None], "paths": [os.path.join(audio_dir, path) for path in audios], "resolutions": len(audios) * [None]}
            
            ids.append(data_id)
            textss.append([text])
            imagess.append([images])
            audioss.append(audios)
            labelss.append(labels)
            mlp_idxs.append(mlp_idx)

        except Exception as e:
            print(f'Error in processing {DATASET_PARSER_NAME}: \n\t\tdata id: {data_id} \n\t\batch_dict: {batch_dict}')
            print(e)
            raise e
    return {"id": ids, "texts": textss, "images": imagess, "audios": audioss, "labels": labelss, "mlp_idx": mlp_idxs}


DATASET_PARSER_NAME = "hetu_ret_v2i"
@AutoEvalI2IDataset.register(DATASET_PARSER_NAME)
def load_hetu_v2i_dataset(model_args, data_args, training_args, *args, **kwargs):
    dataset_name = kwargs.get("dataset_name", DATASET_PARSER_NAME)
    subset_name = kwargs.get("subset_name", dataset_name)
    dataset_split = kwargs.get("dataset_split", "original")
    audio_dir = kwargs.get("audio_dir", "/")
    image_dir = kwargs.get("image_dir", "/")

    mlp_idx = int(kwargs.get("mlp_idx", -1))

    dataset_path = kwargs["dataset_path"]
    dataset = datasets.load_dataset('json', data_files=dataset_path, streaming=False)['train']

    i2i_dataset_dic = dict()
    for pair in dataset:
        pid, qid = pair['pid'], pair['qid']
        pid = str(pid)
        # 加入前缀区分 q 和 d
        qid = f"ITEM_{qid}"

        if pid in i2i_dataset_dic:
            i2i_dataset_dic[pid]["labels"].append(qid)
        else:
            i2i_dataset_dic[pid] = {
                "id": pid,
                "text": pair["qry"],
                "images": pair["qry_image_path"],
                "audios": pair["qry_audio_path"],
                "labels": [qid],
            }
        if qid in i2i_dataset_dic:
            continue
        else:
            i2i_dataset_dic[qid] = {
                "id": qid,
                "text": pair["pos_text"],
                "images": pair["pos_image_path"],
                "audios": pair["pos_audio_path"],
                "labels": [],
            }

    i2i_dataset = list(i2i_dataset_dic.values())
    dataset = datasets.Dataset.from_list(i2i_dataset)
    print_master(f"Loaded v2i dataset with {len(dataset)} items")
    
    num_sample_per_subset = kwargs.get("num_sample_per_subset", getattr(data_args, "num_sample_per_subset", None))
    if num_sample_per_subset is not None and num_sample_per_subset < dataset.num_rows:
        num_rows = int(num_sample_per_subset)
        dataset = dataset.select(range(num_rows))
    num_rows = dataset.num_rows

    kwargs['model_backbone'] = model_args.model_backbone
    kwargs['image_resolution'] = data_args.image_resolution
    kwargs['global_dataset_name'] = f'{DATASET_PARSER_NAME}/{subset_name}'
    kwargs['num_hardneg'] = data_args.num_hardneg
    kwargs['audio_dir'] = audio_dir
    kwargs['image_dir'] = image_dir
    kwargs['mlp_idx'] = mlp_idx
    assert data_args.num_hardneg <= 0, "hard negative sampling is not supported in hetu ret dataset for now"

    dataset = dataset.map(lambda x: data_prepare(x, **kwargs), batched=True, batch_size=128, drop_last_batch=False)

    dataset = dataset.select_columns(["id", "texts", "images", "audios", "labels", "mlp_idx", "global_dataset_name", "task_type", "cls_type"])
    # dataset = dataset.cast(MULTIMODAL_FEATURES)
    print_master(f"Loaded {DATASET_PARSER_NAME}/{subset_name} dataset with {num_rows} samples [mlp_idx={mlp_idx}]")

    return dataset

