#!/bin/bash
set -euo pipefail
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
export MASTER_PORT="${MASTER_PORT:-2209}"
export RDZV_ID="${RDZV_ID:-musid_baseline_ret_openqa_ortho1}"
export EXP_NAME="${EXP_NAME:-musid_baseline_ret_openqa_ortho1}"
export TASK_TYPES="retrieval openqa"
export DATASET_CONFIG="${DATASET_CONFIG:-$REPO_DIR/experiments/musid/yaml/musid_train_hetu_orthogonal.yaml}"
export DATA_WEIGHTS="${DATA_WEIGHTS:-1 96}"
export LOSS_WEIGHTS="${LOSS_WEIGHTS:-1 0.5}"
export GRADIENT_ACCUMULATION_STEPS="${GRADIENT_ACCUMULATION_STEPS:-97}"
export ENABLE_GRAD_CACHE=true
export ORTHO_W="${ORTHO_W:-1.0}"
unset XSEQ_ARGS
bash "$REPO_DIR/experiments/musid/scripts/train_musid_multitask.sh" "$@"
