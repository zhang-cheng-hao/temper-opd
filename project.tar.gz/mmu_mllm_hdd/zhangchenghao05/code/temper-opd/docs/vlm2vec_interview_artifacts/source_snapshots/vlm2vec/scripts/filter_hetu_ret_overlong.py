#!/usr/bin/env python3
import argparse
import ast
import json
import re
from pathlib import Path


DEFAULT_INPUTS = [
    "/mmu_vcg_wjc_hdd/duyong/code/llm_rec_embedding/数据整合/训练数据0402/ia_pair.jsonl",
    "/mmu_vcg_wjc_hdd/duyong/code/llm_rec_embedding/数据整合/训练数据0402/lf_pair.jsonl",
    "/mmu_vcg_wjc_hdd/duyong/code/llm_rec_embedding/数据整合/训练数据0402/xl_pair.jsonl",
]
DEFAULT_OUTPUT_DIR = "/mmu_vcg_wjc_hdd/duyong/code/llm_rec_embedding/数据整合/训练数据0402/filtered_8192"

IMAGE_PLACEHOLDERS = [
    "<|IMAGE|>",
    "<image>",
    "<|image_pad|>",
    "<|vision_start|>",
    "<|vision_end|>",
    "<|image_placeholder|>",
    "<|video_placeholder|>",
]
AUDIO_PLACEHOLDERS = [
    "<|AUDIO|>",
    "<audio>",
    "<|audio_token|>",
    "<|audio_bos|>",
    "<|audio_eos|>",
    "<|audio_placeholder|>",
]


def ensure_list(value):
    if value is None:
        return []
    if isinstance(value, str):
        stripped = value.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            try:
                value = ast.literal_eval(stripped)
            except Exception:
                return [value]
    if isinstance(value, list):
        flattened = []
        for item in value:
            if item is None:
                continue
            if isinstance(item, list):
                flattened.extend(x for x in item if x is not None)
            else:
                flattened.append(item)
        return flattened
    return [value]


def count_items(value):
    return len(ensure_list(value))


def normalize_text_for_estimate(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<\|ctoken_pad_\d+\|>", "", text)
    for token in IMAGE_PLACEHOLDERS:
        text = text.replace(token, "")
    for token in AUDIO_PLACEHOLDERS:
        text = text.replace(token, "")
    return text


def get_first_present(record, keys, default=""):
    for key in keys:
        if key in record and record[key] is not None:
            return record[key]
    return default


def count_sides(record):
    qry_text = get_first_present(record, ["qry", "query_text", "qry_text", "text"], "")
    pos_text = get_first_present(record, ["pos_text", "positive_text", "cand_text"], "")
    qry_images = get_first_present(record, ["qry_image_path", "query_image_path", "qry_image", "query_image"], [])
    pos_images = get_first_present(record, ["pos_image_path", "positive_image_path", "cand_image_path", "pos_image"], [])
    qry_audios = get_first_present(record, ["qry_audio_path", "query_audio_path", "qry_audio"], [])
    pos_audios = get_first_present(record, ["pos_audio_path", "positive_audio_path", "cand_audio_path", "pos_audio"], [])
    return qry_text, pos_text, qry_images, pos_images, qry_audios, pos_audios


def estimate_side_tokens(text, image_count, audio_count, args):
    normalized_text = normalize_text_for_estimate(text)
    text_chars = len(normalized_text)
    return (
        text_chars
        + image_count * args.image_token_budget
        + audio_count * args.audio_token_budget
        + args.compress_token_budget
        + args.overhead_tokens
    )


def main():
    parser = argparse.ArgumentParser(description="Heuristically filter overlong hetu retrieval pairs.")
    parser.add_argument("--input-paths", nargs="+", default=DEFAULT_INPUTS)
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--bad-dir", default=None, help="Directory for rejected samples. Defaults to <output-dir>/bad.")
    parser.add_argument("--stats-path", default=None, help="Optional aggregate stats json path.")
    parser.add_argument("--max-est-tokens", type=int, default=8192)
    parser.add_argument("--image-token-budget", type=int, default=200)
    parser.add_argument("--audio-token-budget", type=int, default=0)
    parser.add_argument("--compress-token-budget", type=int, default=4)
    parser.add_argument("--overhead-tokens", type=int, default=128)
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    bad_dir = Path(args.bad_dir) if args.bad_dir else output_dir / "bad"
    output_dir.mkdir(parents=True, exist_ok=True)
    bad_dir.mkdir(parents=True, exist_ok=True)

    aggregate = {
        "input_paths": [],
        "output_dir": str(output_dir),
        "bad_dir": str(bad_dir),
        "max_est_tokens": args.max_est_tokens,
        "image_token_budget": args.image_token_budget,
        "audio_token_budget": args.audio_token_budget,
        "compress_token_budget": args.compress_token_budget,
        "overhead_tokens": args.overhead_tokens,
        "files": [],
    }

    for input_path_str in args.input_paths:
        input_path = Path(input_path_str)
        output_path = output_dir / f"{input_path.stem}.filtered.jsonl"
        bad_path = bad_dir / f"{input_path.stem}.bad.jsonl"
        stats_path = output_dir / f"{input_path.stem}.stats.json"

        total = 0
        kept = 0
        filtered = 0
        query_filtered = 0
        pos_filtered = 0
        reason_counts = {
            "query_over_budget": 0,
            "pos_over_budget": 0,
        }
        top_cases = []

        with input_path.open("r", encoding="utf-8") as fin, \
                output_path.open("w", encoding="utf-8") as fout, \
                bad_path.open("w", encoding="utf-8") as fbad:
            for line in fin:
                if not line.strip():
                    continue
                total += 1
                if args.limit is not None and total > args.limit:
                    break

                record = json.loads(line)
                qry_text, pos_text, qry_images, pos_images, qry_audios, pos_audios = count_sides(record)

                qry_image_count = count_items(qry_images)
                pos_image_count = count_items(pos_images)
                qry_audio_count = count_items(qry_audios)
                pos_audio_count = count_items(pos_audios)

                qry_est = estimate_side_tokens(qry_text, qry_image_count, qry_audio_count, args)
                pos_est = estimate_side_tokens(pos_text, pos_image_count, pos_audio_count, args)
                pair_est = max(qry_est, pos_est)
                top_cases.append((pair_est, record.get("qid", record.get("id")), qry_est, pos_est))

                qry_over = qry_est > args.max_est_tokens
                pos_over = pos_est > args.max_est_tokens
                if qry_over or pos_over:
                    filtered += 1
                    if qry_over:
                        query_filtered += 1
                        reason_counts["query_over_budget"] += 1
                    if pos_over:
                        pos_filtered += 1
                        reason_counts["pos_over_budget"] += 1
                    fbad.write(json.dumps({
                        "reason": "query_over_budget" if qry_over and not pos_over else
                                 "pos_over_budget" if pos_over and not qry_over else
                                 "query_over_budget|pos_over_budget",
                        "qid": record.get("qid", record.get("id")),
                        "qry_est": qry_est,
                        "pos_est": pos_est,
                        "max_est_tokens": args.max_est_tokens,
                        "qry_image_count": qry_image_count,
                        "pos_image_count": pos_image_count,
                        "qry_audio_count": qry_audio_count,
                        "pos_audio_count": pos_audio_count,
                        "record": record,
                    }, ensure_ascii=False) + "\n")
                    continue

                kept += 1
                fout.write(line)

        top_cases.sort(reverse=True)
        stats = {
            "input_path": str(input_path),
            "output_path": str(output_path),
            "bad_path": str(bad_path),
            "total": total,
            "kept": kept,
            "filtered": filtered,
            "kept_ratio": 0.0 if total == 0 else kept / total,
            "reason_counts": reason_counts,
            "query_filtered": query_filtered,
            "pos_filtered": pos_filtered,
            "top_cases": [
                {
                    "est": est,
                    "qid": qid,
                    "qry_est": qry_est,
                    "pos_est": pos_est,
                }
                for est, qid, qry_est, pos_est in top_cases[:20]
            ],
        }

        with stats_path.open("w", encoding="utf-8") as f:
            json.dump(stats, f, ensure_ascii=False, indent=2)

        aggregate["input_paths"].append(str(input_path))
        aggregate["files"].append(stats)
        print(json.dumps(stats, ensure_ascii=False, indent=2))

    if args.stats_path:
        stats_path = Path(args.stats_path)
        stats_path.parent.mkdir(parents=True, exist_ok=True)
        with stats_path.open("w", encoding="utf-8") as f:
            json.dump(aggregate, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
