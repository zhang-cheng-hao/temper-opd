#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Collect ONLY images (*.png) under analyze_orthogonal.py output_dir into JSONL.

Each line:
{
  "type": "image",
  "path": "...",
  "meta": {"size_bytes": ..., "mtime": "..."},
  "checkpoint_key": "...",   # best-effort (dir name like parent__checkpoint-xxx), optional
  "group": "summary|per_batch|comparison|other"  # best-effort
}

Usage:
  python /mmu_mllm_hdd/zhangchenghao05/code/vlm2vec/scripts/collect_orthogonal_outputs.py \
    --output_dir /mmu_mllm_hdd/zhangchenghao05/hetu_next \
    --out_jsonl /mmu_mllm_hdd/zhangchenghao05/hetu_next/collected_images.jsonl \
    --absolute_paths
"""

import json
import glob
import argparse
from pathlib import Path
from datetime import datetime


def _file_meta(p: Path):
    try:
        st = p.stat()
        return {
            "size_bytes": int(st.st_size),
            "mtime": datetime.fromtimestamp(st.st_mtime).isoformat(),
        }
    except Exception:
        return None


def _to_path_str(p: Path, root: Path, absolute_paths: bool):
    if absolute_paths:
        return str(p.resolve())
    try:
        return str(p.resolve().relative_to(root.resolve()))
    except Exception:
        return str(p)


def _infer_checkpoint_key(p: Path, root: Path):
    """
    Best-effort: find immediate dir under root that looks like '<something>__checkpoint-*'
    e.g. root/<parent__checkpoint-500>/figs/summary/xxx.png
    """
    try:
        rel = p.resolve().relative_to(root.resolve())
        parts = rel.parts
        if len(parts) >= 1:
            top = parts[0]
            if "__checkpoint-" in top or top.startswith("checkpoint-"):
                return top
    except Exception:
        pass
    return None


def _infer_group(p: Path):
    norm = str(p).replace("\\", "/")
    if "/figs/summary/" in norm:
        return "summary"
    if "/figs/per_batch/" in norm:
        return "per_batch"
    if "/comparison/" in norm:
        return "comparison"
    return "other"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output_dir", type=str, required=True)
    parser.add_argument("--out_jsonl", type=str, default=None)
    parser.add_argument("--absolute_paths", action="store_true")
    args = parser.parse_args()

    root = Path(args.output_dir)
    if not root.exists():
        raise SystemExit(f"output_dir not found: {root}")

    out_jsonl = Path(args.out_jsonl) if args.out_jsonl else (root / "collected_images.jsonl")
    out_jsonl.parent.mkdir(parents=True, exist_ok=True)

    pngs = sorted(Path(x) for x in glob.glob(str(root / "**" / "mean_sim_heatmap.png"), recursive=True))

    with out_jsonl.open("w", encoding="utf-8") as fp:
        # meta header
        fp.write(json.dumps({
            "type": "meta",
            "collected_at": datetime.now().isoformat(),
            "root": str(root.resolve()) if args.absolute_paths else str(root),
            "num_png": len(pngs),
        }, ensure_ascii=False) + "\n")

        for p in pngs:
            fp.write(json.dumps({
                "type": "image",
                "path": _to_path_str(p, root, args.absolute_paths),
                "meta": _file_meta(p),
                "checkpoint_key": _infer_checkpoint_key(p, root),
                "group": _infer_group(p),
            }, ensure_ascii=False) + "\n")

    print(f"[OK] Wrote {len(pngs)} images to: {out_jsonl}")


if __name__ == "__main__":
    main()
