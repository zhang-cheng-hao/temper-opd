from itertools import repeat
from typing import Dict, List, Any, Optional

import logging
from functools import partial
from dataclasses import field, dataclass
from transformers import ProcessorMixin, AutoProcessor, AutoTokenizer
from src.arguments import DataArguments, ModelArguments, TrainingArguments
import torch
import numpy as np
import json
from qwen_vl_utils import smart_resize

from src.model.processor import TOTAL_COMPRESS_TOKENS, LLAVA_NEXT, QWEN2_VL, QWEN2_5_VL, KORUS, KORUS_OMNI, \
    QWEN2_VL_TOKENSELECTION, QWEN2_5_VL_TOKENSELECTION, PHI3V, VLM_IMAGE_TOKENS, VLM_AUDIO_TOKENS, process_vlm_inputs_fns
from PIL import Image
import io
from src.utils import print_rank, print_master
import math
import os
import traceback
logger = logging.getLogger(__name__)


PHI_IMAGE_TOKEN_MAX_INPUT_ID = int(1e9)
LLAVA_IMAGE_TOKEN_ID = 32000


def split_and_process_vlm_inputs(model_input: dict, chunk_size: int):
    assert len(model_input) == 1
    arg_key = list(model_input.keys())[0]
    arg_val = model_input[arg_key]
    if arg_val is None:
        return None

    keys = list(arg_val.keys())
    chunked_tensors = []
    for k in keys:
        if isinstance(arg_val[k], torch.Tensor):
            # for position_ids, we need to split along dim=1
            chunked_tensor = arg_val[k].split(chunk_size, dim=0) if k != "position_ids" else arg_val[k].split(chunk_size, dim=1)
        else:
            chunked_tensor = [arg_val[k][i: i + chunk_size] for i in list(range(0, len(arg_val[k]), chunk_size))]
        chunked_tensors.append(chunked_tensor)
    chunked_arg_val = [dict(zip(kk, tt)) for kk, tt in zip(repeat(keys), zip(*chunked_tensors))]
    chunked_inputs = [{arg_key: c} for c in chunked_arg_val]

    return chunked_inputs


def split_vlm_inputs(model_input: dict, chunk_size: int):
    assert len(model_input) == 1
    arg_key = list(model_input.keys())[0]
    arg_val = model_input[arg_key]
    keys = list(arg_val.keys())

    # for input_ids and attention_mask, split directly
    chunked_tensors = [arg_val[k].split(chunk_size, dim=0) for k in ["input_ids", "attention_mask"]]

    # for pixel_values and image_sizes, need to split based on the position of images
    input_ids = arg_val["input_ids"]
    # positions = torch.nonzero(((input_ids < 0) & (input_ids > -MAX_INPUT_ID)) | input_ids == LLAVE_IMAGE_TOKEN_ID, as_tuple=True)
    positions = torch.nonzero((input_ids < 0) & (input_ids > -PHI_IMAGE_TOKEN_MAX_INPUT_ID), as_tuple=True)
    row_contain_image = torch.unique(positions[0])  # indicates which row in input_ids contain images
    num_chunks = len(chunked_tensors[0])
    chunk_image_count = []
    for chunk_idx in range(num_chunks):
        chunk_image_count.append(torch.sum(
            (row_contain_image >= chunk_idx * chunk_size) & (row_contain_image < (chunk_idx + 1) * chunk_size)).item())
    if "pixel_values" in keys:
        pixel_values = arg_val["pixel_values"]
        image_sizes = arg_val["image_sizes"]
        chunked_tensors.append(torch.split(pixel_values, chunk_image_count))
        chunked_tensors.append(torch.split(image_sizes, chunk_image_count))

    chunked_arg_val = []
    for kk, tt in zip(repeat(keys), zip(*chunked_tensors)):
        if "pixel_values" in keys and tt[2].numel() == 0:  # this chunk doesn't contain image
            chunked_arg_val.append(dict(zip(kk[:2], tt[:2])))
        else:
            chunked_arg_val.append(dict(zip(kk, tt)))

    return [{arg_key: c} for c in chunked_arg_val]


def get_dense_rep(x):
    """
    Get either qry_reps or tgt_reps or neg_reps.
    Returns (reps, aux_reps) tuple.
    """
    if x["qry_reps"] is None:
        if x["tgt_reps"] is None:
            val = x["neg_reps"]
        else:
            val = x["tgt_reps"]
    else:
        val = x["qry_reps"]

    if isinstance(val, tuple) and len(val) >= 2:
        return val[0], val[1]
    return val, None


@dataclass
class TrainTextImageDataCollator:
    data_args: DataArguments
    model_args: ModelArguments
    processor: ProcessorMixin

    def __call__(self, examples):
        """
        :param examples: qry, qry_image, pos_text, pos_image
        """
        qry_inputs = self._get_batch_inputs(examples, "query_text", "query_image")
        pos_inputs = self._get_batch_inputs(examples, "pos_text", "pos_image")
        neg_inputs = self._get_batch_inputs(examples, "neg_text", "neg_image")
        return qry_inputs, pos_inputs

    def _get_batch_inputs(self, examples, text_keyname, image_keyname):
        texts, images = [], []
        for example in examples:
            # @ruimeng filter invalid data examples here will lead to fail to sync across devices (unequal batch size)
            # use dummy input for now
            if example is None or not example:
                text, image = '  ', None
            text, image = example[text_keyname], example[image_keyname]
            if type(text) == list:
                if len(text) == 0 or len(image) == 0:
                    text, image = '  ', None
                else:
                    text, image = text[0], image[0]
            texts.append(text)
            images.append(image)
        inputs = {'text': texts, 'image': images}
        return inputs


@dataclass
class MultimodalDataCollator:
    processor: ProcessorMixin
    model_args: ModelArguments
    data_args: DataArguments
    training_args: TrainingArguments
    batch_size: Optional[int] = None  # used to verify if a batch has invalid data
    model_func_get_rope_index: Optional[Any] = None
    cls_type_to_indices: Dict[str, List[int]] = field(default_factory=lambda: { None: [0, TOTAL_COMPRESS_TOKENS] })
    skip_mode: bool = False

    def __post_init__(self):
        cls_sep_indices = set()
        for cls_indices in self.cls_type_to_indices.values():
            cls_sep_indices.add(cls_indices[0])
            cls_sep_indices.add(cls_indices[-1] + 1)
        self.cls_sep_indices = sorted(list(cls_sep_indices))

    def _get_batch_inputs(self, batch, text_keyname, image_keyname, skip_mode=False):
        texts, visual_inputs = [], []
        for example in batch:
            # @ruimeng filter invalid data examples here may lead to fail to sync across devices (unequal batch size)
            # use dummy input for now
            if example is None or not example:
                text, visual_input = '  ', None
            else:
                text, raw_images = example[text_keyname], example[image_keyname] if image_keyname in example else None
                if type(raw_images) == dict and not skip_mode:
                    visual_input = []
                    assert 'resolutions' in raw_images, "we need len(raw_images['resolutions']) to determine the number of images, set it a list of None of for cases that no resizing is needed"
                    num_images = len(raw_images['resolutions'])
                    for image_idx in range(num_images):
                        bytes = raw_images['bytes'][image_idx] if 'bytes' in raw_images else None
                        path = raw_images['paths'][image_idx] if 'paths' in raw_images else None
                        image_resolution = raw_images['resolutions'][image_idx] if 'resolutions' in raw_images else None
                        if bytes is None and path is None:
                            image = None
                        elif bytes is not None:
                            # vidore, image inputs are already bytes
                            image = Image.open(io.BytesIO(bytes))
                        elif path is not None:
                            try:
                            # mmeb/video datasets, lazy image loading and processing
                                with Image.open(path) as img:
                                    image = img.convert("RGB")
                            except:
                                print(traceback.format_exc())
                                # a black image
                                image = Image.new("RGB", (38, 38), (0, 0, 0))

                        else:
                            print_rank(f"\n{'=' * 50}\nsomething went wrong with a data point from {example['global_dataset_name']}, neither bytes or path is given. \n\t\tquery_text: {example['query_text']}")
                        # if not self.data_args.resize_use_processor and image is not None and image_resolution:
                        #     image = image.resize(image_resolution)
                        # if image is not None and (self.data_args.image_decay_factor is not None and image_resolution is None):
                        #     assert image_resolution is None, "image_resolution is conflicting with image_decay_factor"
                        #     assert self.model_args.model_backbone in [QWEN2_VL, QWEN2_5_VL, QWEN2_VL_TOKENSELECTION, QWEN2_5_VL_TOKENSELECTION], "image_decay_factor is only supported for Qwen models"
                        #     # TODO: this is a hacky way to decay image resolution, need to be refactored
                        #     max_pixels = max(self.data_args.resize_min_pixels, self.data_args.resize_max_pixels * self.data_args.image_decay_factor ** (num_images - image_idx))
                        #     width, height = image.size
                        #     resized_height, resized_width = smart_resize(
                        #         height,
                        #         width,
                        #         min_pixels=self.data_args.resize_min_pixels,
                        #         max_pixels=max_pixels,
                        #     )
                        #     image = image.resize((resized_width, resized_height))  
                        if image is not None:
                            image = self._preprocess_image(image, image_min_pixels=self.data_args.resize_min_pixels, image_max_pixels=self.data_args.resize_max_pixels)
                            visual_input.append(image)
                    if len(visual_input) == 0:
                        visual_input = None
                else:
                    visual_input = None

                if visual_input is None:
                    # TODO: remove audio here for now
                    text = text.replace(VLM_IMAGE_TOKENS[self.training_args.model_backbone], '').replace(VLM_AUDIO_TOKENS[self.training_args.model_backbone], '')
            texts.append(text)
            visual_inputs.append(visual_input)
        inputs = {'text': texts, 'images': visual_inputs}
        return inputs

    def _get_batch_audio_inputs(self, examples, audio_keyname, skip_mode=False):

        audio_inputs = []

        # from ipdb import set_trace; set_trace()

        for example in examples:
            if skip_mode or example is None or not example:
                audio_input = None
            else:
                audio_input = []
                raw_audios = example[audio_keyname] if audio_keyname in example else None
                if type(raw_audios) == dict:
                    assert 'resolutions' in raw_audios, "we need len(raw_images['resolutions']) to determine the number of images, set it a list of None of for cases that no resizing is needed"
                    num_audios = len(raw_audios['resolutions'])
                    for audio_idx in range(num_audios):
                        path = raw_audios['paths'][audio_idx] if 'paths' in raw_audios else None
                        if path is not None:
                            pass
                            # handle in process fn
                        else:
                            print_rank(f"\n{'=' * 50}\nsomething went wrong with a data point from {example['global_dataset_name']}, neither bytes or path is given. \n\t\tquery_text: {example['query_text']}")
                        
                        audio_input.append(path)
            
            audio_inputs.append(audio_input)
        return audio_inputs
    
    def _preprocess_image(
        self, image: "ImageObject", image_max_pixels=512*512, image_min_pixels=32*32
    ) -> "ImageObject":
        r"""Pre-process a single image."""
        if (image.width * image.height) > image_max_pixels:
            resize_factor = math.sqrt(image_max_pixels / (image.width * image.height))
            width, height = int(image.width * resize_factor), int(image.height * resize_factor)
            image = image.resize((width, height))

        if (image.width * image.height) < image_min_pixels:
            resize_factor = math.sqrt(image_min_pixels / (image.width * image.height))
            width, height = int(image.width * resize_factor), int(image.height * resize_factor)
            image = image.resize((width, height))

        if image.mode != "RGB":
            image = image.convert("RGB")

        return image

    def _get_ret_batch_inputs(self, examples, skip_mode=False):
        """
        :param examples: 'query_text', 'query_image_path', 'pos_text', 'pos_image_path',
        """
        qry_inputs = self._get_batch_inputs(examples, "query_text", "query_image", skip_mode=skip_mode)
        qry_audios = self._get_batch_audio_inputs(examples, "query_audio", skip_mode=skip_mode)
        # qry_mlp_idx = self._get_mlp_inputs(examples, "mlp_idx", skip_mode=skip_mode)
        # qry_inputs['mlp_idx'] = qry_mlp_idx
        if len(qry_audios) > 0:
            qry_inputs['audios'] = qry_audios

        pos_inputs = self._get_batch_inputs(examples, "pos_text", "pos_image", skip_mode=skip_mode)
        pos_audios = self._get_batch_audio_inputs(examples, "pos_audio", skip_mode=skip_mode)
        # pos_mlp_idx = self._get_mlp_inputs(examples, "mlp_idx", skip_mode=skip_mode)
        # pos_inputs['mlp_idx'] = pos_mlp_idx
        if len(pos_audios) > 0:
            pos_inputs['audios'] = pos_audios

        if skip_mode:
            self.skip_bar.update(1)

        bs = len(qry_inputs['text'])
        assert bs > 0, 'An empty batch'
        # pad batch to batch_size to avoid hanging in distributed training
        if self.batch_size is not None and bs < self.batch_size:
            raise RuntimeError(f"Expect batch size {self.batch_size}, but got batch size of {bs}")
        
        process_fn = partial(process_vlm_inputs_fns[KORUS_OMNI], task_type="retrieval", get_rope_func=self.model_func_get_rope_index) \
            if self.model_args.compression_mode else process_vlm_inputs_fns[self.training_args.model_backbone]
        # process_fn = partial(process_vlm_inputs_fns[KORUS], task_type="retrieval") \
        #     if self.model_args.compression_mode else process_vlm_inputs_fns[self.training_args.model_backbone]
        qry_inputs['cls_indices'] = [self.cls_type_to_indices[e["cls_type"]] for e in examples]
        pos_inputs['cls_indices'] = [self.cls_type_to_indices[e["cls_type"]] for e in examples]

        processed_qry_inputs = process_fn(qry_inputs, processor=self.processor, max_length=self.data_args.max_len, cls_sep_indices=self.cls_sep_indices)
        processed_pos_inputs = process_fn(pos_inputs, processor=self.processor, max_length=self.data_args.max_len, cls_sep_indices=self.cls_sep_indices)

        processed_qry_inputs['mlp_idx'] = [e['mlp_idx'] for e in examples]
        processed_pos_inputs['mlp_idx'] = [e['mlp_idx'] for e in examples]

        processed_qry_inputs['text'] = [e['query_text'] for e in examples]
        processed_pos_inputs['text'] = [e['pos_text'] for e in examples]
        processed_qry_inputs['global_dataset_name'] = [e['global_dataset_name'] for e in examples]
        processed_pos_inputs['global_dataset_name'] = [e['global_dataset_name'] for e in examples]
        # hard negative mining
        processed_neg_inputs = None
        if self.data_args.num_hardneg > 0:
            raise NotImplementedError("Hard negative mining is not implemented yet in multimodal collator.")
            
            # neg_inputs = self._get_batch_inputs(examples, "neg_text", "neg_image")
            # processed_neg_inputs = process_fn(neg_inputs, processor=self.processor, max_length=self.data_args.max_len)
            # processed_neg_inputs['text'] = [e['neg_text'] for e in examples]
            # processed_neg_inputs['global_dataset_name'] = [e['global_dataset_name'] for e in examples]

        processed_qry_inputs['id'] = [e['id'] for e in examples]
        processed_pos_inputs['id'] = [e['id'] for e in examples]
        processed_qry_inputs['task_type'] = [e['task_type'] for e in examples]
        processed_pos_inputs['task_type'] = [e['task_type'] for e in examples]
        processed_qry_inputs['cls_type'] = [e['cls_type'] for e in examples]
        processed_pos_inputs['cls_type'] = [e['cls_type'] for e in examples]
        # print_rank(f"\t\tQry collator: processed_qry_inputs['input_ids'].shape={processed_qry_inputs['input_ids'].shape}\t\tPos collator: processed_pos_inputs['input_ids'].shape={processed_pos_inputs['input_ids'].shape}")
        return processed_qry_inputs, processed_pos_inputs, processed_neg_inputs
    
    def _constuct_conversations(self, enc_qry_inputs, enc_ans_inputs, dec_qry_inputs, dec_ans_inputs):
        conversations = []
        enc_texts = []
        for enc_qry_text, enc_ans_text, dec_qry_text, dec_ans_text in \
            zip(enc_qry_inputs['text'], enc_ans_inputs['text'], dec_qry_inputs['text'], dec_ans_inputs['text']):
            enc_texts.append(enc_qry_text + enc_ans_text if enc_qry_text is not None and enc_ans_text is not None else "")
            conversations.append([
                {
                    "role": "user",
                    "content": [{"type": "text", "text": dec_qry_text}],
                },
                {
                    "role": "assistant",
                    "content": [{"type": "text", "text": dec_ans_text}],
                }
            ])
        texts = self.processor.apply_chat_template(conversations, tokenize=False, add_generation_prompt=False)
        texts = [enc_t + t for enc_t, t in zip(enc_texts, texts)]  # filter out empty queries
        return {"text": texts, "images": enc_qry_inputs['images']}

    def _get_qa_batch_inputs(self, examples, skip_mode=False):
        """
        :param examples: 'encode_query', 'encode_answer', 'encode_image', 'decode_query', 'decode_answer'
        """
        enc_qry_inputs = self._get_batch_inputs(examples, "encode_query", "encode_image", skip_mode=skip_mode)
        enc_ans_inputs = self._get_batch_inputs(examples, "encode_answer", "", skip_mode=skip_mode)
        dec_qry_inputs = self._get_batch_inputs(examples, "decode_query", "", skip_mode=skip_mode)
        dec_ans_inputs = self._get_batch_inputs(examples, "decode_answer", "", skip_mode=skip_mode)

        if skip_mode:
            self.skip_bar.update(1)

        # audio_inputs = []

        # # from ipdb import set_trace; set_trace()

        # for example in examples:
        #     if example is None or not example:
        #         raw_audios = None
        #     else:
        #         audio_input = []
        #         raw_audios = example['encode_audio'] if 'encode_audio' in example else None
        #         if type(raw_audios) == dict:
        #             assert 'resolutions' in raw_audios, "we need len(raw_images['resolutions']) to determine the number of images, set it a list of None of for cases that no resizing is needed"
        #             num_audios = len(raw_audios['resolutions'])
        #             for audio_idx in range(num_audios):
        #                 path = raw_audios['paths'][audio_idx] if 'paths' in raw_audios else None
        #                 if path is not None:
        #                     pass
        #                     # handle in process fn
        #                 else:
        #                     print_rank(f"\n{'=' * 50}\nsomething went wrong with a data point from {example['global_dataset_name']}, neither bytes or path is given. \n\t\tquery_text: {example['query_text']}")
                        
        #                 audio_input.append(path)
            
        #     audio_inputs.append(audio_input)

        inputs = self._constuct_conversations(enc_qry_inputs, enc_ans_inputs, dec_qry_inputs, dec_ans_inputs)

        audio_inputs = self._get_batch_audio_inputs(examples, "encode_audio")

        if len(audio_inputs) > 0:
            inputs['audios'] = audio_inputs

        bs = len(enc_qry_inputs['text'])
        assert bs > 0, 'An empty batch'
        # pad batch to batch_size to avoid hanging in distributed training
        if self.batch_size is not None and bs < self.batch_size:
            raise RuntimeError(f"Expect batch size {self.batch_size}, but got batch size of {bs}")

        # === 蒸馏模式：同时构造 comp (student) 和 nat (teacher) 输入 ===
        if self.training_args.distillation_loss and self.model_args.compression_mode:
            # comp (student): prob=0.0
            process_fn_comp = partial(process_vlm_inputs_fns[KORUS_OMNI], task_type="openqa",
                                     prob=0.0, get_rope_func=self.model_func_get_rope_index)

            # nat (teacher): prob=1.0 (强制跳过压缩)
            process_fn_nat = partial(process_vlm_inputs_fns[KORUS_OMNI], task_type="openqa",
                                    prob=1.0, get_rope_func=self.model_func_get_rope_index)

            # 构造 comp 输入
            inputs_comp = inputs.copy()
            inputs_comp['cls_indices'] = [self.cls_type_to_indices[e["cls_type"]] for e in examples]
            processed_inputs_comp = process_fn_comp(inputs_comp, processor=self.processor,
                                                     max_length=self.data_args.max_len, cls_sep_indices=self.cls_sep_indices)

            # 构造 nat 输入
            inputs_nat = inputs.copy()
            inputs_nat['cls_indices'] = [self.cls_type_to_indices[e["cls_type"]] for e in examples]
            processed_inputs_nat = process_fn_nat(inputs_nat, processor=self.processor,
                                                    max_length=self.data_args.max_len, cls_sep_indices=self.cls_sep_indices)

            # 包装返回（必须直接包含 task_type，因为 training_step 会访问 inputs["task_type"]）
            return {
                "distill_openqa": True,
                "task_type": [e['task_type'] for e in examples],
                "comp": processed_inputs_comp,
                "nat": processed_inputs_nat,
                "global_dataset_name": [e['global_dataset_name'] for e in examples],
                "cls_type": [e['cls_type'] for e in examples],
                "id": [e['id'] for e in examples],
            }
        else:
            # 非蒸馏模式：原有逻辑
            process_fn = partial(process_vlm_inputs_fns[KORUS_OMNI], task_type="openqa",
                                prob=self.training_args.native_prob, get_rope_func=self.model_func_get_rope_index) \
                    if self.model_args.compression_mode else process_vlm_inputs_fns[self.training_args.model_backbone]

            inputs['cls_indices'] = [self.cls_type_to_indices[e["cls_type"]] for e in examples]
            processed_inputs = process_fn(inputs, processor=self.processor, max_length=self.data_args.max_len, cls_sep_indices=self.cls_sep_indices)

            processed_inputs['global_dataset_name'] = [e['global_dataset_name'] for e in examples]
            processed_inputs['task_type'] = [e['task_type'] for e in examples]
            processed_inputs['cls_type'] = [e['cls_type'] for e in examples]
            processed_inputs['id'] = [e['id'] for e in examples]

            return processed_inputs

    def __call__(self, examples):
        task_type = examples[0].get('task_type', 'retrieval')  # we assert task_type is the same for all examples in a batch
        
        assert all(x['task_type'] == task_type for x in examples), \
            f"Task type mismatch in the batch: {[e['task_type'] for e in examples]}"

        skip_mark = os.path.join(self.training_args.output_dir, 'skip')

        if os.path.exists(skip_mark):
            self.skip_mode = True
            print_master(f"Skipping mode enabled")
            if not hasattr(self, 'skip_bar'):
                from tqdm import tqdm
                self.skip_bar = tqdm(total=0, desc=f"Skipping...", disable=torch.distributed.is_initialized() and torch.distributed.get_rank() > 0)
        else:
            self.skip_mode = False


        if 'retrieval' in task_type:
            return self._get_ret_batch_inputs(examples, skip_mode=getattr(self, 'skip_mode', False))
        elif 'openqa' in task_type:
            return self._get_qa_batch_inputs(examples, skip_mode=getattr(self, 'skip_mode', False))
        else:
            raise NotImplementedError(f"Unsupported task type [{task_type}] in the collator.")
