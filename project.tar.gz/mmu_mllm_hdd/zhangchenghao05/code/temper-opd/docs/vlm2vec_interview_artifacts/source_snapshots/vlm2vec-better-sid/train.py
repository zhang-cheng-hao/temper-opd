# Adapted from Tevatron code
import logging
import os.path
import sys

logging.basicConfig(
    level=logging.INFO, format='[%(asctime)s] %(levelname)s [%(name)s:%(lineno)s] %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]  # Ensures logs appear in stdout
)
logger = logging.getLogger(__name__)

import sys
import torch
import wandb
import yaml
from transformers import HfArgumentParser
from transformers.trainer_utils import set_seed
from src.arguments import ModelArguments, DataArguments, TrainingArguments
from src.data.collator.train_collator import MultimodalDataCollator
from src.data.loader.mixed_dataset import init_mixed_dataset
from src.model.model import MMEBModel
from src.trainer import GradCacheLateProcessTrainer, OpenQATrainer, MultiTaskTrainer, DynamicLossWeight
from src.utils import print_rank, print_master, find_latest_checkpoint
from src.model.processor import load_processor, get_backbone_name, TOTAL_COMPRESS_TOKENS


def main():
    # a hack for torch.distributed.launch: https://github.com/huggingface/transformers/issues/22171
    for arg in sys.argv:
        if arg.startswith("--local-rank="):
            rank = arg.split("=")[1]
            sys.argv.remove(arg)
            sys.argv.append('--local_rank')
            sys.argv.append(rank)
    parser = HfArgumentParser((ModelArguments, DataArguments, TrainingArguments))

    model_args, data_args, training_args = parser.parse_args_into_dataclasses()
    model_args: ModelArguments
    data_args: DataArguments
    training_args: TrainingArguments

    # assert not (training_args.normalize_in_loss & model_args.normalize), "Only one normalization method should be enabled."

    # DEBUG PRINTS for Distributed Setup
    print("Distributed init debug info:")
    print(f"RANK: {os.environ.get('RANK')}")
    print(f"LOCAL_RANK: {os.environ.get('LOCAL_RANK')}")
    print(f"WORLD_SIZE: {os.environ.get('WORLD_SIZE')}")
    print(f"MASTER_ADDR: {os.environ.get('MASTER_ADDR')}")
    print(f"MASTER_PORT: {os.environ.get('MASTER_PORT')}")

    if torch.distributed.is_available():
        print(f"torch.distributed.is_initialized: {torch.distributed.is_initialized()}")
        if torch.distributed.is_initialized():
            print(f"torch.distributed.get_rank(): {torch.distributed.get_rank()}")
            print(f"torch.distributed.get_world_size(): {torch.distributed.get_world_size()}")

    # SET SEED before init trainer
    set_seed(training_args.seed)
    print_rank("init: seed set")

    # Check for existing checkpoints
    if training_args.resume_from == 'auto':
        resume_checkpoint_dir = find_latest_checkpoint(training_args.output_dir)
        if resume_checkpoint_dir:
            logger.info(f"Resuming from checkpoint: {resume_checkpoint_dir}")
        else:
            logger.warning(
                f"resume_from=auto but no checkpoint found under {training_args.output_dir}; starting fresh training."
            )
    elif training_args.resume_from.isdigit():
        resume_checkpoint_dir = os.path.join(training_args.output_dir, f'checkpoint-{training_args.resume_from}')
        if os.path.exists(resume_checkpoint_dir):
            logger.info(f"Resuming from checkpoint: {resume_checkpoint_dir}")
        else:
            raise FileNotFoundError(
                f"resume_from={training_args.resume_from} but checkpoint not found: {resume_checkpoint_dir}"
            )
    else:
        resume_checkpoint_dir = None
        logger.info("No checkpoint found. Starting fresh training.")

    # Initialize WandB if enabled
    if 'wandb' in training_args.report_to:
        if (torch.distributed.is_initialized() and torch.distributed.get_rank() == 0) or (not torch.distributed.is_initialized()):
            print_rank('init wandb')
            wandb.init(project=training_args.project_name, name=training_args.run_name, mode="online")
            wandb.define_metric("diag/global_step")
            wandb.define_metric("load_summary/*", step_metric="diag/global_step")
            wandb.define_metric("orth/*", step_metric="diag/global_step")
            wandb.config.update(model_args)
            wandb.config.update(data_args)
            wandb.config.update({k: v for k, v in training_args.to_dict().items() if k != "deepspeed"})  # skip deepspeed config for wandb
    
    # Override gradient accumulation steps
    assert sum(training_args.data_weights) > 0 and all(x >= 0 for x in training_args.data_weights), "data_weights must be non-negative and at least one must be positive"
    if sum(training_args.data_weights) % training_args.gradient_accumulation_steps != 0:
        raise ValueError(f"gradient_accumulation_steps must be divisible by sum of data_weights: {sum(training_args.data_weights)} % {training_args.gradient_accumulation_steps} != 0")

    model = MMEBModel.build(model_args)
    print_rank("init: model built")
    model_backbone = get_backbone_name(hf_config=model.config, model_type=model_args.model_type)
    setattr(model_args, 'model_backbone', model_backbone)
    setattr(training_args, 'model_backbone', model_backbone)
    print_rank(f'model_backbone: {model_backbone}')
    processor = load_processor(model_args, data_args)
    print_rank("init: processor loaded")
    setattr(model, 'processor', processor)

    train_collator = MultimodalDataCollator(
        processor=processor, 
        model_args=model_args, 
        data_args=data_args, 
        training_args=training_args, 
        model_func_get_rope_index=model.encoder.get_rope_index,
        cls_type_to_indices=model.config.cls_type_to_indices
    )
    with open(data_args.dataset_config, 'r') as yaml_file:
        dataset_config = yaml.safe_load(yaml_file)
        print_rank("init: dataset config loaded")
        train_dataloader = init_mixed_dataset(dataset_config, model_args, data_args, training_args, train_collator)
    print_rank(f"init: mixed dataset ready only_retrv={train_dataloader.only_retrv_data} only_openqa={train_dataloader.only_openqa_data}")

    extra_kwargs = {}
    if train_dataloader.only_openqa_data:
        print_rank("Only OpenQA data found, using OpenQATrainer")
        trainer_cls = OpenQATrainer
    elif train_dataloader.only_retrv_data:
        print_rank("Only Retrieval data found, using GradCacheLateProcessTrainer")
        trainer_cls = GradCacheLateProcessTrainer
    else:
        print_rank("Mixed data found, using MultiTaskTrainer")
        trainer_cls = MultiTaskTrainer
        loss_weights = DynamicLossWeight(training_args.task_types, training_args.loss_weights, warmup_steps=0, strategy='fixed')
        extra_kwargs['callbacks'] = [loss_weights]
        extra_kwargs['loss_weights'] = loss_weights

    trainer = trainer_cls(
        model=model,
        processing_class=processor,
        args=training_args,
        multitask_dataloader=train_dataloader,
        train_dataset=None,
        data_collator=None,
        **extra_kwargs,
        # model_args=model_args,
        # max_length=data_args.max_len,
    )
    print_rank(f"init: trainer constructed cls={trainer_cls.__name__}")
    train_dataloader.trainer = trainer

    print_rank("init: entering trainer.train")
    trainer.train(resume_from_checkpoint=resume_checkpoint_dir)
    print_rank("init: trainer.train returned")
    trainer.save_model(training_args.output_dir)

    if trainer.is_world_process_zero():
        processor.save_pretrained(training_args.output_dir)


if __name__ == "__main__":
    main()
