import argparse
import json
import math
import os
import random
from typing import Dict, List

import numpy as np
import torch
import torch.distributed as dist
import torch.nn.functional as F
from torch.nn.parallel import DistributedDataParallel

from src.cached_projector.data import list_cache_files, load_cache_shard, parse_bool
from src.loss import DistributedContrastiveLoss, SimpleContrastiveLoss
from src.model.projector import MultiHeadMLPProjector, save_projector_state_dict_artifacts


def parse_args():
    parser = argparse.ArgumentParser(description="Train low-dimensional projectors from cached VLM embeddings.")
    parser.add_argument("--cache_dir", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--head_dims", nargs="+", type=int, default=[64, 32, 16])
    parser.add_argument("--multi_head_weights", nargs="+", type=float, default=None)
    parser.add_argument("--hidden_dim", type=int, default=0)
    parser.add_argument("--mode", choices=["mlp", "linear"], default="mlp")
    parser.add_argument("--per_device_batch_size", type=int, default=32)
    parser.add_argument("--max_steps", type=int, default=4000)
    parser.add_argument("--save_steps", type=int, default=500)
    parser.add_argument("--logging_steps", type=int, default=10)
    parser.add_argument("--learning_rate", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=0.0)
    parser.add_argument("--warmup_steps", type=int, default=100)
    parser.add_argument("--temperature", type=float, default=0.02)
    parser.add_argument("--similarity_type", choices=["dense", "maxsim", "maxsim_topk", "slot_aligned"], default="dense")
    parser.add_argument("--maxsim_topk", type=int, default=4)
    parser.add_argument("--normalize_input", default="true")
    parser.add_argument("--normalize_output", default="true")
    parser.add_argument("--local_contrastive_loss", default="false")
    parser.add_argument("--match_cache_rank", default="true")
    parser.add_argument("--shuffle_files", default="true")
    parser.add_argument("--shuffle_samples", default="true")
    parser.add_argument("--orthogonal_loss", type=float, default=0.0)
    parser.add_argument("--orthogonal_margin", type=float, default=0.0)
    parser.add_argument("--orthogonal_base_dim", type=int, default=2048)
    parser.add_argument("--orthogonal_warmup_steps", type=int, default=0)
    parser.add_argument("--multi_head_orthogonal_weights", nargs="*", type=float, default=None)
    parser.add_argument("--save_multi_head_standalone_heads", default="true")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--resume_from", default=None)
    return parser.parse_args()


def init_distributed():
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    if world_size <= 1:
        return False, 0, 0, 1
    if not dist.is_initialized():
        dist.init_process_group(backend="nccl")
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    torch.cuda.set_device(local_rank)
    return True, local_rank, dist.get_rank(), dist.get_world_size()


def unwrap_projector(projector):
    return projector.module if isinstance(projector, DistributedDataParallel) else projector


def get_lr(step: int, base_lr: float, warmup_steps: int) -> float:
    if warmup_steps > 0 and step < warmup_steps:
        return base_lr * float(step + 1) / float(warmup_steps)
    return base_lr


def get_scale(step: int, warmup_steps: int) -> float:
    if warmup_steps > 0 and step < warmup_steps:
        return float(step + 1) / float(warmup_steps)
    return 1.0


def reduce_for_similarity(x: torch.Tensor, similarity_type: str) -> torch.Tensor:
    if similarity_type == "dense" and x.dim() == 3:
        return x.mean(dim=1)
    return x


def local_orthogonal_loss(x: torch.Tensor, margin: float = 0.0) -> torch.Tensor:
    if x.dim() == 2:
        x = x.unsqueeze(1)
    if x.dim() != 3 or x.shape[1] <= 1:
        return x.new_zeros(())
    x = F.normalize(x.float(), p=2, dim=-1)
    sim = (x @ x.transpose(-2, -1)).abs()
    sim = sim - torch.diag_embed(torch.diagonal(sim, dim1=-2, dim2=-1))
    t = x.shape[1]
    return (sim - margin).clamp_min(0).pow(2).sum(dim=(-1, -2)).div(t * (t - 1)).mean()


def projector_config_dict(projector: MultiHeadMLPProjector, args) -> Dict[str, object]:
    return {
        "pooling": "multi_head_mlp",
        "projector_type": "multi_head_mlp",
        "hidden_dim": int(projector.hidden_dim),
        "num_scales": int(projector.num_scales),
        "output_dims": {str(name): int(dim) for name, dim in projector.output_dims.items()},
        "hidden_dims": projector.hidden_dims,
        "mode": projector.mode,
        "input_normalize": parse_bool(args.normalize_input, True),
        "output_normalize": parse_bool(args.normalize_output, True),
    }


def save_checkpoint(projector, output_dir: str, args, step: int, final: bool = False):
    base_projector = unwrap_projector(projector)
    config = projector_config_dict(base_projector, args)
    save_dir = output_dir if final else os.path.join(output_dir, f"checkpoint-{step}")
    save_projector_state_dict_artifacts(base_projector.state_dict(), save_dir, config=config)

    if parse_bool(args.save_multi_head_standalone_heads, True):
        for head_name in base_projector.output_dims:
            state = {
                key: value
                for key, value in base_projector.state_dict().items()
                if key.startswith(f"heads.{head_name}.")
            }
            head_config = dict(config)
            head_config["output_dims"] = {str(head_name): int(base_projector.output_dims[head_name])}
            if head_config.get("hidden_dims"):
                head_config["hidden_dims"] = {str(head_name): int(head_config["hidden_dims"][head_name])}
            save_projector_state_dict_artifacts(
                state,
                os.path.join(save_dir, f"head_{head_name}"),
                config=head_config,
            )


def main():
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    is_dist, local_rank, rank, world_size = init_distributed()
    device = torch.device(f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu")
    is_master = rank == 0

    files = list_cache_files(
        args.cache_dir,
        rank=rank,
        world_size=world_size,
        match_cache_rank=parse_bool(args.match_cache_rank, True),
        shuffle_files=parse_bool(args.shuffle_files, True),
        seed=args.seed,
    )
    sample = load_cache_shard(files[0])
    inferred_hidden_dim = int(sample["qry"].shape[-1])
    hidden_dim = int(args.hidden_dim or inferred_hidden_dim)
    if hidden_dim != inferred_hidden_dim:
        raise ValueError(f"hidden_dim={hidden_dim} does not match cache dim={inferred_hidden_dim}")

    output_dims = {str(dim): int(dim) for dim in args.head_dims}
    projector = MultiHeadMLPProjector(hidden_dim=hidden_dim, output_dims=output_dims, mode=args.mode)
    if args.resume_from:
        state_path = args.resume_from
        if os.path.isdir(state_path):
            state_path = os.path.join(state_path, "projector.pth")
        projector.load_state_dict(torch.load(state_path, map_location="cpu"))
    projector.to(device)
    if is_dist:
        projector = DistributedDataParallel(projector, device_ids=[local_rank], output_device=local_rank)

    optimizer = torch.optim.AdamW(projector.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    use_dist_loss = is_dist and not parse_bool(args.local_contrastive_loss, False)
    loss_cls = DistributedContrastiveLoss if use_dist_loss else SimpleContrastiveLoss
    loss_fn = loss_cls(
        temperature=args.temperature,
        calc_metrics=True,
        similarity_type=args.similarity_type,
        maxsim_topk=args.maxsim_topk,
    )

    weights = args.multi_head_weights or [1.0] * len(args.head_dims)
    if len(weights) != len(args.head_dims):
        raise ValueError("--multi_head_weights length must match --head_dims")
    if args.multi_head_orthogonal_weights:
        orth_weights = args.multi_head_orthogonal_weights
    else:
        orth_weights = [
            args.orthogonal_loss * float(dim) / float(args.orthogonal_base_dim)
            for dim in args.head_dims
        ]
    if len(orth_weights) != len(args.head_dims):
        raise ValueError("--multi_head_orthogonal_weights length must match --head_dims")

    os.makedirs(args.output_dir, exist_ok=True)
    if is_master:
        train_config = vars(args).copy()
        train_config.update(
            {
                "world_size": world_size,
                "hidden_dim": hidden_dim,
                "token_count": int(sample["qry"].shape[1]) if sample["qry"].dim() == 3 else 1,
                "multi_head_orthogonal_weights_effective": orth_weights,
                "cache_file_count_this_rank": len(files),
            }
        )
        with open(os.path.join(args.output_dir, "train_config.json"), "w", encoding="utf-8") as f:
            json.dump(train_config, f, indent=2, sort_keys=True)
            f.write("\n")
        print(json.dumps({"event": "start", **train_config}, ensure_ascii=False))

    step = 0
    epoch = 0
    normalize_input = parse_bool(args.normalize_input, True)
    normalize_output = parse_bool(args.normalize_output, True)
    shuffle_samples = parse_bool(args.shuffle_samples, True)

    while step < args.max_steps:
        epoch += 1
        if parse_bool(args.shuffle_files, True):
            random.Random(args.seed + epoch + rank).shuffle(files)
        for path in files:
            shard = load_cache_shard(path)
            qry_cpu = shard["qry"]
            tgt_cpu = shard["tgt"]
            n = int(qry_cpu.shape[0])
            order = torch.randperm(n) if shuffle_samples else torch.arange(n)
            for start in range(0, n, args.per_device_batch_size):
                if step >= args.max_steps:
                    break
                idx = order[start : start + args.per_device_batch_size]
                if idx.numel() < max(5, args.per_device_batch_size):
                    continue

                qry = qry_cpu[idx].to(device=device, dtype=torch.float32, non_blocking=True)
                tgt = tgt_cpu[idx].to(device=device, dtype=torch.float32, non_blocking=True)
                if normalize_input:
                    qry = F.normalize(qry, p=2, dim=-1)
                    tgt = F.normalize(tgt, p=2, dim=-1)

                optimizer.zero_grad(set_to_none=True)
                qry_heads = projector(qry)
                tgt_heads = projector(tgt)

                total_loss = None
                orth_scale = get_scale(step, args.orthogonal_warmup_steps)
                log_row = {"step": step + 1, "epoch": epoch, "file": os.path.basename(path)}
                for dim, weight, orth_weight in zip(args.head_dims, weights, orth_weights):
                    name = str(dim)
                    qh = qry_heads[name]
                    th = tgt_heads[name]
                    if normalize_output:
                        qh = F.normalize(qh, p=2, dim=-1)
                        th = F.normalize(th, p=2, dim=-1)
                    loss_input_q = reduce_for_similarity(qh, args.similarity_type)
                    loss_input_t = reduce_for_similarity(th, args.similarity_type)
                    loss_out = loss_fn(loss_input_q, loss_input_t)
                    if isinstance(loss_out, tuple):
                        contrastive_loss, metrics = loss_out
                    else:
                        contrastive_loss, metrics = loss_out, {}
                    head_loss = contrastive_loss * float(weight)
                    if orth_weight:
                        orth_weight = float(orth_weight) * orth_scale
                        orth = (local_orthogonal_loss(qh, args.orthogonal_margin) + local_orthogonal_loss(th, args.orthogonal_margin)) / 2.0
                        head_loss = head_loss + orth * orth_weight
                        log_row[f"orth#{name}"] = float(orth.detach().cpu())
                        log_row[f"orth_weight#{name}"] = orth_weight
                    total_loss = head_loss if total_loss is None else total_loss + head_loss
                    log_row[f"loss#{name}"] = float(contrastive_loss.detach().cpu())
                    for k, v in (metrics or {}).items():
                        if isinstance(v, (int, float)):
                            log_row[f"{k}#{name}"] = float(v)

                total_loss.backward()
                lr = get_lr(step, args.learning_rate, args.warmup_steps)
                for group in optimizer.param_groups:
                    group["lr"] = lr
                optimizer.step()

                step += 1
                log_row["lr"] = lr
                log_row["total_loss"] = float(total_loss.detach().cpu())
                if is_master and (step == 1 or step % args.logging_steps == 0):
                    print(json.dumps(log_row, ensure_ascii=False), flush=True)
                if is_master and args.save_steps > 0 and step % args.save_steps == 0:
                    save_checkpoint(projector, args.output_dir, args, step)

            if step >= args.max_steps:
                break

        if not files:
            break

    if is_master:
        save_checkpoint(projector, args.output_dir, args, step, final=True)
    if is_dist:
        dist.barrier()
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
