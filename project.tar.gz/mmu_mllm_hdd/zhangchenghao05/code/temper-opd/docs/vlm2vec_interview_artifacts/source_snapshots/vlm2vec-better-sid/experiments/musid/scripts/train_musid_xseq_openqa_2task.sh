#!/bin/bash
set -euo pipefail
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
export MASTER_PORT="${MASTER_PORT:-2208}"
export RDZV_ID="${RDZV_ID:-musid_xseq_openqa_2task}"
export EXP_NAME="${EXP_NAME:-musid_xseq_openqa_2task}"
export TASK_TYPES="openqa xseq_openqa"
export DATASET_CONFIG="${DATASET_CONFIG:-$REPO_DIR/experiments/musid/yaml/musid_xseq_openqa_mix.yaml}"
export DATA_WEIGHTS="${DATA_WEIGHTS:-96 96}"
export LOSS_WEIGHTS="${LOSS_WEIGHTS:-0.5 0.5}"
export GRADIENT_ACCUMULATION_STEPS="${GRADIENT_ACCUMULATION_STEPS:-192}"
export ENABLE_GRAD_CACHE=false
export XSEQ_ARGS="${XSEQ_ARGS:---xseq_enable True --xseq_layers 16 18 20 22 --xseq_topk 4 --xseq_bank_size 2048 --xseq_min_bank_size 128 --xseq_same_cls_only True --xseq_sample_softmax True --xseq_sample_tau 0.07 --xseq_slot_softmax False --xseq_slot_tau 0.07 --xseq_slot_mean_preserve True --xseq_diag_batch_size 8 --xseq_diag_steps 20 --xseq_log_loss_delta True --xseq_log_slot_stats True}"
bash "$REPO_DIR/experiments/musid/scripts/train_musid_multitask.sh" "$@"
