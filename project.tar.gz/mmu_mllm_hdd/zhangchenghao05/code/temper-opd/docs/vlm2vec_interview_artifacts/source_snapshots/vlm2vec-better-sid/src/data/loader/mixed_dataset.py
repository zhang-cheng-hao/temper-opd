import torch
from typing import Dict, List
from torch.utils.data import IterableDataset, DataLoader
from datasets.distributed import split_dataset_by_node

from src.data.dataset.base_pair_dataset import AutoPairDataset
from src.data.dataset.base_qa_dataset import AutoQADataset
from src.data.dataset.hf_datasets import interleave_datasets
from src.utils import print_master


class MixedDataLoader:
    
    def __init__(
        self,
        datasets: Dict[str, IterableDataset],
        batch_sizes: List[int],
        weights: List[List[int]],
        data_collator=None,
        args=None,
    ):
        """
        weights 是一个最小周期，每个周期包含各个任务的权重
        """
        if isinstance(weights[0], int):
            weights = [[weight] for weight in weights]
        assert all(len(weights[0]) == len(weights[i]) for i in range(len(weights))), f"Weights must have the same length for each task: {weights}"
        assert len(datasets) == len(batch_sizes) == len(weights), "Datasets, batch_sizes and weights must have the same length."
        datasets, batch_sizes, weights = self._filter_datasets(datasets, batch_sizes, weights)
        self.dataloaders = {}
        for i, (dataset_name, dataset) in enumerate(datasets.items()):
            dataloader = self._get_dataloader(dataset=dataset,
                                              batch_size=batch_sizes[i],
                                              data_collator=data_collator,
                                              args=args)
            self.dataloaders[dataset_name] = dataloader

        self.iterators = {k: iter(dl) for k, dl in self.dataloaders.items()}
        self.dataset = list(datasets.values())
        self.sampler = None
        self.batch_sampler = None
            
        self.step = 0
        self.task_schedule = []
        for i in range(len(weights[0])):
            for task, weight in zip(datasets.keys(), weights):
                self.task_schedule.extend([task] * weight[i])
        print_master(f"Task schedule: {self.task_schedule}")

    def __iter__(self):
        # 保证多卡同步：所有进程 task 顺序一致
        while True:
            cur_task = self.task_schedule[self.step]
            self.step = (self.step + 1) % len(self.task_schedule)
            try:
                yield next(self.iterators[cur_task])
            except StopIteration:
                self.iterators[cur_task] = iter(self.dataloaders[cur_task])
                yield next(self.iterators[cur_task])
    
    def _filter_datasets(self, datasets, batch_sizes, weights):
        final_datasets = {}
        final_batch_sizes = []
        final_weights = []
        for i, (dataset_name, dataset) in enumerate(datasets.items()):
            if dataset is None or sum(weights[i]) == 0:
                print_master("*" * 50)
                print_master(f"Dataset [{dataset_name}] is ignored, skipping.")
                print_master("*" * 50)
                continue
            final_datasets[dataset_name] = dataset
            final_batch_sizes.append(batch_sizes[i])
            final_weights.append(weights[i])
        return final_datasets, final_batch_sizes, final_weights

    def _get_dataloader(self, dataset, batch_size, args, data_collator):
        """Get the train dataloader for the dataset."""
        assert isinstance(dataset, torch.utils.data.IterableDataset), f"{dataset} should be an IterableDataset, but got {type(dataset)}"
        dataloader_params = {
            "batch_size": batch_size,
            "collate_fn": data_collator,
            "num_workers": args.dataloader_num_workers,
            "pin_memory": args.dataloader_pin_memory,
            "persistent_workers": args.dataloader_persistent_workers,
        }

        dataloader_params["sampler"] = None
        dataloader_params["shuffle"] = False
        dataloader_params["drop_last"] = True
        dataloader_params["prefetch_factor"] = None # # tune on both prefetch_factor and persistent_workers will cause hang at epoch2
        return DataLoader(dataset, **dataloader_params)

    @property
    def only_openqa_data(self):
        # return "openqa" in self.dataloaders and "retrieval" not in self.dataloaders
        return False
    
    @property
    def only_retrv_data(self):
        # return "retrieval" in self.dataloaders and "openqa" not in self.dataloaders
        return False


def init_mixed_dataset(dataset_config, model_args, data_args, training_args, data_collator=None):

    task_types = training_args.task_types

    task_probs_lst = [_calculate_probabilities(dataset_config, task_type) for task_type in task_types]

    world_size = torch.distributed.get_world_size() if torch.distributed.is_initialized() else 1

    task_datasets_lst = [
        _create_datasets(
            dataset_config, 
            task_type, 
            model_args, 
            data_args, 
            training_args, 
            task_probs
        ) 
        for task_type, task_probs in zip(task_types, task_probs_lst)
    ]

    total_openqa_num_rows = 0 
    total_retrv_num_rows = 0
    batch_sizes = []
    for task_type, task_datasets in zip(task_types, task_datasets_lst):
        if "openqa" in task_type:
            total_openqa_num_rows += _validate_datasets(task_datasets, training_args.per_device_openqa_train_batch_size * world_size, 'openqa')
            batch_sizes.append(training_args.per_device_openqa_train_batch_size)
        elif "retrieval" in task_type:
            total_retrv_num_rows += _validate_datasets(task_datasets, training_args.per_device_retrv_train_batch_size * world_size, 'retrieval')
            batch_sizes.append(training_args.per_device_retrv_train_batch_size)
        else:
            print_master(f"Unknown task_type: [{task_type}]")
            batch_sizes.append(training_args.per_device_retrv_train_batch_size)

    data_weights_cycles = [
        [training_args.data_weights[j] for j in range(i, len(training_args.data_weights), len(task_types))]
        for i in range(len(task_types))
    ]

    retrv_weights = [
        data_weight
        for task_type, data_weights in zip(task_types, data_weights_cycles)
        if "retrieval" in task_type
        for data_weight in data_weights
    ]
    openqa_weights = [
        data_weight
        for task_type, data_weights in zip(task_types, data_weights_cycles)
        if "openqa" in task_type
        for data_weight in data_weights
    ]

    print_master(
        f"\nInitializing interleaved datasets:"
        f"\n\t\tworld_size={world_size}"
        f"\n\t\ttotal num rows: [retrieval={total_retrv_num_rows}] [openqa={total_openqa_num_rows}]"
        f"\n\t\tglobal batch size: [retrieval={training_args.per_device_retrv_train_batch_size * world_size}] [openqa={training_args.per_device_openqa_train_batch_size * world_size}]"
        f"\n\t\tmixing weights: [retrieval:openqa={sum(retrv_weights)}:{sum(openqa_weights)}]"
        # f"\n\t\testimated num step per epoch={estimated_steps:.2f}"
        # f"\n\t\tinterleave_batch_size={interleave_batch_size}"
    )

    interleave_batch_size = _get_interleave_batch_size(training_args, world_size)
    openqa_interleave_batch_size = _get_interleave_batch_size(training_args, world_size, is_openqa=True)
    train_datasets = [
        _create_interleaved_dataset(
            task_datasets, 
            task_probs, 
            openqa_interleave_batch_size if 'openqa' in task_type else interleave_batch_size, 
            training_args
        )
        for task_type, task_probs, task_datasets in zip(task_types, task_probs_lst, task_datasets_lst)
    ]
    
    if torch.distributed.is_initialized():
        train_datasets = [
            split_dataset_by_node(train_dataset, rank=torch.distributed.get_rank(), world_size=world_size)
            if train_dataset is not None else None
            for train_dataset in train_datasets
        ]

    train_dataloader = MixedDataLoader(
        datasets={
            task_type: train_dataset
            for task_type, train_dataset in zip(task_types, train_datasets)
        }, 
        weights=data_weights_cycles, 
        batch_sizes=batch_sizes,
        data_collator=data_collator, args=training_args)  # retrieval first
    return train_dataloader


def _calculate_probabilities(dataset_config, task_type):
        """Calculate probabilities for datasets of a specific task type."""
        weights = [d['weight'] for d in dataset_config.values() if d.get('task_type', 'retrieval') == task_type]
        weight_sum = sum(weights)
        return [w / weight_sum for w in weights] if weight_sum > 0 else []


def _create_datasets(dataset_config, task_type, model_args, data_args, training_args, probs):
    """Create datasets for a specific task type."""
    datasets = []
    dataset_idx = 0
    print_master(f"=========== Create {task_type.upper()} datasets ===========")
    for data_idx, (global_dataset_name, config) in enumerate(dataset_config.items()):
        if config.get('task_type', 'retrieval') != task_type:
            continue
            
        if 'retrieval' in task_type:
            dataset = AutoPairDataset.instantiate(model_args=model_args, data_args=data_args, training_args=training_args, **config)
        elif 'openqa' in task_type:
            dataset = AutoQADataset.instantiate(model_args=model_args, data_args=data_args, training_args=training_args, **config)
        else:
            raise ValueError(f"Unsupported task type: {task_type}")
            
        datasets.append(dataset)
        print_master(
            f"\t\tDataset#{data_idx} (dataset_parser={config.get('dataset_parser', 'n/a')}): "
            f"{global_dataset_name}, task_type={task_type}, num_rows={dataset.num_rows}, "
            f"prob={probs[dataset_idx] * 100.0:.2f}%"
        )
        dataset_idx += 1
    print_master(f"Total {len(datasets)} {task_type.upper()} datasets created.")
    
    return datasets


def _get_interleave_batch_size(training_args, world_size, is_openqa=False):
    """Calculate interleave batch size."""
    if is_openqa:
        if training_args.qa_interleave_batch_size and training_args.qa_interleave_batch_size <= 1.0:
            return int(training_args.per_device_openqa_train_batch_size * world_size * training_args.qa_interleave_batch_size)
        return training_args.qa_interleave_batch_size
    
    if training_args.interleave_batch_size and training_args.interleave_batch_size <= 1.0:
        return int(training_args.per_device_retrv_train_batch_size * world_size * training_args.interleave_batch_size)
    return training_args.interleave_batch_size


def _validate_datasets(datasets, global_batch_size, task_type):
    """Validate that datasets have sufficient rows."""
    total_rows = sum(d.num_rows for d in datasets)
    if total_rows == 0:
        return total_rows

    assert total_rows >= global_batch_size, (
        f"total_num_rows(={total_rows}) for {task_type} must be >= global batch size "
        f"(={global_batch_size}), since the last batch will be dropped."
    )
    return total_rows


def _create_interleaved_dataset(datasets, probs, batch_size, training_args):
    """Create interleaved dataset if multiple datasets exist."""
    if len(datasets) > 1:
        return interleave_datasets(
            datasets, probabilities=probs, batch_size=batch_size,
            seed=training_args.seed, stopping_strategy=training_args.interleave_stopping_strategy
        )
    return datasets[0] if datasets else None
