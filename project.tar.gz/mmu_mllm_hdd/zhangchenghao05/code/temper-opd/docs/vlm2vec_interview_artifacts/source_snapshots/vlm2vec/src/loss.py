from torch import Tensor
import torch.distributed as dist
import torch
import torch.nn.functional as F


def _ensure_token_axis(x: Tensor) -> Tensor:
    if x is None:
        return None
    if x.dim() == 2:
        return x.unsqueeze(1)
    return x


def _dense_logits(x: Tensor, y: Tensor) -> Tensor:
    return torch.matmul(x, y.transpose(0, 1))


def _reduce_pairwise_topk(scores: Tensor, topk: int) -> Tensor:
    flat_scores = scores.flatten(start_dim=-2)
    if flat_scores.shape[-1] == 0:
        raise ValueError(f"Expected non-empty token axis, got {tuple(scores.shape)}")
    k = min(max(int(topk), 1), flat_scores.shape[-1])
    if k == 1:
        return flat_scores.amax(dim=-1)
    return flat_scores.topk(k=k, dim=-1).values.mean(dim=-1)


def _maxsim_logits(x: Tensor, y: Tensor) -> Tensor:
    x = _ensure_token_axis(x)
    y = _ensure_token_axis(y)
    return _reduce_pairwise_topk(torch.einsum("btd,nsd->bnts", x, y), topk=1)


def _maxsim_topk_logits(x: Tensor, y: Tensor, topk: int) -> Tensor:
    x = _ensure_token_axis(x)
    y = _ensure_token_axis(y)
    return _reduce_pairwise_topk(torch.einsum("btd,nsd->bnts", x, y), topk=topk)


def _slot_aligned_logits(x: Tensor, y: Tensor) -> Tensor:
    x = _ensure_token_axis(x)
    y = _ensure_token_axis(y)
    if x.shape[1] != y.shape[1]:
        raise ValueError(f"slot_aligned expects same slot count, got {tuple(x.shape)} vs {tuple(y.shape)}")
    return torch.einsum("bsd,nsd->bns", x, y).mean(dim=-1)


def _dense_neg_logits(x: Tensor, neg: Tensor) -> Tensor:
    return (x * neg).sum(-1, keepdim=True)


def _maxsim_neg_logits(x: Tensor, neg: Tensor) -> Tensor:
    x = _ensure_token_axis(x)
    neg = _ensure_token_axis(neg)
    return _reduce_pairwise_topk(torch.einsum("btd,bsd->bts", x, neg), topk=1).unsqueeze(-1)


def _maxsim_topk_neg_logits(x: Tensor, neg: Tensor, topk: int) -> Tensor:
    x = _ensure_token_axis(x)
    neg = _ensure_token_axis(neg)
    return _reduce_pairwise_topk(torch.einsum("btd,bsd->bts", x, neg), topk=topk).unsqueeze(-1)


def _slot_aligned_neg_logits(x: Tensor, neg: Tensor) -> Tensor:
    x = _ensure_token_axis(x)
    neg = _ensure_token_axis(neg)
    if x.shape[1] != neg.shape[1]:
        raise ValueError(f"slot_aligned expects same slot count, got {tuple(x.shape)} vs {tuple(neg.shape)}")
    return torch.einsum("bsd,bsd->bs", x, neg).mean(dim=-1, keepdim=True)

def compute_accuracy(scores, target, topk=(1, 3, 5)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        # Get the indices of the top k predictions
        _, pred = scores.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = {}
        for k in topk:
            correct_k = correct[:k].reshape(-1).float().sum(0, keepdim=True)
            res[f'Acc@{k}'] = correct_k.mul_(100.0 / batch_size).item()
            # res.append(correct_k.mul_(100.0 / batch_size))

        return res


def _slot_pair_stats(x: Tensor) -> dict[str, float]:
    x = _ensure_token_axis(x)
    if x is None or x.dim() != 3 or x.shape[1] <= 1:
        return {
            "offdiag_cos_abs_mean": 0.0,
            "offdiag_cos_abs_max": 0.0,
        }

    x_norm = F.normalize(x.float(), p=2, dim=-1)
    sim = x_norm @ x_norm.transpose(-2, -1)
    sim_abs = sim.abs()
    sim_abs = sim_abs - torch.diag_embed(torch.diagonal(sim_abs, dim1=-2, dim2=-1))
    t = x.shape[1]
    denom = max(t * (t - 1), 1)
    offdiag_abs_mean = (sim_abs.sum(dim=(-1, -2)) / denom).mean().item()
    offdiag_abs_max = sim_abs.amax(dim=(-1, -2)).mean().item()
    return {
        "offdiag_cos_abs_mean": offdiag_abs_mean,
        "offdiag_cos_abs_max": offdiag_abs_max,
    }


def _centered_linear_hsic(x: Tensor, y: Tensor) -> Tensor:
    x = x.float() - x.float().mean(dim=0, keepdim=True)
    y = y.float() - y.float().mean(dim=0, keepdim=True)
    n = x.shape[0]
    if n <= 1:
        return x.new_zeros(())
    cov = x.transpose(0, 1) @ y
    return cov.pow(2).sum() / float((n - 1) ** 2)


def _infer_collective_device(x: Tensor) -> torch.device:
    if isinstance(x, torch.Tensor):
        return x.device
    if torch.cuda.is_available():
        return torch.device("cuda", torch.cuda.current_device())
    return torch.device("cpu")


def _gather_variable_batch_tensor(x: Tensor) -> Tensor:
    x = _ensure_token_axis(x)
    if not dist.is_initialized():
        return x

    device = _infer_collective_device(x)
    if x is None:
        local_shape = torch.zeros(3, device=device, dtype=torch.long)
        dtype = torch.float32
    else:
        if x.dim() != 3:
            raise ValueError(f"Expected x dim in {{2,3}}, got {tuple(x.shape)}")
        local_shape = torch.tensor(list(x.shape), device=x.device, dtype=torch.long)
        dtype = x.dtype

    gathered_shapes = [torch.zeros_like(local_shape) for _ in range(dist.get_world_size())]
    dist.all_gather(gathered_shapes, local_shape)
    gathered_shapes = torch.stack(gathered_shapes, dim=0)

    total_batch = int(gathered_shapes[:, 0].sum().item())
    if total_batch == 0:
        return None

    slot_count = int(gathered_shapes[:, 1].max().item())
    hidden_size = int(gathered_shapes[:, 2].max().item())
    if slot_count <= 0 or hidden_size <= 0:
        return None

    if x is not None and x.shape[1:] != (slot_count, hidden_size):
        raise ValueError(
            f"All gathered token tensors must share slot/hidden dims, got local {tuple(x.shape)} "
            f"vs global slot={slot_count}, hidden={hidden_size}"
        )

    max_local_batch = int(gathered_shapes[:, 0].max().item())
    padded = torch.zeros((max_local_batch, slot_count, hidden_size), device=device, dtype=dtype)
    if x is not None and x.shape[0] > 0:
        padded[: x.shape[0]] = x

    gathered = [torch.empty_like(padded) for _ in range(dist.get_world_size())]
    dist.all_gather(gathered, padded)
    if x is not None:
        gathered[dist.get_rank()][: x.shape[0]] = x

    parts = []
    for gathered_tensor, shape in zip(gathered, gathered_shapes):
        local_batch = int(shape[0].item())
        if local_batch > 0:
            parts.append(gathered_tensor[:local_batch])
    return torch.cat(parts, dim=0) if parts else None


def _global_slot_hsic(x: Tensor, batch_chunk_size: int = 256) -> Tensor:
    x = _ensure_token_axis(x)
    if x is None or x.dim() != 3:
        device = x.device if isinstance(x, torch.Tensor) else None
        return torch.zeros((), device=device, dtype=torch.float32)

    x = x.float()
    batch_size, slot_count, _ = x.shape
    if batch_size <= 1 or slot_count <= 1:
        return x.new_zeros(())

    x = x - x.mean(dim=0, keepdim=True)
    slots = x.permute(1, 0, 2).contiguous()
    chunk_size = max(int(batch_chunk_size), 1)
    pairwise_hsic = torch.zeros((slot_count, slot_count), device=x.device, dtype=torch.float32)

    for start in range(0, batch_size, chunk_size):
        end = min(start + chunk_size, batch_size)
        slot_chunk = slots[:, start:end, :]
        gram_rows = torch.einsum("tcd,tbd->tcb", slot_chunk, slots)
        pairwise_hsic = pairwise_hsic + torch.einsum("tcb,scb->ts", gram_rows, gram_rows)

    pairwise_hsic = pairwise_hsic / float((batch_size - 1) ** 2)
    offdiag_mask = ~torch.eye(slot_count, device=x.device, dtype=torch.bool)
    return pairwise_hsic.masked_select(offdiag_mask).mean()


def compute_slot_hsic_metrics(x: Tensor) -> dict[str, float]:
    x = _ensure_token_axis(x)
    if x is None or x.dim() != 3 or x.shape[1] <= 1:
        stats = _slot_pair_stats(x)
        return {
            "hsic_mean": 0.0,
            **stats,
        }

    hsic_mean = _global_slot_hsic(x).item()
    stats = _slot_pair_stats(x)
    return {
        "hsic_mean": hsic_mean,
        **stats,
    }


@torch.no_grad()
def calc_false_neg_mask(logits, target, threshold=0.1):
    pos_scores = torch.gather(logits, 1, target.unsqueeze(1))
    mask = logits > (pos_scores + threshold)
    mask[torch.arange(logits.shape[0]), target] = False

    return mask

def test_mask_false_neg():
    logits = torch.tensor(
        [
            [0.80, 0.91, 0.00], 
            [0.80, 0.81, 0.91], 
            [0.10, 0.90, 0.90]
        ])
    target = torch.tensor([0, 0, 0], dtype=torch.long)
    mask = calc_false_neg_mask(logits, target, threshold=0.1)
    assert mask.tolist() == [
        [False, True, False],
        [False, False, True],
        [False, True, True],
    ], mask
    print("Test passed", mask)

class SimpleContrastiveLoss:
    def __init__(
        self, 
        temperature: float = 0.02, 
        is_symmetric: bool = False, 
        calc_metrics: bool = False,
        matryoshkas: list[int] = [],
        should_mask_false_neg: bool = False,
        normalize_in_loss: bool = False,
        similarity_type: str = "dense",
        maxsim_topk: int = 4,
    ):
        self.temperature = temperature
        self.is_symmetric = is_symmetric
        self.calc_metrics = calc_metrics
        self.matryoshkas = matryoshkas
        self.should_mask_false_neg = should_mask_false_neg
        self.normalize_in_loss = normalize_in_loss
        self.similarity_type = similarity_type
        self.maxsim_topk = maxsim_topk

    def _compute_logits(self, x: Tensor, y: Tensor, neg: Tensor = None) -> Tensor:
        if self.normalize_in_loss:
            x = F.normalize(x, p=2, dim=-1)
            y = F.normalize(y, p=2, dim=-1)
            if neg is not None:
                neg = F.normalize(neg, p=2, dim=-1)

        if self.similarity_type in {"maxsim", "maxsim_topk", "slot_aligned"}:
            if self.similarity_type == "maxsim_topk":
                logits = _maxsim_topk_logits(x, y, topk=self.maxsim_topk) / self.temperature
            elif self.similarity_type == "slot_aligned":
                logits = _slot_aligned_logits(x, y) / self.temperature
            else:
                logits = _maxsim_logits(x, y) / self.temperature
            if neg is not None:
                assert not self.is_symmetric
                if self.similarity_type == "maxsim_topk":
                    neg_logits = _maxsim_topk_neg_logits(x, neg, topk=self.maxsim_topk) / self.temperature
                elif self.similarity_type == "slot_aligned":
                    neg_logits = _slot_aligned_neg_logits(x, neg) / self.temperature
                else:
                    neg_logits = _maxsim_neg_logits(x, neg) / self.temperature
                logits = torch.cat([logits, neg_logits], dim=-1)
            return logits

        logits = _dense_logits(x, y) / self.temperature
        if neg is not None:
            assert not self.is_symmetric
            neg_logits = _dense_neg_logits(x, neg) / self.temperature
            logits = torch.cat([logits, neg_logits], dim=-1)
        return logits

    def __call__(self, x: Tensor, y: Tensor, neg: Tensor = None, target: Tensor = None, reduction: str = 'mean') -> Tensor:
        if target is None:
            target_per_qry = y.size(0) // x.size(0)
            target = torch.arange(
                0, x.size(0) * target_per_qry, target_per_qry, device=x.device, dtype=torch.long)

        logits = self._compute_logits(x, y, neg=neg)

        mask = calc_false_neg_mask(logits, target)

        # 先算指标，否则算 loss 的时候可能因为 mask 会更改 logits
        if self.calc_metrics:
            with torch.no_grad():
                metrics = compute_accuracy(logits, target)

            is_false_neg = mask.detach().cpu()
            metrics.update({
                "false_neg_rate": (100.0 * is_false_neg.sum() / is_false_neg.numel()).item(), 
            })
        else:
            metrics = None

        # 将分数比 target 高的 mask 掉
        if self.should_mask_false_neg:
            logits[mask] = -float('inf')
            
        if self.is_symmetric:
            # CLIP-style symmetric loss
            loss_i2t = F.cross_entropy(logits, target, reduction=reduction)
            loss_t2i = F.cross_entropy(logits.transpose(0, 1), target, reduction=reduction)
            loss = (loss_i2t + loss_t2i) / 2.0
        else:
            # Standard one-directional loss
            loss = F.cross_entropy(logits, target, reduction=reduction)
        

        for dim in self.matryoshkas:
            if dim == x.shape[-1]:
                continue
            x1 = x[..., :dim]
            y1 = y[..., :dim]
            neg1 = neg[..., :dim] if neg is not None else None
            logits1 = self._compute_logits(x1, y1, neg=neg1)
            
            mask1 = calc_false_neg_mask(logits1, target)

            if self.calc_metrics:
                with torch.no_grad():
                    metrics1 = compute_accuracy(logits1, target)
                metrics.update({f"{k}#{dim}": v for k, v in metrics1.items()})

                is_false_neg1 = mask1.detach().cpu()
                metrics.update({
                    f"false_neg_rate#{dim}": (100.0 * is_false_neg1.sum() / is_false_neg1.numel()).item(), 
                })

            if self.should_mask_false_neg:
                logits1[mask1] = -float('inf')
                
            if self.is_symmetric:
                # CLIP-style symmetric loss
                loss_i2t1 = F.cross_entropy(logits1, target, reduction=reduction)
                loss_t2i1 = F.cross_entropy(logits1.transpose(0, 1), target, reduction=reduction)
                loss1 = (loss_i2t1 + loss_t2i1) / 2.0
            else:
                # Standard one-directional loss
                loss1 = F.cross_entropy(logits1, target, reduction=reduction)
            loss += loss1
            if metrics is not None:
                metrics.update({f"loss#{dim}": loss1.item()})

        if metrics is not None:
            return loss, metrics
        return loss
        # return loss, metrics if metrics is not None else loss 


class DistributedContrastiveLoss(SimpleContrastiveLoss):
    def __init__(
        self, 
        n_target: int = 0, 
        scale_loss: bool = True, 
        temperature: float = 0.02, 
        is_symmetric: bool = False, 
        calc_metrics: bool = False,
        matryoshkas: list[int] = [],
        should_mask_false_neg: bool=False,
        normalize_in_loss: bool = False,
        similarity_type: str = "dense",
        maxsim_topk: int = 4,
    ):
        assert dist.is_initialized(), "Distributed training has not been properly initialized."
        super().__init__(
            temperature=temperature, 
            is_symmetric=is_symmetric, 
            calc_metrics=calc_metrics, 
            matryoshkas=matryoshkas, 
            should_mask_false_neg=should_mask_false_neg,
            normalize_in_loss=normalize_in_loss,
            similarity_type=similarity_type,
            maxsim_topk=maxsim_topk,
        )
        self.world_size = dist.get_world_size()
        self.rank = dist.get_rank()
        self.scale_loss = scale_loss

    def __call__(self, x: Tensor, y: Tensor, neg: Tensor = None, **kwargs):
        dist_x = self.gather_tensor(x)
        dist_y = self.gather_tensor(y)
        dist_neg = self.gather_tensor(neg)
        loss = super().__call__(dist_x, dist_y, dist_neg, **kwargs)
        if type(loss) == tuple:
            loss, metrics = loss
        else:
            metrics = None
        if self.scale_loss:
            loss = loss * self.world_size
        return loss, metrics

    def gather_tensor(self, t):
        if t is None:
            return None
        gathered = [torch.empty_like(t) for _ in range(self.world_size)]
        dist.all_gather(gathered, t)
        gathered[self.rank] = t
        return torch.cat(gathered, dim=0)


class DistributedOrthogonalLoss:
    def __init__(self, loss_weights: float = 1.0, scale_loss: bool = True, margin: float = 0.1):
        assert dist.is_initialized(), "Distributed training has not been properly initialized."
        self.loss_weights = loss_weights
        self.scale_loss = scale_loss
        self.margin = margin
        self.world_size = dist.get_world_size()

    def __call__(self, *args, **kwargs):
        use_abs = bool(kwargs.get("use_abs", True))
        # Default to no all_reduce to avoid mismatched collectives across ranks.
        sync_loss = bool(kwargs.get("sync_loss", False))
        return_raw = bool(kwargs.get("return_raw", False))
        if not args:
            args = (None,)

        # 先计算本地 loss，再决定是否做一次同步。
        losses = [self.reduce_orth_loss(x, use_abs=use_abs) for x in args]
        valid_count = sum(x is not None for x in args)
        if valid_count == 0:
            loss = losses[0]
        else:
            loss = torch.stack(losses).sum() / valid_count

        if sync_loss:
            dist.all_reduce(loss, op=dist.ReduceOp.SUM)
            loss = loss / self.world_size

        raw_loss = loss
        if self.scale_loss:
            loss = loss * self.world_size
        weighted_loss = loss * self.loss_weights
        if return_raw:
            return weighted_loss, raw_loss.detach()
        return weighted_loss

    def reduce_orth_loss(self, x: Tensor, **kwargs):
        use_abs = bool(kwargs.get("use_abs", True))

        device = None
        if x is not None:
            device = x.device
        elif torch.cuda.is_available():
            device = torch.device("cuda", torch.cuda.current_device())
        else:
            device = torch.device("cpu")

        # 用 0 标量占位，x 为 None 或 T<=1 时也能进入 all_reduce。
        loss = torch.zeros((), device=device, dtype=torch.float32)

        if x is not None:
            if x.dim() == 2:
                x = x.unsqueeze(0)  # (1, T, D)
            if x.dim() != 3:
                raise ValueError(f"Expected x dim in {{2,3}}, got {tuple(x.shape)}")

            _, T, _ = x.shape
            if T > 1:
                x = F.normalize(x, p=2, dim=-1)
                sim = x @ x.transpose(-2, -1)  # (B, T, T)
                if use_abs:
                    sim = sim.abs()

                # 去掉对角（不靠 masked_select）
                sim = sim - torch.diag_embed(torch.diagonal(sim, dim1=-2, dim2=-1))

                loss = (sim - self.margin).clamp_min(0).pow(2)
                loss = loss.sum(dim=(-1, -2)) / (T * (T - 1))  # 只对 off-diag 做平均
                loss = loss.mean()
                loss = loss.float()

        return loss


class DistributedHSICLoss:
    def __init__(
        self,
        loss_weights: float = 1.0,
        scale_loss: bool = True,
        global_batch: bool = True,
        batch_chunk_size: int = 256,
    ):
        assert dist.is_initialized(), "Distributed training has not been properly initialized."
        self.loss_weights = loss_weights
        self.scale_loss = scale_loss
        self.global_batch = global_batch
        self.batch_chunk_size = batch_chunk_size
        self.world_size = dist.get_world_size()

    def __call__(self, *args, **kwargs):
        sync_loss = bool(kwargs.get("sync_loss", False))
        return_raw = bool(kwargs.get("return_raw", False))
        if not args:
            args = (None,)

        losses = [self.reduce_hsic_loss(x) for x in args]
        valid_count = sum(x is not None for x in args)
        if valid_count == 0:
            loss = losses[0]
        else:
            loss = torch.stack(losses).sum() / valid_count

        if sync_loss:
            dist.all_reduce(loss, op=dist.ReduceOp.SUM)
            loss = loss / self.world_size

        raw_loss = loss
        if self.scale_loss:
            loss = loss * self.world_size
        weighted_loss = loss * self.loss_weights
        if return_raw:
            return weighted_loss, raw_loss.detach()
        return weighted_loss

    def reduce_hsic_loss(self, x: Tensor):
        device = None
        if x is not None:
            device = x.device
        elif torch.cuda.is_available():
            device = torch.device("cuda", torch.cuda.current_device())
        else:
            device = torch.device("cpu")

        loss = torch.zeros((), device=device, dtype=torch.float32)
        x = _ensure_token_axis(x)
        if x is None or x.dim() != 3:
            return loss

        if self.global_batch:
            x = _gather_variable_batch_tensor(x)
            if x is None:
                return loss

        return _global_slot_hsic(x, batch_chunk_size=self.batch_chunk_size).to(device=device, dtype=torch.float32)


class DistributedVolumeLoss:
    def __init__(
        self,
        loss_weights: float = 1.0,
        scale_loss: bool = True,
        std_threshold: float = 1.0,
        std_weight: float = 1.0,
        eps: float = 1e-4,
    ):
        assert dist.is_initialized(), "Distributed training has not been properly initialized."
        self.loss_weights = loss_weights
        self.scale_loss = scale_loss
        self.std_threshold = std_threshold
        self.std_weight = std_weight
        self.eps = eps
        self.world_size = dist.get_world_size()

    def __call__(self, *args, **kwargs):
        sync_loss = bool(kwargs.get("sync_loss", False))
        return_raw = bool(kwargs.get("return_raw", False))
        if not args:
            args = (None,)

        components = [self.reduce_volume_loss(x) for x in args]
        valid_count = sum(x is not None for x in args)
        if valid_count == 0:
            total_loss, std_loss, vol_loss = components[0]
        else:
            total_loss = torch.stack([item[0] for item in components]).sum() / valid_count
            std_loss = torch.stack([item[1] for item in components]).sum() / valid_count
            vol_loss = torch.stack([item[2] for item in components]).sum() / valid_count

        if sync_loss:
            dist.all_reduce(total_loss, op=dist.ReduceOp.SUM)
            dist.all_reduce(std_loss, op=dist.ReduceOp.SUM)
            dist.all_reduce(vol_loss, op=dist.ReduceOp.SUM)
            total_loss = total_loss / self.world_size
            std_loss = std_loss / self.world_size
            vol_loss = vol_loss / self.world_size

        raw_total_loss = total_loss
        raw_std_loss = std_loss
        raw_vol_loss = vol_loss
        if self.scale_loss:
            total_loss = total_loss * self.world_size
        weighted_loss = total_loss * self.loss_weights
        if return_raw:
            return weighted_loss, {
                "volume_loss": raw_total_loss.detach(),
                "volume_std_loss": raw_std_loss.detach(),
                "volume_logdet_loss": raw_vol_loss.detach(),
            }
        return weighted_loss

    def reduce_volume_loss(self, x: Tensor):
        device = None
        if x is not None:
            device = x.device
        elif torch.cuda.is_available():
            device = torch.device("cuda", torch.cuda.current_device())
        else:
            device = torch.device("cpu")

        total_loss = torch.zeros((), device=device, dtype=torch.float32)
        std_loss = torch.zeros((), device=device, dtype=torch.float32)
        vol_loss = torch.zeros((), device=device, dtype=torch.float32)

        if x is not None:
            if x.dim() == 2:
                x = x.unsqueeze(0)
            if x.dim() != 3:
                raise ValueError(f"Expected x dim in {{2,3}}, got {tuple(x.shape)}")

            _, token_count, _ = x.shape
            if token_count > 0:
                x = x.float()
                token_std = torch.sqrt(x.var(dim=-1, unbiased=False) + 1e-6)
                std_loss = F.relu(self.std_threshold - token_std).mean().float()

                x_norm = F.normalize(x, p=2, dim=-1)
                gram = x_norm @ x_norm.transpose(-2, -1)
                eye = torch.eye(token_count, device=x.device, dtype=x.dtype).unsqueeze(0)
                reg_gram = gram + self.eps * eye
                sign, logdet = torch.linalg.slogdet(reg_gram)
                logdet = torch.where(sign > 0, logdet, torch.zeros_like(logdet))
                vol_loss = (-logdet).mean().float()
                total_loss = vol_loss + self.std_weight * std_loss

        return total_loss, std_loss, vol_loss


class SimpleSigmoidLoss:
    def __init__(self, temperature: float = 0.02, bias: float = 0.0):
        self.temperature = temperature
        self.bias = bias

    def __call__(self, x: Tensor, y: Tensor, target: Tensor = None, reduction: str = 'mean') -> Tensor:
        if target is None:
            target_per_qry = y.size(0) // x.size(0)
            target = torch.arange(
                0, x.size(0) * target_per_qry, target_per_qry, device=x.device, dtype=torch.long)
        # Compute similarity matrix
        logits = torch.matmul(x, y.transpose(0, 1)) / self.temperature + self.bias
        # Create labels for positive pairs
        batch_size = logits.size(0)
        labels = torch.zeros_like(logits)
        labels[torch.arange(batch_size), target] = 1.0
        # SigLIP loss: sigmoid loss on all pairs
        loss = -labels * F.logsigmoid(logits) - (1 - labels) * F.logsigmoid(-logits)
        if reduction == 'mean':
            return loss.mean()
        elif reduction == 'sum':
            return loss.sum()
        else:
            return loss


class DistributedSigmoidLoss(SimpleSigmoidLoss):
    def __init__(self, scale_loss: bool = True, temperature: float = 0.02, bias: float = 0.0):
        assert dist.is_initialized(), "Distributed training has not been properly initialized."
        super().__init__(temperature, bias)
        self.world_size = dist.get_world_size()
        self.rank = dist.get_rank()
        self.scale_loss = scale_loss
    
    def __call__(self, x: Tensor, y: Tensor, target: Tensor = None, reduction: str = 'mean') -> Tensor:
        # Gather tensors from all processes
        dist_x = self.gather_tensor(x)
        dist_y = self.gather_tensor(y)
        # Use parent class implementation
        loss = super().__call__(dist_x, dist_y, target, reduction)
        if self.scale_loss and reduction in ['mean', 'sum']:
            loss = loss * self.world_size
        return loss
    
    def gather_tensor(self, t):
        gathered = [torch.empty_like(t) for _ in range(self.world_size)]
        dist.all_gather(gathered, t)
        gathered[self.rank] = t
        return torch.cat(gathered, dim=0)

class InExampleContrastiveLoss:
    """
    Categorization loss: cross_entropy of 1 out of K classes (target labels)
    x.shape=[bsz, hdim], y.shape=[bsz, num_label, hdim]
    """

    def __init__(self, n_hard_negatives: int = 0, temperature: float = 1.0, ndim: int = None, *args, **kwargs):
        self.target_per_qry = n_hard_negatives + 1
        self.temperature = temperature
        self.ndim = ndim

    def __call__(self, x: Tensor, y: Tensor, reduction: str = 'mean'):
        # print("gather InExampleContrastiveLoss")
        if torch.distributed.is_initialized():
            x = dist_utils.dist_gather(x)
            y = dist_utils.dist_gather(y)
        bsz, ndim = x.size(0), x.size(1)
        target = torch.zeros(bsz, dtype=torch.long, device=x.device)
        if self.ndim:
            ndim = self.ndim
            x = x[:, :ndim]
            y = y[:, :ndim]
        logits = torch.einsum('bod,bsd->bs', x.view(bsz, 1, ndim), y.view(bsz, -1, ndim)) * self.temperature
        preds = torch.argmax(logits, dim=-1)
        loss = F.cross_entropy(logits, target, reduction=reduction)
        loss_detail = {"logits": logits, "labels": target, "preds": preds}
        return loss, loss_detail


class DistributedDistillationLoss:
    """
    从 nat (teacher) 到 comp (student) 的 KL 散度蒸馏损失。
    只在答案段进行蒸馏，使用 labels mask 对齐。
    """
    def __init__(
        self,
        temperature: float = 2.0,
        warmup_steps: int = 1000,
    ):
        self.temperature = temperature
        self.warmup_steps = warmup_steps
        self.current_step = 0

    def update_step(self, step: int):
        """更新当前步数，用于 warmup"""
        self.current_step = step

    def get_lambda(self) -> float:
        """获取当前 lambda（warmup 系数）"""
        if self.current_step >= self.warmup_steps:
            return 1.0
        return self.current_step / self.warmup_steps

    def __call__(
        self,
        student_logits: torch.Tensor,  # [B, L, V]
        teacher_logits: torch.Tensor,  # [B, L, V]
        labels: torch.Tensor,          # [B, L]
    ) -> tuple:
        """
        Args:
            student_logits: comp 模式的 logits
            teacher_logits: nat 模式的 logits (detach)
            labels: 标签，非 -100 位置为答案段
        Returns:
            loss_kl: 蒸馏损失
            lambda_kl: 当前 warmup 系数（用于 logging）
        """
        # 构造答案 mask
        answer_mask = (labels != -100)  # [B, L]

        # 边界检查：无答案 token 时返回零损失
        if not answer_mask.any():
            device = student_logits.device
            return torch.tensor(0.0, device=device), self.get_lambda()

        # 只在答案位置提取 logits
        student_ans_logits = student_logits[answer_mask]  # [N, V]
        teacher_ans_logits = teacher_logits[answer_mask]  # [N, V]

        # 计算温度缩放的 KL 散度
        T = self.temperature
        p_teacher = F.softmax(teacher_ans_logits / T, dim=-1)
        log_p_student = F.log_softmax(student_ans_logits / T, dim=-1)

        kl_div = F.kl_div(log_p_student, p_teacher, reduction='batchmean')
        loss_kl = kl_div * (T * T)  # T^2 缩放

        # 应用 warmup lambda
        lambda_kl = self.get_lambda()
        loss_kl = loss_kl * lambda_kl

        return loss_kl, lambda_kl


if __name__ == "__main__":
    test_mask_false_neg()
