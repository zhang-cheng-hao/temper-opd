import collections
from collections import defaultdict
import contextlib
import functools
import shutil
import sys
import time
from datetime import timedelta

from packaging import version
from accelerate import skip_first_batches, DistributedType, InitProcessGroupKwargs
from transformers import PretrainedConfig, TrainerCallback
from transformers.trainer import Trainer, TRAINING_ARGS_NAME, TRAINER_STATE_NAME
import torch.distributed as dist
from typing import Optional
import os
import torch
import math
try:
    import wandb
except ImportError:
    wandb = None

from src.data.collator.train_collator import split_vlm_inputs, get_dense_rep, split_and_process_vlm_inputs
from src.model.model import MMEBModel
from src.model.projector import save_projector_artifacts, save_projector_state_dict_artifacts
from src.loss import SimpleContrastiveLoss, DistributedContrastiveLoss, DistributedOrthogonalLoss, DistributedHSICLoss, compute_slot_hsic_metrics, DistributedDistillationLoss
from src.grad_cache.grad_cache import GradCache
from torch.utils.data import DataLoader, Dataset, IterableDataset, RandomSampler, SequentialSampler

from transformers.training_args import OptimizerNames, ParallelMode, TrainingArguments
from transformers.trainer_callback import (
    ExportableState,
    TrainerState,
)
from transformers.trainer_utils import (
    TrainOutput,
    has_length,
    speed_metrics, seed_worker,
)

from transformers.trainer_pt_utils import (
    get_model_param_count,
)

from transformers.trainer import FSDP_MODEL_NAME, _is_peft_model
from transformers.utils import (
    XLA_FSDPV2_MIN_VERSION,
    is_accelerate_available,
    is_apex_available,
    is_torch_xla_available,
    logging, is_sagemaker_mp_enabled,
    CONFIG_NAME, WEIGHTS_NAME, SAFE_WEIGHTS_NAME,
    ADAPTER_WEIGHTS_NAME, ADAPTER_SAFE_WEIGHTS_NAME
)

from transformers.integrations.deepspeed import deepspeed_load_checkpoint

from src.utils import batch_to_device
from src.utils import print_master, print_rank
from src.xseq import (
    XSeqMemoryBank,
    compute_similarity_spectrum,
    compute_xseq_slot_diagnostics,
    per_sample_ce_loss,
    summarize_loss_delta,
)

if is_apex_available():
    from apex import amp

if is_torch_xla_available():
    import torch_xla.core.xla_model as xm
    from torch_xla import __version__ as XLA_VERSION

    IS_XLA_FSDPV2_POST_2_2 = version.parse(XLA_VERSION) >= version.parse(XLA_FSDPV2_MIN_VERSION)
    if IS_XLA_FSDPV2_POST_2_2:
        pass
else:
    IS_XLA_FSDPV2_POST_2_2 = False

logger = logging.get_logger(__name__)


def linear_warmup_scale(step: int, warmup_steps: int) -> float:
    if warmup_steps <= 0:
        return 1.0
    if step <= 0:
        return 0.0
    return min(step / float(warmup_steps), 1.0)

class MMEBTrainer(Trainer):
    def __init__(self, *args, **kwargs):
        super(MMEBTrainer, self).__init__(*args, **kwargs)
        self.is_ddp = dist.is_initialized()
        self.processor = self.processing_class
        self._dist_loss_scale_factor = dist.get_world_size() if self.is_ddp else 1

    def _is_rank0(self) -> bool:
        return (not dist.is_initialized()) or dist.get_rank() == 0

    def _log_wandb_metrics(self, metrics: dict, step: int):
        if not metrics or wandb is None or wandb.run is None or not self._is_rank0():
            return
        payload = dict(metrics)
        payload["diag/global_step"] = float(step)
        wandb.log(payload)

    def get_batch_samples(self, epoch_iterator, num_batches):
        batch_samples = []
        num_items_in_batch = None
        for _ in range(num_batches):
            try:
                batch_samples += [next(epoch_iterator)]
            except StopIteration:
                break
        if len(batch_samples) > 0 and "labels" in batch_samples[0]:
            # For now we don't support object detection
            try:
                num_items_in_batch = sum([(batch["labels"].ne(-100)).sum() for batch in batch_samples])
            except (TypeError, AttributeError):
                pass
        if self.args.average_tokens_across_devices and num_items_in_batch is not None:
            num_items_in_batch = self.accelerator.gather(num_items_in_batch).sum().item()
        if torch.is_tensor(num_items_in_batch):
            num_items_in_batch = num_items_in_batch.item()
        return batch_samples, num_items_in_batch

    def compute_loss(self, model, inputs, *args, **kwargs):
        qry_inputs, tgt_inputs = inputs
        return model(qry=qry_inputs, tgt=tgt_inputs)

    def _save(self, output_dir: Optional[str] = None, state_dict=None):
        os.makedirs(output_dir, exist_ok=True)

        if state_dict is None:
            state_dict = self.model.state_dict()
        prefix = 'encoder.'
        assert all(k.startswith(prefix) for k in state_dict.keys()), list(state_dict.keys())
        state_dict = {k[len(prefix):]: v for k, v in state_dict.items()}
        self.model.encoder.save_pretrained(
            output_dir, state_dict=state_dict, safe_serialization=self.args.save_safetensors
        )

        if self.tokenizer is not None:
            self.tokenizer.save_pretrained(output_dir)

        torch.save(self.args, os.path.join(output_dir, TRAINING_ARGS_NAME))


    def _get_train_sampler(self) -> Optional[torch.utils.data.Sampler]:
        # override original trainer's method
        if self.train_dataset is None or not has_length(self.train_dataset):
            return None
            return RandomSampler(self.train_dataset)

    def get_train_dataloader(self) -> DataLoader:
        """
        override original trainer's method to disable self.accelerator.prepare since it will wrap DataLoaderDispatcher and lead to
        (1) `RuntimeError: You can't use batches of different size with `dispatch_batches=True` or when using an `IterableDataset`.`
        (2) all outputs of dataloader must be tensors
        """
        if self.train_dataset is None:
            raise ValueError("Trainer: training requires a train_dataset.")
        train_dataset = self.train_dataset
        data_collator = self.data_collator
        train_dataset = self._remove_unused_columns(train_dataset, description="training")
        dataloader_params = {
            "batch_size": self._train_batch_size,
            "collate_fn": data_collator,
            "num_workers": self.args.dataloader_num_workers,
            "pin_memory": self.args.dataloader_pin_memory,
            "persistent_workers": self.args.dataloader_persistent_workers,
        }
        if not isinstance(train_dataset, torch.utils.data.IterableDataset):
            dataloader_params["sampler"] = self._get_train_sampler()
            dataloader_params["drop_last"] = self.args.dataloader_drop_last
            dataloader_params["worker_init_fn"] = seed_worker
            dataloader_params["prefetch_factor"] = self.args.dataloader_prefetch_factor
        else:
            dataloader_params["sampler"] = None
            dataloader_params["shuffle"] = False
            dataloader_params["drop_last"] = True
            dataloader_params["prefetch_factor"] = None # # tune on both prefetch_factor and persistent_workers will cause hang at epoch2
        return DataLoader(train_dataset, **dataloader_params)

    def _load_from_checkpoint(self, resume_from_checkpoint, model=None):
        self.model_args.checkpoint_path = resume_from_checkpoint
        logger.info(f"Loading checkpoint from {resume_from_checkpoint}")
        self.model = MMEBModel.load(self.model_args)
        self.model_wrapped = self.model

    def _inner_training_loop(
        self, batch_size=None, args=None, resume_from_checkpoint=None, trial=None, ignore_keys_for_eval=None
    ):
        self.accelerator.free_memory()
        self._train_batch_size = batch_size
        if self.args.auto_find_batch_size:
            if self.state.train_batch_size != self._train_batch_size:
                from accelerate.utils import release_memory

                (self.model_wrapped,) = release_memory(self.model_wrapped)
                self.model_wrapped = self.model

                # Check for DeepSpeed *after* the intial pass and modify the config
                if self.is_deepspeed_enabled:
                    # Temporarily unset `self.args.train_batch_size`
                    original_bs = self.args.per_device_train_batch_size
                    self.args.per_device_train_batch_size = self._train_batch_size // max(1, self.args.n_gpu)
                    self.propagate_args_to_deepspeed(True)
                    self.args.per_device_train_batch_size = original_bs
            self.state.train_batch_size = self._train_batch_size
        logger.debug(f"Currently training with a batch size of: {self._train_batch_size}")
        # Data loader and number of training steps
        train_dataloader = self.get_train_dataloader()

        # Setting up training control variables:
        # number of training epochs: num_train_epochs
        # number of training steps per epoch: num_update_steps_per_epoch
        # total number of training steps to execute: max_steps
        total_train_batch_size = self._train_batch_size * args.gradient_accumulation_steps * args.world_size

        len_dataloader = None
        num_train_tokens = None
        if has_length(train_dataloader):
            len_dataloader = len(train_dataloader)
            num_update_steps_per_epoch = len_dataloader // args.gradient_accumulation_steps
            num_update_steps_per_epoch = max(num_update_steps_per_epoch, 1)
            num_examples = self.num_examples(train_dataloader)
            if args.max_steps > 0:
                max_steps = args.max_steps
                num_train_epochs = args.max_steps // num_update_steps_per_epoch + int(
                    args.max_steps % num_update_steps_per_epoch > 0
                )
                # May be slightly incorrect if the last batch in the training dataloader has a smaller size but it's
                # the best we can do.
                num_train_samples = args.max_steps * total_train_batch_size
                if args.include_tokens_per_second:
                    num_train_tokens = (
                        self.num_tokens(train_dataloader, args.max_steps) * args.gradient_accumulation_steps
                    )
            else:
                max_steps = math.ceil(args.num_train_epochs * num_update_steps_per_epoch)
                num_train_epochs = math.ceil(args.num_train_epochs)
                num_train_samples = self.num_examples(train_dataloader) * args.num_train_epochs
                if args.include_tokens_per_second:
                    num_train_tokens = self.num_tokens(train_dataloader) * args.num_train_epochs
        elif args.max_steps > 0:  # Rely on max_steps when dataloader does not have a working size
            max_steps = args.max_steps
            # Setting a very large number of epochs so we go as many times as necessary over the iterator.
            num_train_epochs = sys.maxsize
            num_update_steps_per_epoch = max_steps
            num_examples = total_train_batch_size * args.max_steps
            num_train_samples = args.max_steps * total_train_batch_size
            if args.include_tokens_per_second:
                num_train_tokens = self.num_tokens(train_dataloader, args.max_steps) * args.gradient_accumulation_steps
        else:
            raise ValueError(
                "args.max_steps must be set to a positive value if dataloader does not have a length, was"
                f" {args.max_steps}"
            )

        delay_optimizer_creation = is_sagemaker_mp_enabled() or self.is_fsdp_xla_enabled or self.is_fsdp_enabled

        # We need to reset the scheduler, as its parameters may be different on subsequent calls
        if self._created_lr_scheduler:
            self.lr_scheduler = None
            self._created_lr_scheduler = False

        self.create_optimizer_and_scheduler(num_training_steps=max_steps)

        self.state = TrainerState(
            stateful_callbacks=[
                cb for cb in self.callback_handler.callbacks + [self.control] if isinstance(cb, ExportableState)
            ]
        )
        self.state.is_hyper_param_search = trial is not None
        self.state.train_batch_size = self._train_batch_size

        # Compute absolute values for logging, eval, and save if given as ratio
        if args.logging_steps is not None:
            if args.logging_steps < 1:
                self.state.logging_steps = math.ceil(max_steps * args.logging_steps)
            else:
                self.state.logging_steps = args.logging_steps
        if args.eval_steps is not None:
            if args.eval_steps < 1:
                self.state.eval_steps = math.ceil(max_steps * args.eval_steps)
            else:
                self.state.eval_steps = args.eval_steps
        if args.save_steps is not None:
            if args.save_steps < 1:
                self.state.save_steps = math.ceil(max_steps * args.save_steps)
            else:
                self.state.save_steps = args.save_steps

        # Activate gradient checkpointing if needed
        if args.gradient_checkpointing:
            self.model.gradient_checkpointing_enable(gradient_checkpointing_kwargs=args.gradient_checkpointing_kwargs)

        model = self._wrap_model(self.model_wrapped)

        # as the model is wrapped, don't use `accelerator.prepare`
        # this is for unhandled cases such as
        # FSDP-XLA, SageMaker MP/DP, DataParallel, IPEX
        use_accelerator_prepare = True if model is self.model else False

        if delay_optimizer_creation:
            if use_accelerator_prepare:
                self._fsdp_qlora_plugin_updates()
                self.model = self.accelerator.prepare(self.model)
            self.create_optimizer_and_scheduler(num_training_steps=max_steps)

        # prepare using `accelerator` prepare
        if use_accelerator_prepare:
            self.model.train()
            if hasattr(self.lr_scheduler, "step"):
                if self.use_apex:
                    model = self.accelerator.prepare(self.model)
                else:
                    model, self.optimizer = self.accelerator.prepare(self.model, self.optimizer)
            else:
                # to handle cases wherein we pass "DummyScheduler" such as when it is specified in DeepSpeed config.
                model, self.optimizer, self.lr_scheduler = self.accelerator.prepare(
                    self.model, self.optimizer, self.lr_scheduler
                )
        elif self.args.optim in [OptimizerNames.LOMO, OptimizerNames.ADALOMO]:
            # In this case we are in DDP + LOMO, which should be supported
            self.optimizer = self.accelerator.prepare(self.optimizer)

        if self.is_fsdp_enabled:
            self.model = self.model_wrapped = model

        # for the rest of this function `model` is the outside model, whether it was wrapped or not
        if model is not self.model:
            self.model_wrapped = model

        # backward compatibility
        if self.is_deepspeed_enabled:
            self.deepspeed = self.model_wrapped

        # ckpt loading
        if resume_from_checkpoint is not None:
            if self.is_deepspeed_enabled:
                deepspeed_load_checkpoint(
                    self.model_wrapped, resume_from_checkpoint, load_module_strict=not _is_peft_model(self.model)
                )
            elif is_sagemaker_mp_enabled() or self.is_fsdp_enabled:
                self._load_from_checkpoint(resume_from_checkpoint, self.model_wrapped)

        # Check if saved optimizer or scheduler states exist
        self._load_optimizer_and_scheduler(resume_from_checkpoint)

        # important: at this point:
        # self.model         is the Transformers Model
        # self.model_wrapped is DDP(Transformers Model), Deepspeed(Transformers Model),
        # FSDP(Transformers Model), Dynamo Optimized Module(Transformers Model) etc.

        # Train!
        logger.info("***** Running training *****")
        logger.info(f"  Num examples = {num_examples:,}")
        logger.info(f"  Num Epochs = {num_train_epochs:,}")
        logger.info(f"  Instantaneous batch size per device = {self.args.per_device_train_batch_size:,}")
        if self.args.per_device_train_batch_size != self._train_batch_size:
            logger.info(f"  Training with DataParallel so batch size has been adjusted to: {self._train_batch_size:,}")
        logger.info(f"  Total train batch size (w. parallel, distributed & accumulation) = {total_train_batch_size:,}")
        logger.info(f"  Gradient Accumulation steps = {args.gradient_accumulation_steps}")
        logger.info(f"  Total optimization steps = {max_steps:,}")
        logger.info(f"  Number of trainable parameters = {get_model_param_count(model, trainable_only=True):,}")

        self.state.epoch = 0
        start_time = time.time()
        epochs_trained = 0
        steps_trained_in_current_epoch = 0
        steps_trained_progress_bar = None

        # @ruimeng use steps_trained_in_current_epoch to skip batches for finding buggy data
        # steps_trained_in_current_epoch = 42

        # Check if continuing training from a checkpoint
        if resume_from_checkpoint is not None and os.path.isfile(
            os.path.join(resume_from_checkpoint, TRAINER_STATE_NAME)
        ):
            self.state = TrainerState.load_from_json(os.path.join(resume_from_checkpoint, TRAINER_STATE_NAME))
            self.compare_trainer_and_checkpoint_args(self.args, self.state)
            self._load_callback_state()
            epochs_trained = int(self.state.global_step // num_update_steps_per_epoch)
            if not args.ignore_data_skip:
                steps_trained_in_current_epoch = self.state.global_step % (num_update_steps_per_epoch)
                steps_trained_in_current_epoch *= args.gradient_accumulation_steps
            else:
                steps_trained_in_current_epoch = 0

            logger.info("  Continuing training from checkpoint, will skip to saved global_step")
            logger.info(f"  Continuing training from epoch {epochs_trained}")
            logger.info(f"  Continuing training from global step {self.state.global_step}")
            if not args.ignore_data_skip:
                logger.info(
                    f"  Will skip the first {epochs_trained} epochs then the first"
                    f" {steps_trained_in_current_epoch} batches in the first epoch."
                )

        # Update the references
        self.callback_handler.model = self.model
        self.callback_handler.optimizer = self.optimizer
        self.callback_handler.lr_scheduler = self.lr_scheduler
        self.callback_handler.train_dataloader = train_dataloader
        # This should be the same if the state has been saved but in case the training arguments changed, it's safer
        # to set this after the load.
        self.state.max_steps = max_steps
        self.state.num_train_epochs = num_train_epochs
        self.state.is_local_process_zero = self.is_local_process_zero()
        self.state.is_world_process_zero = self.is_world_process_zero()

        # tr_loss is a tensor to avoid synchronization of TPUs through .item()
        tr_loss = torch.tensor(0.0).to(args.device)
        tr_aux_loss_dict = defaultdict(lambda: torch.tensor(0.0).to(args.device))
        tr_metrics = defaultdict(list)
        # _total_loss_scalar is updated everytime .item() has to be called on tr_loss and stores the sum of all losses
        self._total_loss_scalar = 0.0
        self._globalstep_last_logged = self.state.global_step
        model.zero_grad()
        grad_norm: Optional[float] = None
        self.control = self.callback_handler.on_train_begin(args, self.state, self.control)

        if args.eval_on_start:
            self._evaluate(trial, ignore_keys_for_eval, skip_scheduler=True)

        total_batched_samples = 0
        for epoch in range(epochs_trained, num_train_epochs):
            epoch_dataloader = train_dataloader
            if hasattr(epoch_dataloader.dataset, "set_epoch"):
                # print(f'\t\tSetting new epoch={epoch}')
                epoch_dataloader.dataset.set_epoch(epoch)
            if isinstance(epoch_dataloader.dataset, (tuple, list)):
                for d in epoch_dataloader.dataset:
                    if hasattr(d, "set_epoch"):
                        # print(f'\t\tSetting new epoch={epoch} for dataset={d}')
                        d.set_epoch(epoch)

            # Reset the past mems state at the beginning of each epoch if necessary.
            if args.past_index >= 0:
                self._past = None

            steps_in_epoch = (
                len(epoch_dataloader)
                if len_dataloader is not None
                else args.max_steps * args.gradient_accumulation_steps
            )
            self.control = self.callback_handler.on_epoch_begin(args, self.state, self.control)

            if epoch == epochs_trained and resume_from_checkpoint is not None and steps_trained_in_current_epoch == 0:
                self._load_rng_state(resume_from_checkpoint)

            rng_to_sync = False
            steps_skipped = 0
            epoch_iterator = iter(epoch_dataloader)
            if steps_trained_in_current_epoch > 0:
                # epoch_dataloader = skip_first_batches(epoch_dataloader, steps_trained_in_current_epoch)
                if torch.distributed.get_rank() == 0:
                    with open(os.path.join(self.args.output_dir, 'skip'), 'w') as f:
                        f.write(str(steps_trained_in_current_epoch))
                torch.distributed.barrier()

                for _ in range(steps_trained_in_current_epoch):
                    next(epoch_iterator)
                torch.distributed.barrier()

                if torch.distributed.get_rank() == 0:
                    os.remove(os.path.join(self.args.output_dir, 'skip'))

                torch.distributed.barrier()
                
                steps_skipped = steps_trained_in_current_epoch
                steps_trained_in_current_epoch = 0
                rng_to_sync = True

            step = -1
            # epoch_iterator = iter(epoch_dataloader)
            # We chunkify the epoch iterator into gradient accumulation steps `n` batches
            remainder = num_examples % args.gradient_accumulation_steps
            num_items_in_batch = None
            if remainder == 0:
                remainder = args.gradient_accumulation_steps
            update_step = -1
            total_updates = steps_in_epoch // args.gradient_accumulation_steps + 1
            for _ in range(total_updates):
                update_step += 1
                num_batches = args.gradient_accumulation_steps if update_step != (total_updates - 1) else remainder
                batch_samples, num_items_in_batch = self.get_batch_samples(epoch_iterator, num_batches)
                for i, inputs in enumerate(batch_samples):
                    step += 1
                    total_batched_samples += 1

                    # dataset_stat = collections.Counter(inputs[0]['global_dataset_name'])
                    # print_rank(f"dataset name: {str(set(inputs[0]['global_dataset_name']))}")
                    # for dname, count in sorted(dataset_stat.items(), key=lambda t:t[1], reverse=True):
                    #     print_rank(f"\t\tdataset_name={dname}, count={count}")

                    is_last_step_and_steps_less_than_grad_acc = (
                        steps_in_epoch <= args.gradient_accumulation_steps and (step + 1) == steps_in_epoch
                    )
                    do_sync_step = is_last_step_and_steps_less_than_grad_acc or (
                        total_batched_samples % args.gradient_accumulation_steps == 0
                    )
                    # Since we perform prefetching, we need to manually set sync_gradients
                    if not do_sync_step:
                        self.accelerator.gradient_state._set_sync_gradients(False)
                    else:
                        self.accelerator.gradient_state._set_sync_gradients(True)

                    if self.args.include_num_input_tokens_seen:
                        main_input_name = getattr(self.model, "main_input_name", "input_ids")
                        if main_input_name not in inputs:
                            logger.warning(
                                "Tried to track the number of tokens seen, however the current model is "
                                "not configured properly to know what item is the input. To fix this, add "
                                "a `main_input_name` attribute to the model class you are using."
                            )
                        else:
                            input_tokens = inputs[main_input_name].numel()
                            input_tokens = torch.tensor(input_tokens, device=self.args.device, dtype=torch.int64)
                            self.state.num_input_tokens_seen += self.accelerator.gather(input_tokens).cpu().item()
                    if rng_to_sync:
                        self._load_rng_state(resume_from_checkpoint)
                        rng_to_sync = False

                    # Skip past any already trained steps if resuming training
                    if steps_trained_in_current_epoch > 0:
                        steps_trained_in_current_epoch -= 1
                        if steps_trained_progress_bar is not None:
                            steps_trained_progress_bar.update(1)
                        if steps_trained_in_current_epoch == 0:
                            self._load_rng_state(resume_from_checkpoint)
                        continue
                    elif steps_trained_progress_bar is not None:
                        steps_trained_progress_bar.close()
                        steps_trained_progress_bar = None

                    if step % args.gradient_accumulation_steps == 0:
                        self.control = self.callback_handler.on_step_begin(args, self.state, self.control)

                    # We explicitly want to avoid relying on `accelerator.accumulate` for generation training
                    context = (
                        functools.partial(self.accelerator.no_sync, model=model)
                        if i != len(batch_samples) - 1
                        # and self.accelerator.distributed_type != DistributedType.DEEPSPEED
                        else contextlib.nullcontext
                    )
                    with context():
                        tr_loss_step = self.training_step(model, inputs, num_items_in_batch)

                    if type(tr_loss_step) == tuple:
                        if len(tr_loss_step) == 3:
                            tr_loss_step, metrics_step, loss_type = tr_loss_step
                        elif len(tr_loss_step) == 2:
                            tr_loss_step, metrics_step = tr_loss_step
                            loss_type = None
                        else:
                            raise ValueError(
                                f"The training_step should return either a single loss value or a tuple of (loss, loss_type, metrics)."
                            )
                    else:
                        metrics_step, loss_type = None, None

                    if metrics_step is not None:
                        for k, v in metrics_step.items():
                            tr_metrics[k].append(v)

                    if (
                        args.logging_nan_inf_filter
                        and not is_torch_xla_available()
                        and (torch.isnan(tr_loss_step) or torch.isinf(tr_loss_step))
                    ):
                        tr_aux_loss_dict[loss_type] = tr_aux_loss_dict[loss_type] + tr_aux_loss_dict[loss_type] / (1 + self.state.global_step - self._globalstep_last_logged)

                        # if loss is nan or inf simply add the average of previous logged losses
                        tr_loss = tr_loss + tr_loss / (1 + self.state.global_step - self._globalstep_last_logged)

                    else:
                        if tr_loss.device != tr_loss_step.device:
                            raise ValueError(
                                f"Calculated loss must be on the original device: {tr_loss.device} but device in use is {tr_loss_step.device}"
                            )

                        tr_aux_loss_dict[loss_type] = tr_aux_loss_dict[loss_type] + tr_loss_step

                        tr_loss = tr_loss + tr_loss_step

                    self.current_flos += float(self.floating_point_ops(inputs))

                    if do_sync_step:
                        # Since we perform prefetching, we need to manually set sync_gradients to True
                        self.accelerator.gradient_state._set_sync_gradients(True)

                        # Gradient clipping
                        if args.max_grad_norm is not None and args.max_grad_norm > 0:
                            # deepspeed does its own clipping

                            if self.use_apex:
                                # Revert to normal clipping otherwise, handling Apex or full precision
                                _grad_norm = torch.nn.utils.clip_grad_norm_(
                                    amp.master_params(self.optimizer),
                                    args.max_grad_norm,
                                )
                            else:
                                _grad_norm = self.accelerator.clip_grad_norm_(
                                    model.parameters(),
                                    args.max_grad_norm,
                                )

                            if (
                                is_accelerate_available()
                                and self.accelerator.distributed_type == DistributedType.DEEPSPEED
                            ):
                                grad_norm = model.get_global_grad_norm()
                                # In some cases the grad norm may not return a float
                                if hasattr(grad_norm, "item"):
                                    grad_norm = grad_norm.item()
                            else:
                                grad_norm = _grad_norm

                        self.control = self.callback_handler.on_pre_optimizer_step(args, self.state, self.control)

                        self.optimizer.step()

                        self.control = self.callback_handler.on_optimizer_step(args, self.state, self.control)

                        optimizer_was_run = not self.accelerator.optimizer_step_was_skipped
                        if optimizer_was_run:
                            # Delay optimizer scheduling until metrics are generated
                            if not isinstance(self.lr_scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                                self.lr_scheduler.step()

                        model.zero_grad()
                        self.state.global_step += 1
                        self.state.epoch = epoch + (step + 1 + steps_skipped) / steps_in_epoch
                        self.control = self.callback_handler.on_step_end(args, self.state, self.control)
                        self._maybe_log_save_evaluate(tr_loss, grad_norm, model, trial, epoch, ignore_keys_for_eval, time.time(), tr_aux_loss_dict=tr_aux_loss_dict, tr_metrics=tr_metrics)
                    else:
                        self.control = self.callback_handler.on_substep_end(args, self.state, self.control)

                    # PyTorch/XLA relies on the data loader to insert the mark_step for
                    # each step. Since we are breaking the loop early, we need to manually
                    # insert the mark_step here.
                    if self.control.should_epoch_stop or self.control.should_training_stop:
                        if is_torch_xla_available():
                            xm.mark_step()
                        break
                # We also need to break out of the nested loop
                if self.control.should_epoch_stop or self.control.should_training_stop:
                    if is_torch_xla_available():
                        xm.mark_step()
                    break
            if step < 0:
                logger.warning(
                    "There seems not to be a single sample in your epoch_iterator, stopping training at step"
                    f" {self.state.global_step}! This is expected if you're using an IterableDataset and set"
                    f" num_steps ({max_steps}) higher than the number of available samples."
                )
                self.control.should_training_stop = True

            self.control = self.callback_handler.on_epoch_end(args, self.state, self.control)
            self._maybe_log_save_evaluate(tr_loss, grad_norm, model, trial, epoch, ignore_keys_for_eval, time.time())

            if self.control.should_training_stop:
                break

        if args.past_index and hasattr(self, "_past"):
            # Clean the state at the end of training
            delattr(self, "_past")

        logger.info("\n\nTraining completed. Do not forget to share your model on huggingface.co/models =)\n\n")
        if args.load_best_model_at_end and self.state.best_model_checkpoint is not None:
            # Wait for everyone to get here so we are sure the model has been saved by process 0.
            if is_torch_xla_available():
                xm.rendezvous("load_best_model_at_end")
            elif args.parallel_mode == ParallelMode.DISTRIBUTED:
                dist.barrier()

            self._load_best_model()

        # add remaining tr_loss
        self._total_loss_scalar += tr_loss.item()
        effective_global_step = max(self.state.global_step, 0.001)  # Avoid ZeroDivisionError
        train_loss = self._total_loss_scalar / effective_global_step

        metrics = speed_metrics(
            "train",
            start_time,
            num_samples=num_train_samples,
            num_steps=self.state.max_steps,
            num_tokens=num_train_tokens,
        )
        self.store_flos()
        metrics["total_flos"] = self.state.total_flos
        metrics["train_loss"] = train_loss

        self.is_in_train = False

        self._memory_tracker.stop_and_update_metrics(metrics)

        self.log(metrics)

        run_dir = self._get_output_dir(trial)
        checkpoints_sorted = self._sorted_checkpoints(use_mtime=False, output_dir=run_dir)

        # Delete the last checkpoint when save_total_limit=1 if it's different from the best checkpoint and process allowed to save.
        if self.args.should_save and self.state.best_model_checkpoint is not None and self.args.save_total_limit == 1:
            for checkpoint in checkpoints_sorted:
                if not os.path.samefile(checkpoint, self.state.best_model_checkpoint):
                    logger.info(f"Deleting older checkpoint [{checkpoint}] due to args.save_total_limit")
                    shutil.rmtree(checkpoint, ignore_errors=True)

        self.control = self.callback_handler.on_train_end(args, self.state, self.control)

        # Wait for the checkpoint to be uploaded.
        self._finish_current_push()

        # After training we make sure to retrieve back the original forward pass method
        # for the embedding layer by removing the forward post hook.
        if self.neftune_noise_alpha is not None:
            self._deactivate_neftune(self.model)

        return TrainOutput(self.state.global_step, train_loss, metrics)
    
    def _maybe_log_save_evaluate(
        self, tr_loss, grad_norm, model, trial, epoch, ignore_keys_for_eval, start_time, learning_rate=None,
        tr_aux_loss_dict=None, tr_metrics=None,
    ):
        if self.control.should_log and self.state.global_step > self._globalstep_last_logged:
            if is_torch_xla_available():
                xm.mark_step()

            logs: dict[str, float] = {}

            # all_gather + mean() to get average loss over all processes
            tr_loss_scalar = self._nested_gather(tr_loss).mean().item()

            # reset tr_loss to zero
            tr_loss -= tr_loss

            logs["loss"] = round(tr_loss_scalar / (self.state.global_step - self._globalstep_last_logged), 4)
            if grad_norm is not None:
                logs["grad_norm"] = grad_norm.item() if isinstance(grad_norm, torch.Tensor) else grad_norm
            if learning_rate is not None:
                logs["learning_rate"] = learning_rate
            else:
                logs["learning_rate"] = self._get_learning_rate()

            if tr_aux_loss_dict is not None:
                for loss_type, tr_aux_loss in tr_aux_loss_dict.items():
                    tr_aux_loss_scalar = self._nested_gather(tr_aux_loss).mean().item()
                    tr_aux_loss_dict[loss_type] -= tr_aux_loss 
                    if tr_aux_loss_scalar > 0:
                        logs[f"{loss_type}_loss"] = round(tr_aux_loss_scalar / (self.state.global_step - self._globalstep_last_logged), 4)
            if tr_metrics is not None:
                for k, v in tr_metrics.items():
                    if len(v) > 0:
                        logs[k] = sum(v) / len(v)

            # 蒸馏相关指标
            if hasattr(self, '_last_distillation_lambda') and self._last_distillation_lambda is not None:
                logs["distill_lambda"] = round(self._last_distillation_lambda, 4)
            if hasattr(self, '_last_distillation_loss_kl') and self._last_distillation_loss_kl is not None:
                logs["distill_loss_kl"] = round(self._last_distillation_loss_kl, 6)
            if hasattr(self, '_last_orthogonal_loss') and self._last_orthogonal_loss is not None:
                logs["orthogonal_loss"] = round(self._last_orthogonal_loss, 6)
                logs["orth/global_raw"] = round(self._last_orthogonal_loss, 6)
            if hasattr(self, '_last_hsic_loss') and self._last_hsic_loss is not None:
                logs["hsic_loss"] = round(self._last_hsic_loss, 6)
                logs["hsic/global_raw"] = round(self._last_hsic_loss, 6)
            wandb_diag_logs = {}
            if hasattr(self, '_last_orthogonal_layer_losses') and self._last_orthogonal_layer_losses is not None:
                for k, v in self._last_orthogonal_layer_losses.items():
                    wandb_diag_logs[k] = round(v, 6) if isinstance(v, float) else v
            if hasattr(self, '_last_load_diag_metrics') and self._last_load_diag_metrics is not None:
                for k, v in self._last_load_diag_metrics.items():
                    wandb_diag_logs[k] = round(v, 6) if isinstance(v, float) else v
            if hasattr(self, '_last_hsic_diag_metrics') and self._last_hsic_diag_metrics is not None:
                for k, v in self._last_hsic_diag_metrics.items():
                    wandb_diag_logs[k] = round(v, 6) if isinstance(v, float) else v
            if hasattr(self, '_last_xseq_diag_metrics') and self._last_xseq_diag_metrics is not None:
                for k, v in self._last_xseq_diag_metrics.items():
                    wandb_diag_logs[k] = round(v, 6) if isinstance(v, float) else v

            # 清理蒸馏临时变量以释放内存
            if hasattr(self, '_last_distillation_loss_kl'):
                delattr(self, '_last_distillation_loss_kl')
            if hasattr(self, '_last_orthogonal_loss'):
                delattr(self, '_last_orthogonal_loss')
            if hasattr(self, '_last_hsic_loss'):
                delattr(self, '_last_hsic_loss')
            if hasattr(self, '_last_orthogonal_layer_losses'):
                delattr(self, '_last_orthogonal_layer_losses')
            if hasattr(self, '_last_load_diag_metrics'):
                delattr(self, '_last_load_diag_metrics')
            if hasattr(self, '_last_hsic_diag_metrics'):
                delattr(self, '_last_hsic_diag_metrics')
            if hasattr(self, '_last_xseq_diag_metrics'):
                delattr(self, '_last_xseq_diag_metrics')

            self._total_loss_scalar += tr_loss_scalar
            self._globalstep_last_logged = self.state.global_step
            self.store_flos()

            self.log(logs, start_time)
            self._log_wandb_metrics(wandb_diag_logs, self.state.global_step)

        metrics = None
        if self.control.should_evaluate:
            metrics = self._evaluate(trial, ignore_keys_for_eval)
            is_new_best_metric = self._determine_best_metric(metrics=metrics, trial=trial)

            if self.args.save_strategy == SaveStrategy.BEST:
                self.control.should_save = is_new_best_metric

        if self.control.should_save:
            self._save_checkpoint(model, trial)
            self.control = self.callback_handler.on_save(self.args, self.state, self.control)


    def create_optimizer(self):
        """
        Setup the optimizer.

        We provide a reasonable default that works well. If you want to use something else, you can pass a tuple in the
        Trainer's init through `optimizers`, or subclass and override this method in a subclass.
        """
        opt_model = self.model_wrapped if is_sagemaker_mp_enabled() else self.model

        if self.optimizer is None:
            decay_parameters = self.get_decay_parameter_names(opt_model)
            optimizer_grouped_parameters = [
                {
                    "params": [
                        p for n, p in opt_model.encoder.named_parameters() if (n in decay_parameters and p.requires_grad)
                    ],
                    "weight_decay": self.args.weight_decay,
                },
                {
                    "params": [
                        p for n, p in opt_model.encoder.named_parameters() if (n not in decay_parameters and p.requires_grad)
                    ],
                    "weight_decay": 0.0,
                },
            ]
            
            if getattr(opt_model, "projector", None) is not None:
                if self.args.projector_lr != self.args.learning_rate:
                    logger.info(f"Using different learning rate {self.args.projector_lr} for projector")
                optimizer_grouped_parameters += [
                    {
                        "params": [p for p in opt_model.projector.parameters() if p.requires_grad],
                        "lr": self.args.projector_lr,
                        "weight_decay": self.args.weight_decay,
                    }
                ]

            if self.optimizer_cls_and_kwargs is not None:
                optimizer_cls, optimizer_kwargs = self.optimizer_cls_and_kwargs
            else:
                optimizer_cls, optimizer_kwargs = self.get_optimizer_cls_and_kwargs(self.args, opt_model)

            self.optimizer = optimizer_cls(optimizer_grouped_parameters, **optimizer_kwargs)

        return self.optimizer


class GradCacheLateProcessTrainer(MMEBTrainer):
    """
    Adapted from gradcache repo.
    """
    def __init__(self, *args, multitask_dataloader=None, **kwargs):
        self.max_length = kwargs.get("max_length", 512)
        self._multitask_dataloader = multitask_dataloader
        if "max_length" in kwargs:
            del kwargs["max_length"]
        self.model_args = kwargs.get("model_args", None)
        if "model_args" in kwargs:
            del kwargs["model_args"]
        super(GradCacheLateProcessTrainer, self).__init__(*args, **kwargs)
        self.is_ddp = dist.is_initialized()
        self._dist_loss_scale_factor = dist.get_world_size() if self.is_ddp else 1
        loss_fn_cls = DistributedContrastiveLoss if self.is_ddp else SimpleContrastiveLoss
        loss_fn = loss_fn_cls(
            temperature=self.model.temperature,
            is_symmetric=self.args.is_symmetric, 
            calc_metrics=True,
            matryoshkas=self.args.matryoshkas,
            should_mask_false_neg=self.args.should_mask_false_neg,
            normalize_in_loss=self.args.normalize_in_loss,
            similarity_type=self.args.similarity_type,
            maxsim_topk=self.args.maxsim_topk,
        )
        self.loss_fn = loss_fn
        self._multi_head_aux_loss_fn = None
        if self.is_ddp:
            self._orthogonal_diag_loss_fn = DistributedOrthogonalLoss(
                loss_weights=1.0,
                margin=self.args.orthogonal_margin,
            )
        else:
            self._orthogonal_diag_loss_fn = None
        self._hsic_loss_fn = None
        if self.is_ddp and self.args.hsic_loss is not None and self.args.hsic_loss > 0:
            self._hsic_loss_fn = DistributedHSICLoss(
                loss_weights=self.args.hsic_loss,
            )

        if self.is_ddp and (
            (self.args.orthogonal_loss is not None and self.args.orthogonal_loss > 0)
            or (self.args.hsic_loss is not None and self.args.hsic_loss > 0)
        ):
            base_aux_loss_fn = DistributedOrthogonalLoss(
                loss_weights=self.args.orthogonal_loss,
                margin=self.args.orthogonal_margin,
            ) if self.args.orthogonal_loss is not None and self.args.orthogonal_loss > 0 else None
            self._multi_head_aux_loss_fn = DistributedOrthogonalLoss(
                loss_weights=1.0,
                margin=self.args.orthogonal_margin,
            ) if base_aux_loss_fn is not None else None

            def aux_loss_fn(*aux_args, **aux_kwargs):
                total_loss = None
                raw_logs = {}

                if base_aux_loss_fn is not None:
                    scale = linear_warmup_scale(self.state.global_step, self.args.orthogonal_warmup_steps)
                    orth_kwargs = dict(aux_kwargs)
                    orth_kwargs.setdefault("sync_loss", False)
                    orth_out = base_aux_loss_fn(*aux_args, **orth_kwargs)
                    if orth_kwargs.get("return_raw", False):
                        orth_loss, orth_raw_loss = orth_out
                        total_loss = orth_loss * scale
                        raw_logs["orthogonal_loss"] = orth_raw_loss.detach()
                    else:
                        total_loss = orth_out * scale

                if self._hsic_loss_fn is not None:
                    hsic_kwargs = dict(aux_kwargs)
                    hsic_kwargs.setdefault("sync_loss", False)
                    hsic_out = self._hsic_loss_fn(*aux_args, **hsic_kwargs)
                    if hsic_kwargs.get("return_raw", False):
                        hsic_loss, hsic_raw_loss = hsic_out
                        total_loss = hsic_loss if total_loss is None else total_loss + hsic_loss
                        raw_logs["hsic_loss"] = hsic_raw_loss.detach()
                    else:
                        total_loss = hsic_out if total_loss is None else total_loss + hsic_out

                if total_loss is None:
                    device = None
                    for x in aux_args:
                        if x is not None:
                            device = x.device
                            break
                    if device is None:
                        device = self.accelerator.device
                    total_loss = torch.zeros((), device=device, dtype=torch.float32)

                if aux_kwargs.get("return_raw", False):
                    return total_loss, raw_logs
                return total_loss
        else:
            aux_loss_fn = None

        def aux_metrics_fn(*aux_args):
            if not aux_args:
                return None

            query_tokens = aux_args[0] if len(aux_args) > 0 else None
            target_tokens = aux_args[1] if len(aux_args) > 1 else None
            diag_logs = {}
            branch_names = ["qry", "tgt", "neg"]
            branch_pairs = []
            for idx, tokens in enumerate(aux_args):
                if tokens is None:
                    continue
                name = branch_names[idx] if idx < len(branch_names) else f"branch_{idx}"
                branch_pairs.append((name, tokens))

            run_orth_diag = self._should_run_orthogonal_diag()
            run_hsic_diag = self._should_run_hsic_diag()
            if not run_orth_diag and not run_hsic_diag:
                return None

            if run_orth_diag:
                diag_logs["orth/diag_step"] = float(self.state.global_step)

                loss_args = [x for x in (query_tokens, target_tokens) if x is not None]
                if loss_args and self._orthogonal_diag_loss_fn is not None:
                    _, raw_loss = self._orthogonal_diag_loss_fn(
                        *loss_args,
                        use_abs=True,
                        sync_loss=False,
                        return_raw=True,
                    )
                    diag_logs["orth/light_raw"] = raw_loss.item()

                def token_stats(x, prefix):
                    if x is None:
                        return
                    if x.dim() == 2:
                        x = x.unsqueeze(0)
                    if x.dim() != 3 or x.shape[1] <= 0:
                        return
                    x_norm = torch.nn.functional.normalize(x, p=2, dim=-1)
                    sim = x_norm @ x_norm.transpose(-2, -1)
                    sim = sim - torch.diag_embed(torch.diagonal(sim, dim1=-2, dim2=-1))
                    t = x.shape[1]
                    denom = max(t * (t - 1), 1)
                    diag_logs[f"orth/{prefix}_offdiag_abs_mean"] = (sim.abs().sum(dim=(-1, -2)) / denom).mean().item()
                    token_norm = x.norm(dim=-1)
                    diag_logs[f"orth/{prefix}_token_norm_mean"] = token_norm.mean().item()

                token_stats(query_tokens, "qry")
                token_stats(target_tokens, "tgt")
                if query_tokens is not None and target_tokens is not None:
                    q = torch.nn.functional.normalize(query_tokens.mean(dim=1), p=2, dim=-1)
                    t = torch.nn.functional.normalize(target_tokens.mean(dim=1), p=2, dim=-1)
                    diag_logs["orth/align_cosine_mean"] = (q * t).sum(dim=-1).mean().item()

            if run_hsic_diag:
                diag_logs["hsic/diag_step"] = float(self.state.global_step)
                hsic_means = []
                offdiag_means = []
                offdiag_maxes = []
                for prefix, tokens in branch_pairs:
                    branch_hsic = compute_slot_hsic_metrics(tokens, gather_distributed=self.is_ddp)
                    diag_logs[f"hsic/{prefix}_mean"] = branch_hsic["hsic_mean"]
                    diag_logs[f"slot_pair/{prefix}_offdiag_cos_abs_mean"] = branch_hsic["offdiag_cos_abs_mean"]
                    diag_logs[f"slot_pair/{prefix}_offdiag_cos_abs_max"] = branch_hsic["offdiag_cos_abs_max"]
                    hsic_means.append(branch_hsic["hsic_mean"])
                    offdiag_means.append(branch_hsic["offdiag_cos_abs_mean"])
                    offdiag_maxes.append(branch_hsic["offdiag_cos_abs_max"])
                if hsic_means:
                    diag_logs["hsic/mean"] = sum(hsic_means) / len(hsic_means)
                    diag_logs["slot_pair/offdiag_cos_abs_mean"] = sum(offdiag_means) / len(offdiag_means)
                    diag_logs["slot_pair/offdiag_cos_abs_max"] = max(offdiag_maxes)
                self._last_hsic_diag_step = self.state.global_step
            return diag_logs
        # process_fn = functools.partial(process_vlm_inputs_fns[self.args.model_backbone], processor=self.processing_class, max_length=self.max_length)

        self.gc = GradCache(
            models=[self.model, self.model, self.model],
            chunk_sizes=[self.args.gc_q_chunk_size, self.args.gc_p_chunk_size, self.args.gc_q_chunk_size],
            loss_fn=loss_fn,
            aux_loss_fn=aux_loss_fn,
            aux_metrics_fn=aux_metrics_fn,
            split_input_fn=split_and_process_vlm_inputs,
            # process_fn=process_fn,
            get_rep_fn=get_dense_rep,
            fp16=self.args.fp16,
            scaler=self.scaler if self.args.fp16 else None
        )

    def _slice_diag_batch(self, x, n: int):
        if torch.is_tensor(x):
            return x[:n]
        if isinstance(x, dict):
            return {k: self._slice_diag_batch(v, n) for k, v in x.items()}
        if isinstance(x, list):
            return x[:n]
        if isinstance(x, tuple):
            return tuple(self._slice_diag_batch(v, n) for v in x[:n])
        return x

    def _reduce_diag_value(self, key: str, value: float) -> float:
        if not self.is_ddp:
            return float(value)

        device = self.accelerator.device if hasattr(self, "accelerator") else self.model.device
        tensor = torch.tensor(float(value), device=device, dtype=torch.float32)
        if key.endswith("_max") or "/cuda/" in key:
            op = dist.ReduceOp.MAX
        elif key.endswith("_min"):
            op = dist.ReduceOp.MIN
        else:
            op = dist.ReduceOp.SUM
        dist.all_reduce(tensor, op=op)
        if op == dist.ReduceOp.SUM:
            tensor /= dist.get_world_size()
        return tensor.item()

    def _aggregate_diag_logs(self, diag_logs: dict) -> dict:
        return {
            key: self._reduce_diag_value(key, value) if isinstance(value, (int, float)) else value
            for key, value in diag_logs.items()
        }

    def _should_run_orthogonal_diag(self) -> bool:
        if self._orthogonal_diag_loss_fn is None:
            return False
        diag_steps = getattr(self.args, "orthogonal_diag_steps", 50)
        if diag_steps <= 0:
            return False
        step = self.state.global_step
        if getattr(self, "_last_orthogonal_diag_step", None) == step:
            return False
        if step == 0:
            return True

        # Best-effort logging schedule: denser in early training where representation
        # dynamics tend to change faster, then back off to the steady-state interval.
        if step < 200:
            interval = min(diag_steps, 10)
        elif step < 1000:
            interval = min(diag_steps, 25)
        else:
            interval = diag_steps
        interval = max(interval, 1)
        return step % interval == 0

    def _should_run_hsic_diag(self) -> bool:
        if self._hsic_loss_fn is None:
            return False
        diag_steps = getattr(self.args, "hsic_diag_steps", 50)
        if diag_steps <= 0:
            return False
        step = self.state.global_step
        if getattr(self, "_last_hsic_diag_step", None) == step:
            return False
        if step == 0:
            return True
        if step < 200:
            interval = min(diag_steps, 10)
        elif step < 1000:
            interval = min(diag_steps, 25)
        else:
            interval = diag_steps
        interval = max(interval, 1)
        return step % interval == 0

    def _should_run_load_diag(self) -> bool:
        diag_steps = getattr(self.args, "load_diag_steps", 50)
        if diag_steps <= 0:
            return False
        step = self.state.global_step
        if getattr(self, "_last_load_diag_step", None) == step:
            return False
        return step == 0 or step % max(diag_steps, 1) == 0

    def _get_local_batch_size(self, batch) -> int:
        attention_mask = batch.get("attention_mask")
        if isinstance(attention_mask, torch.Tensor):
            return int(attention_mask.shape[0])
        input_ids = batch.get("input_ids")
        if isinstance(input_ids, torch.Tensor):
            return int(input_ids.shape[0])
        for value in batch.values():
            if isinstance(value, list):
                return len(value)
        return 0

    def _get_active_token_counts(self, batch, batch_size: int) -> torch.Tensor:
        attention_mask = batch.get("attention_mask")
        if not isinstance(attention_mask, torch.Tensor):
            return torch.zeros(batch_size, dtype=torch.float32)
        if attention_mask.dim() == 1:
            attention_mask = attention_mask.unsqueeze(0)
        reduce_dims = tuple(range(1, attention_mask.dim()))
        return attention_mask.float().sum(dim=reduce_dims)

    def _grid_to_counts(self, grid_entry, merge_size_sq: int) -> tuple[float, float]:
        if grid_entry is None:
            return 0.0, 0.0
        if isinstance(grid_entry, torch.Tensor):
            grid = grid_entry.detach()
        else:
            try:
                grid = torch.as_tensor(grid_entry)
            except Exception:
                return 0.0, 0.0
        if grid.numel() == 0:
            return 0.0, 0.0
        if grid.dim() == 1:
            if grid.numel() != 3:
                return 0.0, 0.0
            grid = grid.reshape(1, 3)
        elif grid.dim() >= 2 and grid.shape[-1] == 3:
            grid = grid.reshape(-1, 3)
        elif grid.numel() % 3 == 0:
            grid = grid.reshape(-1, 3)
        else:
            return 0.0, 0.0
        grid = grid.to(dtype=torch.float32)
        image_count = float(grid.shape[0])
        visual_tokens = float((grid.prod(dim=-1).sum() / max(merge_size_sq, 1)).item())
        return image_count, visual_tokens

    def _get_visual_counts(self, batch, batch_size: int) -> tuple[torch.Tensor, torch.Tensor]:
        image_grid_thw = batch.get("image_grid_thw")
        device = None
        attention_mask = batch.get("attention_mask")
        if isinstance(attention_mask, torch.Tensor):
            device = attention_mask.device
        image_counts = torch.zeros(batch_size, dtype=torch.float32, device=device)
        visual_tokens = torch.zeros(batch_size, dtype=torch.float32, device=device)
        if image_grid_thw is None or batch_size <= 0:
            return image_counts, visual_tokens

        merge_size = getattr(getattr(self.processor, "image_processor", None), "merge_size", 2)
        merge_size_sq = int(merge_size) * int(merge_size)

        if isinstance(image_grid_thw, list):
            entries = image_grid_thw[:batch_size]
        elif isinstance(image_grid_thw, torch.Tensor):
            if image_grid_thw.dim() == 3 and image_grid_thw.shape[0] == batch_size:
                entries = [image_grid_thw[i] for i in range(batch_size)]
            elif image_grid_thw.dim() == 2 and image_grid_thw.shape[0] == batch_size and image_grid_thw.shape[-1] == 3:
                entries = [image_grid_thw[i] for i in range(batch_size)]
            else:
                entries = [image_grid_thw]
        else:
            entries = [image_grid_thw]

        for idx, entry in enumerate(entries[:batch_size]):
            count, tokens = self._grid_to_counts(entry, merge_size_sq)
            image_counts[idx] = count
            visual_tokens[idx] = tokens
        return image_counts, visual_tokens

    def _add_scalar_stats(self, logs: dict, prefix: str, values: torch.Tensor):
        if values.numel() == 0:
            return
        values = values.float()
        logs[f"{prefix}_mean"] = values.mean().item()
        logs[f"{prefix}_max"] = values.max().item()

    def _compute_batch_load_diag(self, model, queries, targets):
        if not self._should_run_load_diag():
            return

        qry_bs = self._get_local_batch_size(queries)
        tgt_bs = self._get_local_batch_size(targets)
        batch_size = min(qry_bs, tgt_bs)
        if batch_size <= 0:
            return

        qry_active = self._get_active_token_counts(queries, qry_bs)[:batch_size]
        tgt_active = self._get_active_token_counts(targets, tgt_bs)[:batch_size]
        qry_images, qry_visual = self._get_visual_counts(queries, qry_bs)
        tgt_images, tgt_visual = self._get_visual_counts(targets, tgt_bs)
        qry_images = qry_images.to(qry_active.device)
        qry_visual = qry_visual.to(qry_active.device)
        tgt_images = tgt_images.to(tgt_active.device)
        tgt_visual = tgt_visual.to(tgt_active.device)
        qry_images = qry_images[:batch_size]
        qry_visual = qry_visual[:batch_size]
        tgt_images = tgt_images[:batch_size]
        tgt_visual = tgt_visual[:batch_size]

        qry_non_visual = (qry_active - qry_visual).clamp_min(0)
        tgt_non_visual = (tgt_active - tgt_visual).clamp_min(0)
        pair_active = qry_active + tgt_active
        pair_visual = qry_visual + tgt_visual
        pair_images = qry_images + tgt_images
        eps = 1e-6

        diag_logs = {
            "load_summary/diag_step": float(self.state.global_step),
            "load_summary/local_batch_size": float(batch_size),
            "load_summary/qry_active_tokens_mean": qry_active.float().mean().item(),
            "load_summary/tgt_active_tokens_mean": tgt_active.float().mean().item(),
            "load_summary/qry_visual_tokens_mean": qry_visual.float().mean().item(),
            "load_summary/tgt_visual_tokens_mean": tgt_visual.float().mean().item(),
            "load_summary/qry_non_visual_tokens_est_mean": qry_non_visual.float().mean().item(),
            "load_summary/tgt_non_visual_tokens_est_mean": tgt_non_visual.float().mean().item(),
            "load_summary/qry_image_count_mean": qry_images.float().mean().item(),
            "load_summary/tgt_image_count_mean": tgt_images.float().mean().item(),
            "load_summary/pair_active_tokens_total_mean": pair_active.float().mean().item(),
            "load_summary/pair_visual_tokens_total_mean": pair_visual.float().mean().item(),
            "load_summary/tgt_token_share_mean": (tgt_active / pair_active.clamp_min(eps)).mean().item(),
            "load_summary/tgt_visual_share_mean": (tgt_visual / pair_visual.clamp_min(eps)).mean().item(),
            "load_summary/tgt_image_share_mean": (tgt_images / pair_images.clamp_min(eps)).mean().item(),
            "load_summary/tgt_to_qry_active_ratio_mean": (tgt_active / qry_active.clamp_min(eps)).mean().item(),
            "load_summary/tgt_heavier_active_frac": (tgt_active > qry_active).float().mean().item(),
            "load_summary/tgt_heavier_visual_frac": (tgt_visual > qry_visual).float().mean().item(),
        }
        qry_has_visual = qry_visual > 0
        diag_logs["load_summary/qry_has_visual_frac"] = qry_has_visual.float().mean().item()
        if qry_has_visual.any():
            visual_ratio = tgt_visual[qry_has_visual] / qry_visual[qry_has_visual].clamp_min(eps)
            diag_logs["load_summary/tgt_to_qry_visual_ratio_mean"] = visual_ratio.mean().item()
        else:
            diag_logs["load_summary/tgt_to_qry_visual_ratio_mean"] = 0.0

        if torch.cuda.is_available():
            device = model.device
            diag_logs["load_summary/cuda_allocated_gb"] = torch.cuda.memory_allocated(device) / (1024 ** 3)
            diag_logs["load_summary/cuda_reserved_gb"] = torch.cuda.memory_reserved(device) / (1024 ** 3)
            diag_logs["load_summary/cuda_max_allocated_gb"] = torch.cuda.max_memory_allocated(device) / (1024 ** 3)
            diag_logs["load_summary/cuda_max_reserved_gb"] = torch.cuda.max_memory_reserved(device) / (1024 ** 3)

        self._last_load_diag_metrics = self._aggregate_diag_logs(diag_logs)
        self._last_load_diag_step = self.state.global_step

    def _compute_layerwise_orthogonal_diag(self, model, queries, targets):
        if not self._should_run_orthogonal_diag():
            return

        sample_size = int(getattr(self.args, "orthogonal_diag_sample_size", 0))
        base_model = self.accelerator.unwrap_model(model)

        def collect_layer_tokens(batch):
            if sample_size > 0:
                batch = self._slice_diag_batch(batch, sample_size)
            local_inputs = dict(batch)
            local_inputs["return_dict"] = True
            local_inputs["output_hidden_states"] = True

            amp_context = contextlib.nullcontext()
            if torch.cuda.is_available() and (self.args.bf16 or self.args.fp16):
                amp_dtype = torch.bfloat16 if self.args.bf16 else torch.float16
                amp_context = torch.autocast(device_type="cuda", dtype=amp_dtype)

            with torch.no_grad():
                with amp_context:
                    outputs = base_model.encoder(**local_inputs)

            hidden_states = None
            if hasattr(outputs, "hidden_states"):
                hidden_states = outputs.hidden_states
            elif isinstance(outputs, dict):
                hidden_states = outputs.get("hidden_states")
            if hidden_states is None:
                return []

            attention_mask = batch["attention_mask"]
            pooling_kwargs = {}
            if "cls_indices" in batch:
                pooling_kwargs["cls_indices"] = batch["cls_indices"]
            if "mlp_idx" in batch:
                pooling_kwargs["mlp_idx"] = batch["mlp_idx"]

            layer_tokens = []
            for hidden in hidden_states:
                _, chorus_tokens = base_model._pooling(hidden, attention_mask, **pooling_kwargs)
                layer_tokens.append(chorus_tokens)
            return layer_tokens

        query_layers = collect_layer_tokens(queries)
        target_layers = collect_layer_tokens(targets)
        num_layers = max(len(query_layers), len(target_layers))
        if num_layers == 0:
            return

        def summarize_layer_metrics(query_tokens, target_tokens):
            metrics = {}

            def token_stats(x, prefix):
                if x is None:
                    return
                if x.dim() == 2:
                    x = x.unsqueeze(0)
                if x.dim() != 3 or x.shape[1] <= 0:
                    return

                x_norm = torch.nn.functional.normalize(x, p=2, dim=-1)
                sim = x_norm @ x_norm.transpose(-2, -1)
                sim = sim - torch.diag_embed(torch.diagonal(sim, dim1=-2, dim2=-1))

                T = x.shape[1]
                denom = max(T * (T - 1), 1)
                offdiag_abs = sim.abs().sum(dim=(-1, -2)) / denom
                metrics[f"sim/{prefix}_offdiag_abs_mean"] = offdiag_abs.mean().item()
                metrics[f"sim/{prefix}_offdiag_abs_max"] = sim.abs().amax(dim=(-1, -2)).mean().item()

                flat = x.reshape(-1, x.shape[-1]).float()
                if flat.shape[0] >= 2:
                    feat_std = flat.std(dim=0)
                    metrics[f"spread/{prefix}_feat_std_mean"] = feat_std.mean().item()
                    metrics[f"spread/{prefix}_feat_std_min"] = feat_std.min().item()
                token_norm = x.norm(dim=-1)
                metrics[f"spread/{prefix}_token_norm_mean"] = token_norm.mean().item()
                metrics[f"spread/{prefix}_token_norm_std"] = token_norm.std().item()

            token_stats(query_tokens, "qry")
            token_stats(target_tokens, "tgt")

            if query_tokens is not None and target_tokens is not None:
                q = query_tokens.mean(dim=1)
                t = target_tokens.mean(dim=1)
                q = torch.nn.functional.normalize(q, p=2, dim=-1)
                t = torch.nn.functional.normalize(t, p=2, dim=-1)
                metrics["align/cosine_mean"] = (q * t).sum(dim=-1).mean().item()

            return metrics

        diag_logs = {"orth/diag_step": float(self.state.global_step)}
        for layer_idx in range(num_layers):
            aux_args = []
            query_tokens = query_layers[layer_idx] if layer_idx < len(query_layers) else None
            target_tokens = target_layers[layer_idx] if layer_idx < len(target_layers) else None
            if query_tokens is not None:
                aux_args.append(query_tokens)
            if target_tokens is not None:
                aux_args.append(target_tokens)
            if not aux_args:
                continue

            _, raw_loss = self._orthogonal_diag_loss_fn(
                *aux_args,
                use_abs=True,
                sync_loss=False,
                return_raw=True,
            )
            diag_logs[f"orth/layer_{layer_idx:02d}"] = raw_loss.item()
            for k, v in summarize_layer_metrics(query_tokens, target_tokens).items():
                diag_logs[f"{k}/layer_{layer_idx:02d}"] = v

        self._last_orthogonal_layer_losses = self._aggregate_diag_logs(diag_logs)
        self._last_orthogonal_diag_step = self.state.global_step
    
    def get_train_dataloader(self) -> DataLoader:
        if self._multitask_dataloader is not None:
            return self._multitask_dataloader
        return super().get_train_dataloader()

    def _unwrap_multi_head_reps(self, value):
        if isinstance(value, tuple) and len(value) >= 2:
            return value[0], value[1]
        return value, None

    def _is_multi_head_model(self, model) -> bool:
        base_model = self.accelerator.unwrap_model(model) if hasattr(self, "accelerator") else model
        return getattr(base_model, "pooling", None) == "multi_head_mlp"

    def _encode_multi_head_chunks(self, model, model_input: dict, chunk_size: int, output_key: str):
        chunk_size = max(int(chunk_size), 1)
        chunks = self.gc.split_inputs(model_input, chunk_size)
        reps_by_head = defaultdict(list)

        for chunk in chunks:
            output = model(**chunk)
            reps, _ = self._unwrap_multi_head_reps(output[output_key])
            if not isinstance(reps, dict):
                raise ValueError("multi_head_mlp training expects dict outputs from the projector heads.")
            for head_name, head_reps in reps.items():
                reps_by_head[head_name].append(head_reps)

        return {
            head_name: torch.cat(head_reps, dim=0)
            for head_name, head_reps in reps_by_head.items()
        }

    def _multi_head_training_step(self, model, queries, targets, negatives):
        qry_reps = self._encode_multi_head_chunks(
            model,
            queries,
            self.args.gc_q_chunk_size,
            "qry_reps",
        )
        tgt_reps = self._encode_multi_head_chunks(
            model,
            targets,
            self.args.gc_p_chunk_size,
            "tgt_reps",
        )
        neg_reps = self._encode_multi_head_chunks(
            model,
            negatives,
            self.args.gc_q_chunk_size,
            "neg_reps",
        ) if negatives["neg"] else None
        if not isinstance(qry_reps, dict) or not isinstance(tgt_reps, dict):
            raise ValueError("multi_head_mlp training expects dict outputs from the projector heads.")

        base_model = self.accelerator.unwrap_model(model) if hasattr(self, "accelerator") else model
        head_names = list(base_model.projector.output_dims.keys())
        loss_weights = getattr(base_model, "multi_head_loss_weights", None) or [1.0] * len(head_names)
        orthogonal_weights = getattr(self.args, "multi_head_orthogonal_weights", None) or []
        if orthogonal_weights and len(orthogonal_weights) != len(head_names):
            raise ValueError(
                f"multi_head_orthogonal_weights length must match heads: "
                f"{len(orthogonal_weights)} vs {len(head_names)} ({head_names})"
            )
        if not orthogonal_weights:
            orthogonal_weights = [float(self.args.orthogonal_loss or 0.0)] * len(head_names)
        orthogonal_scale = linear_warmup_scale(self.state.global_step, self.args.orthogonal_warmup_steps)

        total_loss = None
        contrastive_loss_sum = None
        orthogonal_loss_sum = None
        loss_weight_sum = 0.0
        metrics = {}
        for idx, head_name in enumerate(head_names):
            head_qry = qry_reps[head_name]
            head_tgt = tgt_reps[head_name]
            head_neg = neg_reps[head_name] if isinstance(neg_reps, dict) else None

            loss_out = self.loss_fn(head_qry, head_tgt, head_neg)
            if isinstance(loss_out, tuple):
                head_loss, head_metrics = loss_out
            else:
                head_loss, head_metrics = loss_out, None

            weight = loss_weights[idx] if idx < len(loss_weights) else 1.0
            weighted_head_loss = head_loss * weight
            total_loss = weighted_head_loss if total_loss is None else total_loss + weighted_head_loss
            contrastive_loss_sum = weighted_head_loss if contrastive_loss_sum is None else contrastive_loss_sum + weighted_head_loss
            loss_weight_sum += float(weight)
            head_loss_detached = head_loss.detach()
            metrics[f"head_{head_name}_loss"] = (head_loss_detached / self._dist_loss_scale_factor).item()
            metrics[f"head_{head_name}_weighted_loss"] = ((weighted_head_loss.detach()) / self._dist_loss_scale_factor).item()
            metrics[f"head_{head_name}_loss_raw_scaled"] = head_loss_detached.item()
            if head_metrics is not None:
                metrics.update({f"head_{head_name}_{k}": v for k, v in head_metrics.items()})

            if self._multi_head_aux_loss_fn is not None:
                orth_loss, raw_orth_loss = self._multi_head_aux_loss_fn(
                    head_qry,
                    head_tgt,
                    use_abs=True,
                    sync_loss=False,
                    return_raw=True,
                )
                orth_weight = orthogonal_weights[idx] if idx < len(orthogonal_weights) else 0.0
                weighted_orth_loss = orth_loss * orth_weight * orthogonal_scale
                total_loss = total_loss + weighted_orth_loss
                orthogonal_loss_sum = weighted_orth_loss if orthogonal_loss_sum is None else orthogonal_loss_sum + weighted_orth_loss
                metrics[f"head_{head_name}_orthogonal_loss"] = raw_orth_loss.item()
                metrics[f"head_{head_name}_orthogonal_weighted_loss"] = (
                    weighted_orth_loss.detach() / self._dist_loss_scale_factor
                ).item()
                metrics[f"head_{head_name}_orthogonal_weight"] = float(orth_weight)

        if contrastive_loss_sum is not None:
            contrastive_loss_log = contrastive_loss_sum.detach() / self._dist_loss_scale_factor
            metrics["multi_head_contrastive_loss_sum"] = contrastive_loss_log.item()
            if loss_weight_sum > 0:
                metrics["multi_head_contrastive_loss_mean"] = (contrastive_loss_log / loss_weight_sum).item()
        if orthogonal_loss_sum is not None:
            metrics["multi_head_orthogonal_weighted_loss_sum"] = (
                orthogonal_loss_sum.detach() / self._dist_loss_scale_factor
            ).item()
        if total_loss is not None:
            metrics["multi_head_objective_loss"] = (total_loss.detach() / self._dist_loss_scale_factor).item()

        return total_loss, metrics

    def _backward_multi_head_loss(self, loss: torch.Tensor):
        kwargs = {}

        if self.args.optim in [OptimizerNames.LOMO, OptimizerNames.ADALOMO]:
            kwargs["learning_rate"] = self._get_learning_rate()

        if self.args.n_gpu > 1:
            loss = loss.mean()

        if self.args.gradient_accumulation_steps > 1:
            loss = loss / self.args.gradient_accumulation_steps

        if self.use_apex:
            with amp.scale_loss(loss, self.optimizer) as scaled_loss:
                scaled_loss.backward()
        else:
            if self.accelerator.distributed_type == DistributedType.DEEPSPEED:
                kwargs["scale_wrt_gas"] = False
            self.accelerator.backward(loss, **kwargs)

        return loss.detach()

    def _save_single_head_checkpoints(self, output_dir: str, encoder_state_dict: dict):
        projector = getattr(self.model, "projector", None)
        if projector is None or not hasattr(projector, "heads"):
            return

        for head_name, head in projector.heads.items():
            head_output_dir = os.path.join(output_dir, f"head_{head_name}")
            os.makedirs(head_output_dir, exist_ok=True)
            print_master(f"Saving single-head checkpoint {head_name} to {head_output_dir}")

            self.model.encoder.save_pretrained(
                head_output_dir,
                state_dict=encoder_state_dict,
                safe_serialization=self.args.save_safetensors,
            )
            if self.tokenizer is not None:
                self.tokenizer.save_pretrained(head_output_dir)

            torch.save(self.args, os.path.join(head_output_dir, TRAINING_ARGS_NAME))
            self.model.encoder.config.to_json_file(os.path.join(head_output_dir, 'config.json'))

            single_head_projector_state = {
                f"heads.{head_name}.{key}": value.detach().cpu()
                for key, value in head.state_dict().items()
            }
            input_normalize = bool(
                getattr(self.model, "normalize", False)
                and getattr(self.model, "pooling", None) in {"linear", "mlp", "multi_head_mlp"}
            )
            save_projector_state_dict_artifacts(
                single_head_projector_state,
                head_output_dir,
                config_overrides={
                    "input_normalize": input_normalize,
                    "output_normalize": bool(getattr(self.model, "normalize", False)),
                },
            )

    def training_step(self, model, inputs, *args, **kwargs) -> torch.Tensor:
        model.train()
        queries, targets, negatives = inputs
        queries = batch_to_device(queries, model.device)
        targets = batch_to_device(targets, model.device)
        negatives = batch_to_device(negatives, model.device)
        queries, targets, negatives = {'qry': queries}, {'tgt': targets}, {'neg': negatives}

        _distributed = self.args.local_rank > -1
        deepspeed = self.deepspeed if self.is_deepspeed_enabled else None
        if deepspeed is not None:
            deepspeed.set_gradient_accumulation_boundary(is_boundary=self.accelerator.sync_gradients)
        if self._is_multi_head_model(model):
            loss = self._multi_head_training_step(model, queries, targets, negatives)
            if type(loss) == tuple:
                loss, metrics = loss
            else:
                metrics = None
            loss = self._backward_multi_head_loss(loss)
            loss = (loss, metrics)
        elif _distributed:
            self.gc.models = [model, model, model]
            loss = self.gc(queries, targets, negatives, no_sync_except_last=_distributed, deepspeed=deepspeed)
        else:
            loss = model(queries, targets, negatives)

        self._compute_batch_load_diag(model, queries["qry"], targets["tgt"])

        if type(loss) ==  tuple:
            loss, metrics = loss
            if metrics is not None:
                if "hsic_loss" in metrics:
                    self._last_hsic_loss = float(metrics["hsic_loss"])
                orth_diag_metrics = {k: v for k, v in metrics.items() if k.startswith("orth/")}
                hsic_diag_metrics = {k: v for k, v in metrics.items() if k.startswith("hsic/") or k.startswith("slot_pair/")}
                if orth_diag_metrics:
                    self._last_orthogonal_layer_losses = self._aggregate_diag_logs(orth_diag_metrics)
                    self._last_orthogonal_diag_step = self.state.global_step
                if hsic_diag_metrics:
                    self._last_hsic_diag_metrics = self._aggregate_diag_logs(hsic_diag_metrics)
                    self._last_hsic_diag_step = self.state.global_step
                metrics = {
                    k: v
                    for k, v in metrics.items()
                    if not (k.startswith("orth/") or k.startswith("hsic/") or k.startswith("slot_pair/"))
                }
            task_type = kwargs.get("task_type", "retrieval")
            if metrics is not None:
                metrics = {
                    f"{task_type}_{k}": v
                    for k, v in metrics.items()
                }
        else:
            metrics = None

        return loss / self._dist_loss_scale_factor, metrics


    def _save(self, output_dir: Optional[str] = None, state_dict=None):
        print_master(f"Saving model to {output_dir}")
        os.makedirs(output_dir, exist_ok=True)

        if state_dict is None:
            state_dict = self.model.state_dict()
        prefix = 'encoder.'
        # assert all(k.startswith(prefix) for k in state_dict.keys()), list(state_dict.keys())
        state_dict = {k[len(prefix):]: v for k, v in state_dict.items() if k.startswith(prefix)}
        self.model.encoder.save_pretrained(
            output_dir, state_dict=state_dict, safe_serialization=self.args.save_safetensors
        )

        if self.tokenizer is not None:
            self.tokenizer.save_pretrained(output_dir)

        torch.save(self.args, os.path.join(output_dir, TRAINING_ARGS_NAME))
        self.model.encoder.config.to_json_file(os.path.join(output_dir, 'config.json'))
        if self.model.projector is not None:
            input_normalize = bool(
                getattr(self.model, "normalize", False)
                and getattr(self.model, "pooling", None) in {"linear", "mlp", "multi_head_mlp"}
            )
            save_projector_artifacts(
                self.model.projector,
                output_dir,
                pooling=getattr(self.model, "pooling", None),
                input_normalize=input_normalize,
                output_normalize=bool(getattr(self.model, "normalize", False)),
            )
            if getattr(self.args, "save_multi_head_standalone_heads", False):
                self._save_single_head_checkpoints(output_dir, state_dict)
        if self.model.ret_mlp_heads is not None:
            torch.save(self.model.ret_mlp_heads.state_dict(), os.path.join(output_dir, 'ret_mlp_heads.pth'))


class OpenQATrainer(Trainer):
    def __init__(self, *args, multitask_dataloader=None, **kwargs):
        super(OpenQATrainer, self).__init__(*args, **kwargs)
        self.model_accepts_loss_kwargs = False  # HACK: fix unconsistency for Gradient Accumulation Steps loss
        self._multitask_dataloader = multitask_dataloader

        # 初始化 orthogonal loss (仅当设置时启用)
        self.is_ddp = dist.is_initialized()
        if self.is_ddp and self.args.orthogonal_loss_openqa is not None and self.args.orthogonal_loss_openqa > 0:
            self.aux_loss_fn = DistributedOrthogonalLoss(
                loss_weights=self.args.orthogonal_loss_openqa,
                margin=self.args.orthogonal_margin
            )
        else:
            self.aux_loss_fn = None

    def _load_from_checkpoint(self, resume_from_checkpoint, model=None):
        self.model_args.checkpoint_path = resume_from_checkpoint
        logger.info(f"Loading checkpoint from {resume_from_checkpoint}")
        self.model = MMEBModel.load(self.model_args)
        self.model_wrapped = self.model
    
    def _save(self, output_dir: Optional[str] = None, state_dict=None):
        print_master(f"Saving model to {output_dir}")
        os.makedirs(output_dir, exist_ok=True)

        if state_dict is None:
            state_dict = self.model.state_dict()
        prefix = 'encoder.'
        encoder_modules = [k.startswith(prefix) for k in state_dict.keys()]
        if all(encoder_modules):
            # assert all(encoder_modules), list(state_dict.keys())
            state_dict = {k[len(prefix):]: v for k, v in state_dict.items()}
            self.model.encoder.save_pretrained(
                output_dir, state_dict=state_dict, safe_serialization=self.args.save_safetensors
            )

            if self.tokenizer is not None:
                self.tokenizer.save_pretrained(output_dir)

            torch.save(self.args, os.path.join(output_dir, TRAINING_ARGS_NAME))
            self.model.encoder.config.to_json_file(os.path.join(output_dir, 'config.json'))
        else:
            super()._save(output_dir, state_dict)  # model not warpped as encoder

    def get_train_dataloader(self) -> DataLoader:
        
        """
        override original trainer's method to disable self.accelerator.prepare since it will wrap DataLoaderDispatcher and lead to
        (1) `RuntimeError: You can't use batches of different size with `dispatch_batches=True` or when using an `IterableDataset`.`
        (2) all outputs of dataloader must be tensors
        """
        if self._multitask_dataloader:
            return self._multitask_dataloader
        
        if self.train_dataset is None:
            raise ValueError("Trainer: training requires a train_dataset.")
        train_dataset = self.train_dataset
        data_collator = self.data_collator
        train_dataset = self._remove_unused_columns(train_dataset, description="training")
        dataloader_params = {
            "batch_size": self._train_batch_size,
            "collate_fn": data_collator,
            "num_workers": self.args.dataloader_num_workers,
            "pin_memory": self.args.dataloader_pin_memory,
            "persistent_workers": self.args.dataloader_persistent_workers,
        }

        if not isinstance(train_dataset, torch.utils.data.IterableDataset):
            dataloader_params["sampler"] = self._get_train_sampler()
            dataloader_params["drop_last"] = self.args.dataloader_drop_last
            dataloader_params["worker_init_fn"] = seed_worker
            dataloader_params["prefetch_factor"] = self.args.dataloader_prefetch_factor
        else:
            dataloader_params["sampler"] = None
            dataloader_params["shuffle"] = False
            dataloader_params["drop_last"] = True
            dataloader_params["prefetch_factor"] = None # # tune on both prefetch_factor and persistent_workers will cause hang at epoch2
        dataloader =  DataLoader(train_dataset, **dataloader_params)
        return dataloader


class MultiTaskTrainer(GradCacheLateProcessTrainer):
    def __init__(self, *args, multitask_dataloader=None, loss_weights=None, **kwargs):
        super().__init__(*args, **kwargs)
        self._multitask_dataloader = multitask_dataloader
        self._loss_weights = loss_weights
        self.model_accepts_loss_kwargs = False
        assert len(self.args.data_weights) % len(self.args.task_types) == 0, f"len(data_weights) % len(task_types) != 0: {self.args.data_weights} vs {self.args.task_types}"
        assert sum(self.args.data_weights) % self.args.gradient_accumulation_steps == 0, f"sum(data_weights) % gradient_accumulation_steps != 0: {self.args.data_weights}"
        # TODO: 如果以后每个周期 qa 的 acc 不固定，需要改一下
        data_weights_cycles = [
            [self.args.data_weights[j] for j in range(i, len(self.args.data_weights), len(self.args.task_types))]
            for i in range(len(self.args.task_types))
        ]
        self.task_grad_acc_dict = {}
        for task_type, data_weights_cycle in zip(self.args.task_types, data_weights_cycles):
            self.task_grad_acc_dict[task_type] = data_weights_cycle

        # 初始化蒸馏损失
        if self.args.distillation_loss:
            self.distillation_fn = DistributedDistillationLoss(
                temperature=self.args.distillation_temperature,
                warmup_steps=self.args.distillation_warmup_steps,
            )
        else:
            self.distillation_fn = None

        # 初始化 orthogonal loss for openqa（仅当设置时启用）
        self.is_ddp = dist.is_initialized()
        if self.is_ddp and self.args.orthogonal_loss_openqa is not None and self.args.orthogonal_loss_openqa > 0:
            self.aux_loss_fn = DistributedOrthogonalLoss(
                loss_weights=self.args.orthogonal_loss_openqa,
                margin=self.args.orthogonal_margin
            )
        else:
            self.aux_loss_fn = None
        self.xseq_memory_bank = None
        self._xseq_internal_layers = sorted({int(layer) - 1 for layer in getattr(self.args, "xseq_layers", []) if int(layer) > 0})
        if self.args.xseq_enable and self._xseq_internal_layers:
            xseq_text_model = self._get_xseq_text_model(self.model)
            if xseq_text_model is None or not hasattr(xseq_text_model, "configure_xseq"):
                raise NotImplementedError("xseq_openqa currently requires a Qwen2.5-Omni thinker text model.")
            xseq_text_model.configure_xseq([layer_idx + 1 for layer_idx in self._xseq_internal_layers])
            self.xseq_memory_bank = XSeqMemoryBank(
                capacity=self.args.xseq_bank_size,
                topk=self.args.xseq_topk,
            )


    def get_train_dataloader(self) -> DataLoader:
        return self._multitask_dataloader

    def _get_xseq_text_model(self, model):
        root_model = self._get_mmeb_model(model)
        encoder = getattr(root_model, "encoder", None)
        if encoder is None:
            return None

        queue = [encoder]
        seen = set()
        while queue:
            current = queue.pop(0)
            if current is None:
                continue
            current_id = id(current)
            if current_id in seen:
                continue
            seen.add(current_id)

            if hasattr(current, "configure_xseq"):
                return current

            for attr in ("model", "base_model", "module"):
                child = getattr(current, attr, None)
                if child is not None:
                    queue.append(child)

            get_base_model = getattr(current, "get_base_model", None)
            if callable(get_base_model):
                try:
                    queue.append(get_base_model())
                except Exception:
                    pass
        return None

    def _get_mmeb_model(self, model):
        return getattr(model, "module", model)

    def _should_run_xseq_diag(self) -> bool:
        if not self.args.xseq_enable or not self.args.xseq_log_slot_stats:
            return False
        diag_steps = max(int(getattr(self.args, "xseq_diag_steps", 0)), 0)
        if diag_steps <= 0:
            return False
        step = self.state.global_step
        if getattr(self, "_last_xseq_diag_step", None) == step:
            return False
        if step == 0:
            return True
        return step % diag_steps == 0

    def _collect_openqa_outputs(self, outputs):
        hidden_states = None
        if hasattr(outputs, "hidden_states"):
            hidden_states = outputs.hidden_states
        elif isinstance(outputs, dict):
            hidden_states = outputs.get("hidden_states")
        last_hidden = hidden_states[-1] if hidden_states is not None else None
        return hidden_states, last_hidden

    def _extract_openqa_slots(self, model, hidden_states, inputs):
        model = self._get_mmeb_model(model)
        sep_indices = inputs.get("sep_indices")
        cls_indices = inputs.get("cls_indices")
        slot_tokens = model.extract_slot_tokens(hidden_states[-1], sep_indices=sep_indices, cls_indices=cls_indices) if hidden_states is not None else None
        pooled_rep = model.pool_slot_tokens(
            slot_tokens,
            mlp_idx=inputs.get("mlp_idx"),
            head_name=getattr(model, "eval_head_name", None),
            target_dim=getattr(model, "target_dim", None),
        )
        layer_slots = {}
        for layer_idx in self._xseq_internal_layers:
            hidden_idx = layer_idx + 1
            if hidden_states is None or hidden_idx >= len(hidden_states):
                continue
            layer_slots[layer_idx] = model.extract_slot_tokens(
                hidden_states[hidden_idx],
                sep_indices=sep_indices,
                cls_indices=cls_indices,
            )
        slot_indices = model.extract_slot_indices(sep_indices=sep_indices, cls_indices=cls_indices, device=hidden_states[-1].device) if hidden_states is not None else None
        return slot_tokens, pooled_rep, layer_slots, slot_indices

    def _compute_openqa_aux_loss(self, chorus_tokens):
        if self.aux_loss_fn is None:
            return None, None
        ortho_loss, raw_ortho_loss = self.aux_loss_fn(
            chorus_tokens,
            use_abs=True,
            sync_loss=False,
            return_raw=True,
        )
        self._last_orthogonal_loss = raw_ortho_loss.item()
        ortho_scale = linear_warmup_scale(self.state.global_step, self.args.orthogonal_warmup_steps)
        return ortho_loss, ortho_scale

    def _get_seq2seq_loss(self, outputs, labels):
        if self.label_smoother is not None and labels is not None:
            return self.label_smoother(outputs, labels)
        return outputs["loss"] if isinstance(outputs, dict) else outputs[0]

    def _compute_openqa_loss_with_aux(self, model, inputs):
        local_inputs = dict(inputs)
        local_inputs["return_dict"] = True
        local_inputs["output_hidden_states"] = True

        labels = local_inputs.get("labels")
        outputs = model(**local_inputs)
        loss = self._get_seq2seq_loss(outputs, labels)
        hidden_states, _ = self._collect_openqa_outputs(outputs)
        chorus_tokens, _, _, _ = self._extract_openqa_slots(model, hidden_states, inputs)
        ortho_loss, ortho_scale = self._compute_openqa_aux_loss(chorus_tokens)
        if ortho_loss is not None:
            loss = loss + ortho_loss * ortho_scale
        return loss

    def _normalize_xseq_apply_to(self):
        raw_scopes = getattr(self.args, "xseq_apply_to", ["q"])
        if isinstance(raw_scopes, str):
            raw_scopes = raw_scopes.replace(",", " ").split()
        aliases = {
            "c": "c",
            "chorus": "c",
            "slot": "c",
            "slots": "c",
            "q": "q",
            "question": "q",
            "query": "q",
            "a": "a",
            "answer": "a",
            "none": None,
            "off": None,
            "false": None,
        }
        scopes = set()
        for scope in raw_scopes:
            for item in str(scope).replace(",", " ").split():
                key = item.strip().lower()
                if not key:
                    continue
                if key not in aliases:
                    raise ValueError(f"Unsupported xseq_apply_to scope: {scope}. Expected any of c, q, a.")
                if aliases[key] is not None:
                    scopes.add(aliases[key])
        return scopes

    def _make_xseq_token_mask(self, inputs, slot_indices=None):
        labels = inputs.get("labels")
        input_ids = inputs.get("input_ids")
        ref = labels if labels is not None else input_ids
        if ref is None:
            return None
        token_mask = torch.zeros_like(ref, dtype=torch.bool)
        scopes = self._normalize_xseq_apply_to()
        if not scopes:
            return token_mask

        if "c" in scopes and slot_indices is not None:
            slot_indices = slot_indices.to(token_mask.device)
            batch_indices = torch.arange(token_mask.shape[0], device=token_mask.device).unsqueeze(1).expand_as(slot_indices)
            valid_slots = (slot_indices >= 0) & (slot_indices < token_mask.shape[1])
            token_mask[batch_indices[valid_slots], slot_indices[valid_slots]] = True

        sep_indices = inputs.get("sep_indices")
        if "q" in scopes and sep_indices is not None and sep_indices.shape[-1] >= 3:
            sep_indices = sep_indices.to(token_mask.device)
            for batch_idx in range(token_mask.shape[0]):
                q_start = int(sep_indices[batch_idx, -3].item())
                q_end = int(sep_indices[batch_idx, -2].item())
                q_start = max(q_start, 0)
                q_end = min(q_end, token_mask.shape[1])
                if q_end > q_start:
                    token_mask[batch_idx, q_start:q_end] = True

        if "a" in scopes:
            if labels is not None:
                # Causal LM CE uses logits[:, :-1] to predict labels[:, 1:].
                # Enable xseq at logit positions whose next-token label participates in the loss.
                token_mask[:, :-1] |= labels[:, 1:].ne(-100)
            elif sep_indices is not None and sep_indices.shape[-1] >= 2:
                sep_indices = sep_indices.to(token_mask.device)
                for batch_idx in range(token_mask.shape[0]):
                    a_start = int(sep_indices[batch_idx, -2].item())
                    a_start = max(a_start, 0)
                    if token_mask.shape[1] > a_start:
                        token_mask[batch_idx, a_start:] = True

        return token_mask

    def _make_sample_ids(self, inputs):
        ids = inputs.get("id")
        if ids is not None:
            return [str(x) for x in ids]
        return [f"sample_{self.state.global_step}_{idx}" for idx in range(inputs["input_ids"].shape[0])]

    def _make_cls_types(self, inputs):
        cls_types = inputs.get("cls_type")
        if cls_types is not None:
            return [x if x not in {"", "None"} else None for x in cls_types]
        return [None] * inputs["input_ids"].shape[0]

    def _build_xseq_state(self, model, pooled_rep, slot_tokens, layer_slots, slot_indices, inputs):
        model = self._get_mmeb_model(model)
        ref_tensor = pooled_rep if pooled_rep is not None else slot_tokens
        if self.xseq_memory_bank is None or ref_tensor is None or slot_indices is None:
            return None, None
        sample_ids = self._make_sample_ids(inputs)
        cls_types = self._make_cls_types(inputs)
        retrieved = self.xseq_memory_bank.retrieve(
            query_reps=pooled_rep,
            query_slots=slot_tokens,
            sample_ids=sample_ids,
            cls_types=cls_types,
            layers=self._xseq_internal_layers,
            topk=self.args.xseq_topk,
            similarity_type=self.args.similarity_type,
            same_cls_only=self.args.xseq_same_cls_only,
            sample_softmax=self.args.xseq_sample_softmax,
            sample_tau=self.args.xseq_sample_tau,
            device=ref_tensor.device,
            dtype=ref_tensor.dtype,
        )
        token_mask = self._make_xseq_token_mask(inputs, slot_indices=slot_indices)
        xseq_state = {
            "sample_gate": retrieved["sample_gate"].to(device=ref_tensor.device, dtype=ref_tensor.dtype),
            "sample_cos": retrieved["sample_cos"].to(device=ref_tensor.device, dtype=ref_tensor.dtype),
            "external_slots": retrieved["slots_by_layer"],
            "token_mask": token_mask.to(ref_tensor.device) if token_mask is not None else None,
            "cls_indices": slot_indices.to(ref_tensor.device),
            "slot_softmax": self.args.xseq_slot_softmax,
            "slot_tau": float(self.args.xseq_slot_tau),
            "slot_mean_preserve": self.args.xseq_slot_mean_preserve,
        }
        return xseq_state, retrieved

    def _compute_xseq_openqa_loss(self, model, inputs):
        core_model = self._get_mmeb_model(model)
        local_inputs = dict(inputs)
        local_inputs["return_dict"] = True
        local_inputs["output_hidden_states"] = True
        bank_ready = (
            self.args.xseq_enable
            and self.xseq_memory_bank is not None
            and len(self.xseq_memory_bank) >= self.args.xseq_min_bank_size
        )
        outputs_local = model(**local_inputs)
        local_loss = self._get_seq2seq_loss(outputs_local, inputs.get("labels"))
        hidden_states_local, _ = self._collect_openqa_outputs(outputs_local)
        slot_tokens, pooled_rep, layer_slots, slot_indices = self._extract_openqa_slots(core_model, hidden_states_local, inputs)
        if isinstance(pooled_rep, dict):
            raise ValueError(
                "xseq_openqa with pooling='multi_head_mlp' requires eval_head_name to select a single head."
            )
        local_per_sample = per_sample_ce_loss(outputs_local.logits, inputs["labels"]) if inputs.get("labels") is not None else None

        sample_ids = self._make_sample_ids(inputs)
        cls_types = self._make_cls_types(inputs)

        xseq_diag_logs = {}
        xseq_diag_logs.update(compute_similarity_spectrum(pooled_rep) if pooled_rep is not None else {})
        if self.xseq_memory_bank is not None:
            xseq_diag_logs["xseq/bank_size"] = float(len(self.xseq_memory_bank))

        use_slot_aligned_similarity = self.args.similarity_type == "slot_aligned"
        has_sample_similarity_inputs = (
            slot_tokens is not None and slot_tokens.dim() == 3
            if use_slot_aligned_similarity
            else pooled_rep is not None and pooled_rep.dim() == 2
        )

        use_xseq = bank_ready and has_sample_similarity_inputs and slot_indices is not None

        final_loss = local_loss
        ortho_loss = None
        ortho_scale = None
        if use_xseq:
            xseq_state, retrieved = self._build_xseq_state(core_model, pooled_rep, slot_tokens, layer_slots, slot_indices, inputs)
            xseq_diag_logs["xseq/candidate_count_mean"] = retrieved["candidate_count"].mean().item()
            xseq_diag_logs["xseq/sample_gate_mean"] = xseq_state["sample_gate"].mean().item()
            xseq_diag_logs["xseq/sample_cos_mean"] = xseq_state["sample_cos"].mean().item()

            xseq_inputs = dict(inputs)
            xseq_inputs["return_dict"] = True
            xseq_inputs["output_hidden_states"] = self.aux_loss_fn is not None
            xseq_inputs["xseq_state"] = xseq_state
            del outputs_local, hidden_states_local
            outputs_xseq = model(**xseq_inputs)
            final_loss = self._get_seq2seq_loss(outputs_xseq, inputs.get("labels"))
            if self.aux_loss_fn is not None:
                hidden_states_xseq, _ = self._collect_openqa_outputs(outputs_xseq)
                slot_tokens_xseq, _, _, _ = self._extract_openqa_slots(core_model, hidden_states_xseq, inputs)
                ortho_loss, ortho_scale = self._compute_openqa_aux_loss(slot_tokens_xseq)

            if self.args.xseq_log_loss_delta and local_per_sample is not None and inputs.get("labels") is not None:
                xseq_per_sample = per_sample_ce_loss(outputs_xseq.logits, inputs["labels"])
                xseq_diag_logs.update(summarize_loss_delta(xseq_per_sample - local_per_sample))
                xseq_diag_logs["xseq/loss_local_only"] = local_loss.detach().item()
                xseq_diag_logs["xseq/loss_with_xseq"] = final_loss.detach().item()
                xseq_diag_logs["xseq/loss_delta_token_mean"] = (final_loss - local_loss).detach().item()
        elif self.args.xseq_log_loss_delta:
            zero_delta = local_per_sample.detach().new_zeros(local_per_sample.shape) if local_per_sample is not None else torch.zeros((1,), device=local_loss.device)
            xseq_diag_logs.update(summarize_loss_delta(zero_delta))
            xseq_diag_logs["xseq/loss_local_only"] = local_loss.detach().item()
            xseq_diag_logs["xseq/loss_with_xseq"] = local_loss.detach().item()
            xseq_diag_logs["xseq/loss_delta_token_mean"] = 0.0
        if not use_xseq:
            ortho_loss, ortho_scale = self._compute_openqa_aux_loss(slot_tokens)

        if ortho_loss is not None:
            final_loss = final_loss + ortho_loss * ortho_scale

        if self.args.xseq_log_slot_stats and self._should_run_xseq_diag():
            diag_batch_size = max(int(self.args.xseq_diag_batch_size), 1)
            xseq_diag_logs.update(
                compute_xseq_slot_diagnostics(
                    layer_slots,
                    hsic_fn=compute_slot_hsic_metrics,
                    batch_size_limit=diag_batch_size,
                )
            )
            self._last_xseq_diag_step = self.state.global_step

        if xseq_diag_logs:
            self._last_xseq_diag_metrics = self._aggregate_diag_logs(xseq_diag_logs)

        if self.xseq_memory_bank is not None and (
            (pooled_rep is not None and pooled_rep.dim() == 2)
            or (slot_tokens is not None and slot_tokens.dim() == 3)
        ):
            self.xseq_memory_bank.update(
                sample_ids=sample_ids,
                cls_types=cls_types,
                sample_reps=pooled_rep,
                slots_by_layer=layer_slots,
                sample_slots=slot_tokens,
            )
        return final_loss
    
    def _training_step(
        self, 
        model, 
        inputs, 
        num_items_in_batch=None,
    ) -> torch.Tensor:
        model.train()
        if hasattr(self.optimizer, "train") and callable(self.optimizer.train):
            self.optimizer.train()

        inputs = self._prepare_inputs(inputs)
        with self.compute_loss_context_manager():
            loss = self.compute_loss(model, inputs, num_items_in_batch=num_items_in_batch)

        del inputs
        if (
            self.args.torch_empty_cache_steps is not None
            and self.state.global_step % self.args.torch_empty_cache_steps == 0
        ):
            torch.cuda.empty_cache()

        kwargs = {}

        # For LOMO optimizers you need to explicitly use the learnign rate
        if self.args.optim in [OptimizerNames.LOMO, OptimizerNames.ADALOMO]:
            kwargs["learning_rate"] = self._get_learning_rate()

        if self.args.n_gpu > 1:
            loss = loss.mean()  # mean() to average on multi-gpu parallel training

        loss = loss * self.openqa_loss_weight
        if self.use_apex:
            with amp.scale_loss(loss, self.optimizer) as scaled_loss:
                scaled_loss.backward()
        else:
            # Finally we need to normalize the loss for reporting if GA loss bug is not fixed during compute loss
            if not self.model_accepts_loss_kwargs and self.compute_loss_func is None:
                loss = loss / self.openqa_gradient_accumulation_steps

            # Turning off loss scaling w.r.t. gradient accumulation when DeepSpeed is enabled
            # https://github.com/huggingface/transformers/pull/35808
            if self.accelerator.distributed_type == DistributedType.DEEPSPEED:
                kwargs["scale_wrt_gas"] = False

            self.accelerator.backward(loss, **kwargs)

            return loss.detach()
    
    def compute_loss(self, model, inputs, *args, **kwargs):
        if not isinstance(inputs, (list, tuple)):
            # 检查是否是蒸馏模式输入
            if isinstance(inputs, dict) and inputs.get("distill_openqa", False):
                return self._compute_distillation_loss(model, inputs, *args, **kwargs)
            task_type = inputs["task_type"][0] if isinstance(inputs.get("task_type"), list) and inputs["task_type"] else "openqa"
            if task_type == "xseq_openqa":
                return self._compute_xseq_openqa_loss(model, inputs)
            if "openqa" in task_type:
                return self._compute_openqa_loss_with_aux(model, inputs)
            return Trainer.compute_loss(self, model, inputs, *args, **kwargs)
        else:
            return super().compute_loss(model, inputs, *args, **kwargs)

    def _compute_distillation_loss(self, model, inputs, *args, **kwargs) -> torch.Tensor:
        """
        计算蒸馏损失：L_total = L_ce + lambda * L_kl
        """
        comp_inputs = inputs["comp"]
        nat_inputs = inputs["nat"]

        # === Teacher Forward (nat) - 冻结、无梯度、无 dropout ===
        orig_training = model.training
        with torch.inference_mode():
            model.eval()
            outputs_nat = model(**nat_inputs)

        # 恢复原始模式（训练时就是 train）
        if orig_training:
            model.train()
        else:
            model.eval()

        # === Student Forward (comp) ===
        outputs_comp = model(**comp_inputs)
        loss_ce = outputs_comp.loss

        # === Distillation Loss ===
        if self.distillation_fn is not None:
            # 更新 step
            self.distillation_fn.update_step(self.state.global_step)

            # 提取 logits 并立即释放不需要的大对象
            student_logits = outputs_comp.logits  # [B, L, V]
            teacher_logits = outputs_nat.logits.detach()  # [B, L, V]
            del outputs_comp, outputs_nat  # 释放内存

            # 可选的对齐检查（前 N 步启用）
            if self.state.global_step < 10:
                self._check_label_alignment(comp_inputs['labels'], nat_inputs['labels'])

            # 计算蒸馏损失
            loss_kl, lambda_kl = self.distillation_fn(
                student_logits=student_logits,
                teacher_logits=teacher_logits,
                labels=comp_inputs['labels'],
            )
            del student_logits, teacher_logits  # 释放内存

            # 组合损失
            loss_total = loss_ce + self.args.distillation_lambda * loss_kl

            # 保存供 logging 使用（使用标量避免保留引用）
            self._last_distillation_lambda = lambda_kl
            self._last_distillation_loss_kl = loss_kl.detach().item()

            return loss_total
        else:
            return loss_ce

    def _check_label_alignment(self, comp_labels: torch.Tensor, nat_labels: torch.Tensor):
        """检查 comp/nat 的答案 token 是否一致"""
        comp_answer = comp_labels[comp_labels != -100]
        nat_answer = nat_labels[nat_labels != -100]
        if comp_answer.shape[0] != nat_answer.shape[0] or not torch.equal(comp_answer, nat_answer):
            print_rank(f"[WARNING] Label mismatch detected! comp_ans={comp_answer}, nat_ans={nat_answer}")

    def training_step(self, model, inputs, *args, **kwargs) -> torch.Tensor:
        if not isinstance(inputs, (list, tuple)):
            task_types = inputs["task_type"]
            assert all(task_types[0] == task_types[i] for i in range(1, len(task_types))), "task_types must be same for all batches"
            assert 'openqa' in task_types[0], f"task_type must be openqa: {task_types[0]}"
            if self._loss_weights is not None:
                self.openqa_loss_weight = self._loss_weights[task_types[0]]
            # TODO: 如果以后每个周期 qa 的 acc 不固定，需要改一下
            grad_acc_cycle = self.task_grad_acc_dict[task_types[0]]
            assert all(grad_acc_cycle[0] == grad_acc_cycle[i] for i in range(1, len(grad_acc_cycle))), f"Only support fixed grad acc for openqa in each cycle: {grad_acc_cycle}"
            self.openqa_gradient_accumulation_steps = grad_acc_cycle[0]

            return self._training_step(model, inputs, *args, **kwargs), None, task_types[0]  # openqa
        else:
            task_types = inputs[0]["task_type"]
            assert all(task_types[0] == task_types[i] for i in range(1, len(task_types))), "task_types must be same for all batches"
            if self._loss_weights is not None:
                self.gc.retrv_loss_weight = self._loss_weights[task_types[0]]
            kwargs["task_type"] = task_types[0]
            return super().training_step(model, inputs, *args, **kwargs) + (task_types[0], )


class DynamicLossWeight(TrainerCallback):
    def __init__(self, task_types, loss_weights, warmup_steps=100, strategy='fixed'):
        assert len(task_types) == len(loss_weights), "task_types and loss_weight must have same length"
        self.loss_weights = dict(zip(task_types, loss_weights))
        self.warmup_steps = warmup_steps
        self.strategy = strategy

    def __getitem__(self, key):
        return self.loss_weights[key]
    
    def on_step_end(self, args, state, control, **kwargs):
        if self.strategy == 'fixed':
            return
        else:
            raise NotImplementedError(f"unknown strategy [{self.strategy}]")
