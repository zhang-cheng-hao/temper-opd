#!/bin/bash

set -euo pipefail

export NCCL_DEBUG="${NCCL_DEBUG:-WARN}"
export NCCL_TIMEOUT="${NCCL_TIMEOUT:-6000}"
export TORCH_NCCL_BLOCKING_WAIT=1
export TORCH_NCCL_ASYNC_ERROR_HANDLING=1
export TORCH_NCCL_TIMEOUT="${TORCH_NCCL_TIMEOUT:-6000}"
export NCCL_COMM_TIMEOUT="${NCCL_COMM_TIMEOUT:-6000}"
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"

NNODES="${1:-${NNODES:-1}}"
NODE_RANK="${2:-${NODE_RANK:-0}}"
export NNODES NODE_RANK

GPUS_PER_NODE="${GPUS_PER_NODE:-1}"
CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
WORLD_SIZE=$((NNODES * GPUS_PER_NODE))

if [ "$NNODES" -eq 1 ]; then
    MASTER_ADDR="${MASTER_ADDR:-localhost}"
else
    MASTER_ADDR="${MASTER_ADDR:-10.82.121.98}"
fi
MASTER_PORT="${MASTER_PORT:-2207}"
RDZV_ID="${RDZV_ID:-musid_openqa_t4_warm50_step150}"

MODE="${MODE:-xseq}"
case "$MODE" in
    baseline)
        TASK_TYPE="openqa"
        DATASET_CONFIG="${DATASET_CONFIG:-$REPO_DIR/experiments/musid/yaml/musid_openqa.yaml}"
        XSEQ_ARGS=""
        ;;
    xseq)
        TASK_TYPE="xseq_openqa"
        DATASET_CONFIG="${DATASET_CONFIG:-$REPO_DIR/experiments/musid/yaml/musid_xseq_openqa.yaml}"
        XSEQ_ARGS="--xseq_enable True --xseq_layers 28 32 36 --xseq_topk ${XSEQ_TOPK:-4} --xseq_bank_size ${XSEQ_BANK_SIZE:-512} --xseq_min_bank_size ${XSEQ_MIN_BANK_SIZE:-32} --xseq_same_cls_only ${XSEQ_SAME_CLS_ONLY:-True} --xseq_sample_softmax ${XSEQ_SAMPLE_SOFTMAX:-True} --xseq_sample_tau ${XSEQ_SAMPLE_TAU:-0.07} --xseq_slot_softmax ${XSEQ_SLOT_SOFTMAX:-False} --xseq_slot_tau ${XSEQ_SLOT_TAU:-0.07} --xseq_slot_mean_preserve ${XSEQ_SLOT_MEAN_PRESERVE:-True} --xseq_diag_batch_size ${XSEQ_DIAG_BATCH_SIZE:-8} --xseq_diag_steps ${XSEQ_DIAG_STEPS:-10} --xseq_log_loss_delta ${XSEQ_LOG_LOSS_DELTA:-True} --xseq_log_slot_stats ${XSEQ_LOG_SLOT_STATS:-True}"
        ;;
    *)
        echo "Unsupported MODE=$MODE; use MODE=baseline or MODE=xseq" >&2
        exit 1
        ;;
esac

TOTAL_QA_BATCH_SIZE="${TOTAL_QA_BATCH_SIZE:-64}"
PER_DEVICE_QA_BATCH_SIZE="${PER_DEVICE_QA_BATCH_SIZE:-2}"
QA_ACC_STEP="${QA_ACC_STEP:-$((TOTAL_QA_BATCH_SIZE / (WORLD_SIZE * PER_DEVICE_QA_BATCH_SIZE)))}"
NUM_WORKERS="${NUM_WORKERS:-2}"
QA_INTERLEAVE_BATCH_SIZE="${QA_INTERLEAVE_BATCH_SIZE:-1}"
LR="${LR:-5e-5}"
MAX_STEPS="${MAX_STEPS:-150}"
SAVE_STEPS="${SAVE_STEPS:-50}"
LOGGING_STEPS="${LOGGING_STEPS:-1}"
WARMUP_STEPS="${WARMUP_STEPS:-50}"

ORTHO_W="${ORTHO_W:-0.5}"
ORTHO_M="${ORTHO_M:-0.0}"
O_WARMUP_STEPS="${O_WARMUP_STEPS:-50}"

OUTPUT_ROOT="${OUTPUT_ROOT:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs}"
MODEL_NAME="${MODEL_NAME:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/LLaMA-Factory/saves/qwen2_5omni-3b/sft_datav2/merge}"

if [ "$GPUS_PER_NODE" -le 0 ]; then
    echo "GPUS_PER_NODE must be > 0, got $GPUS_PER_NODE" >&2
    exit 1
fi

if [ "$NNODES" -le 0 ]; then
    echo "NNODES must be > 0, got $NNODES" >&2
    exit 1
fi

if [ ! -d "$MODEL_NAME" ]; then
    echo "MODEL_NAME does not exist: $MODEL_NAME" >&2
    exit 1
fi

if [ ! -f "$DATASET_CONFIG" ]; then
    echo "DATASET_CONFIG does not exist: $DATASET_CONFIG" >&2
    exit 1
fi

if [ $((TOTAL_QA_BATCH_SIZE % (WORLD_SIZE * PER_DEVICE_QA_BATCH_SIZE))) -ne 0 ]; then
    echo "TOTAL_QA_BATCH_SIZE=$TOTAL_QA_BATCH_SIZE must be divisible by WORLD_SIZE*PER_DEVICE_QA_BATCH_SIZE=$((WORLD_SIZE * PER_DEVICE_QA_BATCH_SIZE))" >&2
    exit 1
fi

if [ $((TOTAL_QA_BATCH_SIZE / (WORLD_SIZE * PER_DEVICE_QA_BATCH_SIZE))) -ne "$QA_ACC_STEP" ]; then
    echo "QA_ACC_STEP=$QA_ACC_STEP does not match TOTAL_QA_BATCH_SIZE/(WORLD_SIZE*PER_DEVICE_QA_BATCH_SIZE)" >&2
    exit 1
fi

export TOTAL_COMPRESS_TOKENS="${TOTAL_COMPRESS_TOKENS:-4}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface/datasets}"

export WANDB_DISABLED="${WANDB_DISABLED:-false}"
export WANDB_PROJECT="${WANDB_PROJECT:-VLM2Vec}"
export WANDB_RUN_GROUP="${WANDB_RUN_GROUP:-musid}"

TORCHRUN=$(command -v torchrun)
if [ -z "$TORCHRUN" ]; then
    echo "torchrun not found in PATH. Please activate the env first." >&2
    exit 1
fi

EXP_NAME="${EXP_NAME:-musid_${MODE}_t${TOTAL_COMPRESS_TOKENS}_ow${ORTHO_W}_warm${WARMUP_STEPS}_steps${MAX_STEPS}_bs${TOTAL_QA_BATCH_SIZE}}"
EXP_DIR="${EXP_DIR:-$OUTPUT_ROOT/$EXP_NAME}"
export WANDB_NAME="$EXP_NAME"
export WANDB_DIR="$EXP_DIR"

mkdir -p "$EXP_DIR/wandb"

echo "Python location: $(which python)"
echo "Python version: $(python --version)"
echo "torchrun: $TORCHRUN"
echo "MODE: $MODE"
echo "TASK_TYPE: $TASK_TYPE"
echo "MODEL_NAME: $MODEL_NAME"
echo "DATASET_CONFIG: $DATASET_CONFIG"
echo "EXP_DIR: $EXP_DIR"
echo "WORLD_SIZE: $WORLD_SIZE"
echo "CUDA_VISIBLE_DEVICES: $CUDA_VISIBLE_DEVICES"
echo "TOTAL_COMPRESS_TOKENS: $TOTAL_COMPRESS_TOKENS"
echo "TOTAL_QA_BATCH_SIZE: $TOTAL_QA_BATCH_SIZE"
echo "PER_DEVICE_QA_BATCH_SIZE: $PER_DEVICE_QA_BATCH_SIZE"
echo "QA_ACC_STEP: $QA_ACC_STEP"
echo "NUM_WORKERS: $NUM_WORKERS"

cmd="CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES \
    $TORCHRUN \
    --nproc_per_node=$GPUS_PER_NODE \
    --nnodes=$NNODES \
    --max_restarts=0 \
    --rdzv_backend=c10d \
    --rdzv_id=$RDZV_ID \
    --rdzv_endpoint=$MASTER_ADDR:$MASTER_PORT \
    --node_rank=$NODE_RANK \
    train.py \
    --seed 42 \
    --compression_mode \
    --max_grad_norm 0.5 \
    --task_types $TASK_TYPE \
    --split_cls_tokens_by_task False --cls_types video goods \
    --dataset_config $DATASET_CONFIG \
    --pooling none --similarity_type slot_aligned --normalize True --temperature 0.02 --native_prob 0.0 \
    --bf16 --deepspeed experiments/zero1.json \
    --split_layer 36 \
    --gradient_accumulation_steps $QA_ACC_STEP \
    --data_weights $QA_ACC_STEP \
    --loss_weights 0.5 \
    --orthogonal_loss_openqa $ORTHO_W --orthogonal_margin $ORTHO_M --orthogonal_warmup_steps $O_WARMUP_STEPS \
    --hsic_loss 0.00 --hsic_diag_steps 20 \
    --model_name $MODEL_NAME \
    --model_type qwen2_5_omni \
    --dataloader_num_workers $NUM_WORKERS --dataloader_pin_memory False --dataloader_persistent_workers False \
    --run_name $EXP_NAME --output_dir $EXP_DIR \
    --max_len 8192 --resize_min_pixels $((32*32)) --resize_max_pixels $((512*512)) \
    --per_device_train_batch_size 1 --per_device_retrv_train_batch_size 1 --per_device_openqa_train_batch_size $PER_DEVICE_QA_BATCH_SIZE \
    --qa_interleave_batch_size $QA_INTERLEAVE_BATCH_SIZE \
    --lr_scheduler_type cosine --learning_rate $LR --projector_lr $LR --weight_decay 0 --warmup_steps $WARMUP_STEPS \
    --max_steps $MAX_STEPS --save_steps $SAVE_STEPS --logging_steps $LOGGING_STEPS --save_safetensors True --remove_unused_columns False \
    --resume_from none --report_to wandb \
    $XSEQ_ARGS"

echo "$cmd"
eval "$cmd"
