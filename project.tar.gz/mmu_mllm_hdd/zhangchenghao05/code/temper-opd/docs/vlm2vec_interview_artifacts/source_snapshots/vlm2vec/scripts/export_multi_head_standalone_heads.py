#!/usr/bin/env python3
"""Export standalone per-head checkpoints from a multi-head projector checkpoint."""

import argparse
import json
import shutil
from pathlib import Path


PROJECTOR_WEIGHTS_NAME = "projector.pth"
PROJECTOR_CONFIG_NAME = "projector_config.json"

SKIP_FILE_NAMES = {
    PROJECTOR_WEIGHTS_NAME,
    PROJECTOR_CONFIG_NAME,
    "optimizer.pt",
    "scheduler.pt",
    "trainer_state.json",
    "scaler.pt",
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("checkpoint_dir", type=Path)
    parser.add_argument("--heads", nargs="*", default=None, help="Head names to export, e.g. 64 32 16.")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--hardlink", action="store_true", help="Hardlink shared checkpoint files when possible.")
    return parser.parse_args()


def discover_heads(state_dict):
    heads = []
    for key in state_dict:
        parts = key.split(".")
        if len(parts) >= 3 and parts[0] == "heads" and parts[1] not in heads:
            heads.append(parts[1])
    if not heads:
        raise ValueError("No multi-head projector weights found. Expected keys like heads.64.fc1.weight.")
    return heads


def copy_checkpoint_files(src_dir, dst_dir, hardlink=False):
    for src in src_dir.iterdir():
        if src.is_dir():
            continue
        if src.name in SKIP_FILE_NAMES or src.name.startswith("rng_state_"):
            continue
        dst = dst_dir / src.name
        if hardlink:
            try:
                dst.hardlink_to(src)
                continue
            except OSError:
                pass
        shutil.copy2(src, dst)


def make_single_head_config(config, state_dict, head_name):
    if config.get("projector_type") not in {None, "multi_head_mlp"} and config.get("pooling") != "multi_head_mlp":
        raise ValueError(f"Unsupported projector config for multi-head export: {config}")

    output_dims = dict(config.get("output_dims") or {})
    hidden_dims = config.get("hidden_dims")
    if hidden_dims is not None:
        hidden_dims = dict(hidden_dims)

    if head_name in output_dims:
        single_output_dims = {head_name: int(output_dims[head_name])}
    else:
        fc2_key = f"heads.{head_name}.fc2.weight"
        linear_key = f"heads.{head_name}.weight"
        if fc2_key in state_dict:
            single_output_dims = {head_name: int(state_dict[fc2_key].shape[0])}
        elif linear_key in state_dict:
            single_output_dims = {head_name: int(state_dict[linear_key].shape[0])}
        else:
            raise ValueError(f"Unable to infer output dim for head {head_name}")

    single_hidden_dims = None
    if hidden_dims and head_name in hidden_dims:
        single_hidden_dims = {head_name: int(hidden_dims[head_name])}

    single_config = dict(config)
    single_config.update(
        {
            "pooling": "multi_head_mlp",
            "projector_type": "multi_head_mlp",
            "output_dims": single_output_dims,
            "hidden_dims": single_hidden_dims,
        }
    )
    return single_config


def main():
    args = parse_args()
    import torch

    checkpoint_dir = args.checkpoint_dir
    projector_path = checkpoint_dir / PROJECTOR_WEIGHTS_NAME
    config_path = checkpoint_dir / PROJECTOR_CONFIG_NAME

    if not checkpoint_dir.is_dir():
        raise FileNotFoundError(f"checkpoint_dir not found: {checkpoint_dir}")
    if not projector_path.exists():
        raise FileNotFoundError(f"projector weights not found: {projector_path}")
    if not config_path.exists():
        raise FileNotFoundError(f"projector config not found: {config_path}")

    state_dict = torch.load(projector_path, map_location="cpu")
    with config_path.open("r", encoding="utf-8") as f:
        config = json.load(f)

    available_heads = discover_heads(state_dict)
    heads = args.heads or available_heads
    missing = [head for head in heads if head not in available_heads]
    if missing:
        raise ValueError(f"Unknown heads {missing}; available heads: {available_heads}")

    for head_name in heads:
        output_dir = checkpoint_dir / f"head_{head_name}"
        if output_dir.exists():
            if not args.overwrite:
                raise FileExistsError(f"{output_dir} exists; pass --overwrite to replace projector files.")
            shutil.rmtree(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        copy_checkpoint_files(checkpoint_dir, output_dir, hardlink=args.hardlink)

        single_state = {
            key: value.detach().cpu()
            for key, value in state_dict.items()
            if key.startswith(f"heads.{head_name}.")
        }
        torch.save(single_state, output_dir / PROJECTOR_WEIGHTS_NAME)
        single_config = make_single_head_config(config, state_dict, head_name)
        with (output_dir / PROJECTOR_CONFIG_NAME).open("w", encoding="utf-8") as f:
            json.dump(single_config, f, indent=2, sort_keys=True)
            f.write("\n")
        print(f"exported {head_name}: {output_dir}")


if __name__ == "__main__":
    main()
