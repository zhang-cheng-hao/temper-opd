#!/usr/bin/env python3
"""
分析 orthogonal loss 效果的脚本
用法:
    python scripts/analyze_orthogonal.py --checkpoint /path/to/checkpoint --dataset_config /path/to/config.yaml --output_dir ./analysis
"""
import os
import sys
import torch
import torch.nn.functional as F
import json
import numpy as np
from pathlib import Path
import re
import shlex
import glob

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from transformers import HfArgumentParser
from src.arguments import ModelArguments, DataArguments
from src.model.model import MMEBModel
from src.model.processor import load_processor, get_backbone_name, TOTAL_COMPRESS_TOKENS
from src.data.loader.mixed_dataset import init_mixed_dataset
from src.data.collator.train_collator import MultimodalDataCollator
from torch.utils.data import DataLoader

try:
    import matplotlib
    matplotlib.use('Agg')  # 非 GUI 后端
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False
    print("Warning: matplotlib not found, visualization will be skipped. Install with: pip install matplotlib")


def compute_sim_matrix(chorus_tokens, margin=0.1):
    """
    计算相似度矩阵和 orthogonal loss

    Args:
        chorus_tokens: (B, T, D) 其中 B=batch, T=compress_tokens, D=hidden_size

    Returns:
        dict containing sim matrix and statistics
    """
    B, T, D = chorus_tokens.shape

    # L2 normalize
    x_norm = F.normalize(chorus_tokens, p=2, dim=-1)

    # Similarity matrix: (B, T, T)
    sim = x_norm @ x_norm.transpose(-2, -1)

    # 取绝对值 (与 DistributedOrthogonalLoss 中的 use_abs=True 对应)
    sim = sim.abs()

    # 去掉对角线 (自己的相似度)
    sim_off_diag = sim.clone()
    for i in range(B):
        sim_off_diag[i].fill_diagonal_(0)

    # Orthogonal loss 计算
    loss = (sim_off_diag - margin).clamp_min(0).pow(2)
    loss = loss.sum(dim=(-1, -2)) / (T * (T - 1))
    loss = loss.mean()

    return {
        'sim': sim,  # (B, T, T)
        'sim_off_diag': sim_off_diag,  # (B, T, T) 对角线为0
        'loss': loss.item(),
        'T': T,
        'stats': {
            'sim_mean': sim.mean().item(),
            'sim_std': sim.std().item(),
            'sim_max': sim.max().item(),
            'sim_min': sim.min().item(),
            'off_diag_mean': sim_off_diag.mean().item(),
            'off_diag_std': sim_off_diag.std().item(),
            'off_diag_max': sim_off_diag.max().item(),
            'off_diag_min': sim_off_diag.min().item(),
        }
    }


def visualize_sim_matrix(sim_matrices, checkpoint_name, output_dir, batch_idx=0):
    """
    可视化���似度矩阵

    Args:
        sim_matrices: (B, T, T) 相似度矩阵
        checkpoint_name: checkpoint 名称
        output_dir: 输出目录
        batch_idx: batch 索引
    """
    if not HAS_MATPLOTLIB:
        return

    B, T, _ = sim_matrices.shape

    # 计算子图行列数
    n_cols = min(4, B)
    n_rows = (B + n_cols - 1) // n_cols

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(4 * n_cols, 4 * n_rows))
    if B == 1:
        axes = np.array([axes])
    axes = axes.flatten()

    for i in range(B):
        if i >= len(axes):
            break
        sim = sim_matrices[i].cpu().numpy()

        # 绘制热力图
        im = axes[i].imshow(sim, cmap='RdBu_r', vmin=-1, vmax=1, aspect='auto')
        axes[i].set_title(f'Sample {i}')
        axes[i].set_xlabel('Token Index')
        axes[i].set_ylabel('Token Index')

        # 添加数值标注
        for row in range(T):
            for col in range(T):
                axes[i].text(col, row, f'{sim[row, col]:.2f}',
                           ha='center', va='center', fontsize=8)

    # 隐藏多余的子图
    for i in range(B, len(axes)):
        axes[i].axis('off')

    plt.suptitle(f'{checkpoint_name} - Batch {batch_idx}', fontsize=14)
    plt.tight_layout()

    output_path = os.path.join(output_dir, f'sim_matrix_batch{batch_idx}.png')
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved visualization: {output_path}")


def plot_comparison(results_list, checkpoint_names, output_dir):
    if not HAS_MATPLOTLIB or len(results_list) != 2:
        return

    # 提取统计指标（按 batch 顺序）
    metrics = {
        'loss': ([r['loss'] for r in results_list[0]], [r['loss'] for r in results_list[1]]),
        'off_diag_mean': (
            [r['stats']['off_diag_mean'] for r in results_list[0]],
            [r['stats']['off_diag_mean'] for r in results_list[1]],
        ),
        'off_diag_std': (
            [r['stats']['off_diag_std'] for r in results_list[0]],
            [r['stats']['off_diag_std'] for r in results_list[1]],
        ),
        'off_diag_max': (
            [r['stats']['off_diag_max'] for r in results_list[0]],
            [r['stats']['off_diag_max'] for r in results_list[1]],
        ),
    }

    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    n_batches = len(results_list[0])
    x = np.arange(n_batches)
    width = 0.35

    for idx, (metric_name, (v1, v2)) in enumerate(metrics.items()):
        row = idx // 2
        col = idx % 2
        ax = axes[row, col]
        ax.bar(x - width/2, v1, width, label=checkpoint_names[0])
        ax.bar(x + width/2, v2, width, label=checkpoint_names[1])
        ax.set_xlabel('Batch')
        ax.set_ylabel(metric_name)
        ax.set_title(f'{metric_name} Comparison')
        ax.legend()
        ax.grid(True, alpha=0.3)

    plt.suptitle('Orthogonal Loss Effect Comparison', fontsize=16)
    plt.tight_layout()

    output_path = os.path.join(output_dir, 'comparison.png')
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"\nSaved comparison plot: {output_path}")


def _move_to_cuda(batch_inputs):
    for k, v in batch_inputs.items():
        if isinstance(v, torch.Tensor):
            batch_inputs[k] = v.cuda()
        elif isinstance(v, dict):
            for kk, vv in v.items():
                if isinstance(vv, torch.Tensor):
                    batch_inputs[k][kk] = vv.cuda()
    return batch_inputs


def _extract_chorus_tokens(hidden_states, attention_mask, total_compress_tokens, sep_indices=None):
    # Prefer sep_indices when available (openqa), otherwise fall back to last tokens (retrieval).
    if sep_indices is not None:
        # sep_indices: [ctoken_start, ctoken_end, ...]
        c_start = sep_indices[:, 0]
        c_end = sep_indices[:, 1]
        batch_size = hidden_states.shape[0]
        token_indices = torch.arange(total_compress_tokens, device=hidden_states.device).unsqueeze(0)
        token_indices = token_indices + c_start.unsqueeze(1)
        batch_indices = torch.arange(batch_size, device=hidden_states.device).unsqueeze(1).expand(-1, total_compress_tokens)
        return hidden_states[batch_indices, token_indices].contiguous()

    batch_size = hidden_states.shape[0]
    left_padding = (attention_mask[:, -1].sum() == attention_mask.shape[0])
    if left_padding:
        return hidden_states[torch.arange(batch_size), -total_compress_tokens:, :]
    eos_indices = attention_mask.sum(dim=1, keepdim=True)
    token_indices = torch.arange(total_compress_tokens, device=hidden_states.device).unsqueeze(0)
    token_indices = token_indices + eos_indices - total_compress_tokens
    batch_indices = torch.arange(batch_size, device=hidden_states.device).unsqueeze(1).expand(-1, total_compress_tokens)
    return hidden_states[batch_indices, token_indices].contiguous()


def _parse_train_sh(sh_path):
    with open(sh_path, "r") as f:
        content = f.read()

    variables = {}
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export "):].strip()
        if "=" in line and not line.startswith("cmd="):
            key, val = line.split("=", 1)
            variables[key.strip()] = val.strip().strip('"').strip("'")

    cmd_match = re.search(r'cmd="([\s\S]*?)"\s*', content)
    cmd = cmd_match.group(1) if cmd_match else ""

    def _sub_var(m):
        name = m.group(1)
        return variables.get(name, m.group(0))

    cmd = re.sub(r"\$(\w+)", _sub_var, cmd)
    cmd = cmd.replace("\\\n", " ")
    cmd = re.sub(r"\s+", " ", cmd).strip()

    tokens = shlex.split(cmd)
    config = {}
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        if tok.startswith("--"):
            key = tok.lstrip("-")
            values = []
            j = i + 1
            while j < len(tokens) and not tokens[j].startswith("--"):
                values.append(tokens[j])
                j += 1
            if len(values) == 0:
                config[key] = True
            elif len(values) == 1:
                config[key] = values[0]
            else:
                config[key] = " ".join(values)
            i = j
            continue
        i += 1

    if "TOTAL_COMPRESS_TOKENS" in variables:
        config["total_compress_tokens"] = variables["TOTAL_COMPRESS_TOKENS"]
    if "EXP_DIR" in variables:
        config["exp_dir"] = variables["EXP_DIR"]
    if "EXP_NAME" in variables:
        config["exp_name"] = variables["EXP_NAME"]

    return config


def _find_latest_checkpoint(exp_dir):
    if not exp_dir or not os.path.isdir(exp_dir):
        return None
    # Prefer checkpoint-* style
    candidates = sorted(
        glob.glob(os.path.join(exp_dir, "checkpoint-*")),
        key=lambda p: os.path.getmtime(p),
        reverse=True,
    )
    if candidates:
        return candidates[0]
    # Fallback to global_step* style
    candidates = sorted(
        glob.glob(os.path.join(exp_dir, "global_step*")),
        key=lambda p: os.path.getmtime(p),
        reverse=True,
    )
    return candidates[0] if candidates else None


def analyze_checkpoint(checkpoint_path, dataset_config, output_dir, num_batches=32, batch_size=4, visualize=True,
                       model_type=None, compression_mode=True, split_layer=None, cls_types=None, total_compress_tokens=8,
                       task_types=None, use_nat=False):
    """
    分析单个 checkpoint

    Args:
        checkpoint_path: 模型 checkpoint 路径
        dataset_config: 数据集配置文件路径
        output_dir: 输出目录
        num_batches: 分析多少个 batch
        batch_size: 每个 batch 的样本数
        visualize: 是否可视化
        model_type: 模型类型 (如 qwen2_5_omni)
        compression_mode: 是否使用压缩模式
        split_layer: 分层位置
        cls_types: cls 类型列表
        total_compress_tokens: 压缩 token 数量
    """
    os.makedirs(output_dir, exist_ok=True)

    print(f"\n{'='*60}")
    print(f"Analyzing checkpoint: {checkpoint_path}")
    print(f"{'='*60}\n")

    # 设置环境变量
    import src.model.processor
    original_tokens = getattr(src.model.processor, 'TOTAL_COMPRESS_TOKENS', None)
    src.model.processor.TOTAL_COMPRESS_TOKENS = total_compress_tokens
    globals()['TOTAL_COMPRESS_TOKENS'] = total_compress_tokens

    # ========== 1. 加载模型 ==========
    print("Loading model...")
    model_args = ModelArguments(
        model_name=checkpoint_path,
        pooling="avg",  # 训练脚本用的是 avg
        normalize=True,
        model_type=model_type,
        compression_mode=compression_mode,
        split_layer=split_layer,
    )

    processor = load_processor(model_args)
    model = MMEBModel.build(model_args)
    model.eval()
    model = model.cuda()

    backbone = get_backbone_name(hf_config=model.config, model_type=model_args.model_type)
    print(f"  Backbone: {backbone}")
    print(f"  Compress tokens: {TOTAL_COMPRESS_TOKENS}")

    # ========== 2. 加载数据 ==========
    print("\nLoading dataset...")
    # 初始化数据集
    if task_types is None:
        # Default to retrieval-only for analysis to match the batch unpacking below.
        task_types = ["retrieval"]

    training_args = type('obj', (object,), {
        'task_types': task_types,
        'per_device_retrv_train_batch_size': batch_size,
        'per_device_openqa_train_batch_size': batch_size,
        'data_weights': [1] * len(task_types),
        'interleave_batch_size': 1,
        'qa_interleave_batch_size': 1,
        'dataloader_num_workers': 0,
        'dataloader_pin_memory': False,
        'dataloader_persistent_workers': False,
    })()

    train_dataset = init_mixed_dataset(
        model_args=model_args,
        data_args=DataArguments(
            dataset_config=dataset_config,
            image_resolution="mid",
        ),
        training_args=training_args,
    )

    # Collator
    collator = MultimodalDataCollator(
        processor=processor,
        model_args=model_args,
        data_args=DataArguments(),
        training_args=type('obj', (object,), {
            'orthogonal_loss': None,
            'distillation_loss': None,
            'orthogonal_margin': 0.1,
            'orthogonal_loss_qry': False,
            'orthogonal_loss_tgt': True,
        })(),
        model_func_get_rope_index=model.encoder.get_rope_index,
        cls_type_to_indices=getattr(model.config, 'cls_type_to_indices', {None: [0, TOTAL_COMPRESS_TOKENS]}),
    )

    # init_mixed_dataset returns a MixedDataLoader (already a dataloader-like iterable).
    dataloader = train_dataset

    # ========== 3. 分析 ==========
    print("\nComputing similarity matrices...")

    all_results = []
    batch_count = 0

    with torch.no_grad():
        for batch in dataloader:
            if batch_count >= num_batches:
                break

            if isinstance(batch, (list, tuple)) and len(batch) == 2:
                # retrieval batch: (qry_inputs, tgt_inputs)
                qry_inputs, tgt_inputs = batch
                qry_inputs = _move_to_cuda(qry_inputs)
                tgt_inputs = _move_to_cuda(tgt_inputs)

                # Forward pass - 获取 chorus tokens
                hidden_states = model.encoder(**tgt_inputs, return_dict=True, output_hidden_states=True)
                attention_mask = tgt_inputs['attention_mask']
                sep_indices = tgt_inputs.get('sep_indices', None)
            elif isinstance(batch, dict):
                # openqa batch
                if batch.get("distill_openqa", False):
                    inputs = batch["nat"] if use_nat else batch["comp"]
                else:
                    inputs = batch
                inputs = _move_to_cuda(inputs)

                hidden_states = model.encoder(**inputs, return_dict=True, output_hidden_states=True)
                attention_mask = inputs['attention_mask']
                sep_indices = inputs.get('sep_indices', None)
            else:
                raise RuntimeError("Unexpected batch structure. Check task_types and dataset config.")

            hidden_states = hidden_states.hidden_states[-1]

            # 获取 chorus tokens
            chorus_tokens = _extract_chorus_tokens(
                hidden_states,
                attention_mask=attention_mask,
                total_compress_tokens=TOTAL_COMPRESS_TOKENS,
                sep_indices=sep_indices,
            )

            # Normalize
            chorus_tokens = F.normalize(chorus_tokens, p=2, dim=-1)

            # 计算相似度矩阵
            result = compute_sim_matrix(chorus_tokens)
            result['batch_idx'] = batch_count
            all_results.append(result)

            print(f"  Batch {batch_count}: loss={result['loss']:.4f}, "
                  f"sim_mean={result['stats']['sim_mean']:.4f}, "
                  f"off_diag_mean={result['stats']['off_diag_mean']:.4f}")

            batch_count += 1

    # ========== 4. 汇总结果 ==========
    print("\n" + "="*60)
    print("Summary Statistics:")
    print("="*60)

    avg_loss = sum(r['loss'] for r in all_results) / len(all_results)
    avg_sim_mean = sum(r['stats']['sim_mean'] for r in all_results) / len(all_results)
    avg_off_diag_mean = sum(r['stats']['off_diag_mean'] for r in all_results) / len(all_results)
    avg_off_diag_std = sum(r['stats']['off_diag_std'] for r in all_results) / len(all_results)

    print(f"  Average orthogonal loss: {avg_loss:.4f}")
    print(f"  Average sim mean: {avg_sim_mean:.4f}")
    print(f"  Average off-diag sim mean: {avg_off_diag_mean:.4f}")
    print(f"  Average off-diag sim std: {avg_off_diag_std:.4f}")

    # ========== 5. 保存结果 ==========
    output_file = os.path.join(output_dir, 'analysis_results.json')
    with open(output_file, 'w') as f:
        json.dump({
            'checkpoint': checkpoint_path,
            'num_batches': len(all_results),
            'summary': {
                'avg_loss': avg_loss,
                'avg_sim_mean': avg_sim_mean,
                'avg_off_diag_mean': avg_off_diag_mean,
                'avg_off_diag_std': avg_off_diag_std,
            },
            'batches': [
                {
                    'batch_idx': r['batch_idx'],
                    'loss': r['loss'],
                    'stats': r['stats'],
                    'sim_matrix': r['sim'].tolist(),
                }
                for r in all_results
            ]
        }, f, indent=2)

    print(f"\nResults saved to: {output_file}")

    # ========== 6. 可视化 ==========
    if visualize and HAS_MATPLOTLIB:
        print("\nGenerating visualizations...")
        checkpoint_name = os.path.basename(checkpoint_path)
        for r in all_results:
            visualize_sim_matrix(r['sim'], checkpoint_name, output_dir, r['batch_idx'])

    print("="*60)

    return all_results


def main():
    import argparse
    parser = argparse.ArgumentParser(description='Analyze orthogonal loss effect')
    parser.add_argument('--checkpoint', type=str, default=None, help='Path to checkpoint (single mode)')
    parser.add_argument('--checkpoint2', type=str, default=None, help='Path to second checkpoint for comparison')
    parser.add_argument('--dataset_config', type=str, default=None, help='Path to dataset config yaml')
    parser.add_argument('--output_dir', type=str, default='./analysis_output', help='Output directory')
    parser.add_argument('--num_batches', type=int, default=32, help='Number of batches to analyze')
    parser.add_argument('--batch_size', type=int, default=4, help='Batch size')
    parser.add_argument('--no_visualize', action='store_true', help='Disable visualization')

    # 模型相关参数
    parser.add_argument('--model_type', type=str, default='qwen2_5_omni', help='Model type')
    parser.add_argument('--compression_mode', action='store_true', default=True, help='Use compression mode')
    parser.add_argument('--split_layer', type=int, default=36, help='Split layer for compression')
    parser.add_argument('--cls_types', type=str, default='video,goods', help='CLS types (comma-separated)')
    parser.add_argument('--total_compress_tokens', type=int, default=8, help='Total compress tokens')
    parser.add_argument('--task_types', type=str, default='retrieval', help='Task types (comma-separated)')
    parser.add_argument('--use_nat', action='store_true', help='Use nat inputs when distill_openqa is enabled')
    parser.add_argument(
        '--train_sh1',
        type=str,
        default='/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec/experiments/hetu/train_korus-qwen2omni-3B_hetu_hetu_videoonly_orthogonal.sh',
        help='Path to training shell script (checkpoint 1 config)',
    )
    parser.add_argument(
        '--train_sh2',
        type=str,
        default='/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec/experiments/hetu/train_korus-qwen2omni-3B_hetu_hetu_videoonly_baseline.sh',
        help='Path to training shell script (checkpoint 2 config)',
    )

    args = parser.parse_args()
    visualize = not args.no_visualize
    sh_config1 = _parse_train_sh(args.train_sh1) if args.train_sh1 else {}
    sh_config2 = _parse_train_sh(args.train_sh2) if args.train_sh2 else {}

    def _pick_from_sh(key, default_value, sh_config):
        return sh_config.get(key, default_value)

    if args.train_sh1:
        # Prefer values from train_sh1 unless explicitly set on CLI.
        if args.dataset_config is None:
            args.dataset_config = _pick_from_sh("dataset_config", args.dataset_config, sh_config1)
        if args.model_type == 'qwen2_5_omni':
            args.model_type = _pick_from_sh("model_type", args.model_type, sh_config1)
        if args.split_layer == 36:
            args.split_layer = int(_pick_from_sh("split_layer", args.split_layer, sh_config1))
        if args.total_compress_tokens == 8:
            args.total_compress_tokens = int(_pick_from_sh("total_compress_tokens", args.total_compress_tokens, sh_config1))
        if args.task_types == 'retrieval' and "task_types" in sh_config1:
            args.task_types = sh_config1["task_types"]
        if args.cls_types == 'video,goods' and "cls_types" in sh_config1:
            args.cls_types = sh_config1["cls_types"]
        if args.output_dir == './analysis_output' and "exp_dir" in sh_config1:
            args.output_dir = os.path.join(sh_config1["exp_dir"], "analysis_output")

        if args.checkpoint is None and "exp_dir" in sh_config1:
            args.checkpoint = _find_latest_checkpoint(sh_config1["exp_dir"])

    if args.train_sh2 and args.checkpoint2 is None and "exp_dir" in sh_config2:
        args.checkpoint2 = _find_latest_checkpoint(sh_config2["exp_dir"])

    # Recompute after possible overrides
    if args.cls_types and " " in args.cls_types:
        args.cls_types = args.cls_types.replace(" ", ",")
    if args.task_types and " " in args.task_types:
        args.task_types = args.task_types.replace(" ", ",")
    cls_types = args.cls_types.split(',') if args.cls_types else None
    task_types = args.task_types.split(',') if args.task_types else None

    # 通用参数
    if args.dataset_config is None:
        raise SystemExit("dataset_config is required. Provide --dataset_config or --train_sh1 with --dataset_config in the script.")
    if args.checkpoint is None:
        raise SystemExit("checkpoint is required. Provide --checkpoint or --train_sh1 with EXP_DIR containing checkpoints.")
    if args.checkpoint2 is None and args.train_sh2:
        raise SystemExit("checkpoint2 is required. Provide --checkpoint2 or --train_sh2 with EXP_DIR containing checkpoints.")

    common_kwargs = dict(
        model_type=args.model_type,
        compression_mode=args.compression_mode,
        split_layer=args.split_layer,
        cls_types=cls_types,
        total_compress_tokens=args.total_compress_tokens,
        task_types=task_types,
        use_nat=args.use_nat,
    )

    # 单个 checkpoint 分析
    if args.checkpoint2 is None:
        analyze_checkpoint(
            checkpoint_path=args.checkpoint,
            dataset_config=args.dataset_config,
            output_dir=args.output_dir,
            num_batches=args.num_batches,
            batch_size=args.batch_size,
            visualize=visualize,
            **common_kwargs,
        )
    else:
        # 对比两个 checkpoint
        print("\n" + "="*60)
        print("COMPARISON MODE")
        print("="*60)

        # 分析第一个 checkpoint
        output_dir1 = os.path.join(args.output_dir, 'checkpoint1')
        results1 = analyze_checkpoint(
            checkpoint_path=args.checkpoint,
            dataset_config=args.dataset_config,
            output_dir=output_dir1,
            num_batches=args.num_batches,
            batch_size=args.batch_size,
            visualize=visualize,
            **common_kwargs,
        )

        # 分析第二个 checkpoint
        output_dir2 = os.path.join(args.output_dir, 'checkpoint2')
        results2 = analyze_checkpoint(
            checkpoint_path=args.checkpoint2,
            dataset_config=args.dataset_config,
            output_dir=output_dir2,
            num_batches=args.num_batches,
            batch_size=args.batch_size,
            visualize=visualize,
            **common_kwargs,
        )

        # 生成对比图
        if visualize and HAS_MATPLOTLIB:
            print("\nGenerating comparison plot...")
            name1 = os.path.basename(args.checkpoint)
            name2 = os.path.basename(args.checkpoint2)
            plot_comparison([results1, results2], [name1, name2], args.output_dir)

        # 打印对比总结
        print("\n" + "="*60)
        print("COMPARISON SUMMARY")
        print("="*60)

        avg_loss1 = sum(r['loss'] for r in results1) / len(results1)
        avg_loss2 = sum(r['loss'] for r in results2) / len(results2)
        avg_off_mean1 = sum(r['stats']['off_diag_mean'] for r in results1) / len(results1)
        avg_off_mean2 = sum(r['stats']['off_diag_mean'] for r in results2) / len(results2)

        print(f"\n{'Checkpoint':<30} {'Loss':>12} {'Off-Diag Mean':>14}")
        print("-" * 60)
        print(f"{'Checkpoint 1':<30} {avg_loss1:>12.4f} {avg_off_mean1:>14.4f}")
        print(f"{'Checkpoint 2':<30} {avg_loss2:>12.4f} {avg_off_mean2:>14.4f}")
        print("-" * 60)
        print(f"{'Difference (1 - 2)':<30} {avg_loss1-avg_loss2:>12.4f} {avg_off_mean1-avg_off_mean2:>14.4f}")
        print("="*60)


if __name__ == '__main__':
    main()
