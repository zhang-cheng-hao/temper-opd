#!/bin/bash
set -euo pipefail

REPO_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_DIR"

export http_proxy=[REDACTED_PROXY]
export https_proxy=[REDACTED_PROXY]
export no_proxy=[REDACTED_NO_PROXY]

NNODES="${1:-${NNODES:-1}}"
NODE_RANK="${2:-${NODE_RANK:-0}}"
shift $(( $# >= 2 ? 2 : $# ))
export NNODES NODE_RANK

for arg in "$@"; do
    case "$arg" in
        *=*)
            export "$arg"
            ;;
        *)
            echo "[WARN] ignore non key=value arg: $arg"
            ;;
    esac
done

export NCCL_IB_QPS_PER_CONNECTION=4
export NCCL_IB_DISABLE=0
export NCCL_IB_GID_INDEX=3
export NCCL_IB_HCA=mlx5
export NCCL_DEBUG=WARN
export NCCL_NET_OVERHEAD=1000
export NCCL_PROTO=^LL128
export TORCH_NCCL_BLOCKING_WAIT=1
export TORCH_NCCL_ASYNC_ERROR_HANDLING=1
export TORCH_NCCL_TIMEOUT=6000
export NCCL_COMM_TIMEOUT=6000
export LD_LIBRARY_PATH=/usr/local/nvidia/lib:/usr/local/nvidia/lib64
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

GPUS_PER_NODE="${GPUS_PER_NODE:-8}"
WORLD_SIZE=$((GPUS_PER_NODE * NNODES))
if [ "$NNODES" -eq 1 ]; then
    MASTER_ADDR=localhost
else
    MASTER_ADDR="${MASTER_ADDR:-10.82.121.98}"
fi
MASTER_PORT="${MASTER_PORT:-2207}"

MODEL_NAME="${MODEL_NAME:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/LLaMA-Factory/saves/qwen2_5omni-3b/sft_datav2/merge/}"
MODEL_TYPE="${MODEL_TYPE:-qwen2_5_omni}"
TORCHRUN="${TORCHRUN:-/mmu_mllm_hdd/zhangchenghao05/envs/vlm2vec/bin/torchrun}"

STAGE1_YAML="${STAGE1_YAML:-$REPO_DIR/experiments/hetu/train_goods_0402_stage1.yaml}"
STAGE2_YAML="${STAGE2_YAML:-$REPO_DIR/experiments/hetu/train_goods_0402_stage2.yaml}"

VARIANT="${VARIANT:-mean}"
STAGE="${STAGE:-full}"

TOTAL_RETRV_BATCH_SIZE="${TOTAL_RETRV_BATCH_SIZE:-1024}"
TOTAL_QA_BATCH_SIZE="${TOTAL_QA_BATCH_SIZE:-128}"
NUM_WORKERS="${NUM_WORKERS:-2}"
INTERLEAVE_BATCH_SIZE="${INTERLEAVE_BATCH_SIZE:-1}"
QA_INTERLEAVE_BATCH_SIZE="${QA_INTERLEAVE_BATCH_SIZE:-1}"
TASK_TYPES="${TASK_TYPES:-retrieval_goods}"
CLS_TYPES="${CLS_TYPES:-goods}"
DATA_WEIGHTS="${DATA_WEIGHTS:-1}"
LOSS_WEIGHTS="${LOSS_WEIGHTS:-1}"
MATRYOSHKAS="${MATRYOSHKAS:-}"
GRADIENT_ACCUMULATION_STEPS="${GRADIENT_ACCUMULATION_STEPS:-1}"
LR="${LR:-5e-5}"
WARMUP_STEPS="${WARMUP_STEPS:-100}"
SAVE_STEPS_STAGE1="${SAVE_STEPS_STAGE1:-500}"
SAVE_STEPS_STAGE2="${SAVE_STEPS_STAGE2:-500}"
STAGE1_MAX_STEPS="${STAGE1_MAX_STEPS:-10000}"
STAGE2_MAX_STEPS="${STAGE2_MAX_STEPS:-3000}"
STAGE1_MAX_LEN="${STAGE1_MAX_LEN:-8192}"
STAGE2_MAX_LEN="${STAGE2_MAX_LEN:-8192}"
MIN_PIXELS="${MIN_PIXELS:-3136}"
MAX_IMAGE_TOKENS="${MAX_IMAGE_TOKENS:-200}"
MAX_PIXELS="${MAX_PIXELS:-$((28 * 28 * MAX_IMAGE_TOKENS))}"
RESUME_FROM="${RESUME_FROM:-auto}"
MODE="${MODE:-train}"

ORTHO_W="${ORTHO_W:-0.01}"
ORTHO_M="${ORTHO_M:-0.2}"
ORTHO_W_OPENQA="${ORTHO_W_OPENQA:-}"
VOLUME_W_OPENQA="${VOLUME_W_OPENQA:-}"
HSIC_W_OPENQA="${HSIC_W_OPENQA:-}"
ORTHO_WARMUP_STEPS="${ORTHO_WARMUP_STEPS:-100}"
MAXSIM_TOPK="${MAXSIM_TOPK:-4}"
GC_Q_CHUNK_SIZE="${GC_Q_CHUNK_SIZE:-4}"
GC_P_CHUNK_SIZE="${GC_P_CHUNK_SIZE:-2}"
ORTHOGONAL_DIAG_STEPS="${ORTHOGONAL_DIAG_STEPS:-50}"
LOAD_DIAG_STEPS="${LOAD_DIAG_STEPS:-50}"

export TOTAL_COMPRESS_TOKENS="${TOTAL_COMPRESS_TOKENS:-4}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface/datasets}"
export WANDB_DISABLED="${WANDB_DISABLED:-false}"
export WANDB_PROJECT="${WANDB_PROJECT:-VLM2Vec}"
export WANDB_API_KEY="${WANDB_API_KEY:-[REDACTED_WANDB_API_KEY]}"

if [ "$WANDB_DISABLED" = "true" ]; then
    REPORT_TO="${REPORT_TO:-none}"
else
    REPORT_TO="${REPORT_TO:-wandb}"
fi

if [ ! -x "$TORCHRUN" ]; then
    echo "[ERR] torchrun not found or not executable: $TORCHRUN" >&2
    exit 1
fi
if [ ! -e "$MODEL_NAME" ]; then
    echo "[ERR] base model path not found: $MODEL_NAME" >&2
    exit 1
fi
if [ ! -f "$STAGE1_YAML" ]; then
    echo "[ERR] stage1 yaml not found: $STAGE1_YAML" >&2
    exit 1
fi
if [ ! -f "$STAGE2_YAML" ]; then
    echo "[ERR] stage2 yaml not found: $STAGE2_YAML" >&2
    exit 1
fi
if [ "$WORLD_SIZE" -le 0 ]; then
    echo "[ERR] invalid world size: GPUS_PER_NODE=$GPUS_PER_NODE NNODES=$NNODES" >&2
    exit 1
fi
if [ $((TOTAL_RETRV_BATCH_SIZE % WORLD_SIZE)) -ne 0 ]; then
    echo "[ERR] TOTAL_RETRV_BATCH_SIZE=$TOTAL_RETRV_BATCH_SIZE must be divisible by world size=$WORLD_SIZE" >&2
    exit 1
fi
if [[ " $TASK_TYPES " == *" openqa "* ]] && [ $((TOTAL_QA_BATCH_SIZE % WORLD_SIZE)) -ne 0 ]; then
    echo "[ERR] TOTAL_QA_BATCH_SIZE=$TOTAL_QA_BATCH_SIZE must be divisible by world size=$WORLD_SIZE" >&2
    exit 1
fi

PER_DEVICE_RETRV_BATCH_SIZE=$((TOTAL_RETRV_BATCH_SIZE / WORLD_SIZE))
PER_DEVICE_QA_BATCH_SIZE=$((TOTAL_QA_BATCH_SIZE / WORLD_SIZE))

read -r -a TASK_TYPES_ARGS <<< "$TASK_TYPES"
read -r -a CLS_TYPES_ARGS <<< "$CLS_TYPES"
read -r -a DATA_WEIGHTS_ARGS <<< "$DATA_WEIGHTS"
read -r -a LOSS_WEIGHTS_ARGS <<< "$LOSS_WEIGHTS"
read -r -a MATRYOSHKAS_ARGS <<< "$MATRYOSHKAS"

case "$VARIANT" in
    mean)
        POOLING="avg"
        SIMILARITY_TYPE="dense"
        ORTHO_W_EFFECTIVE="0"
        ORTHO_M_EFFECTIVE="0"
        ORTHO_WARMUP_STEPS_EFFECTIVE="0"
        ;;
    maxtop4_ortho)
        POOLING="none"
        SIMILARITY_TYPE="maxsim_topk"
        ORTHO_W_EFFECTIVE="$ORTHO_W"
        ORTHO_M_EFFECTIVE="$ORTHO_M"
        ORTHO_WARMUP_STEPS_EFFECTIVE="$ORTHO_WARMUP_STEPS"
        ;;
    slotalign_ortho)
        POOLING="none"
        SIMILARITY_TYPE="slot_aligned"
        ORTHO_W_EFFECTIVE="$ORTHO_W"
        ORTHO_M_EFFECTIVE="$ORTHO_M"
        ORTHO_WARMUP_STEPS_EFFECTIVE="$ORTHO_WARMUP_STEPS"
        ;;
    *)
        echo "[ERR] unsupported VARIANT=$VARIANT, expected mean, maxtop4_ortho, or slotalign_ortho" >&2
        exit 1
        ;;
esac

case "$STAGE" in
    stage1|stage2|full)
        ;;
    *)
        echo "[ERR] unsupported STAGE=$STAGE, expected stage1, stage2, or full" >&2
        exit 1
        ;;
esac

OUTPUT_ROOT="${OUTPUT_ROOT:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0402_twostage}"
RUN_NAME="${RUN_NAME:-goods_0402_${VARIANT}_t${TOTAL_COMPRESS_TOKENS}}"
EXP_DIR="$OUTPUT_ROOT/$RUN_NAME"
STAGE1_DIR="$EXP_DIR/stage1"
STAGE2_DIR="$EXP_DIR/stage2"
CUDA_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"

mkdir -p "$STAGE1_DIR" "$STAGE2_DIR"

run_stage() {
    local stage_name="$1"
    local stage_yaml="$2"
    local init_model_name="$3"
    local stage_output_dir="$4"
    local stage_max_len="$5"
    local stage_max_steps="$6"
    local stage_save_steps="$7"
    local stage_resume_from="$8"
    local log_file="$stage_output_dir/train.log"

    if [ ! -e "$init_model_name" ]; then
        echo "[ERR] init model path not found for $stage_name: $init_model_name" >&2
        exit 1
    fi

    local cmd=(
        env CUDA_VISIBLE_DEVICES="$CUDA_DEVICES"
        "$TORCHRUN"
        --nproc-per-node "$GPUS_PER_NODE"
        --nnodes "$NNODES"
        --max-restarts 0
        --rdzv-backend c10d
        --rdzv-id "${RUN_NAME}-${stage_name}"
        --rdzv-endpoint "$MASTER_ADDR:$MASTER_PORT"
        --node-rank "$NODE_RANK"
        train.py
        --seed 42
        --compression_mode
        --max_grad_norm 0.5
        --task_types "${TASK_TYPES_ARGS[@]}"
        --split_cls_tokens_by_task False
        --cls_types "${CLS_TYPES_ARGS[@]}"
        --dataset_config "$stage_yaml"
        --pooling "$POOLING"
        --similarity_type "$SIMILARITY_TYPE"
        --maxsim_topk "$MAXSIM_TOPK"
        --normalize True
        --temperature 0.02
        --bf16
        --deepspeed experiments/zero1.json
        --split_layer 36
        --gradient_accumulation_steps "$GRADIENT_ACCUMULATION_STEPS"
        --data_weights "${DATA_WEIGHTS_ARGS[@]}"
        --loss_weights "${LOSS_WEIGHTS_ARGS[@]}"
        --model_name "$init_model_name"
        --model_type "$MODEL_TYPE"
        --grad_cache
        --gc_q_chunk_size "$GC_Q_CHUNK_SIZE"
        --gc_p_chunk_size "$GC_P_CHUNK_SIZE"
        --dataloader_num_workers "$NUM_WORKERS"
        --dataloader_pin_memory False
        --dataloader_persistent_workers False
        --run_name "${RUN_NAME}_${stage_name}"
        --project_name "$WANDB_PROJECT"
        --output_dir "$stage_output_dir"
        --max_len "$stage_max_len"
        --resize_min_pixels "$MIN_PIXELS"
        --resize_max_pixels "$MAX_PIXELS"
        --per_device_train_batch_size 1
        --per_device_retrv_train_batch_size "$PER_DEVICE_RETRV_BATCH_SIZE"
        --per_device_openqa_train_batch_size "$PER_DEVICE_QA_BATCH_SIZE"
        --interleave_batch_size "$INTERLEAVE_BATCH_SIZE"
        --qa_interleave_batch_size "$QA_INTERLEAVE_BATCH_SIZE"
        --lr_scheduler_type cosine
        --learning_rate "$LR"
        --projector_lr "$LR"
        --weight_decay 0
        --warmup_steps "$WARMUP_STEPS"
        --orthogonal_loss "$ORTHO_W_EFFECTIVE"
        --orthogonal_margin "$ORTHO_M_EFFECTIVE"
        --orthogonal_warmup_steps "$ORTHO_WARMUP_STEPS_EFFECTIVE"
        --orthogonal_diag_steps "$ORTHOGONAL_DIAG_STEPS"
        --load_diag_steps "$LOAD_DIAG_STEPS"
        --max_steps "$stage_max_steps"
        --save_steps "$stage_save_steps"
        --logging_steps 1
        --save_safetensors True
        --remove_unused_columns False
        --resume_from "$stage_resume_from"
        --report_to "$REPORT_TO"
    )

    if [ ${#MATRYOSHKAS_ARGS[@]} -gt 0 ]; then
        cmd+=(--matryoshkas "${MATRYOSHKAS_ARGS[@]}")
    fi
    if [ -n "$ORTHO_W_OPENQA" ]; then
        cmd+=(--orthogonal_loss_openqa "$ORTHO_W_OPENQA")
    fi
    if [ -n "$VOLUME_W_OPENQA" ]; then
        cmd+=(--volume_loss_openqa "$VOLUME_W_OPENQA")
    fi
    if [ -n "$HSIC_W_OPENQA" ]; then
        cmd+=(--hsic_loss_openqa "$HSIC_W_OPENQA")
    fi

    printf "\n[%s] CMD: " "$stage_name"
    printf "%q " "${cmd[@]}"
    printf "\n"

    if [ "$MODE" = "train" ]; then
        {
            printf "\n[%s] CMD: " "$stage_name"
            printf "%q " "${cmd[@]}"
            printf "\n"
            "${cmd[@]}"
        } 2>&1 | tee -a "$log_file"
    else
        echo "[INFO] MODE=$MODE, print command only."
    fi
}

STAGE2_INIT_MODEL_NAME="${STAGE2_INIT_MODEL_NAME:-$STAGE1_DIR}"

if [ "$STAGE" = "stage1" ]; then
    run_stage "stage1" "$STAGE1_YAML" "$MODEL_NAME" "$STAGE1_DIR" "$STAGE1_MAX_LEN" "$STAGE1_MAX_STEPS" "$SAVE_STEPS_STAGE1" "$RESUME_FROM"
elif [ "$STAGE" = "stage2" ]; then
    run_stage "stage2" "$STAGE2_YAML" "$STAGE2_INIT_MODEL_NAME" "$STAGE2_DIR" "$STAGE2_MAX_LEN" "$STAGE2_MAX_STEPS" "$SAVE_STEPS_STAGE2" "$RESUME_FROM"
else
    run_stage "stage1" "$STAGE1_YAML" "$MODEL_NAME" "$STAGE1_DIR" "$STAGE1_MAX_LEN" "$STAGE1_MAX_STEPS" "$SAVE_STEPS_STAGE1" "$RESUME_FROM"
    run_stage "stage2" "$STAGE2_YAML" "$STAGE2_INIT_MODEL_NAME" "$STAGE2_DIR" "$STAGE2_MAX_LEN" "$STAGE2_MAX_STEPS" "$SAVE_STEPS_STAGE2" "none"
fi
