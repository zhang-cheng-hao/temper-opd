import os
import random
import re
from typing import Dict, Iterable, List, Optional

import torch


RANK_SHARD_RE = re.compile(r"^rank(\d+)_shard(\d+)\.pt$")


def parse_bool(value, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}


def list_cache_files(
    cache_dir: str,
    rank: int = 0,
    world_size: int = 1,
    match_cache_rank: bool = True,
    shuffle_files: bool = True,
    seed: int = 42,
) -> List[str]:
    if not os.path.isdir(cache_dir):
        raise NotADirectoryError(f"cache_dir not found: {cache_dir}")

    all_files = [
        os.path.join(cache_dir, name)
        for name in os.listdir(cache_dir)
        if name.endswith(".pt")
    ]
    all_files.sort()
    if not all_files:
        raise FileNotFoundError(f"No .pt cache shards found in: {cache_dir}")

    selected = all_files
    if world_size > 1:
        if match_cache_rank:
            matched = []
            for path in all_files:
                m = RANK_SHARD_RE.match(os.path.basename(path))
                if m and int(m.group(1)) == rank:
                    matched.append(path)
            if matched:
                selected = matched
            else:
                selected = [p for i, p in enumerate(all_files) if i % world_size == rank]
        else:
            selected = [p for i, p in enumerate(all_files) if i % world_size == rank]

    if not selected:
        raise FileNotFoundError(
            f"No cache shards selected for rank={rank} world_size={world_size} from {cache_dir}"
        )

    if shuffle_files:
        rng = random.Random(seed + rank)
        rng.shuffle(selected)
    return selected


def load_cache_shard(path: str, dtype: Optional[torch.dtype] = None) -> Dict[str, object]:
    obj = torch.load(path, map_location="cpu")
    if not isinstance(obj, dict):
        raise ValueError(f"Cache shard must be a dict, got {type(obj).__name__}: {path}")
    if "qry" not in obj or "tgt" not in obj:
        raise KeyError(f"Cache shard must contain qry/tgt tensors: {path}")

    qry = obj["qry"]
    tgt = obj["tgt"]
    if not torch.is_tensor(qry) or not torch.is_tensor(tgt):
        raise TypeError(f"Cache shard qry/tgt must be tensors: {path}")
    if qry.shape != tgt.shape:
        raise ValueError(f"Cache shard qry/tgt shape mismatch: {tuple(qry.shape)} vs {tuple(tgt.shape)}")
    if qry.dim() not in {2, 3}:
        raise ValueError(f"Cache shard expects 2D or 3D reps, got {tuple(qry.shape)}: {path}")

    if dtype is not None:
        qry = qry.to(dtype=dtype)
        tgt = tgt.to(dtype=dtype)

    return {
        "format_version": int(obj.get("format_version", 1)),
        "qry": qry.contiguous(),
        "tgt": tgt.contiguous(),
        "metadata": obj.get("metadata", {}),
        "path": path,
    }


def iter_shard_batches(
    files: Iterable[str],
    batch_size: int,
    shuffle_samples: bool = True,
    seed: int = 42,
    drop_last: bool = True,
):
    rng = torch.Generator()
    rng.manual_seed(seed)
    for path in files:
        shard = load_cache_shard(path)
        qry = shard["qry"]
        tgt = shard["tgt"]
        n = int(qry.shape[0])
        if shuffle_samples:
            order = torch.randperm(n, generator=rng)
        else:
            order = torch.arange(n)

        for start in range(0, n, batch_size):
            idx = order[start : start + batch_size]
            if drop_last and idx.numel() < batch_size:
                continue
            yield {
                "qry": qry[idx].contiguous(),
                "tgt": tgt[idx].contiguous(),
                "metadata": shard["metadata"],
                "path": path,
                "offset": int(start),
            }
