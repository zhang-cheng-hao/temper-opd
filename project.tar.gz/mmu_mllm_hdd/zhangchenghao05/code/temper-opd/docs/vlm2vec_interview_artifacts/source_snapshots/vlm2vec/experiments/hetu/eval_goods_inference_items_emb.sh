#!/bin/bash
set -euo pipefail

REPO_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_DIR"

export http_proxy=[REDACTED_PROXY]
export https_proxy=[REDACTED_PROXY]
export no_proxy=[REDACTED_NO_PROXY]

NNODES="${1:-${NNODES:-1}}"
NODE_RANK="${2:-${NODE_RANK:-0}}"

export NCCL_IB_QPS_PER_CONNECTION=4
export NCCL_IB_DISABLE=0
export NCCL_IB_GID_INDEX=3
export NCCL_IB_HCA=mlx5
export NCCL_DEBUG=WARN
export NCCL_NET_OVERHEAD=1000
export NCCL_PROTO=^LL128
export LD_LIBRARY_PATH=/usr/local/nvidia/lib:/usr/local/nvidia/lib64
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

GPUS_PER_NODE="${GPUS_PER_NODE:-8}"
if [ "$NNODES" -eq 1 ]; then
  MASTER_ADDR="localhost"
else
  MASTER_ADDR="${MASTER_ADDR:-10.82.121.98}"
fi
MASTER_PORT="${MASTER_PORT:-2207}"

TORCHRUN="${TORCHRUN:-/mmu_mllm_hdd/zhangchenghao05/envs/vlm2vec/bin/torchrun}"
MODEL_TYPE="${MODEL_TYPE:-qwen2_5_omni}"
MODEL_NAME="${MODEL_NAME:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/LLaMA-Factory/saves/qwen2_5omni-3b/sft_datav2/merge/}"
DATASET_CFG="$REPO_DIR/experiments/hetu/eval_goods_inference_items_emb.yaml"
OUTPUT_ROOT="${OUTPUT_ROOT:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_strong300_omni_compare_ortho}"
CUDA_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"
PER_DEVICE_EVAL_BATCH_SIZE="${PER_DEVICE_EVAL_BATCH_SIZE:-16}"
NUM_WORKERS="${NUM_WORKERS:-2}"
IGNORE_CACHE="${IGNORE_CACHE:-false}"
SMOKE_REPORT="${SMOKE_REPORT:-false}"
NUM_SAMPLE_PER_SUBSET="${NUM_SAMPLE_PER_SUBSET:-}"
SMOKE_TOP_K="${SMOKE_TOP_K:-5}"
SMOKE_TEXT_PREVIEW_CHARS="${SMOKE_TEXT_PREVIEW_CHARS:-120}"
RUN_NAME="${RUN_NAME:-}"
POOLING="${POOLING:-}"
SIMILARITY_TYPE="${SIMILARITY_TYPE:-}"
MAXSIM_TOPK="${MAXSIM_TOPK:-4}"
ENCODE_DIR_NAME="${ENCODE_DIR_NAME:-goods_embs}"
SMOKE_ENCODE_DIR_NAME="${SMOKE_ENCODE_DIR_NAME:-${ENCODE_DIR_NAME}_smoke}"
CKPT_SUBDIR="${CKPT_SUBDIR:-checkpoint-200}"
CKPT_SUBDIRS="${CKPT_SUBDIRS:-}"

if [ "$SMOKE_REPORT" = "true" ] && [ -z "$NUM_SAMPLE_PER_SUBSET" ]; then
  NUM_SAMPLE_PER_SUBSET=10
fi

export TOTAL_COMPRESS_TOKENS="${TOTAL_COMPRESS_TOKENS:-4}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface/datasets}"

if [ ! -x "$TORCHRUN" ]; then
  echo "[ERR] torchrun not found or not executable: $TORCHRUN" >&2
  exit 1
fi
if [ ! -e "$MODEL_NAME" ]; then
  echo "[ERR] model path not found: $MODEL_NAME" >&2
  exit 1
fi
if [ ! -f "$DATASET_CFG" ]; then
  echo "[ERR] eval yaml not found: $DATASET_CFG" >&2
  exit 1
fi
if [ -z "$RUN_NAME" ] || [ -z "$POOLING" ] || [ -z "$SIMILARITY_TYPE" ]; then
  echo "[ERR] RUN_NAME, POOLING, and SIMILARITY_TYPE must be set" >&2
  exit 1
fi

run_one_ckpt () {
  local run_name="$1"
  local pooling="$2"
  local similarity_type="$3"
  local maxsim_topk="${4:-$MAXSIM_TOPK}"
  local ckpt_subdir="${5:-$CKPT_SUBDIR}"
  local ckpt_dir="$OUTPUT_ROOT/$run_name"
  if [ -n "$ckpt_subdir" ]; then
    ckpt_dir="$ckpt_dir/$ckpt_subdir"
  fi
  local encode_dir_name="$ENCODE_DIR_NAME"
  if [ "$SMOKE_REPORT" = "true" ]; then
    encode_dir_name="$SMOKE_ENCODE_DIR_NAME"
  fi
  local encode_output_path="$ckpt_dir/$encode_dir_name"

  if [ ! -d "$ckpt_dir" ]; then
    echo "[WARN] missing ckpt_dir, skip: $ckpt_dir"
    return 0
  fi

  local smoke_report_path=""
  if [ "$SMOKE_REPORT" = "true" ]; then
    smoke_report_path="$encode_output_path/emb/Goods_Inference_Items_smoke.json"
  fi

  CMD=(
    env CUDA_VISIBLE_DEVICES="$CUDA_DEVICES"
    "$TORCHRUN"
      --nproc-per-node "$GPUS_PER_NODE"
      --nnodes "$NNODES"
      --max-restarts 0
      --master-addr "$MASTER_ADDR"
      --master-port "$MASTER_PORT"
      --node-rank "$NODE_RANK"
    eval_i2i.py
      --compression_mode
      --cls_types goods
      --split_cls_tokens_by_task False
      --task_types retrieval_goods
      --model_type "$MODEL_TYPE"
      --model_name "$MODEL_NAME"
      --checkpoint_path "$ckpt_dir"
      --encode_output_path "$encode_output_path"
      --bf16
      --split_layer 36
      --pooling "$pooling"
      --similarity_type "$similarity_type"
      --maxsim_topk "$maxsim_topk"
      --normalize True
      --temperature 0.02
      --per_device_eval_batch_size "$PER_DEVICE_EVAL_BATCH_SIZE"
      --dataloader_num_workers "$NUM_WORKERS"
      --dataloader_pin_memory False
      --dataloader_persistent_workers False
      --dataset_config "$DATASET_CFG"
      --max_len 8192
      --resize_min_pixels $((32*32))
      --resize_max_pixels $((512*512))
      --ignore_cache "$IGNORE_CACHE"
  )

  if [ -n "$NUM_SAMPLE_PER_SUBSET" ]; then
    CMD+=(--num_sample_per_subset "$NUM_SAMPLE_PER_SUBSET")
  fi

  if [ "$SMOKE_REPORT" = "true" ]; then
    CMD+=(
      --smoke_report True
      --smoke_report_path "$smoke_report_path"
      --smoke_top_k "$SMOKE_TOP_K"
      --smoke_text_preview_chars "$SMOKE_TEXT_PREVIEW_CHARS"
    )
  fi

  printf "CMD: "
  printf "%q " "${CMD[@]}"
  printf "\n"
  "${CMD[@]}"
}

if [ -n "$CKPT_SUBDIRS" ]; then
  IFS=',' read -r -a ckpt_subdir_list <<< "$CKPT_SUBDIRS"
else
  ckpt_subdir_list=("$CKPT_SUBDIR")
fi

for ckpt_subdir in "${ckpt_subdir_list[@]}"; do
  run_one_ckpt "$RUN_NAME" "$POOLING" "$SIMILARITY_TYPE" "$MAXSIM_TOPK" "$ckpt_subdir"
done
