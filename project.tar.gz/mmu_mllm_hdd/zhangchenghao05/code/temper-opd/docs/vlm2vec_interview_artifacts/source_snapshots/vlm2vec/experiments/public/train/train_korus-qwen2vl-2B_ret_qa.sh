#!/bin/bash
# NOTE: replace ... with actual paths
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH
export PATH=$PATH
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
echo "conda location: $(which conda)"
echo "Python location: $(which python)"
echo "Python version: $(python --version)"

source "$(dirname "$0")/train_envs.sh"

export WANDB_RUN_GROUP=korus
export EXP_NAME=Korus_Qwen2vl_2B.ret_qa.autoresize.lora16.native0.5.loss2:1.biattn.avg.mrope.BSr1024g128.lr5e5.step2kwarm100.8A800

export WANDB_NAME=$EXP_NAME
export EXP_DIR=/mmu_mllm_hdd_2/liulihao/outputs/exps/$EXP_NAME
export WANDB_DIR=$EXP_DIR
echo $EXP_DIR

mkdir -p $EXP_DIR/wandb
rm -rf $EXP_DIR/wandb/*

# cd PATH_TO_VLM2VEC_REPO
cmd="CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 \
    torchrun $DISTRIBUTED_ARGS train.py \
    --compression_mode --deepspeed experiments/zero1.json \
    --model_name $MODEL_BASEDIR/Qwen/Qwen2-VL-2B-Instruct --model_type qwen2_vl \
    --bf16 --split_layer 28 --gradient_accumulation_steps 5 --loss_weights 1 0.5 --data_weights 1 4 \
    --lora --lora_r 16 --lora_target_modules o_proj,k_proj,q_proj,v_proj \
    --pooling avg --normalize True --temperature 0.02 --native_prob 0.0 \
    --grad_cache --gc_q_chunk_size 8 --gc_p_chunk_size 8 \
    --dataloader_num_workers 8 --dataset_config experiments/public/train/train_ret_qa.yaml \
    --run_name $EXP_NAME --output_dir $EXP_DIR \
    --max_len 2560 --resize_min_pixels $((28*28*256)) --resize_max_pixels $((28*28*1280)) \
    --per_device_train_batch_size 1 --per_device_retrv_train_batch_size $PER_DEVICE_RETRV_BATCH_SIZE --per_device_openqa_train_batch_size $PER_DEVICE_QA_BATCH_SIZE --interleave_batch_size 64 \
    --lr_scheduler_type cosine --learning_rate 5e-5 --weight_decay 0 --warmup_steps 100 \
    --max_steps 2000 --save_steps 500 --logging_steps 1 --save_safetensors True --remove_unused_columns False \
    --resume_from auto --report_to wandb 2>&1 | tee $EXP_DIR/train.log"

echo $cmd
eval $cmd