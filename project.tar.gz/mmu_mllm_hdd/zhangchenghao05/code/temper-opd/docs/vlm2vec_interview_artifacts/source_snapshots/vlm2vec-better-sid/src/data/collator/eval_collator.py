import logging
from typing import Dict, List, Optional, Any
from functools import partial
from dataclasses import dataclass, field
from transformers import ProcessorMixin, AutoProcessor, AutoTokenizer
from src.arguments import DataArguments, ModelArguments, TrainingArguments
import torch
from qwen_vl_utils import smart_resize
from PIL import Image
from src.model.processor import TOTAL_COMPRESS_TOKENS, LLAVA_NEXT, QWEN2_VL, QWEN2_5_VL, KORUS, KORUS_OMNI, \
    QWEN2_VL_TOKENSELECTION, QWEN2_5_VL_TOKENSELECTION, PHI3V, VLM_IMAGE_TOKENS, VLM_AUDIO_TOKENS, process_vlm_inputs_fns
from PIL import Image
from src.utils import print_rank, print_master
from src.model.processor import process_vlm_inputs_fns
import io
import math
import os
import json
import traceback
import numpy as np

logger = logging.getLogger(__name__)
PHI_IMAGE_TOKEN_MAX_INPUT_ID = int(1e9)
LLAVA_IMAGE_TOKEN_ID = 32000


def _strip_missing_image_tokens(text: str, model_backbone: str) -> str:
    image_tokens = set(VLM_IMAGE_TOKENS.values())
    backbone_token = VLM_IMAGE_TOKENS.get(model_backbone)
    if backbone_token:
        image_tokens.add(backbone_token)
    image_tokens.update({"<|image_1|>", "<|IMAGE|>", "<image>"})

    for token in image_tokens:
        if token:
            text = text.replace(token, "")

    return " ".join(text.split())

@dataclass
class EvalCollator:
    data_args: DataArguments
    model_args: ModelArguments
    processor: ProcessorMixin

    def __call__(self, examples):
        """
        :param examples: qry, qry_image, pos_text, pos_image
        """
        examples = {'text': [e[0] for e in examples], 'images': [e[1] for e in examples]}
        inputs = process_vlm_inputs_fns[self.model_args.model_backbone](examples,
                                                                        processor = self.processor,
                                                                        max_length = self.data_args.max_len)
        inputs['texts'] = examples['text']
        inputs['images'] = examples['images']
        inputs['image_paths'] = [i.filename if hasattr(i, 'filename') else None for i in examples['images']]
        return inputs


@dataclass
class CLIPCollator:
    data_args: DataArguments
    vis_processors: AutoProcessor
    txt_processors: AutoTokenizer

    def __call__(self, examples):
        """
        :param examples: qry, qry_image, pos_text, pos_image
        """
        inputs = self._get_batch_inputs(examples)
        return inputs

    def _get_batch_inputs(self, examples):
        input_ids, pixel_values, attention_mask = [], [], []
        image_exist, text_exist = False, False
        for example in examples:
            text, image = example
            if image is not None:
                if image.mode == 'L':
                    image = image.convert('RGB')
                image_inputs = self.vis_processors(images=image, return_tensors="pt")
                image_exist = True
                pixel_values.append(image_inputs['pixel_values'])
            if text:
                text_exist = True
            text_inputs = self.txt_processors(text, padding=getattr(self.data_args, "padding", True), max_length=self.data_args.max_len, truncation=True, return_tensors="pt")
            input_ids.append(text_inputs["input_ids"].squeeze(0))
        if text_exist:
            input_ids = torch.nn.utils.rnn.pad_sequence(
                input_ids, batch_first=True, padding_value=self.txt_processors.pad_token_id
            )
            attention_mask = input_ids.ne(self.txt_processors.pad_token_id)
        if image_exist:
            pixel_values = torch.cat(pixel_values, dim=0)
        if text_exist and image_exist:
            assert input_ids.size()[0]==pixel_values.size()[0]
        inputs = {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'pixel_values': pixel_values,
        }

        return inputs


@dataclass
class OpenCLIPCollator:
    data_args: DataArguments
    vis_processors: AutoProcessor
    txt_processors: AutoTokenizer

    def __call__(self, examples):
        """
        :param examples: qry, qry_image, pos_text, pos_image
        """
        inputs = self._get_batch_inputs(examples)
        return inputs

    def _get_batch_inputs(self, examples):
        input_ids, pixel_values, attention_mask = [], [], []
        image_exist, text_exist = False, False
        for example in examples:
            text, image = example
            if image is not None:
                if image.mode == 'L':
                    image = image.convert('RGB')
                image_inputs = self.vis_processors(image).unsqueeze(0)
                image_exist = True
                pixel_values.append(image_inputs)
            if text:
                text_exist = True
            text_inputs = self.txt_processors(text)
            input_ids.append(text_inputs)
        if text_exist:
            input_ids = torch.cat(input_ids, dim=0)
            attention_mask = input_ids.ne(0)
        if image_exist:
            pixel_values = torch.cat(pixel_values, dim=0)
        if text_exist and image_exist:
            assert input_ids.size()[0]==pixel_values.size()[0]
        inputs = {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'pixel_values': pixel_values,
        }

        return inputs


@dataclass
class MultimodalEvalDataCollator:
    processor: ProcessorMixin
    training_args: TrainingArguments
    model_args: ModelArguments
    data_args: DataArguments
    encode_side: str
    model_func_get_rope_index: Optional[Any] = None

    def _get_batch_inputs(self, batch, text_keyname, image_keyname):
        texts, visual_inputs = [], []
        for example in batch:
            if example is None or not example:
                text, visual_input = '  ', None
            else:
                ex_text, ex_images = example[text_keyname], example[image_keyname]
                # ex_text, ex_images could be one single pair from the query side or a list of pairs from the candidates side
                has_image = isinstance(ex_images, dict) or (isinstance(ex_images, list) and all(isinstance(item, dict) for item in ex_images))
                if has_image:
                    for text, raw_images in zip(ex_text, ex_images):
                        visual_input = []
                        has_missing_image = False
                        assert 'resolutions' in raw_images, "we need len(raw_images['resolutions']) to determine the number of images, set it a list of None of for cases that no resizing is needed"
                        num_images = len(raw_images['paths'])
                        for image_idx in range(num_images):
                            bytes = raw_images['bytes'][image_idx] if 'bytes' in raw_images else None
                            path = raw_images['paths'][image_idx] if 'paths' in raw_images else None
                            image_resolution = raw_images['resolutions'][image_idx] if 'resolutions' in raw_images else None
                            image = None
                            if bytes is None and path is None:
                                image = None
                            elif bytes is not None:
                                # vidore, image inputs are already bytes
                                image = Image.open(io.BytesIO(bytes))
                            elif path is not None:
                                # mmeb/video datasets, lazy image loading and processing
                                try:
                                    image = Image.open(path)
                                except Exception as e:
                                    print_rank(f"\n{'=' * 50}\nsomething went wrong from {example['global_dataset_name']} when loading image from path: {path}. Error: {e}")
                                    has_missing_image = True
                                    image = None
                            else:
                                print_rank(f"\n{'=' * 50}\nsomething went wrong with a data point from {example['global_dataset_name']}, neither bytes or path is given.")
                                has_missing_image = True
                                image = None
                            if not self.data_args.resize_use_processor and image is not None and image_resolution:
                                image = image.resize(image_resolution)
                            if image is not None and (image_resolution is not None and self.data_args.image_decay_factor is not None):
                                assert image_resolution is None, "image_resolution is conflicting with image_decay_factor"
                                assert self.model_args.model_backbone in [QWEN2_VL, QWEN2_5_VL, QWEN2_VL_TOKENSELECTION, QWEN2_5_VL_TOKENSELECTION], "image_decay_factor is only supported for Qwen models"
                                # TODO: this is a hacky way to decay image resolution, need to be refactored
                                max_pixels = max(self.data_args.resize_min_pixels, self.data_args.resize_max_pixels * self.data_args.image_decay_factor ** (num_images - image_idx))
                                width, height = image.size
                                resized_height, resized_width = smart_resize(
                                    height,
                                    width,
                                    min_pixels=self.data_args.resize_min_pixels,
                                    max_pixels=max_pixels,
                                )
                                image = image.resize((resized_width, resized_height))
                            visual_input.append(image)
                        if has_missing_image:
                            text = _strip_missing_image_tokens(text, self.model_args.model_backbone)
                            visual_input = None
                        texts.append(text)
                        visual_inputs.append(visual_input)
                else:
                    # flatten the list in cases of multiple candidates
                    for text, visual_input in zip(ex_text, ex_images):
                        texts.append(text)
                        visual_inputs.append(visual_input)
                        pass

        inputs = {'text': texts, 'images': visual_inputs}
        return inputs


    def __call__(self, examples):
        """
        :param examples: 'query_text', 'query_image', 'cand_text', 'cand_image'
        """
        process_fn = partial(process_vlm_inputs_fns[KORUS], task_type='retrieval') if self.model_args.compression_mode else  process_vlm_inputs_fns[self.model_args.model_backbone]
        if self.encode_side == 'qry':
            assert type(examples[0]['query_text']) == list or type(examples[0]['query_image']) == list, "Expect text/image to be a list, even it only contains a single element (string, dict or None)"
            inputs = self._get_batch_inputs(examples, "query_text", "query_image")
        else:
            assert type(examples[0]['cand_text']) == list or type(examples[0]['cand_image']) == list, "Expect text/image to be a list, even it only contains a single element (string, dict or None)"
            inputs = self._get_batch_inputs(examples, "cand_text", "cand_image")

        processed_inputs = process_fn(inputs, processor=self.processor, max_length=self.data_args.max_len)
        
        processed_qry_inputs['mlp_idx'] = [e['mlp_idx'] for e in examples]
        processed_pos_inputs['mlp_idx'] = [e['mlp_idx'] for e in examples]
        
        dataset_infos = [e["dataset_infos"] for e in examples]
        return processed_inputs, dataset_infos

@dataclass
class MultimodalInferDataCollator:
    processor: ProcessorMixin
    model_args: ModelArguments
    data_args: DataArguments
    training_args: TrainingArguments
    batch_size: Optional[int] = None  # used to verify if a batch has invalid data
    model_func_get_rope_index: Optional[Any] = None

    def _preprocess_image(
        self, image: "ImageObject", image_max_pixels=512*512, image_min_pixels=32*32
    ) -> "ImageObject":
        r"""Pre-process a single image."""
        if (image.width * image.height) > image_max_pixels:
            resize_factor = math.sqrt(image_max_pixels / (image.width * image.height))
            width, height = int(image.width * resize_factor), int(image.height * resize_factor)
            image = image.resize((width, height))

        if (image.width * image.height) < image_min_pixels:
            resize_factor = math.sqrt(image_min_pixels / (image.width * image.height))
            width, height = int(image.width * resize_factor), int(image.height * resize_factor)
            image = image.resize((width, height))

        if image.mode != "RGB":
            image = image.convert("RGB")

        return image

    def _constuct_conversations(self, enc_qry_inputs, enc_ans_inputs, dec_qry_inputs):
        conversations = []
        enc_texts = []
        for enc_qry_text, enc_ans_text, dec_qry_text in \
            zip(enc_qry_inputs['text'], enc_ans_inputs['text'], dec_qry_inputs['text']):
            enc_texts.append(enc_qry_text + enc_ans_text if enc_qry_text is not None and enc_ans_text is not None else "")
            conversations.append([
                {
                    "role": "user",
                    "content": [{"type": "text", "text": dec_qry_text}],
                },
            ])
        texts = self.processor.apply_chat_template(conversations, tokenize=False, add_generation_prompt=True)
        texts = [enc_t + t for enc_t, t in zip(enc_texts, texts)]  # filter out empty queries
        return {"text": texts, "images": enc_qry_inputs['images']}

    def _get_batch_inputs(self, batch, text_keyname, image_keyname):
        texts, visual_inputs = [], []
        for example in batch:
            # @ruimeng filter invalid data examples here may lead to fail to sync across devices (unequal batch size)
            # use dummy input for now
            if example is None or not example:
                text, visual_input = '  ', None
            else:
                text, raw_images = example[text_keyname], example[image_keyname] if image_keyname in example else None
                if type(raw_images) == dict:
                    visual_input = []
                    assert 'resolutions' in raw_images, "we need len(raw_images['resolutions']) to determine the number of images, set it a list of None of for cases that no resizing is needed"
                    num_images = len(raw_images['resolutions'])
                    for image_idx in range(num_images):
                        bytes = raw_images['bytes'][image_idx] if 'bytes' in raw_images else None
                        path = raw_images['paths'][image_idx] if 'paths' in raw_images else None
                        image_resolution = raw_images['resolutions'][image_idx] if 'resolutions' in raw_images else None
                        if bytes is None and path is None:
                            image = None
                        elif bytes is not None:
                            # vidore, image inputs are already bytes
                            image = Image.open(io.BytesIO(bytes))
                        elif path is not None:
                            try:
                            # mmeb/video datasets, lazy image loading and processing
                                with Image.open(path) as img:
                                    image = img.convert("RGB")
                            except:
                                print(traceback.format_exc())
                                # a black image
                                image = Image.new("RGB", (38, 38), (0, 0, 0))

                        else:
                            print_rank(f"\n{'=' * 50}\nsomething went wrong with a data point from {example['global_dataset_name']}, neither bytes or path is given. \n\t\tquery_text: {example['query_text']}")
                        # if not self.data_args.resize_use_processor and image is not None and image_resolution:
                        #     image = image.resize(image_resolution)
                        # if image is not None and (self.data_args.image_decay_factor is not None and image_resolution is None):
                        #     assert image_resolution is None, "image_resolution is conflicting with image_decay_factor"
                        #     assert self.model_args.model_backbone in [QWEN2_VL, QWEN2_5_VL, QWEN2_VL_TOKENSELECTION, QWEN2_5_VL_TOKENSELECTION], "image_decay_factor is only supported for Qwen models"
                        #     # TODO: this is a hacky way to decay image resolution, need to be refactored
                        #     max_pixels = max(self.data_args.resize_min_pixels, self.data_args.resize_max_pixels * self.data_args.image_decay_factor ** (num_images - image_idx))
                        #     width, height = image.size
                        #     resized_height, resized_width = smart_resize(
                        #         height,
                        #         width,
                        #         min_pixels=self.data_args.resize_min_pixels,
                        #         max_pixels=max_pixels,
                        #     )
                        #     image = image.resize((resized_width, resized_height))  
                        image = self._preprocess_image(image)
                        visual_input.append(image)
                else:
                    # TODO: remove audio here for now
                    visual_input = None
                    text = text.replace(VLM_IMAGE_TOKENS[self.training_args.model_backbone], '').replace(VLM_AUDIO_TOKENS[self.training_args.model_backbone], '')
                        
            texts.append(text)
            visual_inputs.append(visual_input)
        inputs = {'text': texts, 'images': visual_inputs}
        return inputs

    def _get_batch_audio_inputs(self, examples, audio_keyname):

        audio_inputs = []

        # from ipdb import set_trace; set_trace()

        for example in examples:
            if example is None or not example:
                audio_input = None
            else:
                audio_input = []
                raw_audios = example[audio_keyname] if audio_keyname in example else None
                if type(raw_audios) == dict:
                    assert 'resolutions' in raw_audios, "we need len(raw_images['resolutions']) to determine the number of images, set it a list of None of for cases that no resizing is needed"
                    num_audios = len(raw_audios['resolutions'])
                    for audio_idx in range(num_audios):
                        path = raw_audios['paths'][audio_idx] if 'paths' in raw_audios else None
                        if path is not None:
                            pass
                            # handle in process fn
                        else:
                            print_rank(f"\n{'=' * 50}\nsomething went wrong with a data point from {example['global_dataset_name']}, neither bytes or path is given. \n\t\tquery_text: {example['query_text']}")
                        
                        audio_input.append(path)
            
            audio_inputs.append(audio_input)
        return audio_inputs

    def __call__(self, examples):

        enc_qry_inputs = self._get_batch_inputs(examples, "encode_query", "encode_image")
        enc_ans_inputs = self._get_batch_inputs(examples, "encode_answer", "")
        dec_qry_inputs = self._get_batch_inputs(examples, "decode_query", "")

        inputs = self._constuct_conversations(enc_qry_inputs, enc_ans_inputs, dec_qry_inputs)

        audio_inputs = self._get_batch_audio_inputs(examples, "encode_audio")

        if len(audio_inputs) > 0:
            inputs['audios'] = audio_inputs

        bs = len(enc_qry_inputs['text'])
        assert bs > 0, 'An empty batch'
        # pad batch to batch_size to avoid hanging in distributed training
        if self.batch_size is not None and bs < self.batch_size:
            raise RuntimeError(f"Expect batch size {self.batch_size}, but got batch size of {bs}")

        moidel_backbone = self.training_args.model_backbone

        process_fn = partial(process_vlm_inputs_fns[KORUS_OMNI], task_type="openqa", prob=self.training_args.native_prob, get_rope_func=self.model_func_get_rope_index) \
                if self.model_args.compression_mode else process_vlm_inputs_fns[self.training_args.model_backbone]
        processed_inputs = process_fn(inputs, processor=self.processor, max_length=self.data_args.max_len, needs_label=False)
        processed_inputs['global_dataset_name'] = [e['global_dataset_name'] for e in examples]
        processed_inputs['task_type'] = [e['task_type'] for e in examples]
        processed_inputs['id'] = [e['id'] for e in examples]

        meta_infos = [
            {
                'images': example["encode_image"]["paths"],
                "audios": example["encode_audio"]["paths"],
                "category": example.get("category", None),
            }
            for example in examples    
        ]

        return processed_inputs, meta_infos

@dataclass
class MultimodalI2IDataCollator(MultimodalEvalDataCollator):
    encode_side: str = 'qry'
    cls_type_to_indices: Dict[str, List[int]] = field(default_factory=lambda: { None: [0, TOTAL_COMPRESS_TOKENS] })

    def __post_init__(self):
        cls_sep_indices = set()
        for cls_indices in self.cls_type_to_indices.values():
            cls_sep_indices.add(cls_indices[0])
            cls_sep_indices.add(cls_indices[-1] + 1)
        self.cls_sep_indices = sorted(list(cls_sep_indices))


    def _get_batch_audio_inputs(self, examples, audio_keyname):

        audio_inputs = []

        # from ipdb import set_trace; set_trace()

        for example in examples:
            if example is None or not example:
                audio_input = None
            else:
                audio_input = []
                raw_audios = example[audio_keyname] if audio_keyname in example else None
                if type(raw_audios) == dict:
                    assert 'resolutions' in raw_audios, "we need len(raw_images['resolutions']) to determine the number of images, set it a list of None of for cases that no resizing is needed"
                    num_audios = len(raw_audios['resolutions'])
                    for audio_idx in range(num_audios):
                        path = raw_audios['paths'][audio_idx] if 'paths' in raw_audios else None
                        if path is not None:
                            pass
                            # handle in process fn
                        else:
                            print_rank(f"\n{'=' * 50}\nsomething went wrong with a data point from {example['global_dataset_name']}, neither bytes or path is given. \n\t\tquery_text: {example['query_text']}")
                        
                        audio_input.append(path)
            
            audio_inputs.append(audio_input)
        return audio_inputs

    def __call__(self, examples):
        """
        :param examples: 'id', 'texts', 'images', 'audios'
        """
        assert type(examples[0]['texts']) == list and type(examples[0]['images']) == list, "Expect text/image to be a list, even it only contains a single element (string, dict or None)"
        process_fn = partial(process_vlm_inputs_fns[KORUS_OMNI], task_type='retrieval') if self.model_args.compression_mode else  process_vlm_inputs_fns[self.model_args.model_backbone]
        inputs = self._get_batch_inputs(examples, "texts", "images")

        audio_inputs = self._get_batch_audio_inputs(examples, "audios")

        if len(audio_inputs) > 0:
            inputs['audios'] = audio_inputs

        inputs['cls_indices'] = [self.cls_type_to_indices[e["cls_type"]] for e in examples]

        processed_inputs = process_fn(inputs, processor=self.processor, max_length=self.data_args.max_len, get_rope_func=self.model_func_get_rope_index, cls_sep_indices=self.cls_sep_indices)
        
        processed_inputs['mlp_idx'] = [e['mlp_idx'] for e in examples]
        processed_inputs['mlp_idx'] = [e['mlp_idx'] for e in examples]

        meta_infos = [
            {
                "id": e["id"],
                "labels": e["labels"],
            } 
            for e in examples
        ]
        return processed_inputs, meta_infos
