import argparse
import json
import os
import pickle
import shutil
from collections import OrderedDict

import numpy as np
import torch

from src.model.projector import apply_projector, load_projector_artifacts


def parse_args():
    parser = argparse.ArgumentParser(description="Apply a cached projector to pickled embedding files.")
    parser.add_argument("--projector_path", required=True)
    parser.add_argument("--input_dir", required=True, help="Directory containing <Dataset>.pickle files.")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--datasets", nargs="*", default=None, help="Dataset basenames without .pickle. Defaults to all pickles.")
    parser.add_argument("--head_name", default=None, help="Specific multi-head projector head to export. Defaults to all heads.")
    parser.add_argument("--batch_size", type=int, default=4096)
    parser.add_argument("--dtype", choices=["float32", "float16"], default="float32")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    return parser.parse_args()


def convert_output(tensor: torch.Tensor, dtype: str):
    arr = tensor.detach().cpu().numpy()
    if dtype == "float16":
        return arr.astype(np.float16, copy=False)
    return arr.astype(np.float32, copy=False)


def iter_dataset_names(input_dir: str, selected):
    if selected:
        return selected
    names = []
    for filename in os.listdir(input_dir):
        if filename.endswith(".pickle"):
            names.append(filename[:-7])
    return sorted(names)


def save_info_file(input_dir: str, output_dir: str, dataset_name: str):
    src = os.path.join(input_dir, f"{dataset_name}_info.jsonl")
    if os.path.exists(src):
        shutil.copyfile(src, os.path.join(output_dir, f"{dataset_name}_info.jsonl"))


def main():
    args = parse_args()
    projector, config = load_projector_artifacts(args.projector_path, map_location="cpu")
    projector.to(args.device)
    projector.eval()
    os.makedirs(args.output_dir, exist_ok=True)
    with open(os.path.join(args.output_dir, "projector_config.json"), "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, sort_keys=True)
        f.write("\n")

    for dataset_name in iter_dataset_names(args.input_dir, args.datasets):
        input_path = os.path.join(args.input_dir, f"{dataset_name}.pickle")
        if not os.path.exists(input_path):
            raise FileNotFoundError(input_path)
        with open(input_path, "rb") as f:
            embeds = pickle.load(f)
        ids = list(embeds.keys())
        values = [np.asarray(embeds[item_id]) for item_id in ids]

        outputs = {}
        with torch.no_grad():
            for start in range(0, len(ids), args.batch_size):
                batch_ids = ids[start : start + args.batch_size]
                batch = torch.as_tensor(np.stack(values[start : start + args.batch_size]), device=args.device, dtype=torch.float32)
                projected = apply_projector(projector, batch, config, head_name=args.head_name)
                if isinstance(projected, dict):
                    for head, tensor in projected.items():
                        outputs.setdefault(head, OrderedDict())
                        for item_id, row in zip(batch_ids, tensor):
                            outputs[head][item_id] = convert_output(row, args.dtype)
                else:
                    outputs.setdefault(args.head_name or "default", OrderedDict())
                    for item_id, row in zip(batch_ids, projected):
                        outputs[args.head_name or "default"][item_id] = convert_output(row, args.dtype)

        for head, head_embeds in outputs.items():
            head_dir = args.output_dir if args.head_name else os.path.join(args.output_dir, f"head_{head}")
            os.makedirs(head_dir, exist_ok=True)
            with open(os.path.join(head_dir, f"{dataset_name}.pickle"), "wb") as f:
                pickle.dump(dict(head_embeds), f)
            save_info_file(args.input_dir, head_dir, dataset_name)
            print(json.dumps({"dataset": dataset_name, "head": head, "count": len(head_embeds), "output_dir": head_dir}))


if __name__ == "__main__":
    main()
