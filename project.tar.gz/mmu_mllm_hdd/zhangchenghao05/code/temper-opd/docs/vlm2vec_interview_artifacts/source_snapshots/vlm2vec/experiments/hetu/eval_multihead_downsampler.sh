#!/bin/bash
set -euo pipefail

# 多输出头降维模块评估脚本
# 评估64/32/16三个维度的性能

REPO_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_DIR"

export http_proxy=[REDACTED_PROXY]
export https_proxy=[REDACTED_PROXY]
export no_proxy=[REDACTED_NO_PROXY]

MODEL_PATH="${1:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/multihead_downsampler/multihead_64_32_16}"
EVAL_YAML="${2:-experiments/hetu/eval_goods_0402_test3_emb.yaml}"
OUTPUT_ROOT="${3:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/eval_multihead}"

GPUS_PER_NODE="${GPUS_PER_NODE:-8}"
TORCHRUN="${TORCHRUN:-/mmu_mllm_hdd/zhangchenghao05/envs/vlm2vec/bin/torchrun}"

export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface/datasets}"

# 评估每个头
echo "=========================================="
echo "Evaluating Multi-head Downsampler"
echo "Model: $MODEL_PATH"
echo "=========================================="

for HEAD_NAME in 64 32 16; do
    echo ""
    echo "========== Evaluating Head: $HEAD_NAME =========="

    HEAD_OUTPUT_DIR="$OUTPUT_ROOT/head_$HEAD_NAME"
    mkdir -p "$HEAD_OUTPUT_DIR"

    CMD=(
        "$TORCHRUN"
        --nproc-per-node "$GPUS_PER_NODE"
        --nnodes 1
        --rdzv-backend c10d
        --rdzv-id "eval_head_${HEAD_NAME}"
        --rdzv-endpoint localhost:0
        eval.py
        --dataset_config "$EVAL_YAML"
        --encode_output_path "$HEAD_OUTPUT_DIR"
        --model_name "$MODEL_PATH"
        --pooling multi_head_mlp
        --similarity_type "${SIMILARITY_TYPE:-maxsim}"
        --normalize True
        --compression_mode
        --bf16
        --eval_head_name "$HEAD_NAME"
    )

    echo "Command: ${CMD[*]}"
    "${CMD[@]}" 2>&1 | tee "$HEAD_OUTPUT_DIR/eval.log"

    # 打印主要指标
    if [ -f "$HEAD_OUTPUT_DIR/IA_Pair_0402_score.json" ]; then
        echo "=== Head $HEAD_NAME Results ==="
        cat "$HEAD_OUTPUT_DIR/IA_Pair_0402_score.json" | python3 -m json.tool
    fi
done

echo ""
echo "All evaluations completed!"
