from typing import List, Union, Callable, Any
from contextlib import nullcontext
from itertools import repeat
from collections import UserDict
import logging
import os

import torch
from torch import nn, Tensor
from torch.cuda.amp import GradScaler, autocast
from src.grad_cache.context_managers import RandContext
from src.utils import print_master

logger = logging.getLogger(__name__)


def _maybe_log_cuda_mem(tag: str):
    if os.environ.get("VLM2VEC_MEM_DEBUG", "").lower() not in {"1", "true", "yes"}:
        return
    if not torch.cuda.is_available():
        return
    device = torch.cuda.current_device()
    allocated_gb = torch.cuda.memory_allocated(device) / (1024 ** 3)
    reserved_gb = torch.cuda.memory_reserved(device) / (1024 ** 3)
    max_allocated_gb = torch.cuda.max_memory_allocated(device) / (1024 ** 3)
    max_reserved_gb = torch.cuda.max_memory_reserved(device) / (1024 ** 3)
    print_master(
        f"[mem] {tag} alloc={allocated_gb:.2f}GiB reserved={reserved_gb:.2f}GiB "
        f"max_alloc={max_allocated_gb:.2f}GiB max_reserved={max_reserved_gb:.2f}GiB"
    )


class GradCache:
    """
    Gradient Cache class. Implements input chunking, first graph-less forward pass, Gradient Cache creation, second
    forward & backward gradient computation. Optimizer step is not included. Native torch automatic mixed precision is
    supported. User needs to handle gradient unscaling and scaler update after a gradeitn cache step.
    """
    def __init__(
        self,
        models: List[nn.Module],
        chunk_sizes: Union[int, List[int]],
        loss_fn: Callable[..., Tensor],
        aux_loss_fn: Callable[..., Tensor] = None,
        aux_metrics_fn: Callable[..., Any] = None,
        split_input_fn: Callable[[Any, int], Any] = None,
        get_rep_fn: Callable[..., Tensor] = None,
        fp16: bool = False,
        scaler: GradScaler = None,
        process_fn: Callable = None,
        retrv_loss_weight: float = 1.0,
    ):
        """
        Initialize the Gradient Cache class instance.
        :param models: A list of all encoder models to be updated by the current cache.
        :param chunk_sizes: An integer indicating chunk size. Or a list of integers of chunk size for each model.
        :param loss_fn: A loss function that takes arbitrary numbers of representation tensors and
        arbitrary numbers of keyword arguments as input. It should not in any case modify the input tensors' relations
        in the autograd graph, which are later relied upon to create the gradient cache.
        :param split_input_fn: An optional function that split generic model input into chunks. If not provided, this
        class will try its best to split the inputs of supported types. See `split_inputs` function.
        :param get_rep_fn: An optional function that takes generic model output and return representation tensors. If
        not provided, the generic output is assumed to be the representation tensor.
        :param fp16: If True, run mixed precision training, which requires scaler to also be set.
        :param scaler: A GradScaler object for automatic mixed precision training.
        """
        self.models = models

        if isinstance(chunk_sizes, int):
            self.chunk_sizes = [chunk_sizes for _ in range(len(models))]
        else:
            self.chunk_sizes = chunk_sizes

        self.split_input_fn = split_input_fn
        self.process_fn = process_fn
        self.get_rep_fn = get_rep_fn
        self.loss_fn = loss_fn
        self.aux_loss_fn = aux_loss_fn
        self.aux_metrics_fn = aux_metrics_fn
        self.retrv_loss_weight = retrv_loss_weight

        if fp16:
            assert scaler is not None, "mixed precision training requires a gradient scaler passed in"

        self.fp16 = fp16
        self.scaler = scaler

        self._get_input_tensors_strict = False

    def __call__(self, *args, **kwargs):
        """
        Call the cache_step function.
        :return: Current step loss.
        """
        return self.cache_step(*args, **kwargs)

    def split_inputs(self, model_input, chunk_size: int) -> List:
        """
        Split input into chunks. Will call user provided `split_input_fn` if specified. Otherwise,
        it can handle input types of tensor, list of tensors and dictionary of tensors.
        :param model_input: Generic model input.
        :param chunk_size:  Size of each chunk.
        :return: A list of chunked model input.
        """
        # delegate splitting to user provided function
        if self.split_input_fn is not None:
            return self.split_input_fn(model_input, chunk_size)

        if isinstance(model_input, (dict, UserDict)) and all(isinstance(x, Tensor) for x in model_input.values()):
            keys = list(model_input.keys())
            chunked_tensors = [model_input[k].split(chunk_size, dim=0) for k in keys]
            return [dict(zip(kk, tt)) for kk, tt in zip(repeat(keys), zip(*chunked_tensors))]

        elif isinstance(model_input, list) and all(isinstance(x, Tensor) for x in model_input):
            chunked_x = [t.split(chunk_size, dim=0) for t in model_input]
            return [list(s) for s in zip(*chunked_x)]

        elif isinstance(model_input, Tensor):
            return list(model_input.split(chunk_size, dim=0))

        elif isinstance(model_input, tuple) and list(map(type, model_input)) == [list, dict]:
            args_chunks = self.split_inputs(model_input[0], chunk_size)
            kwargs_chunks = self.split_inputs(model_input[1], chunk_size)
            return list(zip(args_chunks, kwargs_chunks))

        else:
            raise NotImplementedError(f'Model input split not implemented for type {type(model_input)}')

    def get_input_tensors(self, model_input) -> List[Tensor]:
        """
        Recursively go through model input and grab all tensors, which are then used to record current device random
        states. This method will do its best to parse types of Tensor, tuple, list, dict and UserDict. Other types will
        be ignored unless self._get_input_tensors_strict is set to True, in which case an exception will be raised.
        :param model_input: input to model
        :return: all torch tensors in model_input
        """
        if isinstance(model_input, Tensor):
            return [model_input]

        elif isinstance(model_input, (list, tuple)):
            return sum((self.get_input_tensors(x) for x in model_input), [])

        elif isinstance(model_input, (dict, UserDict)):
            return sum((self.get_input_tensors(x) for x in model_input.values()), [])

        elif self._get_input_tensors_strict:
            raise NotImplementedError(f'get_input_tensors not implemented for type {type(model_input)}')

        else:
            return []

    def model_call(self, model: nn.Module, model_input):
        """
        Literally call the model's __call__ method.
        :param model: model to be called
        :param model_input: input to the model call
        :return: model output
        """
        with autocast() if self.fp16 else nullcontext():
            if isinstance(model_input, Tensor):
                return model(model_input)
            elif isinstance(model_input, list):
                return model(*model_input)
            elif isinstance(model_input, (dict, UserDict)):
                return model(**model_input)
            elif isinstance(model_input, tuple) and list(map(type, model_input)) == [list, dict]:
                model_args, model_kwargs = model_input
                return model(*model_args, **model_kwargs)
            else:
                raise NotImplementedError

    def get_reps(self, model_out) -> Tensor:
        """
        Return representation tensor from generic model output
        :param model_out: generic model output
        :return: a single tensor corresponding to the model representation output
        """
        if self.get_rep_fn is not None:
            return self.get_rep_fn(model_out)
        else:
            return model_out

    def compute_loss(self, *reps: Tensor, aux_reps = None,  **loss_kwargs) -> Tensor:
        """
        Compute the loss based on the representation tensors. The tensors should be ordered same as the list of models
        registered in this GradCache class instance.
        :param reps: Representations for computing the loss.
        :param loss_kwargs: Keyword arguments input to the loss function.
        :return: the loss tensor.
        """
        loss = self.loss_fn(*reps, **loss_kwargs)
        if type(loss) == tuple:
            loss, metrics = loss
        else:
            metrics = None
        # Note: aux_loss is handled separately in build_cache for gradient caching
        return loss, metrics

    def forward_no_grad(
        self,
        model: nn.Module,
        model_inputs,
    ) -> Union[Tensor, List[RandContext]]:
        """
        The first forward pass without gradient computation.
        :param model: Encoder model.
        :param model_inputs: Model input already broken into chunks.
        :return: A tuple of a) representations and b) recorded random states.
        """
        if model_inputs is None:
            return None, None, None
        
        rnd_states = []
        model_reps = []
        model_aux_reps = []

        with torch.no_grad():
            for x in model_inputs:
                rnd_states.append(RandContext(*self.get_input_tensors(x)))
                y = self.model_call(model, x)
                reps, aux_reps = self.get_reps(y)
                model_reps.append(reps)
                model_aux_reps.append(aux_reps)

        # concatenate all sub-batch representations
        model_reps = torch.cat(model_reps, dim=0)
        if model_aux_reps and all(r is not None for r in model_aux_reps):
            model_aux_reps = torch.cat(model_aux_reps, dim=0)
        else:
            model_aux_reps = None
        _maybe_log_cuda_mem("forward_no_grad.done")
        return model_reps, model_aux_reps, rnd_states

    def build_cache(self, *reps: Tensor, aux_reps = None, deepspeed = None, **loss_kwargs) -> Union[List[Tensor], Tensor]:
        """
        Compute the gradient cache
        :param reps: Computed representations from all encoder models
        :param loss_kwargs: Extra keyword arguments to the loss function
        :return: A tuple of a) gradient cache for each encoder model, b) aux gradient cache, c) loss tensor, d) metrics
        """
        reps = [r.detach().requires_grad_() for r in reps if r is not None]
        aux_cache = None
        aux_metric_logs = None
        aux_metric_reps = None
        aux_raw_logs = None
        if aux_reps is not None:
            aux_metric_reps = [r.detach() for r in aux_reps if r is not None]
        if aux_metric_reps and self.aux_metrics_fn is not None:
            with torch.no_grad():
                aux_metric_logs = self.aux_metrics_fn(*aux_metric_reps)
        if aux_reps is not None and self.aux_loss_fn is not None:
            aux_reps = [r.detach().requires_grad_() for r in aux_reps if r is not None]
            if aux_reps:
                _maybe_log_cuda_mem("build_cache.before_aux_loss")
                with autocast() if self.fp16 else nullcontext():
                    aux_loss, raw_aux_loss = self.aux_loss_fn(*aux_reps, return_raw=True)
                    if isinstance(raw_aux_loss, dict):
                        aux_raw_logs = {
                            k: (v.item() if isinstance(v, torch.Tensor) else float(v))
                            for k, v in raw_aux_loss.items()
                        }
                    else:
                        aux_raw_logs = {"aux_loss": raw_aux_loss.item()}
                print_master(str(aux_raw_logs))
                _maybe_log_cuda_mem("build_cache.after_aux_loss")
                aux_loss.backward()
                _maybe_log_cuda_mem("build_cache.after_aux_backward")
                aux_cache = [r.grad for r in aux_reps]
        with autocast() if self.fp16 else nullcontext():
            loss, metrics = self.compute_loss(*reps, aux_reps=None, **loss_kwargs)

        # Add aux_loss to metrics for logging
        if aux_raw_logs:
            if metrics is None:
                metrics = {}
            metrics.update(aux_raw_logs)
        if aux_metric_logs:
            if metrics is None:
                metrics = {}
            metrics.update(aux_metric_logs)

        loss = loss * self.retrv_loss_weight  # scale loss by retrv_loss_weight

        if deepspeed is None:
            if self.fp16:
                self.scaler.scale(loss).backward()
            else:
                loss.backward()
        else:
            deepspeed.backward(loss)
        _maybe_log_cuda_mem("build_cache.after_main_backward")

        cache = [r.grad for r in reps]

        return cache, aux_cache, loss.detach(), metrics

    def forward_backward(
        self,
        model: nn.Module,
        model_inputs,
        cached_gradients: List[Tensor],
        random_states: List[RandContext],
        aux_cached_gradients=None,
        no_sync_except_last: bool = False,
        deepspeed: object = None,
    ):
        """
        Run the second forward and the backward pass to compute gradient for a model.
        :param model: Encoder model.
        :param model_inputs: Chunked input to the encoder model.
        :param cached_gradients: Chunked gradient cache tensor for each input.
        :param random_states: Each input's device random state during the first forward.
        :param no_sync_except_last: If True, under distributed setup, only trigger gradient reduction across processes
        for the last sub-batch's forward-backward pass.
        """
        if aux_cached_gradients is None:
            aux_cached_gradients = [None] * len(model_inputs)
        if no_sync_except_last and deepspeed is None:
            sync_contexts = [model.no_sync for _ in range(len(model_inputs) - 1)] + [nullcontext]
        else:
            sync_contexts = [nullcontext for _ in range(len(model_inputs))]
        if deepspeed is not None:
            do_sync = deepspeed.is_gradient_accumulation_boundary()
            deepspeed.set_gradient_accumulation_boundary(False)
        for i, (x, state, gradient, aux_gradient, sync_context) in enumerate(zip(model_inputs, random_states, cached_gradients, aux_cached_gradients, sync_contexts)):
            with sync_context():
                with state:
                    _maybe_log_cuda_mem(f"forward_backward.before_forward[{i}]")
                    y = self.model_call(model, x)
                    _maybe_log_cuda_mem(f"forward_backward.after_forward[{i}]")
                reps, aux_reps = self.get_reps(y)

                surrogate = torch.dot(reps.flatten(), gradient.flatten())
                if aux_gradient is not None and aux_reps is not None:
                    surrogate = surrogate + torch.dot(aux_reps.flatten(), aux_gradient.flatten())
                if deepspeed is None:
                    surrogate.backward()
                else:
                    if i == len(model_inputs) - 1 and do_sync:
                        deepspeed.set_gradient_accumulation_boundary(True)
                    deepspeed.backward(surrogate)
                _maybe_log_cuda_mem(f"forward_backward.after_backward[{i}]")
        if deepspeed is not None and do_sync:
            deepspeed.step()

    def cache_step(
        self,
        *model_inputs,
        no_sync_except_last: bool = False,
        deepspeed: object = None,
        **loss_kwargs
    ) -> Tensor:
        """
        Run a cached step to compute gradient over the inputs.
        :param model_inputs: Input to each encoder model. Should be in similar order as the class's model.
        :param no_sync_except_last: If True, under distributed setup, for each model, only trigger gradient reduction
        across processes for the last sub-batch's forward-backward pass.
        :param loss_kwargs: Additional keyword arguments to the loss function.
        :return: The current's loss.
        """
        all_reps = []
        all_aux_reps = []
        all_rnd_states = []

        if no_sync_except_last:
            assert deepspeed is not None or all(map(lambda m: isinstance(m, nn.parallel.DistributedDataParallel), self.models)), \
                'Some of models are not wrapped in DistributedDataParallel. Make sure you are running DDP with ' \
                'proper initializations.'

        model_inputs = [self.split_inputs(x, chunk_size) for x, chunk_size in zip(model_inputs, self.chunk_sizes)]
        if self.process_fn:
            # each minibatch -> self.process_fn(minibatch)
            _model_inputs = []
            for arg_group in model_inputs:
                _arg_groups = []
                for key2val_dict in arg_group:
                    _key2val_dict = {}
                    for arg_key, arg_val in key2val_dict.items():
                        _key2val_dict[arg_key] = self.process_fn(arg_val)
                    _arg_groups.append(_key2val_dict)
                _model_inputs.append(_arg_groups)
            model_inputs = _model_inputs

        for model, x in zip(self.models, model_inputs):
            model_reps, model_aux_reps, rnd_states = self.forward_no_grad(model, x)  # forward with sub-batches (batch_size // chunk_size) and concat to one resp (no grad)
            all_reps.append(model_reps)
            all_aux_reps.append(model_aux_reps)
            all_rnd_states.append(rnd_states)

        cache, aux_cache, loss, metrics = self.build_cache(*all_reps, aux_reps=all_aux_reps, deepspeed=deepspeed, **loss_kwargs)  # resp gradient (∂L/∂y)
        cache = [c.split(chunk_size) for c, chunk_size in zip(cache, self.chunk_sizes)]  # split grad cache into sub-batches
        if aux_cache is not None:
            aux_cache = [c.split(chunk_size) if c is not None else None for c, chunk_size in zip(aux_cache, self.chunk_sizes)]
        else:
            aux_cache = [None] * len(self.models)

        for model, x, model_cache, model_aux_cache, rnd_states in zip(
                self.models, model_inputs, cache, aux_cache, all_rnd_states):
            self.forward_backward(model, x, model_cache, rnd_states, aux_cached_gradients=model_aux_cache, no_sync_except_last=no_sync_except_last, deepspeed=deepspeed)  # forward with sub-batches (batch_size // chunk_size) and backward with grad cache (∂L/∂y)
        return loss, metrics
