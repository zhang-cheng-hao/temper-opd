from __future__ import annotations

import math
from typing import Dict, List, Optional

import torch
import torch.nn.functional as F


def cosine_similarity_matrix(x: torch.Tensor) -> torch.Tensor:
    x = F.normalize(x.float(), p=2, dim=-1)
    return x @ x.transpose(-2, -1)


def _safe_quantile(x: torch.Tensor, q: float) -> float:
    if x.numel() == 0:
        return 0.0
    return torch.quantile(x.float(), q).item()


def per_sample_ce_loss(logits: torch.Tensor, labels: torch.Tensor, ignore_index: int = -100) -> torch.Tensor:
    logits = logits[..., :-1, :].contiguous()
    labels = labels[..., 1:].contiguous()
    vocab = logits.shape[-1]
    flat_loss = F.cross_entropy(
        logits.reshape(-1, vocab),
        labels.reshape(-1),
        ignore_index=ignore_index,
        reduction="none",
    ).view_as(labels)
    valid = labels.ne(ignore_index)
    denom = valid.sum(dim=-1).clamp_min(1)
    return (flat_loss * valid).sum(dim=-1) / denom


def compute_similarity_spectrum(sample_reps: torch.Tensor) -> Dict[str, float]:
    if sample_reps is None or sample_reps.dim() != 2 or sample_reps.shape[0] <= 1:
        return {
            "xseq/sim_top1_mean": 0.0,
            "xseq/sim_top2_mean": 0.0,
            "xseq/sim_bottom_mean": 0.0,
        }

    sim = cosine_similarity_matrix(sample_reps)
    bsz = sim.shape[0]
    sim = sim.masked_fill(torch.eye(bsz, device=sim.device, dtype=torch.bool), -float("inf"))
    topk = sim.topk(k=min(2, bsz - 1), dim=-1).values
    bottom = sim.masked_fill(torch.isinf(sim), float("inf")).amin(dim=-1)
    top1 = topk[:, 0]
    top2 = topk[:, 1] if topk.shape[1] > 1 else top1
    return {
        "xseq/sim_top1_mean": top1.mean().item(),
        "xseq/sim_top2_mean": top2.mean().item(),
        "xseq/sim_bottom_mean": bottom.mean().item(),
    }


def _linear_cca_corr(x: torch.Tensor, y: torch.Tensor, eps: float = 1e-4) -> torch.Tensor:
    if x.shape[0] <= 1:
        return x.new_zeros(())
    x = x.float() - x.float().mean(dim=0, keepdim=True)
    y = y.float() - y.float().mean(dim=0, keepdim=True)
    ux, sx, _ = torch.linalg.svd(x, full_matrices=False)
    uy, sy, _ = torch.linalg.svd(y, full_matrices=False)
    valid_x = sx > eps
    valid_y = sy > eps
    if not valid_x.any() or not valid_y.any():
        return x.new_zeros(())
    ux = ux[:, valid_x]
    uy = uy[:, valid_y]
    corr = torch.linalg.svdvals(ux.transpose(0, 1) @ uy)
    return corr.mean()


def _conditional_entropy_from_slots(slots: torch.Tensor, temperature: float = 0.1) -> torch.Tensor:
    if slots.shape[0] <= 1 or slots.shape[1] <= 1:
        return slots.new_zeros(())
    slots = F.normalize(slots.float(), p=2, dim=-1)
    pair_sims = torch.einsum("bqd,ckd->bcqk", slots, slots)
    batch_size = pair_sims.shape[0]
    if batch_size > 1:
        pair_mask = ~torch.eye(batch_size, device=slots.device, dtype=torch.bool)
        pair_sims = pair_sims[pair_mask]
    else:
        pair_sims = pair_sims.reshape(-1, pair_sims.shape[-2], pair_sims.shape[-1])
    if pair_sims.numel() == 0:
        return slots.new_zeros(())
    probs = F.softmax(pair_sims / max(temperature, 1e-4), dim=-1)
    entropy = -(probs * torch.log(probs.clamp_min(1e-8))).sum(dim=-1)
    return entropy.mean()


def compute_sample_gate(
    sims: torch.Tensor,
    use_softmax: bool = True,
    temperature: float = 0.07,
    eps: float = 1e-6,
) -> torch.Tensor:
    if sims.numel() == 0:
        return sims.new_zeros(sims.shape)
    if use_softmax:
        tau = max(float(temperature), 1e-4)
        return F.softmax(sims.float() / tau, dim=-1).clamp_min(eps)
    return ((sims.float() + 1.0) * 0.5).clamp_min(eps)


def compute_slot_aligned_similarity(query_slots: torch.Tensor, key_slots: torch.Tensor) -> torch.Tensor:
    query_slots = F.normalize(query_slots.float(), p=2, dim=-1)
    key_slots = F.normalize(key_slots.float(), p=2, dim=-1)
    if query_slots.dim() == 2:
        query_slots = query_slots.unsqueeze(0)
    if key_slots.dim() == 2:
        key_slots = key_slots.unsqueeze(0)
    if query_slots.shape[-2] != key_slots.shape[-2]:
        raise ValueError(
            f"slot_aligned expects same slot count, got {tuple(query_slots.shape)} vs {tuple(key_slots.shape)}"
        )
    return torch.einsum("bsd,nsd->bns", query_slots, key_slots).mean(dim=-1)


def compute_xseq_slot_diagnostics(
    slots_by_layer: Dict[int, torch.Tensor],
    hsic_fn,
    batch_size_limit: int = 8,
) -> Dict[str, float]:
    diag_logs: Dict[str, float] = {}
    for layer_idx, slot_tokens in slots_by_layer.items():
        if slot_tokens is None or slot_tokens.dim() != 3:
            continue
        x = slot_tokens[:batch_size_limit]
        if x.shape[0] == 0:
            continue
        hsic = hsic_fn(x)
        diag_logs[f"xseq/layer_{layer_idx}_hsic_mean"] = float(hsic["hsic_mean"])
        diag_logs[f"xseq/layer_{layer_idx}_slot_offdiag_abs_mean"] = float(hsic["offdiag_cos_abs_mean"])
        diag_logs[f"xseq/layer_{layer_idx}_slot_offdiag_abs_max"] = float(hsic["offdiag_cos_abs_max"])

        cca_scores: List[torch.Tensor] = []
        slot_count = x.shape[1]
        for i in range(slot_count):
            xi = x[:, i, :]
            for j in range(i + 1, slot_count):
                xj = x[:, j, :]
                cca_scores.append(_linear_cca_corr(xi, xj))
        if cca_scores:
            cca_vals = torch.stack(cca_scores)
            diag_logs[f"xseq/layer_{layer_idx}_cca_mean"] = cca_vals.mean().item()
            diag_logs[f"xseq/layer_{layer_idx}_cca_max"] = cca_vals.max().item()
        else:
            diag_logs[f"xseq/layer_{layer_idx}_cca_mean"] = 0.0
            diag_logs[f"xseq/layer_{layer_idx}_cca_max"] = 0.0

        cond_ent = _conditional_entropy_from_slots(x)
        diag_logs[f"xseq/layer_{layer_idx}_conditional_entropy"] = cond_ent.item()
    return diag_logs


class XSeqMemoryBank:
    def __init__(self, capacity: int = 4096, topk: int = 8):
        self.capacity = max(int(capacity), 1)
        self.topk = max(int(topk), 1)
        self.entries: List[Optional[dict]] = []
        self.ptr = 0

    def __len__(self) -> int:
        return len(self.entries)

    @torch.no_grad()
    def update(
        self,
        sample_ids: List[str],
        cls_types: List[Optional[str]],
        sample_reps: Optional[torch.Tensor],
        slots_by_layer: Dict[int, torch.Tensor],
        sample_slots: Optional[torch.Tensor] = None,
    ) -> None:
        if (sample_reps is None or sample_reps.dim() != 2) and (sample_slots is None or sample_slots.dim() != 3):
            return

        sample_reps_cpu = (
            sample_reps.detach().to(device="cpu", dtype=torch.bfloat16)
            if sample_reps is not None and sample_reps.dim() == 2
            else None
        )
        sample_slots_cpu = (
            sample_slots.detach().to(device="cpu", dtype=torch.bfloat16)
            if sample_slots is not None and sample_slots.dim() == 3
            else None
        )
        layer_cache = {
            int(layer_idx): layer_slots.detach().to(device="cpu", dtype=torch.bfloat16)
            for layer_idx, layer_slots in slots_by_layer.items()
            if layer_slots is not None
        }
        batch_size = sample_reps_cpu.shape[0] if sample_reps_cpu is not None else sample_slots_cpu.shape[0]
        for row in range(batch_size):
            entry = {
                "sample_id": str(sample_ids[row]),
                "cls_type": cls_types[row],
                "sample_rep": sample_reps_cpu[row].clone() if sample_reps_cpu is not None else None,
                "sample_slots": sample_slots_cpu[row].clone() if sample_slots_cpu is not None else None,
                "slots_by_layer": {layer_idx: layer_slots[row].clone() for layer_idx, layer_slots in layer_cache.items()},
            }
            if len(self.entries) < self.capacity:
                self.entries.append(entry)
            else:
                self.entries[self.ptr] = entry
                self.ptr = (self.ptr + 1) % self.capacity

    def retrieve(
        self,
        query_reps: Optional[torch.Tensor],
        query_slots: Optional[torch.Tensor],
        sample_ids: List[str],
        cls_types: List[Optional[str]],
        layers: List[int],
        topk: Optional[int] = None,
        similarity_type: str = "dense",
        same_cls_only: bool = True,
        sample_softmax: bool = True,
        sample_tau: float = 0.07,
        device: Optional[torch.device] = None,
        dtype: Optional[torch.dtype] = None,
    ) -> dict:
        topk = max(int(topk or self.topk), 1)
        ref_tensor = query_reps if query_reps is not None else query_slots
        if ref_tensor is None:
            raise ValueError("xseq retrieve requires either query_reps or query_slots")
        batch_size = ref_tensor.shape[0]
        sample_cos = ref_tensor.new_zeros((batch_size, topk), dtype=torch.float32)
        sample_gate = ref_tensor.new_zeros((batch_size, topk), dtype=torch.float32)
        candidate_count = ref_tensor.new_zeros((batch_size,), dtype=torch.float32)
        slots_by_layer = {
            int(layer_idx): ref_tensor.new_zeros(
                (batch_size, topk, 0, ref_tensor.shape[-1]),
                dtype=dtype or ref_tensor.dtype,
                device=device or ref_tensor.device,
            )
            for layer_idx in layers
        }
        if not self.entries:
            return {
                "sample_cos": sample_cos,
                "sample_gate": sample_gate,
                "slots_by_layer": slots_by_layer,
                "candidate_count": candidate_count,
            }

        # Keep the query branch differentiable while treating bank entries as
        # stop-grad memory.
        query_norm = (
            F.normalize(query_reps.float(), p=2, dim=-1)
            if query_reps is not None
            else None
        )
        query_slots_norm = (
            F.normalize(query_slots.float(), p=2, dim=-1)
            if query_slots is not None
            else None
        )
        target_device = device or ref_tensor.device
        target_dtype = dtype or ref_tensor.dtype
        for row in range(batch_size):
            valid_entries = []
            for entry in self.entries:
                if entry is None:
                    continue
                if entry["sample_id"] == str(sample_ids[row]):
                    continue
                if same_cls_only and cls_types[row] is not None and entry["cls_type"] != cls_types[row]:
                    continue
                if similarity_type == "slot_aligned":
                    if query_slots_norm is None or entry.get("sample_slots") is None:
                        continue
                    if entry["sample_slots"].shape[0] != query_slots_norm.shape[1]:
                        continue
                else:
                    if query_norm is None or entry.get("sample_rep") is None:
                        continue
                valid_entries.append(entry)
            if not valid_entries:
                continue

            if similarity_type == "slot_aligned":
                entry_slots = torch.stack(
                    [entry["sample_slots"].to(device=target_device, dtype=torch.float32) for entry in valid_entries],
                    dim=0,
                )
                entry_slots = F.normalize(entry_slots, p=2, dim=-1)
                sims = compute_slot_aligned_similarity(query_slots_norm[row], entry_slots).squeeze(0)
            else:
                entry_reps = torch.stack(
                    [entry["sample_rep"].to(device=target_device, dtype=torch.float32) for entry in valid_entries],
                    dim=0,
                )
                entry_reps = F.normalize(entry_reps, p=2, dim=-1)
                sims = torch.mv(entry_reps, query_norm[row])
            k = min(topk, sims.shape[0])
            vals, indices = sims.topk(k=k)
            candidate_count[row] = float(k)
            sample_cos[row, :k] = vals.to(sample_cos.device)
            sample_gate[row, :k] = compute_sample_gate(
                vals,
                use_softmax=sample_softmax,
                temperature=sample_tau,
            ).to(sample_gate.device)

            for layer_idx in layers:
                picked = []
                for idx in indices.tolist():
                    slot = valid_entries[idx]["slots_by_layer"].get(int(layer_idx))
                    if slot is None:
                        continue
                    picked.append(slot)
                if not picked:
                    continue
                layer_tensor = torch.stack(picked, dim=0).to(device=target_device, dtype=target_dtype)
                k_slots = layer_tensor.shape[1]
                if slots_by_layer[int(layer_idx)].shape[2] == 0:
                    slots_by_layer[int(layer_idx)] = ref_tensor.new_zeros(
                        (batch_size, topk, k_slots, ref_tensor.shape[-1]),
                        dtype=target_dtype,
                        device=target_device,
                    )
                slots_by_layer[int(layer_idx)][row, :layer_tensor.shape[0]] = layer_tensor

        return {
            "sample_cos": sample_cos,
            "sample_gate": sample_gate,
            "slots_by_layer": slots_by_layer,
            "candidate_count": candidate_count,
        }


def summarize_loss_delta(loss_delta: torch.Tensor) -> Dict[str, float]:
    if loss_delta is None or loss_delta.numel() == 0:
        return {
            "xseq/loss_delta_mean": 0.0,
            "xseq/loss_delta_median": 0.0,
            "xseq/loss_delta_p25": 0.0,
            "xseq/loss_delta_p75": 0.0,
            "xseq/loss_delta_positive_ratio": 0.0,
        }
    flat = loss_delta.detach().float().flatten()
    return {
        "xseq/loss_delta_mean": flat.mean().item(),
        "xseq/loss_delta_median": flat.median().item(),
        "xseq/loss_delta_p25": _safe_quantile(flat, 0.25),
        "xseq/loss_delta_p75": _safe_quantile(flat, 0.75),
        "xseq/loss_delta_positive_ratio": flat.gt(0).float().mean().item(),
    }
