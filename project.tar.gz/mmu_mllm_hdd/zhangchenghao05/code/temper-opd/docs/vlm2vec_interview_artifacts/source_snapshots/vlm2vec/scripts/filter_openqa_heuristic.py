#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def estimate_tokens(record, image_token_budget: int, overhead_tokens: int) -> int:
    convs = record.get("conversations", [])
    texts = [c.get("value", "") for c in convs]
    total_chars = sum(len(x) for x in texts)
    image_count = len(record.get("images", []))
    # Crude but stable:
    # - Chinese-heavy text: chars ~= tokens
    # - each image reserves a fixed visual-token budget
    # - chat template / special tokens add a small constant overhead
    return total_chars + image_count * image_token_budget + overhead_tokens


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input-path",
        default="/mmu_mllm_hdd/zhangchenghao05/data/onerec-think-v2/openqa_author_hetu_compress.jsonl",
    )
    parser.add_argument(
        "--output-path",
        default="/mmu_mllm_hdd/zhangchenghao05/data/onerec-think-v2/filtered/openqa_author_hetu_compress.heuristic.filtered.jsonl",
    )
    parser.add_argument(
        "--bad-output-path",
        default="/mmu_mllm_hdd/zhangchenghao05/data/onerec-think-v2/filtered/openqa_author_hetu_compress.heuristic.bad.jsonl",
    )
    parser.add_argument(
        "--stats-output-path",
        default="/mmu_mllm_hdd/zhangchenghao05/data/onerec-think-v2/filtered/openqa_author_hetu_compress.heuristic.stats.json",
    )
    parser.add_argument("--max-est-tokens", type=int, default=11585)
    parser.add_argument("--max-context-chars", type=int, default=9000)
    parser.add_argument("--max-total-chars", type=int, default=11000)
    parser.add_argument("--max-images", type=int, default=8)
    parser.add_argument("--image-token-budget", type=int, default=384)
    parser.add_argument("--overhead-tokens", type=int, default=512)
    args = parser.parse_args()

    input_path = Path(args.input_path)
    output_path = Path(args.output_path)
    bad_output_path = Path(args.bad_output_path)
    stats_output_path = Path(args.stats_output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    total = 0
    kept = 0
    filtered = 0
    reason_counts = {
        "too_many_images": 0,
        "context_too_long": 0,
        "total_text_too_long": 0,
        "estimated_tokens_too_long": 0,
        "bad_conversations": 0,
    }
    top_estimates = []

    with input_path.open("r", encoding="utf-8") as fin, \
         output_path.open("w", encoding="utf-8") as fout, \
         bad_output_path.open("w", encoding="utf-8") as fbad:
        for line in fin:
            if not line.strip():
                continue
            total += 1
            record = json.loads(line)

            convs = record.get("conversations", [])
            if len(convs) < 3:
                filtered += 1
                reason_counts["bad_conversations"] += 1
                fbad.write(json.dumps({"reason": "bad_conversations", "record": record}, ensure_ascii=False) + "\n")
                continue

            context = convs[0].get("value", "")
            question = convs[1].get("value", "")
            answer = convs[2].get("value", "")
            total_chars = len(context) + len(question) + len(answer)
            image_count = len(record.get("images", []))
            est_tokens = estimate_tokens(record, args.image_token_budget, args.overhead_tokens)
            top_estimates.append((est_tokens, record.get("id")))

            reason = None
            if image_count > args.max_images:
                reason = "too_many_images"
            elif len(context) > args.max_context_chars:
                reason = "context_too_long"
            elif total_chars > args.max_total_chars:
                reason = "total_text_too_long"
            elif est_tokens > args.max_est_tokens:
                reason = "estimated_tokens_too_long"

            if reason is not None:
                filtered += 1
                reason_counts[reason] += 1
                fbad.write(json.dumps({
                    "reason": reason,
                    "id": record.get("id"),
                    "image_count": image_count,
                    "context_chars": len(context),
                    "question_chars": len(question),
                    "answer_chars": len(answer),
                    "total_chars": total_chars,
                    "estimated_tokens": est_tokens,
                }, ensure_ascii=False) + "\n")
                continue

            kept += 1
            fout.write(line)

    top_estimates.sort(reverse=True)
    stats = {
        "input_path": str(input_path),
        "output_path": str(output_path),
        "bad_output_path": str(bad_output_path),
        "total": total,
        "kept": kept,
        "filtered": filtered,
        "kept_ratio": 0.0 if total == 0 else kept / total,
        "config": {
            "max_est_tokens": args.max_est_tokens,
            "max_context_chars": args.max_context_chars,
            "max_total_chars": args.max_total_chars,
            "max_images": args.max_images,
            "image_token_budget": args.image_token_budget,
            "overhead_tokens": args.overhead_tokens,
        },
        "reason_counts": reason_counts,
        "top_estimates": top_estimates[:20],
    }

    print(json.dumps(stats, ensure_ascii=False, indent=2))
    with stats_output_path.open("w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
