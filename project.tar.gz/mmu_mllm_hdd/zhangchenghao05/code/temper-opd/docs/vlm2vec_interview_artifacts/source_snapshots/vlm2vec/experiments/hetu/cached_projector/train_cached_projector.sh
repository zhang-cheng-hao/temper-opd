#!/bin/bash
set -euo pipefail

REPO_DIR="$(cd "$(dirname "$0")/../../.." && pwd)"
cd "$REPO_DIR"

NNODES="${NNODES:-1}"
NODE_RANK="${NODE_RANK:-0}"
if [ $# -gt 0 ] && [[ "$1" =~ ^[0-9]+$ ]]; then
  NNODES="$1"
  shift
fi
if [ $# -gt 0 ] && [[ "$1" =~ ^[0-9]+$ ]]; then
  NODE_RANK="$1"
  shift
fi

EXTRA_ARGS=()
while [ $# -gt 0 ]; do
  case "$1" in
    *=*) export "$1"; shift ;;
    --cache_dir) CACHE_DIR="$2"; shift 2 ;;
    --output_dir) OUTPUT_DIR="$2"; shift 2 ;;
    --head_dims) HEAD_DIMS=""; shift; while [ $# -gt 0 ] && [[ "$1" != --* ]]; do HEAD_DIMS="${HEAD_DIMS:+$HEAD_DIMS }$1"; shift; done ;;
    --multi_head_weights) MULTI_HEAD_WEIGHTS=""; shift; while [ $# -gt 0 ] && [[ "$1" != --* ]]; do MULTI_HEAD_WEIGHTS="${MULTI_HEAD_WEIGHTS:+$MULTI_HEAD_WEIGHTS }$1"; shift; done ;;
    --multi_head_orthogonal_weights) MULTI_HEAD_ORTHOGONAL_WEIGHTS=""; shift; while [ $# -gt 0 ] && [[ "$1" != --* ]]; do MULTI_HEAD_ORTHOGONAL_WEIGHTS="${MULTI_HEAD_ORTHOGONAL_WEIGHTS:+$MULTI_HEAD_ORTHOGONAL_WEIGHTS }$1"; shift; done ;;
    --hidden_dim) HIDDEN_DIM="$2"; shift 2 ;;
    --mode) PROJECTOR_MODE="$2"; shift 2 ;;
    --per_device_batch_size) PER_DEVICE_BATCH_SIZE="$2"; shift 2 ;;
    --max_steps) MAX_STEPS="$2"; shift 2 ;;
    --save_steps) SAVE_STEPS="$2"; shift 2 ;;
    --logging_steps) LOGGING_STEPS="$2"; shift 2 ;;
    --learning_rate) LR="$2"; shift 2 ;;
    --weight_decay) WEIGHT_DECAY="$2"; shift 2 ;;
    --warmup_steps) WARMUP_STEPS="$2"; shift 2 ;;
    --temperature) TEMPERATURE="$2"; shift 2 ;;
    --similarity_type) SIMILARITY_TYPE="$2"; shift 2 ;;
    --maxsim_topk) MAXSIM_TOPK="$2"; shift 2 ;;
    --normalize_input) NORMALIZE_INPUT="$2"; shift 2 ;;
    --normalize_output) NORMALIZE_OUTPUT="$2"; shift 2 ;;
    --local_contrastive_loss)
      if [ $# -gt 1 ] && [[ "${2:-}" != --* ]]; then
        LOCAL_CONTRASTIVE_LOSS="$2"
        shift 2
      else
        LOCAL_CONTRASTIVE_LOSS="true"
        shift
      fi
      ;;
    --match_cache_rank)
      if [ $# -gt 1 ] && [[ "${2:-}" != --* ]]; then
        MATCH_CACHE_RANK="$2"
        shift 2
      else
        MATCH_CACHE_RANK="true"
        shift
      fi
      ;;
    --shuffle_files) SHUFFLE_FILES="$2"; shift 2 ;;
    --shuffle_samples) SHUFFLE_SAMPLES="$2"; shift 2 ;;
    --orthogonal_loss) ORTHOGONAL_LOSS="$2"; shift 2 ;;
    --orthogonal_base_dim) ORTHOGONAL_BASE_DIM="$2"; shift 2 ;;
    --orthogonal_margin) ORTHOGONAL_MARGIN="$2"; shift 2 ;;
    --orthogonal_warmup_steps) ORTHOGONAL_WARMUP_STEPS="$2"; shift 2 ;;
    --save_multi_head_standalone_heads) SAVE_MULTI_HEAD_STANDALONE_HEADS="$2"; shift 2 ;;
    --resume_from) RESUME_FROM="$2"; shift 2 ;;
    *) EXTRA_ARGS+=("$1"); shift ;;
  esac
done

GPUS_PER_NODE="${GPUS_PER_NODE:-1}"
MASTER_ADDR="${MASTER_ADDR:-localhost}"
MASTER_PORT="${MASTER_PORT:-2218}"
RDZV_ID="${RDZV_ID:-cached-projector-train}"
TORCHRUN="${TORCHRUN:-/mmu_mllm_hdd/zhangchenghao05/envs/vlm2vec/bin/torchrun}"
CACHE_DIR="${CACHE_DIR:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/cached_projector/goods_0429_distinct_attnpool_stage2_cache}"
OUTPUT_DIR="${OUTPUT_DIR:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/cached_projector/goods_cached_projector_retrain_256_128_64}"
HEAD_DIMS="${HEAD_DIMS:-256 128 64}"
if [ -z "${MULTI_HEAD_WEIGHTS:-}" ]; then
  MULTI_HEAD_WEIGHTS=""
  for _dim in $HEAD_DIMS; do
    MULTI_HEAD_WEIGHTS="${MULTI_HEAD_WEIGHTS:+$MULTI_HEAD_WEIGHTS }1.0"
  done
fi
PER_DEVICE_BATCH_SIZE="${PER_DEVICE_BATCH_SIZE:-32}"
MAX_STEPS="${MAX_STEPS:-4000}"
SAVE_STEPS="${SAVE_STEPS:-500}"
LOGGING_STEPS="${LOGGING_STEPS:-10}"
LR="${LR:-1e-3}"
WEIGHT_DECAY="${WEIGHT_DECAY:-0.0}"
WARMUP_STEPS="${WARMUP_STEPS:-100}"
TEMPERATURE="${TEMPERATURE:-0.02}"
SIMILARITY_TYPE="${SIMILARITY_TYPE:-dense}"
MAXSIM_TOPK="${MAXSIM_TOPK:-4}"
NORMALIZE_INPUT="${NORMALIZE_INPUT:-true}"
NORMALIZE_OUTPUT="${NORMALIZE_OUTPUT:-true}"
ORTHOGONAL_LOSS="${ORTHOGONAL_LOSS:-0.5}"
ORTHOGONAL_BASE_DIM="${ORTHOGONAL_BASE_DIM:-2048}"
ORTHOGONAL_MARGIN="${ORTHOGONAL_MARGIN:-0.0}"
ORTHOGONAL_WARMUP_STEPS="${ORTHOGONAL_WARMUP_STEPS:-0}"
MATCH_CACHE_RANK="${MATCH_CACHE_RANK:-true}"
LOCAL_CONTRASTIVE_LOSS="${LOCAL_CONTRASTIVE_LOSS:-false}"
SHUFFLE_FILES="${SHUFFLE_FILES:-true}"
SHUFFLE_SAMPLES="${SHUFFLE_SAMPLES:-true}"
SAVE_MULTI_HEAD_STANDALONE_HEADS="${SAVE_MULTI_HEAD_STANDALONE_HEADS:-true}"
PROJECTOR_MODE="${PROJECTOR_MODE:-mlp}"
MODE="${MODE:-run}"

if [ ! -x "$TORCHRUN" ]; then
  echo "[ERR] torchrun not found: $TORCHRUN" >&2
  exit 1
fi
if [ "$MODE" != "print" ] && [ ! -d "$CACHE_DIR" ]; then
  echo "[ERR] cache dir not found: $CACHE_DIR" >&2
  exit 1
fi

cmd=(
  "$TORCHRUN"
  --nproc-per-node "$GPUS_PER_NODE"
  --nnodes "$NNODES"
  --max-restarts 0
  --rdzv-backend c10d
  --rdzv-id "$RDZV_ID"
  --rdzv-endpoint "$MASTER_ADDR:$MASTER_PORT"
  --node-rank "$NODE_RANK"
  -m src.cached_projector.train
  --cache_dir "$CACHE_DIR"
  --output_dir "$OUTPUT_DIR"
  --head_dims $HEAD_DIMS
  --multi_head_weights $MULTI_HEAD_WEIGHTS
  --mode "$PROJECTOR_MODE"
  --per_device_batch_size "$PER_DEVICE_BATCH_SIZE"
  --max_steps "$MAX_STEPS"
  --save_steps "$SAVE_STEPS"
  --logging_steps "$LOGGING_STEPS"
  --learning_rate "$LR"
  --weight_decay "$WEIGHT_DECAY"
  --warmup_steps "$WARMUP_STEPS"
  --temperature "$TEMPERATURE"
  --similarity_type "$SIMILARITY_TYPE"
  --maxsim_topk "$MAXSIM_TOPK"
  --normalize_input "$NORMALIZE_INPUT"
  --normalize_output "$NORMALIZE_OUTPUT"
  --orthogonal_loss "$ORTHOGONAL_LOSS"
  --orthogonal_base_dim "$ORTHOGONAL_BASE_DIM"
  --orthogonal_margin "$ORTHOGONAL_MARGIN"
  --orthogonal_warmup_steps "$ORTHOGONAL_WARMUP_STEPS"
  --match_cache_rank "$MATCH_CACHE_RANK"
  --local_contrastive_loss "$LOCAL_CONTRASTIVE_LOSS"
  --shuffle_files "$SHUFFLE_FILES"
  --shuffle_samples "$SHUFFLE_SAMPLES"
  --save_multi_head_standalone_heads "$SAVE_MULTI_HEAD_STANDALONE_HEADS"
)
if [ -n "${HIDDEN_DIM:-}" ]; then
  cmd+=(--hidden_dim "$HIDDEN_DIM")
fi
if [ -n "${MULTI_HEAD_ORTHOGONAL_WEIGHTS:-}" ]; then
  cmd+=(--multi_head_orthogonal_weights $MULTI_HEAD_ORTHOGONAL_WEIGHTS)
fi
if [ -n "${RESUME_FROM:-}" ]; then
  cmd+=(--resume_from "$RESUME_FROM")
fi
if [ "${#EXTRA_ARGS[@]}" -gt 0 ]; then
  cmd+=("${EXTRA_ARGS[@]}")
fi

printf "[TRAIN] CMD: "
printf "%q " "${cmd[@]}"
printf "\n"
if [ "$MODE" = "print" ]; then
  exit 0
fi
mkdir -p "$OUTPUT_DIR"
"${cmd[@]}" 2>&1 | tee "$OUTPUT_DIR/train.log"
