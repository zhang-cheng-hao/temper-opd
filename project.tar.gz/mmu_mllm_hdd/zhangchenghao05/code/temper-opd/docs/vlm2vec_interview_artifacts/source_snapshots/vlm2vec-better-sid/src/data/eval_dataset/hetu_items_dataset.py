import os

import datasets

from src.data.eval_dataset.base_i2i_dataset import AutoEvalI2IDataset, add_metainfo_hook, RESOLUTION_MAPPING
from src.model.processor import VLM_AUDIO_TOKENS, VLM_COMPRESS_TOKENS, TOTAL_COMPRESS_TOKENS, VLM_IMAGE_TOKENS
from src.utils import print_master


summarize_prompt = "".join(VLM_COMPRESS_TOKENS) if TOTAL_COMPRESS_TOKENS > 0 else ""


def process_text(text, image_token, audio_token):
    text = text.replace("<image>", image_token)
    text = text.replace("<|image_1|>", image_token)
    if audio_token is not None:
        text = text.replace("<audio>", audio_token)
    else:
        text = text.replace("<audio>", "")
    return text


def ensure_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def get_first_present(batch_dict, candidates, default=None):
    for key in candidates:
        if key in batch_dict:
            return batch_dict[key]
    return default


@add_metainfo_hook
def data_prepare(batch_dict, *args, **kwargs):
    model_backbone = kwargs["model_backbone"]
    image_resolution = kwargs["image_resolution"]
    audio_dir = kwargs["audio_dir"]
    image_dir = kwargs["image_dir"]
    mlp_idx = int(kwargs["mlp_idx"])

    ids, textss, imagess, audioss, labelss, mlp_idxs = [], [], [], [], [], []
    audio_token = VLM_AUDIO_TOKENS.get(model_backbone)

    raw_ids = get_first_present(batch_dict, ["item_id", "photo_id", "id"])
    if raw_ids is None:
        raise KeyError("hetu_items dataset expects one of: item_id, photo_id, id.")

    raw_texts = get_first_present(batch_dict, ["text", "qry", "query", "title"])
    if raw_texts is None:
        raise KeyError("hetu_items dataset expects one of: text, qry, query, title.")

    raw_images = get_first_present(
        batch_dict,
        ["image_path", "images", "image_paths", "images_path", "photo_path", "pic_path", "cover_path"],
        [None] * len(raw_ids),
    )
    raw_audios = get_first_present(batch_dict, ["audio_path", "audio_paths", "audios"], [None] * len(raw_ids))

    for data_id, text, images, audios in zip(raw_ids, raw_texts, raw_images, raw_audios):
        text = process_text(text, image_token=VLM_IMAGE_TOKENS[model_backbone], audio_token=audio_token) + summarize_prompt

        image_paths = ensure_list(images)
        audio_paths = ensure_list(audios)

        image_obj = {
            "bytes": len(image_paths) * [None],
            "paths": [os.path.join(image_dir, path) if path else None for path in image_paths],
            "resolutions": len(image_paths) * [RESOLUTION_MAPPING.get(image_resolution, None)],
        }
        audio_obj = {
            "bytes": len(audio_paths) * [None],
            "paths": [os.path.join(audio_dir, path) if path else None for path in audio_paths],
            "resolutions": len(audio_paths) * [None],
        }

        ids.append(str(data_id))
        textss.append([text])
        imagess.append([image_obj])
        audioss.append(audio_obj)
        labelss.append([])
        mlp_idxs.append(mlp_idx)

    return {
        "id": ids,
        "texts": textss,
        "images": imagess,
        "audios": audioss,
        "labels": labelss,
        "mlp_idx": mlp_idxs,
    }


DATASET_PARSER_NAME = "hetu_items"


@AutoEvalI2IDataset.register(DATASET_PARSER_NAME)
def load_hetu_items_dataset(model_args, data_args, training_args, *args, **kwargs):
    dataset_name = kwargs.get("dataset_name", DATASET_PARSER_NAME)
    subset_name = kwargs.get("subset_name", dataset_name)
    image_dir = kwargs.get("image_dir", "/")
    audio_dir = kwargs.get("audio_dir", "/")
    mlp_idx = int(kwargs.get("mlp_idx", -1))
    task_type = kwargs.get("task_type")

    dataset_path = kwargs["dataset_path"]
    dataset = datasets.load_dataset("json", data_files=dataset_path, streaming=False)["train"]

    num_sample_per_subset = kwargs.get("num_sample_per_subset", getattr(data_args, "num_sample_per_subset", None))
    if num_sample_per_subset is not None and num_sample_per_subset < dataset.num_rows:
        dataset = dataset.select(range(int(num_sample_per_subset)))
    num_rows = dataset.num_rows

    kwargs["model_backbone"] = model_args.model_backbone
    kwargs["image_resolution"] = data_args.image_resolution
    kwargs["global_dataset_name"] = f"{DATASET_PARSER_NAME}/{subset_name}"
    kwargs["image_dir"] = image_dir
    kwargs["audio_dir"] = audio_dir
    kwargs["mlp_idx"] = mlp_idx

    dataset = dataset.map(lambda x: data_prepare(x, **kwargs), batched=True, batch_size=128, drop_last_batch=False)
    dataset = dataset.select_columns(["id", "texts", "images", "audios", "labels", "mlp_idx", "global_dataset_name", "task_type", "cls_type"])
    print_master(f"Loaded {DATASET_PARSER_NAME}/{subset_name} dataset with {num_rows} samples [task_type={task_type}, mlp_idx={mlp_idx}]")
    return dataset
