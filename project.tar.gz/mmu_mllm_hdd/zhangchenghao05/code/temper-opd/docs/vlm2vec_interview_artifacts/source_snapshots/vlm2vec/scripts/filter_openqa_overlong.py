#!/usr/bin/env python3
import argparse
import json
import sys
from pathlib import Path

REPO_DIR = Path(__file__).resolve().parents[1]
if str(REPO_DIR) not in sys.path:
    sys.path.insert(0, str(REPO_DIR))

from PIL import Image
from transformers import AutoProcessor
from transformers.image_utils import ChannelDimension

from src.model.processor import VLM_COMPRESS_TOKENS, VLM_IMAGE_TOKENS, QWEN2_5_OMNI


def build_text_and_images(record, processor):
    conversations = record["conversations"]
    encode_query = conversations[0]["value"].replace("<image>", VLM_IMAGE_TOKENS[QWEN2_5_OMNI]).replace("<audio>", "<|AUDIO|>")
    encode_answer = "".join(VLM_COMPRESS_TOKENS)
    decode_query = conversations[1]["value"].replace("<image>", VLM_IMAGE_TOKENS[QWEN2_5_OMNI])
    decode_answer = conversations[2]["value"].replace("<image>", VLM_IMAGE_TOKENS[QWEN2_5_OMNI])

    decode_conv = [[
        {"role": "user", "content": [{"type": "text", "text": decode_query}]},
        {"role": "assistant", "content": [{"type": "text", "text": decode_answer}]},
    ]]
    chat_text = processor.apply_chat_template(decode_conv, tokenize=False, add_generation_prompt=False)[0]
    full_text = encode_query + encode_answer + chat_text

    images = []
    for path in record.get("images", []):
        if path:
            with Image.open(path) as img:
                images.append(img.convert("RGB"))
    return full_text, images


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-path", default="/mmu_mllm_hdd/zhangchenghao05/data/onerec-think-v2/openqa_author_hetu_compress.jsonl")
    parser.add_argument("--output-path", default=None, help="filtered jsonl path")
    parser.add_argument("--bad-output-path", default=None, help="bad sample jsonl path")
    parser.add_argument("--stats-output-path", default=None, help="stats json path")
    parser.add_argument("--model-name", default="/mmu_mllm_hdd/zhangchenghao05/hetu_next/LLaMA-Factory/saves/qwen2_5omni-3b/sft_datav2/merge/")
    parser.add_argument("--max-length", type=int, default=8192)
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()

    processor = AutoProcessor.from_pretrained(args.model_name, trust_remote_code=True)
    eos_token_id = processor.tokenizer.eos_token_id

    input_path = Path(args.input_path)
    output_f = open(args.output_path, "w", encoding="utf-8") if args.output_path else None
    bad_f = open(args.bad_output_path, "w", encoding="utf-8") if args.bad_output_path else None

    total = 0
    kept = 0
    bad = 0
    eos_missing = 0
    image_open_error = 0
    top_lengths = []

    with input_path.open("r", encoding="utf-8") as fin:
        for line in fin:
            if not line.strip():
                continue
            total += 1
            if args.limit is not None and total > args.limit:
                break

            record = json.loads(line)
            try:
                text, images = build_text_and_images(record, processor)
                inputs = processor(
                    text=[text],
                    images=images if len(images) > 0 else None,
                    return_tensors="pt",
                    max_length=args.max_length,
                    truncation=True,
                    input_data_format=ChannelDimension.LAST,
                )
                input_ids = inputs["input_ids"].squeeze()
                eos_count = int((input_ids == eos_token_id).sum().item())
                input_len = int(input_ids.shape[0])
                top_lengths.append((input_len, record.get("id")))
                if eos_count < 1:
                    bad += 1
                    eos_missing += 1
                    if bad_f:
                        bad_f.write(json.dumps({
                            "reason": "missing_eos_after_truncation",
                            "id": record.get("id"),
                            "input_len": input_len,
                            "num_images": len(record.get("images", [])),
                            "text_preview": text[:500],
                            "record": record,
                        }, ensure_ascii=False) + "\n")
                    continue
            except Exception as e:
                bad += 1
                image_open_error += 1
                if bad_f:
                    bad_f.write(json.dumps({
                        "reason": "processor_or_image_error",
                        "id": record.get("id"),
                        "error": repr(e),
                        "record": record,
                    }, ensure_ascii=False) + "\n")
                continue

            kept += 1
            if output_f:
                output_f.write(line)

    if output_f:
        output_f.close()
    if bad_f:
        bad_f.close()

    top_lengths.sort(reverse=True)
    stats = {
        "input_path": str(input_path),
        "max_length": args.max_length,
        "total": total,
        "kept": kept,
        "bad": bad,
        "eos_missing": eos_missing,
        "image_open_error": image_open_error,
        "bad_ratio": 0.0 if total == 0 else bad / total,
        "top_token_lengths": top_lengths[:20],
    }
    print(json.dumps(stats, ensure_ascii=False, indent=2))

    if args.stats_output_path:
        with open(args.stats_output_path, "w", encoding="utf-8") as f:
            json.dump(stats, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
