from typing import List, Tuple
import ast
import datasets
import numpy as np
from datasets import load_dataset, concatenate_datasets
from PIL import Image
import os
from datasets.features.image import image_to_bytes

from src.data.dataset.base_pair_dataset import AutoPairDataset, add_metainfo_hook, MULTIMODAL_FEATURES, \
    RESOLUTION_MAPPING
from src.model.processor import PHI3V, VLM_IMAGE_TOKENS, VLM_COMPRESS_TOKENS, TOTAL_COMPRESS_TOKENS, VLM_AUDIO_TOKENS
from src.utils import print_master, print_rank
from torch.utils.data import Dataset


summarize_prompt = "".join(VLM_COMPRESS_TOKENS) if TOTAL_COMPRESS_TOKENS > 0 else ""

def process_text(text, image_token, audio_token):
    text = text.replace('<image>', image_token)
    text = text.replace('<|image_1|>', image_token)
    if audio_token is not None:
        text = text.replace('<audio>', audio_token)
    else:
        text = text.replace('<audio>', '')
    return text


def ensure_list(value):
    if value is None:
        return []
    if isinstance(value, str):
        stripped = value.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            try:
                value = ast.literal_eval(stripped)
            except Exception:
                return [value]
    if isinstance(value, list):
        flattened = []
        for item in value:
            if item is None:
                continue
            if isinstance(item, list):
                flattened.extend(x for x in item if x is not None)
            else:
                flattened.append(item)
        return flattened
    return [value]

@add_metainfo_hook
def data_prepare(batch_dict, *args, **kwargs):
    model_backbone = kwargs['model_backbone']
    image_resolution = kwargs['image_resolution']
    audio_dir = kwargs['audio_dir']
    image_dir = kwargs['image_dir']
    mlp_idx = int(kwargs['mlp_idx'])
    batch_size = len(batch_dict['qry'])
    if 'id' not in batch_dict:
        batch_dict['id'] = [f"{i}" for i in range(batch_size)]
    if 'qry_audio_path' not in batch_dict:
        batch_dict['qry_audio_path'] = [[] for _ in range(batch_size)]
    if 'pos_audio_path' not in batch_dict:
        batch_dict['pos_audio_path'] = [[] for _ in range(batch_size)]
    mlp_idxs = []
    
    data_ids = []
    query_texts, query_images, query_audios, pos_texts, pos_images, pos_audios = [], [], [], [], [], []
    audio_token = VLM_AUDIO_TOKENS.get(model_backbone)

    for data_idx, (data_id, query_text, query_image, query_audio, pos_text, pos_image, pos_audio) in enumerate(zip(batch_dict['id'], batch_dict['qry'], batch_dict['qry_image_path'], batch_dict['qry_audio_path'], batch_dict['pos_text'], batch_dict['pos_image_path'], batch_dict['pos_audio_path'])):
        try:
            query_image = ensure_list(query_image)
            query_audio = ensure_list(query_audio)
            pos_image = ensure_list(pos_image)
            pos_audio = ensure_list(pos_audio)

            query_text = process_text(query_text, image_token=VLM_IMAGE_TOKENS[model_backbone], audio_token=audio_token)
            query_image = {"bytes": len(query_image) * [None], "paths": [os.path.join(image_dir, path) if path else None for path in query_image], "resolutions": len(query_image) * [RESOLUTION_MAPPING.get(image_resolution, None)]}
            query_audio = {"bytes": len(query_audio) * [None], "paths": [os.path.join(audio_dir, path) if path else None for path in query_audio], "resolutions": len(query_audio) * [None]}
            pos_text = process_text(pos_text, image_token=VLM_IMAGE_TOKENS[model_backbone], audio_token=audio_token)
            pos_image = {"bytes": len(pos_image) * [None], "paths": [os.path.join(image_dir, path) if path else None for path in pos_image], "resolutions": len(pos_image) * [RESOLUTION_MAPPING.get(image_resolution, None)]}
            pos_audio = {"bytes": len(pos_audio) * [None], "paths": [os.path.join(audio_dir, path) if path else None for path in pos_audio], "resolutions": len(pos_audio) * [None]}

            data_ids.append(data_id)
            query_texts.append(query_text + summarize_prompt)
            query_images.append(query_image)
            query_audios.append(query_audio)
            pos_texts.append(pos_text + summarize_prompt)
            pos_images.append(pos_image)
            pos_audios.append(pos_audio)
            mlp_idxs.append(mlp_idx)

        except Exception as e:
            print(f'Error in processing {DATASET_PARSER_NAME}: \n\t\tdata id: {data_id} \n\t\batch_dict: {batch_dict}')
            print(e)
            raise e
    return {"id": data_ids, "query_text": query_texts, "query_image": query_images, "query_audio": query_audios,
            "pos_text": pos_texts, "pos_image": pos_images, "pos_audio": pos_audios, "mlp_idx": mlp_idxs}


DATASET_PARSER_NAME = "hetu_ret"
@AutoPairDataset.register(DATASET_PARSER_NAME)
def load_hetu_ret_dataset(model_args, data_args, training_args, *args, **kwargs):
    dataset_name = kwargs.get("dataset_name", DATASET_PARSER_NAME)
    subset_name = kwargs.get("subset_name", dataset_name)
    dataset_split = kwargs.get("dataset_split", "original")
    audio_dir = kwargs.get("audio_dir", "/")
    image_dir = kwargs.get("image_dir", "/")

    mlp_idx = int(kwargs.get("mlp_idx", -1))

    dataset_path = kwargs["dataset_path"]
    dataset = datasets.load_dataset('json', data_files=dataset_path, streaming=False)['train']
    
    column_names = dataset.column_names
    num_sample_per_subset = kwargs.get("num_sample_per_subset", getattr(data_args, "num_sample_per_subset", None))
    if num_sample_per_subset is not None and num_sample_per_subset < dataset.num_rows:
        num_rows = int(num_sample_per_subset)
        dataset = dataset.select(range(num_rows))
    num_rows = dataset.num_rows

    num_shards = training_args.dataloader_num_workers if training_args.dataloader_num_workers > 0 else 1
    dataset = dataset.to_iterable_dataset(num_shards=num_shards)  # convert to IterableDataset and multiple shards

    kwargs['model_backbone'] = model_args.model_backbone
    kwargs['image_resolution'] = data_args.image_resolution
    kwargs['global_dataset_name'] = f'{DATASET_PARSER_NAME}/{subset_name}'
    kwargs['num_hardneg'] = data_args.num_hardneg
    kwargs['audio_dir'] = audio_dir
    kwargs['image_dir'] = image_dir
    kwargs['mlp_idx'] = mlp_idx
    assert data_args.num_hardneg <= 0, "hard negative sampling is not supported in hetu ret dataset for now"


    dataset = dataset.map(lambda x: data_prepare(x, **kwargs), batched=True, batch_size=128, drop_last_batch=False)
    dataset = dataset.select_columns(["id", "query_text", "query_image", "query_audio", "pos_text", "pos_image", "pos_audio", "mlp_idx", "global_dataset_name", "task_type", "cls_type"])
    # dataset = dataset._resolve_features()
    # features = _infer_features_from_batch(dataset._head()) # not working: {ArrowInvalid}ArrowInvalid('Could not convert <PIL.Image.Image image mode=RGB size=128x128 at 0x7F7C794E9BD0> with type Image: did not recognize Python value type when inferring an Arrow data type')
    dataset = dataset.cast(MULTIMODAL_FEATURES)
    print_master(f"Loaded {DATASET_PARSER_NAME}/{subset_name} dataset with {num_rows} samples")

    # num_rows in iterable_dataset is overridden, set it here for printing dataset stats
    setattr(dataset, 'num_rows', num_rows)

    return dataset
