import datetime
import logging
import json
import random
import time

import numpy as np
import os
import pickle
import sys
import torch
import torch.distributed as dist
import torch.nn.functional as F
import yaml
from torch.utils.data import DataLoader
from tqdm import tqdm
from transformers import HfArgumentParser, AutoConfig, GenerationConfig
from datasets import Dataset, concatenate_datasets
from datasets.distributed import split_dataset_by_node

from src.arguments import ModelArguments, DataArguments, TrainingArguments
from src.data.collator.eval_collator import MultimodalInferDataCollator
from src.data.eval_dataset.base_infer_dataset import AutoInferDataset
from src.eval_utils.metrics import RankingMetrics
from src.model.model import MMEBModel
from src.model.processor import get_backbone_name, load_processor, COLPALI
from src.utils import batch_to_device, print_rank, print_master
import multiprocessing
from multiprocessing import Pool, cpu_count
logging.basicConfig(level=logging.INFO, format='[%(asctime)s] %(levelname)s [%(name)s:%(lineno)s] %(message)s')
logger = logging.getLogger(__name__)

def pad_dataset_to_divisible(dataset, world_size):
    num_samples = len(dataset)
    if num_samples % world_size == 0:
        return dataset, num_samples

    num_to_add = world_size - (num_samples % world_size)
    padded_size = num_samples + num_to_add

    padding_data = dataset.select([i % len(dataset) for i in range(num_to_add)])
    padded_dataset = concatenate_datasets([dataset, padding_data])
    return padded_dataset, padded_size

def gather_tensor(t):
    gathered = [torch.empty_like(t, dtype=t.dtype, device=t.device) for _ in range(dist.get_world_size())]
    dist.all_gather(gathered, t)
    gathered[dist.get_rank()] = t
    return torch.cat(gathered, dim=0)

def gather_object(o):
    gathered = [None for _ in range(dist.get_world_size())]
    dist.all_gather_object(gathered, o)
    return gathered

def main():
    if "RANK" in os.environ and dist.is_available() and not dist.is_initialized():
        dist.init_process_group(backend="nccl", timeout=datetime.timedelta(minutes=60))
    local_rank = dist.get_rank() if dist.is_initialized() else 0
    world_size = dist.get_world_size() if dist.is_initialized() else 1
    # DEBUG PRINTS for Distributed Setup
    print_master("Distributed init debug info:")
    print_master(f"RANK: {os.environ.get('RANK')}")
    print_master(f"LOCAL_RANK: {os.environ.get('LOCAL_RANK')}")
    print_master(f"WORLD_SIZE: {os.environ.get('WORLD_SIZE')}")
    print_master(f"MASTER_ADDR: {os.environ.get('MASTER_ADDR')}")
    print_master(f"MASTER_PORT: {os.environ.get('MASTER_PORT')}")
    if dist.is_initialized():
        print_rank(f"dist.get_rank(): {dist.get_rank()}")
        print_rank(f"dist.get_world_size(): {dist.get_world_size()}")

    for arg in sys.argv:
        if arg.startswith("--local-rank="):
            rank = arg.split("=")[1]
            sys.argv.remove(arg)
            sys.argv.append('--local_rank')
            sys.argv.append(rank)
    parser = HfArgumentParser((ModelArguments, DataArguments, TrainingArguments))
    model_args, data_args, training_args = parser.parse_args_into_dataclasses()
    model_args: ModelArguments
    data_args: DataArguments
    training_args: TrainingArguments

    output_dir = os.path.join(data_args.encode_output_path, "infer")
    print_master(f"Output path: {output_dir}")
    os.makedirs(output_dir, exist_ok=True)

    # --- Model Loading ---
    hf_config = AutoConfig.from_pretrained(model_args.model_name, trust_remote_code=True)
    if not getattr(model_args, "model_backbone", None):
        model_backbone = get_backbone_name(hf_config=hf_config, model_type=model_args.model_type)
        setattr(model_args, 'model_backbone', model_backbone)
        setattr(training_args, 'model_backbone', model_backbone)
    print_master(f'Model Backbone: {model_args.model_backbone}')
    # --- DDP-Safe Model Loading ---
    # Step 1: Only the master process (rank 0) downloads the model.
    if local_rank == 0:
        processor = load_processor(model_args, data_args)
        processor.tokenizer.padding_side = "left"
        model = MMEBModel.load(model_args, is_trainable=False, processor=processor)
        print_master(f"[rank=0] Loading the model from Huggingface: {model_args.model_name}...")
    # Step 2: All processes wait here. The non-master processes will pause
    # until the master process (rank 0) finishes downloading and exits this barrier.
    if torch.distributed.is_initialized():
        torch.distributed.barrier()
    # Step 3: Now that the model is cached, the non-master processes load it from the local cache.
    if local_rank != 0:
        print_rank(f"Loading the model from cache...")
        processor = load_processor(model_args, data_args)
        processor.tokenizer.padding_side = "left"
        time.sleep(random.randint(2 * local_rank, 3 * local_rank))
        model = MMEBModel.load(model_args, is_trainable=False, processor=processor)
    model.eval()
    model = model.to(training_args.device, dtype=torch.bfloat16)
    with open(data_args.dataset_config, 'r') as yaml_file:
        dataset_configs = yaml.safe_load(yaml_file)

    # todo: hardcoded
    generation_config = GenerationConfig(
        # temperature=0.6,
        # top_p=0.95,
        
        top_k=50,
    )
    max_new_tokens = 1024
    sample_kwargs = dict(
        max_new_tokens=max_new_tokens
    )

    # --- Main Evaluation Loop ---
    for dataset_idx, (dataset_name, task_config) in enumerate(dataset_configs.items()):
        # 0. load dataset
        if dist.is_initialized():
            dist.barrier()
        print_master(f"--- Infering {dataset_name} ---")

        dataset = AutoInferDataset.instantiate(model_args=model_args, data_args=data_args, training_args=training_args, **task_config)
    
        if dist.is_initialized():
            padded_dataset, _ = pad_dataset_to_divisible(dataset, world_size)
            dataset = split_dataset_by_node(padded_dataset, rank=local_rank, world_size=world_size)

        infer_collator = MultimodalInferDataCollator(
            processor, 
            model_args, 
            data_args, 
            training_args, 
            model_func_get_rope_index=model.encoder.get_rope_index
        )
        data_loader = DataLoader(
            dataset, 
            batch_size=training_args.per_device_eval_batch_size, 
            collate_fn=infer_collator, 
            num_workers=training_args.dataloader_num_workers,
        )

        is_exist = {}
        output_file = os.path.join(output_dir, f"{dataset_name}.jsonl")
        if os.path.exists(output_file):
            with open(output_file) as f:
                for line in f:
                    item = json.loads(line)
                    is_exist[item['id']] = True
        print_master(f"Exist num: {len(is_exist)}")

        dist.barrier()

        for inputs, meta_infos in tqdm(data_loader, desc=f"[{local_rank}] Inferring", position=local_rank):
            inputs = batch_to_device(inputs, training_args.device)

            input_ids = inputs['input_ids'].clone()

            data_ids = inputs.pop("id")
            task_types = inputs.pop("task_type")
            global_dataset_names = inputs.pop("global_dataset_name")

            if all(is_exist.get(data_id, False) for data_id in data_ids):
                continue
            
            with torch.no_grad():
                output_ids = model.encoder.generate(
                    **inputs, 
                    **sample_kwargs, 
                    # generation_config=generation_config
                )

            prompts = processor.tokenizer.batch_decode(input_ids, skip_special_tokens=True)
            texts = processor.tokenizer.batch_decode(output_ids, skip_special_tokens=True)
            texts = [text[len(prompt):] for prompt, text in zip(prompts, texts)]

            if dist.is_initialized():

                data_ids = gather_object(data_ids)
                data_ids = [data_id for rank_data_ids in data_ids for data_id in rank_data_ids]
                prompts = gather_object(prompts)
                prompts = [prompt for rank_prompts in prompts for prompt in rank_prompts]
                texts = gather_object(texts)
                texts = [text for rank_texts in texts for text in rank_texts]
                meta_infos = gather_object(meta_infos)
                meta_infos = [meta_info for rank_meta_infos in meta_infos for meta_info in rank_meta_infos]

            if local_rank == 0:

                with open(output_file, "a") as f:
                    for data_id, prompt, text, meta_info in zip(
                        tqdm(data_ids, desc="Saving..."), 
                        prompts, 
                        texts,
                        meta_infos,
                    ):
                        if is_exist.get(data_id, False):
                            continue
                        f.write(json.dumps(meta_info | {
                            "id": data_id,
                            "prompt": prompt,
                            "response": text,
                        }, ensure_ascii=False) + '\n')

            if dist.is_initialized():
                dist.barrier()
                
                
if __name__ == "__main__":
    main()