#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
分析 orthogonal loss 效果的脚本（在你给的可运行版本基础上改）

核心改动（保证“公平对比”且更稳）：
1) ✅ 对比两个 checkpoint 时：先用 ckpt1 的 dataloader 缓存 num_batches 个 batch（CPU），然后 ckpt1/ckpt2 都跑同一份 cached batches
   - 修复你当前代码里“复用同一个 dataloader 导致第二个 ckpt 看到的是不同 batch（因为迭代器已经被消耗）”的问题
2) ✅ 彻底避免 inplace 修改 batch（cuda/popup labels）导致缓存污染
3) ✅ compute_sim_matrix 的 off-diag 统计/均值改为真正的 off-diag（不再被对角线 0 拉低）
4) ✅ 默认只画“summary 图”（平均相似度热力图 + off-diag 直方图），避免 64 batches 生成海量 batch 图（如需 per-batch 图可开开关）

用法（保持你想要的方式可直接跑）：
    python scripts/analyze_orthogonal.py --num_batches 64 --batch_size 4
也支持：
    python scripts/analyze_orthogonal.py --checkpoint ckpt1 --dataset_config cfg.yaml
    python scripts/analyze_orthogonal.py --checkpoint ckpt1 --checkpoint2 ckpt2 --dataset_config cfg.yaml
"""

import os
import sys
import re
import shlex
import glob
import json
from pathlib import Path
from datetime import datetime

import yaml
import numpy as np
import torch
import torch.nn.functional as F
import torch.distributed as dist

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from transformers import AutoConfig  # noqa
from src.arguments import ModelArguments, DataArguments  # noqa
from src.model.model import MMEBModel  # noqa
from src.model.processor import load_processor, get_backbone_name  # noqa

try:
    import matplotlib
    matplotlib.use("Agg")  # 非 GUI 后端
    import matplotlib.pyplot as plt

    HAS_MATPLOTLIB = True
except Exception:
    HAS_MATPLOTLIB = False
    print("Warning: matplotlib not found, visualization will be skipped. Install with: pip install matplotlib")


# --------------------------
# helpers
# --------------------------
def _to_cpu_detached(obj):
    """递归将 tensor 转到 CPU 并 detach（用于缓存 batch）"""
    if isinstance(obj, torch.Tensor):
        return obj.detach().cpu()
    if isinstance(obj, dict):
        return {k: _to_cpu_detached(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return type(obj)(_to_cpu_detached(x) for x in obj)
    return obj


def _to_cuda_clone(obj):
    """递归将 CPU batch 搬到 GPU（不修改原对象，避免缓存污染）"""
    if isinstance(obj, torch.Tensor):
        return obj.cuda(non_blocking=True)
    if isinstance(obj, dict):
        return {k: _to_cuda_clone(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return type(obj)(_to_cuda_clone(x) for x in obj)
    return obj


def collect_batches(dataloader, num_batches):
    """从 dataloader 收集 num_batches 个 batch 到 CPU（用于公平对比）"""
    cached = []
    for i, batch in enumerate(dataloader):
        if i >= num_batches:
            break
        cached.append(_to_cpu_detached(batch))
    return cached

def ddp_setup():
    if "RANK" in os.environ and "WORLD_SIZE" in os.environ:
        dist.init_process_group(backend="nccl")
        rank = int(os.environ["RANK"])
        world_size = int(os.environ["WORLD_SIZE"])
        local_rank = int(os.environ.get("LOCAL_RANK", 0))
        torch.cuda.set_device(local_rank)
        device = torch.device(f"cuda:{local_rank}")
        return True, device, rank, world_size, local_rank
    return False, torch.device("cuda:0"), 0, 1, 0

def ddp_cleanup():
    if dist.is_available() and dist.isinitialized():
        dist.destroy_process_group()
# --------------------------
# chorus token extraction
# --------------------------
def _extract_chorus_tokens(hidden_states, attention_mask, total_compress_tokens, sep_indices=None):
    """
    Prefer sep_indices when available (openqa), otherwise fall back to last tokens (retrieval).
    hidden_states: (B, L, D)
    attention_mask: (B, L)
    sep_indices: (B, >=2) with [ctoken_start, ctoken_end, ...]
    """
    if sep_indices is not None:
        c_start = sep_indices[:, 0]
        batch_size = hidden_states.shape[0]
        token_offsets = torch.arange(total_compress_tokens, device=hidden_states.device).unsqueeze(0)
        token_indices = token_offsets + c_start.unsqueeze(1)
        batch_indices = torch.arange(batch_size, device=hidden_states.device).unsqueeze(1).expand(-1, total_compress_tokens)
        return hidden_states[batch_indices, token_indices].contiguous()

    batch_size = hidden_states.shape[0]
    eos_indices = attention_mask.sum(dim=1, keepdim=True)  # (B,1)
    token_offsets = torch.arange(total_compress_tokens, device=hidden_states.device).unsqueeze(0)
    token_indices = token_offsets + eos_indices - total_compress_tokens
    batch_indices = torch.arange(batch_size, device=hidden_states.device).unsqueeze(1).expand(-1, total_compress_tokens)
    return hidden_states[batch_indices, token_indices].contiguous()


# --------------------------
# metric computation
# --------------------------
def compute_sim_matrix(chorus_tokens, margin=0.2, use_abs=True):
    """
    计算相似度矩阵和 orthogonal loss（off-diag 版，统计更准）

    Args:
        chorus_tokens: (B, T, D) raw hidden (未 normalize)
        margin: orthogonal margin
        use_abs: 是否取 abs(sim)

    Returns:
        dict containing sim matrix and statistics
    """
    B, T, D = chorus_tokens.shape

    # L2 normalize for cosine
    x = F.normalize(chorus_tokens, p=2, dim=-1)  # (B,T,D)
    sim = x @ x.transpose(-2, -1)                # (B,T,T)
    if use_abs:
        sim = sim.abs()

    eye = torch.eye(T, device=sim.device, dtype=torch.bool).unsqueeze(0)  # (1,T,T)
    diag_vals = sim.masked_select(eye).view(B, T)
    off_vals = sim.masked_select(~eye).view(B, T * (T - 1))

    # Orthogonal loss（与训练常用实现一致：off-diag relu(|cos|-m)^2 的 mean）
    loss = (off_vals - margin).clamp_min(0).pow(2).mean()

    # 一些诊断（可选但便于看 collapse）
    norms = chorus_tokens.norm(p=2, dim=-1)  # (B,T)
    collapse_mid_ratio = (off_vals > 0.5).float().mean().item()
    collapse_high_ratio = (off_vals > 0.9).float().mean().item()

    return {
        "sim": sim,           # (B,T,T)
        "loss": float(loss.item()),
        "T": int(T),
        "stats": {
            "sim_mean": float(sim.mean().item()),
            "diag_mean": float(diag_vals.mean().item()),
            "off_diag_mean": float(off_vals.mean().item()),
            "off_diag_std": float(off_vals.std(unbiased=False).item()),
            "off_diag_max": float(off_vals.max().item()),
            "off_diag_min": float(off_vals.min().item()),
            "energy_mean": float(norms.mean().item()),
            "energy_std": float(norms.std(unbiased=False).item()),
            "collapse_mid_ratio": float(collapse_mid_ratio),
            "collapse_high_ratio": float(collapse_high_ratio),
        },
    }


# --------------------------
# visualization (summary-level by default)
# --------------------------
def visualize_summary(all_sims, checkpoint_name, output_dir):
    """
    生成简洁汇总图：
    1) mean_sim_heatmap.png - 所有样本平均相似度矩阵
    2) offdiag_hist.png     - off-diag 分布直方图
    """
    if not HAS_MATPLOTLIB:
        return
    os.makedirs(output_dir, exist_ok=True)

    all_off_vals = []
    sum_mat = None
    count = 0

    for sim_tensor in all_sims:
        sim_np = sim_tensor.detach().float().cpu().numpy()  # (B,T,T)
        B, T, _ = sim_np.shape
        for i in range(B):
            mat = sim_np[i]
            if sum_mat is None:
                sum_mat = np.zeros_like(mat, dtype=np.float64)
            sum_mat += mat
            count += 1
            mask = ~np.eye(T, dtype=bool)
            all_off_vals.extend(mat[mask].tolist())

    if sum_mat is None or count == 0:
        return
    mean_sim = (sum_mat / count).astype(np.float32)

    # heatmap
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(mean_sim, vmin=0.0, vmax=1.0, aspect="auto")
    ax.set_title(f"Mean Similarity Matrix - {checkpoint_name}")
    ax.set_xlabel("Token Index")
    ax.set_ylabel("Token Index")
    plt.colorbar(im, ax=ax, label="abs(cos)")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "mean_sim_heatmap.png"), dpi=150)
    plt.close()

    # offdiag hist
    all_off_vals = np.array(all_off_vals, dtype=np.float32)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(all_off_vals, bins=50, alpha=0.75, edgecolor="black")
    m = float(all_off_vals.mean()) if all_off_vals.size > 0 else 0.0
    ax.axvline(m, linestyle="--", label=f"Mean: {m:.3f}")
    ax.set_xlabel("Off-Diagonal abs(cos)")
    ax.set_ylabel("Count")
    ax.set_title(f"Off-Diagonal Similarity Distribution - {checkpoint_name}")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "offdiag_hist.png"), dpi=150)
    plt.close()


def visualize_sim_matrix_per_batch(sim_matrices, checkpoint_name, output_dir, batch_idx=0, max_samples=8):
    """
    可视化单个 batch 的相似度矩阵（默认不开；你真要看再开 --viz_per_batch）
    """
    if not HAS_MATPLOTLIB:
        return

    B, T, _ = sim_matrices.shape
    B = min(B, max_samples)

    n_cols = min(4, B)
    n_rows = (B + n_cols - 1) // n_cols
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(4 * n_cols, 4 * n_rows))
    if B == 1:
        axes = np.array([axes])
    axes = axes.flatten()

    for i in range(B):
        sim = sim_matrices[i].float().cpu().numpy()
        im = axes[i].imshow(sim, vmin=0.0, vmax=1.0, aspect="auto")
        axes[i].set_title(f"Sample {i}")
        axes[i].set_xlabel("Token Index")
        axes[i].set_ylabel("Token Index")
        plt.colorbar(im, ax=axes[i], fraction=0.046, pad=0.04)

    for i in range(B, len(axes)):
        axes[i].axis("off")

    plt.suptitle(f"{checkpoint_name} - Batch {batch_idx}", fontsize=14)
    plt.tight_layout()
    os.makedirs(output_dir, exist_ok=True)
    out = os.path.join(output_dir, f"sim_matrix_batch{batch_idx}.png")
    plt.savefig(out, dpi=150, bbox_inches="tight")
    plt.close()


def plot_comparison(results_list, checkpoint_names, output_dir):
    """
    仅做一个简洁对比图：loss / off_diag_mean / collapse_mid_ratio（按 batch）
    """
    if not HAS_MATPLOTLIB or len(results_list) != 2:
        return

    metrics = {
        "loss": ([r["loss"] for r in results_list[0]], [r["loss"] for r in results_list[1]]),
        "off_diag_mean": (
            [r["stats"]["off_diag_mean"] for r in results_list[0]],
            [r["stats"]["off_diag_mean"] for r in results_list[1]],
        ),
        "collapse_mid_ratio": (
            [r["stats"]["collapse_mid_ratio"] for r in results_list[0]],
            [r["stats"]["collapse_mid_ratio"] for r in results_list[1]],
        ),
    }

    fig, axes = plt.subplots(1, 3, figsize=(16, 4))
    n_batches = len(results_list[0])
    x = np.arange(n_batches)
    width = 0.35

    for ax, (metric_name, (v1, v2)) in zip(axes, metrics.items()):
        ax.bar(x - width / 2, v1, width, label=checkpoint_names[0], alpha=0.8)
        ax.bar(x + width / 2, v2, width, label=checkpoint_names[1], alpha=0.8)
        ax.set_xlabel("Batch")
        ax.set_ylabel(metric_name)
        ax.set_title(f"{metric_name} Comparison")
        ax.legend()
        ax.grid(True, alpha=0.3)

    plt.suptitle("Orthogonal Loss Effect Comparison", fontsize=14)
    plt.tight_layout()
    out = os.path.join(output_dir, "comparison.png")
    plt.savefig(out, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"\nSaved comparison plot: {out}")


# --------------------------
# train_sh parsing & ckpt finding
# --------------------------
def _parse_train_sh(sh_path):
    with open(sh_path, "r") as f:
        content = f.read()

    variables = {}
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export "):].strip()
        if "=" in line and not line.startswith("cmd="):
            key, val = line.split("=", 1)
            variables[key.strip()] = val.strip().strip('"').strip("'")

    def _expand_vars(s, vars_map, max_passes=3):
        if not s:
            return s
        pattern = re.compile(r"\$\{(\w+)\}|\$(\w+)")
        out = s
        for _ in range(max_passes):
            changed = False

            def _repl(m):
                nonlocal changed
                name = m.group(1) or m.group(2)
                if name in vars_map:
                    changed = True
                    return vars_map[name]
                return m.group(0)

            out = pattern.sub(_repl, out)
            if not changed:
                break
        return out

    for k in list(variables.keys()):
        variables[k] = _expand_vars(variables[k], variables)

    cmd_match = re.search(r'cmd="([\s\S]*?)"\s*', content)
    cmd = cmd_match.group(1) if cmd_match else ""

    def _sub_var(m):
        name = m.group(1)
        return variables.get(name, m.group(0))

    cmd = re.sub(r"\$(\w+)", _sub_var, cmd)
    cmd = cmd.replace("\\\n", " ")
    cmd = re.sub(r"\s+", " ", cmd).strip()

    config = {}
    if cmd:
        tokens = shlex.split(cmd)
        i = 0
        while i < len(tokens):
            tok = tokens[i]
            if tok.startswith("--"):
                key = tok.lstrip("-")
                values = []
                j = i + 1
                while j < len(tokens) and not tokens[j].startswith("--"):
                    values.append(tokens[j])
                    j += 1
                if len(values) == 0:
                    config[key] = True
                elif len(values) == 1:
                    config[key] = values[0]
                else:
                    config[key] = " ".join(values)
                i = j
                continue
            i += 1

    if "TOTAL_COMPRESS_TOKENS" in variables:
        config["total_compress_tokens"] = variables["TOTAL_COMPRESS_TOKENS"]
    if "EXP_DIR" in variables:
        config["exp_dir"] = variables["EXP_DIR"]
    if "EXP_NAME" in variables:
        config["exp_name"] = variables["EXP_NAME"]

    # If train script passes --output_dir, treat it as exp_dir for checkpoint discovery.
    if "output_dir" in config and "exp_dir" not in config:
        config["exp_dir"] = config["output_dir"]

    return config


def _find_latest_checkpoint(exp_dir):
    if not exp_dir or not os.path.isdir(exp_dir):
        return None
    candidates = sorted(
        glob.glob(os.path.join(exp_dir, "checkpoint-*")),
        key=lambda p: os.path.getmtime(p),
        reverse=True,
    )
    if candidates:
        return candidates[0]
    candidates = sorted(
        glob.glob(os.path.join(exp_dir, "global_step*")),
        key=lambda p: os.path.getmtime(p),
        reverse=True,
    )
    return candidates[0] if candidates else None


def _ckpt_names(ckpt_path):
    """
    Build a display name (parent/checkpoint) and a filesystem-safe name (parent__checkpoint).
    This avoids collisions when multiple runs share the same checkpoint basename.
    """
    p = Path(ckpt_path)
    base = p.name
    parent = p.parent.name
    if parent:
        return f"{parent}/{base}", f"{parent}__{base}"
    return base, base


# --------------------------
# build model/dataloader
# --------------------------
def _build_model_args(checkpoint_path, model_type, compression_mode, split_layer):
    model_args = ModelArguments(
        model_name=checkpoint_path,
        pooling="avg",
        normalize=True,
        model_type=model_type,
        compression_mode=compression_mode,
        split_layer=split_layer,
    )

    if not model_args.model_backbone:
        if model_args.model_type is None:
            cfg = AutoConfig.from_pretrained(checkpoint_path, trust_remote_code=True)
            model_args.model_type = getattr(cfg, "model_type", None)
        if model_args.model_type is None:
            raise SystemExit("model_type is required to resolve model_backbone.")
        model_args.model_backbone = get_backbone_name(hf_config=None, model_type=model_args.model_type)

    return model_args


def _build_model(model_args):
    model = MMEBModel.build(model_args)
    model.eval()
    model = model.cuda()
    return model


def _build_dataloader(
    model,
    model_args,
    dataset_config,
    batch_size,
    task_types,
    num_sample_per_subset,
    max_datasets,
    total_compress_tokens,
    output_dir,
    cls_types,
    orthogonal_margin,
):
    # patch processor globals
    os.environ["TOTAL_COMPRESS_TOKENS"] = str(total_compress_tokens)
    import src.model.processor as processor_mod
    processor_mod.TOTAL_COMPRESS_TOKENS = total_compress_tokens
    processor_mod.VLM_COMPRESS_TOKENS = [f"<|ctoken_pad_{i}|>" for i in range(total_compress_tokens)]
    processor_mod.IGNORE_STR = processor_mod.ENCODE_PROMPT + "".join(processor_mod.VLM_COMPRESS_TOKENS)

    from src.data.loader.mixed_dataset import init_mixed_dataset
    from src.data.collator.train_collator import MultimodalDataCollator

    dataset_config_path = dataset_config if isinstance(dataset_config, str) else None
    if isinstance(dataset_config, str):
        with open(dataset_config, "r") as yaml_file:
            dataset_config = yaml.safe_load(yaml_file)

    if max_datasets is not None and isinstance(dataset_config, dict):
        dataset_config = dict(list(dataset_config.items())[:max_datasets])

    data_args = DataArguments(
        dataset_config=dataset_config_path,
        image_resolution="mid",
        num_sample_per_subset=num_sample_per_subset,
    )

    processor = load_processor(model_args, data_args)

    training_args = type("obj", (object,), {
        "task_types": task_types,
        "per_device_retrv_train_batch_size": batch_size,
        "per_device_openqa_train_batch_size": batch_size,
        "data_weights": [1] * len(task_types),
        "interleave_batch_size": 1,
        "qa_interleave_batch_size": 1,
        "dataloader_num_workers": 0,
        "dataloader_pin_memory": False,
        "dataloader_persistent_workers": False,
        "seed": 42,
        "interleave_stopping_strategy": "all_exhausted",
        "output_dir": output_dir,
        "model_backbone": model_args.model_backbone,
    })()

    cls_type_to_indices = getattr(model.config, "cls_type_to_indices", None)
    if cls_type_to_indices:
        cls_type_to_indices = {
            k: v for k, v in cls_type_to_indices.items()
            if isinstance(v, (list, tuple)) and len(v) > 0
        }
    else:
        cls_type_to_indices = {}
    if not cls_type_to_indices:
        cls_type_to_indices = {None: [0, total_compress_tokens]}
    if cls_types:
        for ct in cls_types:
            if ct not in cls_type_to_indices:
                cls_type_to_indices[ct] = [0, total_compress_tokens]

    collator = MultimodalDataCollator(
        processor=processor,
        model_args=model_args,
        data_args=data_args,
        training_args=type("obj", (object,), {
            "orthogonal_loss": None,
            "distillation_loss": None,
            "orthogonal_margin": orthogonal_margin,
            "orthogonal_loss_qry": False,
            "orthogonal_loss_tgt": True,
            "native_prob": 0.0,
            "output_dir": output_dir,
            "model_backbone": model_args.model_backbone,
        })(),
        model_func_get_rope_index=model.encoder.get_rope_index,
        cls_type_to_indices=cls_type_to_indices,
    )

    train_dataset = init_mixed_dataset(
        dataset_config=dataset_config,
        model_args=model_args,
        data_args=data_args,
        training_args=training_args,
        data_collator=collator,
    )
    return train_dataset


# --------------------------
# analysis on cached batches
# --------------------------
@torch.no_grad()
def analyze_cached_batches(
    model,
    cached_batches_cpu,
    output_dir,
    checkpoint_name,
    total_compress_tokens,
    task_types,
    use_nat,
    orthogonal_margin,
    use_abs,
    visualize,
    viz_per_batch,
    viz_per_batch_max,
):
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(os.path.join(output_dir, "batches"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "figs"), exist_ok=True)

    print(f"\n{'=' * 60}")
    print(f"Analyzing: {checkpoint_name}")
    print(f"{'=' * 60}")

    all_results = []
    all_sims = []

    for batch_idx, batch_cpu in enumerate(cached_batches_cpu):
        # move to cuda (non-inplace)
        batch = _to_cuda_clone(batch_cpu)

        # pick inputs
        if isinstance(batch, (list, tuple)) and len(batch) >= 2:
            # retrieval batch: (qry_inputs, tgt_inputs[, ...])
            qry_inputs, tgt_inputs = batch[0], batch[1]
            # 默认分析 tgt side（和你原脚本一致）
            inputs = tgt_inputs
        elif isinstance(batch, dict):
            # openqa / distill batch
            if batch.get("distill_openqa", False):
                inputs = batch["nat"] if use_nat else batch["comp"]
            else:
                inputs = batch
        else:
            raise RuntimeError(f"Unexpected batch structure type: {type(batch)}")

        # avoid loss computation keys (inplace on cuda-copy OK)
        if isinstance(inputs, dict):
            inputs.pop("labels", None)
            inputs.pop("label", None)

        # forward
        hs = model.encoder(**inputs, return_dict=True, output_hidden_states=True)
        hidden_states = hs.hidden_states[-1]
        attention_mask = inputs["attention_mask"]
        sep_indices = inputs.get("sep_indices", None)

        chorus_tokens = _extract_chorus_tokens(
            hidden_states,
            attention_mask=attention_mask,
            total_compress_tokens=total_compress_tokens,
            sep_indices=sep_indices,
        )

        result = compute_sim_matrix(chorus_tokens, margin=orthogonal_margin, use_abs=use_abs)
        result["batch_idx"] = batch_idx

        all_results.append(result)
        all_sims.append(result["sim"])

        # save per-batch json
        batch_json = {
            "batch_idx": batch_idx,
            "loss": result["loss"],
            "stats": result["stats"],
            "sim_matrix": result["sim"].detach().float().cpu().tolist(),
        }
        with open(os.path.join(output_dir, "batches", f"batch_{batch_idx:03d}.json"), "w") as f:
            json.dump(batch_json, f, indent=2)

        print(
            f"  Batch {batch_idx}: loss={result['loss']:.4f}, "
            f"off_diag_mean={result['stats']['off_diag_mean']:.4f}, "
            f"collapse>0.5={result['stats']['collapse_mid_ratio']:.2%}"
        )

        if visualize and viz_per_batch and batch_idx < viz_per_batch_max:
            visualize_sim_matrix_per_batch(
                result["sim"], checkpoint_name, os.path.join(output_dir, "figs", "per_batch"), batch_idx=batch_idx
            )

    # summary
    avg_loss = float(np.mean([r["loss"] for r in all_results])) if all_results else 0.0
    avg_off = float(np.mean([r["stats"]["off_diag_mean"] for r in all_results])) if all_results else 0.0
    avg_off_std = float(np.mean([r["stats"]["off_diag_std"] for r in all_results])) if all_results else 0.0
    avg_collapse = float(np.mean([r["stats"]["collapse_mid_ratio"] for r in all_results])) if all_results else 0.0

    summary = {
        "checkpoint": checkpoint_name,
        "num_batches": len(all_results),
        "avg_loss": avg_loss,
        "avg_off_diag_mean": avg_off,
        "avg_off_diag_std": avg_off_std,
        "avg_collapse_mid_ratio": avg_collapse,
        "orthogonal_margin": orthogonal_margin,
        "use_abs": bool(use_abs),
        "total_compress_tokens": int(total_compress_tokens),
        "task_types": task_types,
        "use_nat": bool(use_nat),
    }
    with open(os.path.join(output_dir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    print("\n" + "=" * 60)
    print("Summary:")
    print(f"  Loss:           {avg_loss:.4f}")
    print(f"  Off-Diag Mean:  {avg_off:.4f}")
    print(f"  Off-Diag Std:   {avg_off_std:.4f}")
    print(f"  Collapse >0.5:  {avg_collapse:.2%}")
    print("=" * 60)

    # summary figs
    if visualize:
        visualize_summary(all_sims, checkpoint_name, os.path.join(output_dir, "figs", "summary"))

    return all_results, summary


# --------------------------
# main
# --------------------------
def main():
    import argparse

    parser = argparse.ArgumentParser(description="Analyze orthogonal loss effect (fair cached-batch comparison)")

    parser.add_argument("--checkpoint", type=str, default="/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/Korus_Qwen2moni_3B.hetu_hetu.BSr1024.BSg32.full.videoonly.re.ortho_m0.2_w0.03_abs.v3.steps5k.run/checkpoint-500", help="Path to checkpoint (single mode)")
    parser.add_argument("--checkpoint2", type=str, default="/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/Korus_Qwen2moni_3B.hetu_hetu.BSr1024.BSg32.full.videoonly.re.ortho_m0.0_w0.00_abs.v3.steps5k.run/checkpoint-500", help="Path to second checkpoint for comparison")
    parser.add_argument("--dataset_config", type=str, default=None, help="Path to dataset config yaml")
    parser.add_argument("--output_dir", type=str, default="/mmu_mllm_hdd/zhangchenghao05/hetu_next", help="Output directory")

    parser.add_argument("--num_batches", type=int, default=32, help="Number of batches to analyze")
    parser.add_argument("--batch_size", type=int, default=4, help="Batch size")

    # Visualization controls
    parser.add_argument("--no_visualize", action="store_true", help="Disable all visualization")
    parser.add_argument("--viz_per_batch", action="store_true", help="Also save per-batch sim heatmaps (few batches)")
    parser.add_argument("--viz_per_batch_max", type=int, default=2, help="Max batches to save per-batch heatmaps")

    # Model-related args
    parser.add_argument("--model_type", type=str, default="qwen2_5_omni", help="Model type")
    parser.add_argument("--compression_mode", action="store_true", default=True, help="Use compression mode")
    parser.add_argument("--split_layer", type=int, default=36, help="Split layer for compression")
    parser.add_argument("--cls_types", type=str, default="video,goods", help="CLS types (comma-separated)")
    parser.add_argument("--total_compress_tokens", type=int, default=8, help="Total compress tokens")
    parser.add_argument("--task_types", type=str, default="retrieval", help="Task types (comma-separated)")
    parser.add_argument("--use_nat", action="store_true", help="Use nat inputs when distill_openqa is enabled")
    parser.add_argument("--num_sample_per_subset", type=int, default=200000, help="Limit samples per subset")
    parser.add_argument("--max_datasets", type=int, default=None, help="Only use first N datasets from dataset_config")

    # Orthogonal params
    parser.add_argument("--orthogonal_margin", type=float, default=0.2, help="Margin for orthogonal loss")
    parser.add_argument("--use_abs", action="store_true", default=True, help="Use abs(sim)")
    parser.add_argument("--no_abs", action="store_true", help="Disable abs(sim)")

    # Train script paths (keep your defaults)
    parser.add_argument(
        "--train_sh1",
        type=str,
        default="/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec/experiments/hetu/train_korus-qwen2omni-3B_hetu_hetu_videoonly_orthogonal.sh",
        help="Path to training shell script (checkpoint 1 config)",
    )
    parser.add_argument(
        "--train_sh2",
        type=str,
        default="/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec/experiments/hetu/train_korus-qwen2omni-3B_hetu_hetu_videoonly_baseline.sh",
        help="Path to training shell script (checkpoint 2 config)",
    )

    args = parser.parse_args()
    visualize = not args.no_visualize
    use_abs = args.use_abs and (not args.no_abs)

    # Parse training scripts
    sh_config1 = _parse_train_sh(args.train_sh1) if args.train_sh1 else {}

    def _pick(key, default, cfg):
        return cfg.get(key, default)

    # Auto-fill from sh1
    if args.train_sh1:
        if args.dataset_config is None:
            args.dataset_config = _pick("dataset_config", args.dataset_config, sh_config1)
        if args.model_type == "qwen2_5_omni":
            args.model_type = _pick("model_type", args.model_type, sh_config1)
        if args.split_layer == 36:
            args.split_layer = int(_pick("split_layer", args.split_layer, sh_config1))
        if args.total_compress_tokens == 8:
            args.total_compress_tokens = int(_pick("total_compress_tokens", args.total_compress_tokens, sh_config1))
        if args.task_types == "retrieval" and "task_types" in sh_config1:
            args.task_types = sh_config1["task_types"]
        if args.cls_types == "video,goods" and "cls_types" in sh_config1:
            args.cls_types = sh_config1["cls_types"]

    # Normalize comma-separated args
    if args.cls_types and " " in args.cls_types:
        args.cls_types = args.cls_types.replace(" ", ",")
    if args.task_types and " " in args.task_types:
        args.task_types = args.task_types.replace(" ", ",")

    cls_types = args.cls_types.split(",") if args.cls_types else None
    task_types = args.task_types.split(",") if args.task_types else None

    # Basic checks
    if args.dataset_config is None:
        raise SystemExit("--dataset_config is required (or train_sh1 must contain it).")
    if args.checkpoint is None:
        raise SystemExit("--checkpoint is required (or train_sh1 EXP_DIR must contain checkpoints).")

    os.makedirs(args.output_dir, exist_ok=True)
    os.makedirs(os.path.join(args.output_dir, "comparison"), exist_ok=True)

    # Save run meta
    run_meta = {
        "timestamp": datetime.now().isoformat(),
        "git_commit": None,
        "checkpoint_path": args.checkpoint,
        "checkpoint2_path": args.checkpoint2,
        "dataset_config": args.dataset_config,
        "model_type": args.model_type,
        "split_layer": args.split_layer,
        "compression_mode": bool(args.compression_mode),
        "total_compress_tokens": int(args.total_compress_tokens),
        "cls_types": cls_types,
        "task_types": task_types,
        "num_batches": int(args.num_batches),
        "batch_size": int(args.batch_size),
        "orthogonal_margin": float(args.orthogonal_margin),
        "use_abs": bool(use_abs),
        "use_nat": bool(args.use_nat),
        "num_sample_per_subset": int(args.num_sample_per_subset),
        "max_datasets": args.max_datasets,
        "visualize": bool(visualize),
        "viz_per_batch": bool(args.viz_per_batch),
        "viz_per_batch_max": int(args.viz_per_batch_max),
    }
    try:
        run_meta["git_commit"] = (
            torch.utils.cpp_extension.check_output(["git", "rev-parse", "HEAD"], cwd=str(project_root))
            .decode()
            .strip()
        )
    except Exception:
        # silent if not in git env
        pass

    with open(os.path.join(args.output_dir, "run_meta.json"), "w") as f:
        json.dump(run_meta, f, indent=2)

    # ========== SINGLE MODE ==========
    if args.checkpoint2 is None:
        print("\n" + "=" * 60)
        print("SINGLE CHECKPOINT MODE")
        print("=" * 60)

        model_args = _build_model_args(
            checkpoint_path=args.checkpoint,
            model_type=args.model_type,
            compression_mode=args.compression_mode,
            split_layer=args.split_layer,
        )
        model = _build_model(model_args)

        dataloader = _build_dataloader(
            model=model,
            model_args=model_args,
            dataset_config=args.dataset_config,
            batch_size=args.batch_size,
            task_types=task_types or ["retrieval"],
            num_sample_per_subset=args.num_sample_per_subset,
            max_datasets=args.max_datasets,
            total_compress_tokens=args.total_compress_tokens,
            output_dir=args.output_dir,
            cls_types=cls_types,
            orthogonal_margin=args.orthogonal_margin,
        )

        print(f"\nCaching {args.num_batches} batches for analysis...")
        cached_batches = collect_batches(dataloader, args.num_batches)
        print(f"  Cached {len(cached_batches)} batches")

        ckpt_display, ckpt_safe = _ckpt_names(args.checkpoint)
        out_dir = os.path.join(args.output_dir, ckpt_safe)
        analyze_cached_batches(
            model=model,
            cached_batches_cpu=cached_batches,
            output_dir=out_dir,
            checkpoint_name=ckpt_display,
            total_compress_tokens=args.total_compress_tokens,
            task_types=task_types or ["retrieval"],
            use_nat=args.use_nat,
            orthogonal_margin=args.orthogonal_margin,
            use_abs=use_abs,
            visualize=visualize,
            viz_per_batch=args.viz_per_batch,
            viz_per_batch_max=args.viz_per_batch_max,
        )
        return

    # ========== COMPARISON MODE (default if train_sh2 works) ==========
    print("\n" + "=" * 60)
    print("COMPARISON MODE (fair comparison with cached batches)")
    print("=" * 60)

    # Build dataloader using ckpt1 model/collator, cache batches once
    model_args1 = _build_model_args(
        checkpoint_path=args.checkpoint,
        model_type=args.model_type,
        compression_mode=args.compression_mode,
        split_layer=args.split_layer,
    )
    model1 = _build_model(model_args1)

    dataloader = _build_dataloader(
        model=model1,
        model_args=model_args1,
        dataset_config=args.dataset_config,
        batch_size=args.batch_size,
        task_types=task_types or ["retrieval"],
        num_sample_per_subset=args.num_sample_per_subset,
        max_datasets=args.max_datasets,
        total_compress_tokens=args.total_compress_tokens,
        output_dir=args.output_dir,
        cls_types=cls_types,
        orthogonal_margin=args.orthogonal_margin,
    )

    print(f"\nCaching {args.num_batches} batches for FAIR comparison...")
    cached_batches = collect_batches(dataloader, args.num_batches)
    print(f"  Cached {len(cached_batches)} batches")

    with open(os.path.join(args.output_dir, "cached_batches_meta.json"), "w") as f:
        json.dump(
            {
                "num_batches": len(cached_batches),
                "batch_size": args.batch_size,
                "total_samples": len(cached_batches) * args.batch_size,
            },
            f,
            indent=2,
        )

    name1, name1_safe = _ckpt_names(args.checkpoint)
    name2, name2_safe = _ckpt_names(args.checkpoint2)

    # Analyze ckpt1
    out_dir1 = os.path.join(args.output_dir, name1_safe)
    results1, summary1 = analyze_cached_batches(
        model=model1,
        cached_batches_cpu=cached_batches,
        output_dir=out_dir1,
        checkpoint_name=name1,
        total_compress_tokens=args.total_compress_tokens,
        task_types=task_types or ["retrieval"],
        use_nat=args.use_nat,
        orthogonal_margin=args.orthogonal_margin,
        use_abs=use_abs,
        visualize=visualize,
        viz_per_batch=args.viz_per_batch,
        viz_per_batch_max=args.viz_per_batch_max,
    )

    # Free ckpt1
    model1 = model1.cpu()
    del model1
    torch.cuda.empty_cache()

    # Analyze ckpt2
    model_args2 = _build_model_args(
        checkpoint_path=args.checkpoint2,
        model_type=args.model_type,
        compression_mode=args.compression_mode,
        split_layer=args.split_layer,
    )
    model2 = _build_model(model_args2)

    out_dir2 = os.path.join(args.output_dir, name2_safe)
    results2, summary2 = analyze_cached_batches(
        model=model2,
        cached_batches_cpu=cached_batches,
        output_dir=out_dir2,
        checkpoint_name=name2,
        total_compress_tokens=args.total_compress_tokens,
        task_types=task_types or ["retrieval"],
        use_nat=args.use_nat,
        orthogonal_margin=args.orthogonal_margin,
        use_abs=use_abs,
        visualize=visualize,
        viz_per_batch=args.viz_per_batch,
        viz_per_batch_max=args.viz_per_batch_max,
    )

    # Comparison plot + summary
    if visualize and HAS_MATPLOTLIB:
        plot_comparison([results1, results2], [name1, name2], os.path.join(args.output_dir, "comparison"))

    comparison = {
        "checkpoint1": name1,
        "checkpoint2": name2,
        "metrics": {
            "avg_loss": {
                "ckpt1": summary1["avg_loss"],
                "ckpt2": summary2["avg_loss"],
                "diff": summary1["avg_loss"] - summary2["avg_loss"],
            },
            "avg_off_diag_mean": {
                "ckpt1": summary1["avg_off_diag_mean"],
                "ckpt2": summary2["avg_off_diag_mean"],
                "diff": summary1["avg_off_diag_mean"] - summary2["avg_off_diag_mean"],
            },
            "avg_collapse_mid_ratio": {
                "ckpt1": summary1["avg_collapse_mid_ratio"],
                "ckpt2": summary2["avg_collapse_mid_ratio"],
                "diff": summary1["avg_collapse_mid_ratio"] - summary2["avg_collapse_mid_ratio"],
            },
        },
    }
    with open(os.path.join(args.output_dir, "comparison", "summary.json"), "w") as f:
        json.dump(comparison, f, indent=2)

    print("\n" + "=" * 60)
    print("COMPARISON SUMMARY")
    print("=" * 60)
    print(f"\n{'Metric':<22} {name1[:18]:>18} {name2[:18]:>18} {'Diff(1-2)':>12}")
    print("-" * 72)
    print(f"{'avg_loss':<22} {summary1['avg_loss']:>18.4f} {summary2['avg_loss']:>18.4f} {(summary1['avg_loss']-summary2['avg_loss']):>12.4f}")
    print(f"{'avg_off_diag_mean':<22} {summary1['avg_off_diag_mean']:>18.4f} {summary2['avg_off_diag_mean']:>18.4f} {(summary1['avg_off_diag_mean']-summary2['avg_off_diag_mean']):>12.4f}")
    print(f"{'avg_collapse_mid_ratio':<22} {summary1['avg_collapse_mid_ratio']:>18.2%} {summary2['avg_collapse_mid_ratio']:>18.2%} {(summary1['avg_collapse_mid_ratio']-summary2['avg_collapse_mid_ratio']):>12.2%}")
    print("=" * 60)


if __name__ == "__main__":
    main()
