#!/bin/bash
set -euo pipefail

REPO_DIR="$(cd "$(dirname "$0")/../../.." && pwd)"
cd "$REPO_DIR"

PROJECTOR_PATH="${PROJECTOR_PATH:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/cached_projector/goods_cached_projector_retrain_256_128_64}"
INPUT_DIR="${INPUT_DIR:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0429_twostage/goods_0429_distinct_attnpool_ortho_retqa_bsr1024_bsq128_t4_s1-10000_s2-4000/stage2/checkpoint-4000/goods_embs/emb}"
OUTPUT_DIR="${OUTPUT_DIR:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/cached_projector/goods_cached_projector_retrain_256_128_64/encoded_embs}"
DATASETS="${DATASETS:-IA_Test_Swing_Items}"
HEAD_NAME="${HEAD_NAME:-}"
DEVICE="${DEVICE:-cuda}"
BATCH_SIZE="${BATCH_SIZE:-4096}"
DTYPE="${DTYPE:-float32}"

cmd=(
  /mmu_mllm_hdd/zhangchenghao05/envs/vlm2vec/bin/python
  -m src.cached_projector.apply
  --projector_path "$PROJECTOR_PATH"
  --input_dir "$INPUT_DIR"
  --output_dir "$OUTPUT_DIR"
  --batch_size "$BATCH_SIZE"
  --device "$DEVICE"
  --dtype "$DTYPE"
)
if [ -n "$DATASETS" ]; then
  cmd+=(--datasets $DATASETS)
fi
if [ -n "$HEAD_NAME" ]; then
  cmd+=(--head_name "$HEAD_NAME")
fi

printf "[APPLY] CMD: "
printf "%q " "${cmd[@]}"
printf "\n"
"${cmd[@]}"
