#!/usr/bin/env python3
import argparse
import json
import os
from collections import Counter


def parse_args():
    parser = argparse.ArgumentParser(description="Count missing image files from a jsonl dataset.")
    parser.add_argument("--input", required=True, help="Path to the jsonl file.")
    parser.add_argument("--image-key", default="image_path", help="Image path field name in each json line.")
    parser.add_argument("--id-key", default="item_id", help="ID field name in each json line.")
    parser.add_argument("--show-missing", type=int, default=20, help="Show first N missing samples.")
    return parser.parse_args()


def main():
    args = parse_args()

    total = 0
    missing = 0
    empty = 0
    shown = 0
    dir_counter = Counter()

    with open(args.input, "r") as f:
        for line in f:
            total += 1
            row = json.loads(line)
            image_path = row.get(args.image_key)
            item_id = row.get(args.id_key, total)

            if not image_path:
                empty += 1
                missing += 1
                if shown < args.show_missing:
                    print(f"[MISSING] id={item_id} path=<EMPTY>")
                    shown += 1
                continue

            if not os.path.exists(image_path):
                missing += 1
                dir_counter[os.path.dirname(image_path)] += 1
                if shown < args.show_missing:
                    print(f"[MISSING] id={item_id} path={image_path}")
                    shown += 1

    print("=" * 80)
    print(f"input: {args.input}")
    print(f"total_rows: {total}")
    print(f"missing_images: {missing}")
    print(f"existing_images: {total - missing}")
    print(f"empty_image_path: {empty}")
    if total > 0:
        print(f"missing_ratio: {missing / total:.6%}")

    if dir_counter:
        print("=" * 80)
        print("top_missing_dirs:")
        for dirname, cnt in dir_counter.most_common(20):
            print(f"{cnt}\t{dirname}")


if __name__ == "__main__":
    main()
