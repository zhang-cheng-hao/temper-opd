#!/bin/bash
set -euo pipefail

REPO_DIR="$(cd "$(dirname "$0")/../../.." && pwd)"
cd "$REPO_DIR"

NNODES="${1:-${NNODES:-1}}"
NODE_RANK="${2:-${NODE_RANK:-0}}"
shift $(( $# >= 2 ? 2 : $# ))
for arg in "$@"; do
  case "$arg" in
    *=*) export "$arg" ;;
    *) echo "[WARN] ignore non key=value arg: $arg" ;;
  esac
done

export TOTAL_COMPRESS_TOKENS="${TOTAL_COMPRESS_TOKENS:-4}"
export VLM_COMPRESS_TOKEN_MODE="${VLM_COMPRESS_TOKEN_MODE:-distinct}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface/datasets}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

GPUS_PER_NODE="${GPUS_PER_NODE:-8}"
MASTER_ADDR="${MASTER_ADDR:-localhost}"
MASTER_PORT="${MASTER_PORT:-2217}"
TORCHRUN="${TORCHRUN:-/mmu_mllm_hdd/zhangchenghao05/envs/vlm2vec/bin/torchrun}"
MODEL_NAME="${MODEL_NAME:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0429_twostage/goods_0429_distinct_slotalign_ortho_retqa_bsr1024_bsq128_t4_s1-10000_s2-4000/stage2/checkpoint-4000}"
MODEL_TYPE="${MODEL_TYPE:-qwen2_5_omni}"
STAGE_YAML="${STAGE_YAML:-experiments/hetu/train_goods_0429_stage2_retqa_curated.yaml}"
CACHE_DIR="${CACHE_DIR:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/cached_projector/goods_0429_distinct_slotalign_stage2_cache_rebuilt}"
POOLING="${POOLING:-none}"
SIMILARITY_TYPE="${SIMILARITY_TYPE:-slot_aligned}"
PER_DEVICE_BATCH_SIZE="${PER_DEVICE_BATCH_SIZE:-32}"
CACHE_MAX_STEPS="${CACHE_MAX_STEPS:-4000}"
CACHE_SHARD_SIZE="${CACHE_SHARD_SIZE:-4096}"
CACHE_DTYPE="${CACHE_DTYPE:-bfloat16}"
NUM_WORKERS="${NUM_WORKERS:-2}"
MAX_LEN="${MAX_LEN:-8192}"
MIN_PIXELS="${MIN_PIXELS:-3136}"
MAX_IMAGE_TOKENS="${MAX_IMAGE_TOKENS:-200}"
MAX_PIXELS="${MAX_PIXELS:-$((28 * 28 * MAX_IMAGE_TOKENS))}"
MODE="${MODE:-run}"

if [ ! -x "$TORCHRUN" ]; then
  echo "[ERR] torchrun not found: $TORCHRUN" >&2
  exit 1
fi
if [ ! -e "$MODEL_NAME" ]; then
  echo "[ERR] model path not found: $MODEL_NAME" >&2
  exit 1
fi
if [ ! -f "$STAGE_YAML" ]; then
  echo "[ERR] yaml not found: $STAGE_YAML" >&2
  exit 1
fi

cmd=(
  "$TORCHRUN"
  --nproc-per-node "$GPUS_PER_NODE"
  --nnodes "$NNODES"
  --max-restarts 0
  --rdzv-backend c10d
  --rdzv-id "cached-projector-cache"
  --rdzv-endpoint "$MASTER_ADDR:$MASTER_PORT"
  --node-rank "$NODE_RANK"
  -m src.cached_projector.build_cache
  --seed 42
  --compression_mode
  --task_types retrieval_goods
  --split_cls_tokens_by_task False
  --cls_types goods
  --dataset_config "$STAGE_YAML"
  --pooling "$POOLING"
  --similarity_type "$SIMILARITY_TYPE"
  --model_name "$MODEL_NAME"
  --model_type "$MODEL_TYPE"
  --output_dir "$CACHE_DIR/run_state"
  --cache_dir "$CACHE_DIR"
  --cache_max_steps "$CACHE_MAX_STEPS"
  --cache_shard_size "$CACHE_SHARD_SIZE"
  --cache_dtype "$CACHE_DTYPE"
  --per_device_train_batch_size 1
  --per_device_retrv_train_batch_size "$PER_DEVICE_BATCH_SIZE"
  --per_device_openqa_train_batch_size 1
  --interleave_batch_size 1
  --data_weights 1
  --loss_weights 1
  --dataloader_num_workers "$NUM_WORKERS"
  --dataloader_pin_memory False
  --dataloader_persistent_workers False
  --max_len "$MAX_LEN"
  --resize_min_pixels "$MIN_PIXELS"
  --resize_max_pixels "$MAX_PIXELS"
  --remove_unused_columns False
  --report_to none
)

printf "[CACHE] CMD: "
printf "%q " "${cmd[@]}"
printf "\n"
if [ "$MODE" = "print" ]; then
  exit 0
fi
mkdir -p "$CACHE_DIR"
"${cmd[@]}" 2>&1 | tee "$CACHE_DIR/build_cache.log"
