#!/bin/bash

set -e

echo "==> Environment"
echo "conda location: $(which conda)"
echo "Python location: $(which python)"
echo "Python version: $(python --version)"
echo ""

# cd projects/VLM2Vec/ || exit
export HF_ENDPOINT='https://hf-mirror.com'
export HF_HOME='/hetu_group/liulihao/.cache/huggingface'
export HF_DATASETS_CACHE='/hetu_group/liulihao/.cache/huggingface/datasets'

# ==============================================================================
# Configuration
# ==============================================================================
CUDA_VISIBLE_DEVICES="0,1,2,3,4,5,6,7"
BATCH_SIZE=16
MODALITIES=("image")
DATA_BASEDIR="/mmu_mllm_hdd_2/liulihao/data/vlm2vec_eval/MMEB-V2"
OUTPUT_BASEDIR="/mmu_mllm_hdd_2/liulihao/outputs/exps/vlm2vec/"
MODEL_BASEDIR="/mmu_mllm_hdd_2/liulihao/models"
# EVAL_MODEL1="/mmu_mllm_hdd_2/liulihao/outputs/exps/Qwen2_5vl_3B.retrv.autoresize.lora16.split36.biattn.BS1024.lr2e5.step2kwarm100.ds2.8A800"
EVAL_MODEL1="/mmu_mllm_hdd_2/liulihao/outputs/exps/Qwen2_5vl_3B.retrv.autoresize.lora16.split27.biattn.BS1024.lr2e5.step2kwarm100.ds2.8A800"
# EVAL_MODEL2="/mmu_mllm_hdd_2/liulihao/outputs/exps/Qwen2_5vl_3B.qa.autoresize.shuffled.fullft.split27.BS64.GA4.lr2e5.step3kwarm100.ds2.8A800"
# EVAL_MODEL3="/mmu_mllm_hdd_2/liulihao/outputs/exps/Qwen2_5vl_3B.qa.autoresize.shuffled.fullft.split36.BS64.GA4.lr2e5.step3kwarm100.ds2.8A800"
# EVAL_MODEL4="/mmu_mllm_hdd_2/liulihao/outputs/exps/Qwen2_5vl_3B.ret_qa.autoresize.lora16.split27.BSr1024.BSg64.w1-1.lr2e5.step2kwarm100.8A800"
# EVAL_MODEL5="/mmu_mllm_hdd_2/liulihao/outputs/exps/Qwen2_5vl_3B.ret_qa.autoresize.lora16.split27.BSr1024.BSg64.GA5.w1-4.lr2e5.step2kwarm100.8A800"


# ==> Define models and their base output paths here
# Format: "MODEL_NAME;BASE_OUTPUT_PATH"
declare -a MODEL_SPECS
MODEL_SPECS+=( "$EVAL_MODEL1;qwen2_5_vl_compression;$OUTPUT_BASEDIR/Qwen2_5VL-3B-Ret-split27-biattn-BS1024-step2k-avg" )
# MODEL_SPECS+=( "$EVAL_MODEL;qwen2_vl;$OUTPUT_BASEDIR/VLM2Vec-V2.0-Qwen2VL-2B-BS1024-step5k" )
# MODEL_SPECS+=( "$EVAL_MODEL;qwen2_vl;$OUTPUT_BASEDIR/VLM2Vec-V2.0-Qwen2VL-2B-BS1024-step5k" )
# MODEL_SPECS+=( "$MODEL_BASEDIR/VLM2Vec/VLM2Vec-V2.0;qwen2_vl;$OUTPUT_BASEDIR/VLM2Vec-V2.0-Qwen2VL-2B" )
# MODEL_SPECS+=( "Alibaba-NLP/gme-Qwen2-VL-2B-Instruct;gme;$OUTPUT_BASEDIR/gme-Qwen2-VL-2B-Instruct" )
# MODEL_SPECS+=( "Alibaba-NLP/gme-Qwen2-VL-7B-Instruct;gme;$OUTPUT_BASEDIR/gme-Qwen2-VL-7B-Instruct" )
# MODEL_SPECS+=( "code-kunkun/LamRA-Ret;lamra;$OUTPUT_BASEDIR/LamRA-Ret" )
# MODEL_SPECS+=( "vidore/colpali-v1.3;colpali;$OUTPUT_BASEDIR/colpali-v1.3" )
#MODEL_SPECS+=( "royokong/e5-v;llava_next;$OUTPUT_BASEDIR/e5-v" )
#MODEL_SPECS+=( "src/model/vlm_backbone/internvideo2/;internvideo2;$OUTPUT_BASEDIR/internvideo2" )
#MODEL_SPECS+=( "code-kunkun/LamRA-Ret-Qwen2.5VL-7b;lamra-qwen25;$OUTPUT_BASEDIR/gme-Qwen2-VL-7B-Instruct" )  # not ready


# ==============================================================================
# Main Execution Loop
# ==============================================================================
# Loop through each model specification
for spec in "${MODEL_SPECS[@]}"; do
  # Parse the model name and base output path from the spec string
  IFS=';' read -r MODEL_NAME MODEL_BACKBONE BASE_OUTPUT_PATH <<< "$spec"

  echo "================================================="
  echo "🚀 Processing Model: $MODEL_NAME"
  echo "================================================="

  # Loop through each modality for the current model
  for MODALITY in "${MODALITIES[@]}"; do
    DATA_CONFIG_PATH="experiments/public/eval/$MODALITY.yaml"
    OUTPUT_PATH="$BASE_OUTPUT_PATH/$MODALITY/"

    echo "-------------------------------------------------"
    echo "  - Modality: $MODALITY"
    echo "  - Output Path: $OUTPUT_PATH"

    # Ensure the output directory exists
    mkdir -p "$OUTPUT_PATH"

    cmd="CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES torchrun --nproc_per_node=8 --master_port=2277 --max_restarts=0 eval.py \
      --pooling avg \
      --normalize true \
      --per_device_eval_batch_size $BATCH_SIZE \
      --model_backbone \"$MODEL_BACKBONE\" \
      --model_name \"$MODEL_NAME\" \
      --dataset_config \"$DATA_CONFIG_PATH\" \
      --encode_output_path \"$OUTPUT_PATH\" \
      --data_basedir \"$DATA_BASEDIR\""

    echo "  - Executing command..."
    # echo "$cmd" # Uncomment for debugging the exact command
    eval "$cmd"
    echo "  - Done."
    echo "-------------------------------------------------"
  done
done

echo "✅ All jobs completed."
