import os
from typing import Dict, List
import torch
import torch.distributed as dist
from torch import nn, Tensor
from transformers import PreTrainedModel, AutoModelForCausalLM, AutoConfig
from peft import LoraConfig, get_peft_model, PeftModel
import numpy as np
from copy import deepcopy
import inspect

from src.utils import print_rank
from src.model.utils import get_parameter_number
from src.arguments import ModelArguments
from src.model.processor import LLAVA_NEXT, QWEN2_VL, QWEN2_5_OMNI, PHI3V, get_backbone_name, print_master, QWEN2_5_VL, INTERNVIDEO2, \
    QWEN2_VL_TOKENSELECTION, QWEN2_5_VL_TOKENSELECTION, backbone2model, GME, VLM_IMAGE_TOKENS, LamRA, LamRA_QWEN2_5, COLPALI, KEYE_VL_1_5, TOTAL_COMPRESS_TOKENS
from src.model.baseline_backbone.colpali import ColPali
from src.model.baseline_backbone.gme.gme_inference import GmeQwen2VL
from src.model.baseline_backbone.lamra.lamra_inference import LamRAQwen2VL
from src.model.baseline_backbone.lamra.lamra_qwen25_inference import LamRAQwen25VL
from src.model.baseline_backbone.phi3_v.modeling_phi3_v import Phi3VForCausalLM
from src.model.baseline_backbone.llava_next import LlavaNextForConditionalGeneration
from src.model.projector import GatedPooling, AttentionPooling, AveragePooling, MultiHeadMLPProjector, get_projector_state_dict_path


def init_weights(m):
    if isinstance(m, nn.Linear):
        # 使用Xavier初始化
        nn.init.xavier_uniform_(m.weight)
        if m.bias is not None:
            nn.init.zeros_(m.bias)


def compute_accuracy(scores, target, topk=(1, 2, 3, 4, 5)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        # Get the indices of the top k predictions
        _, pred = scores.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = {}
        for k in topk:
            correct_k = correct[:k].reshape(-1).float().sum(0, keepdim=True)
            res[f'acc_top{k}'] = correct_k.mul_(100.0 / batch_size).item()
            # res.append(correct_k.mul_(100.0 / batch_size))

        return res


def _make_multi_head_output_dims(model_args: ModelArguments, state_dict: Dict[str, Tensor] = None) -> Dict[str, int]:
    output_dims = {}
    if state_dict is not None:
        for key, value in state_dict.items():
            parts = key.split(".")
            if len(parts) >= 4 and parts[0] == "heads" and parts[-2:] == ["fc2", "weight"]:
                output_dims[parts[1]] = int(value.shape[0])
            elif len(parts) == 3 and parts[0] == "heads" and parts[-1] == "weight":
                output_dims[parts[1]] = int(value.shape[0])
    if output_dims:
        return output_dims
    return {str(d): int(d) for d in model_args.multi_head_dims}


def _make_multi_head_hidden_dims(
    model_args: ModelArguments,
    output_dims: Dict[str, int],
    state_dict: Dict[str, Tensor] = None,
) -> Dict[str, int]:
    hidden_dims = {}
    if state_dict is not None:
        for key, value in state_dict.items():
            parts = key.split(".")
            if len(parts) >= 4 and parts[0] == "heads" and parts[-2:] == ["fc1", "weight"]:
                hidden_dims[parts[1]] = int(value.shape[0])
    if hidden_dims:
        return hidden_dims
    hidden_dim = model_args.projector_hidden_dim if model_args.projector_hidden_dim and model_args.projector_hidden_dim > 0 else 0
    return {name: hidden_dim for name in output_dims} if hidden_dim > 0 else None


def _build_multi_head_projector(
    hidden_size: int,
    model_args: ModelArguments,
    num_scales: int = 1,
    state_dict: Dict[str, Tensor] = None,
) -> MultiHeadMLPProjector:
    output_dims = _make_multi_head_output_dims(model_args, state_dict=state_dict)
    hidden_dims = _make_multi_head_hidden_dims(model_args, output_dims, state_dict=state_dict)
    return MultiHeadMLPProjector(
        hidden_dim=hidden_size,
        output_dims=output_dims,
        hidden_dims=hidden_dims,
        mode='mlp',
        num_scales=num_scales,
    )

class DownSampler(nn.Module):
    def __init__(self, initial_hidden_size: int, down_hidden_size: int, rate=4):
        super().__init__()

        # 检查输入是否有效
        if initial_hidden_size <= down_hidden_size:
            raise ValueError("initial_hidden_size must be greater than down_hidden_size")

        down_projs_list = []
        current_hidden_size = initial_hidden_size

        while current_hidden_size > down_hidden_size:
            # 计算下一层的维度
            # 使用 max() 是为了确保最后一次降维不会低于目标 down_hidden_size
            next_hidden_size = max(current_hidden_size // rate, down_hidden_size)

            # 创建降维层
            down_projs_list.append(
                nn.Sequential(
                    nn.Linear(current_hidden_size, next_hidden_size),
                    nn.LayerNorm(next_hidden_size),
                    nn.SiLU(),
                )
            )

            # 更新当前维度以进行下一次迭代
            current_hidden_size = next_hidden_size

        self.down_projs = nn.ModuleList(down_projs_list)

    def forward(self, x):
        # 示例 forward 方法
        for layer in self.down_projs:
            x = layer(x)
        return x

class RetHead(nn.Module):
    def __init__(
        self,
        num_heads: int,
        hidden_size: int,
        num_tokens: int,
        num_layers: int = 1,
    ):
        super().__init__()
        down_hidden_size = hidden_size // num_tokens
        concat_hidden_size = down_hidden_size * num_tokens
        self.down_sampler = DownSampler(
            initial_hidden_size=hidden_size,
            down_hidden_size=down_hidden_size,
            rate=4
        )
        self.heads = nn.ModuleDict()
        for mlp_id in range(num_heads):
            layers = nn.ModuleList(
                nn.Sequential(
                    nn.Linear(concat_hidden_size, 2 * concat_hidden_size),
                    nn.LayerNorm(2 * concat_hidden_size),
                    nn.SiLU(),
                    nn.Linear(2 * concat_hidden_size, concat_hidden_size)
                )
                for _ in range(num_layers))
            layers.apply(init_weights)

            self.heads[str(mlp_id)] = layers

    def forward(self, hidden_states, mlp_idx):
        """
        先降维，再 concat， 然后过 heads

        Args:
        x: (batch, seqlen, hidden_size)
        mlp_idx: (batch, )

        Returns:
        (batch, hidden_size)
        """
        hidden_states = self.down_sampler(hidden_states)
        hidden_states = hidden_states.view(hidden_states.shape[0], -1)

        assert all(i == mlp_idx[0] for i in mlp_idx), "mlp_idx must be same"

        o = hidden_states
        for layer in self.heads[str(mlp_idx[0])]:
            o = layer(o)
        return o

class RetHead_TTE_Layer(nn.Module):
    def __init__(
        self,
        layer,
        update_causal_mask_fn=None,
        rotary_emb_fn=None,
    ):
        super().__init__()
        self.layer = layer
        self.update_causal_mask_fn = update_causal_mask_fn
        self.rotary_emb_fn = rotary_emb_fn

    def forward(self, hidden_states):

        attention_mask = torch.ones(hidden_states.shape[:2], device=hidden_states.device, dtype=torch.long)
        cache_position = torch.arange(
            0, hidden_states.shape[1], device=hidden_states.device
        )
        position_ids = cache_position.view(1, 1, -1).expand(3, hidden_states.shape[0], -1)

        if self.update_causal_mask_fn is not None:
            attention_mask = self.update_causal_mask_fn(
                attention_mask=attention_mask,
                input_tensor=hidden_states,
                cache_position=cache_position,
                past_key_values=None,
            )

        if self.rotary_emb_fn is not None:
            position_embeddings = self.rotary_emb_fn(
                hidden_states, position_ids,
            )
        else:
            position_embeddings = None

        return self.layer(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            position_embeddings=position_embeddings,
        )

class RetHead_TTE(nn.Module):
    def __init__(
        self,
        layers: nn.ModuleList,
        pooler: nn.Module,
        num_heads: int,
        norm=None,
        last_n_layers: int=8,
        update_causal_mask_fn=None,
        rotary_emb_fn=None,
    ):
        super().__init__()
        # clone layers 的 last_n_layers 层
        self.heads = nn.ModuleDict()
        for mlp_idx in range(num_heads):

            modules = [
                RetHead_TTE_Layer(
                    layer=deepcopy(layer),
                    update_causal_mask_fn=update_causal_mask_fn,
                    rotary_emb_fn=rotary_emb_fn,
                )
                for layer in layers[-last_n_layers : ]
            ]
            if norm is not None:
                norm = deepcopy(norm)
                modules.append(norm)

            self.heads[str(mlp_idx)] = nn.ModuleList(modules)

        self.pooler = pooler

    def forward(self, hidden_states, mlp_idx):
        """

        Args:
        x: (batch, seqlen, hidden_size)
        mlp_idx: (batch, )

        Returns:
        (batch, hidden_size)
        """

        assert all(i == mlp_idx[0] for i in mlp_idx), "mlp_idx must be same"
        for module in self.heads[str(mlp_idx[0])]:
            # TODO
            if hasattr(module, "forward") and "mlp_idx" in inspect.signature(module.forward).parameters:
                hidden_states = module(hidden_states, mlp_idx=mlp_idx)
            else:
                hidden_states = module(hidden_states)
            if isinstance(hidden_states, tuple):
                hidden_states = hidden_states[0]

        if hasattr(module, "forward") and "mlp_idx" in inspect.signature(self.pooler.forward).parameters:
            o = self.pooler(hidden_states, mlp_idx=mlp_idx)
        else:
            o = self.pooler(hidden_states)

        return o


class MMEBModel(nn.Module):
    TRANSFORMER_CLS = AutoModelForCausalLM

    def __init__(self,
                 encoder: PreTrainedModel,
                 projector: nn.Module = None,
                 pooling: str = 'last',
                 normalize: bool = False,
                 temperature: float = 0.02,
                 multi_level: List[int] = None,
                 ret_mlp_heads: nn.ModuleDict = None,
                 cls_type_to_indices: Dict[str, List[int]] = None,
                 projector_apply_to_tokens: bool = False,
                 target_dim: int = None,
                 multi_head_loss_weights: List[float] = None,
                 eval_head_name: str = None,
                ):
        super().__init__()
        self.config = encoder.config
        self.encoder = encoder
        self.projector = projector
        self.pooling = pooling
        self.normalize = normalize
        self.temperature = temperature
        self.multi_level = multi_level
        self.ret_mlp_heads = ret_mlp_heads
        self.projector_apply_to_tokens = projector_apply_to_tokens
        self.target_dim = target_dim  # For dynamic output dimension control
        self.multi_head_loss_weights = multi_head_loss_weights  # Weights for multi-head projector loss
        self.eval_head_name = eval_head_name  # Head name for evaluation in multi-head mode
        self.cross_entropy = nn.CrossEntropyLoss(reduction='mean')
        self.is_ddp = dist.is_initialized()
        self.process_rank = dist.get_rank() if self.is_ddp else 0
        self.world_size = dist.get_world_size() if self.is_ddp else 1
        if self.is_ddp:
            self.process_rank = dist.get_rank()
            self.world_size = dist.get_world_size()

        self.config.cls_type_to_indices = cls_type_to_indices

    def apply_mlp_heads(self, hidden_states, mlp_idx):

        if self.ret_mlp_heads == None:
            return hidden_states

        # 创建输出张量（初始为原始hidden_states）
        output = hidden_states.clone()

        # 将mlp_idx转换为与hidden_states相同设备的张量
        mlp_idx_tensor = torch.tensor(mlp_idx, device=hidden_states.device)

        # 获取所有需要处理的非-1索引
        valid_mask = mlp_idx_tensor != -1
        valid_indices = valid_mask.nonzero().squeeze(-1)

        # 如果没有需要处理的样本，直接返回
        if len(valid_indices) == 0:
            return output

        # 获取有效样本的mlp_id列表
        valid_mlp_ids = mlp_idx_tensor[valid_indices]

        # 找出所有唯一的mlp_id（去重）
        unique_mlp_ids = torch.unique(valid_mlp_ids)

        for mlp_id in unique_mlp_ids:
            # print(f'using mlp_id {mlp_id}')
            # 转换为ModuleDict的字符串键
            mlp_key = str(mlp_id.item())

            # 获取当前mlp_id对应的所有样本索引
            mask = valid_mlp_ids == mlp_id
            batch_indices = valid_indices[mask]

            # 提取需要处理的hidden states
            # [batch_subset, seq_len, hidden_dim]
            selected = hidden_states[batch_indices]

            # 应用对应的MLP头
            transformed = self.ret_mlp_heads[mlp_key](selected)

            # 将结果写回输出张量
            output[batch_indices] = transformed

        return output

    def encode_input(self, input):
        if getattr(self, "model_backbone", None) == INTERNVIDEO2:
            if "input_ids" in input.keys():
                # text side
                text_output = self.encoder.get_text_encoder()(
                    input["input_ids"],
                    attention_mask=input["attention_mask"],
                    return_dict=True,
                    mode="text",
                )
                text_embeds = text_output.last_hidden_state
                pooled_text_embeds = text_embeds[:, 0]
                pooled_output = self.encoder.text_proj(pooled_text_embeds)
                pooled_output /= pooled_output.norm(dim=-1, keepdim=True)
                return pooled_output
            else:
                _, vfeat = self.encoder.encode_vision(input["pixel_values"], test=True)
                vfeat = self.encoder.vision_proj(vfeat)
                vfeat /= vfeat.norm(dim=-1, keepdim=True)
                return vfeat
        elif getattr(self, "model_backbone", None) in [GME, LamRA, LamRA_QWEN2_5]:
            # pooled_output = self.encoder(**input, return_dict=True, output_hidden_states=True)
            texts = [text.replace(VLM_IMAGE_TOKENS[QWEN2_VL] + '\n', '') for text in input["texts"]] # we are actually passing video queries so this should not happen
            images = []
            for imgs in input['images']:
                # if multi images are given, select the middle frame only
                if isinstance(imgs, list):
                    imgs = imgs[len(imgs) // 2]
                    assert not isinstance(imgs, list) # make sure we have extracted the middle frame and it is no longer a list
                    images.append(imgs)
                else:
                    images.append(imgs)
            pooled_output = self.encoder.get_fused_embeddings(texts=texts, images=images)
            return pooled_output
        elif getattr(self, "model_backbone", None) == COLPALI:
            pooled_output = self.encoder(**input, return_dict=True, output_hidden_states=True)
            return pooled_output
        elif getattr(self, "model_backbone", None) == LLAVA_NEXT:
            input['pixel_values'] = input['pixel_values'].squeeze(dim=1)
            input['image_sizes'] = input['image_sizes'].squeeze(dim=1)
            hidden_states = self.encoder(**input, return_dict=True, output_hidden_states=True)
            hidden_states = hidden_states.hidden_states[-1]
            pooled_output = self._pooling(hidden_states, input['attention_mask'])
            return pooled_output
        else:
            if getattr(self, "model_backbone", None) == QWEN2_5_OMNI:
                if self.multi_level is None:
                    outputs = self.encoder(
                        **input,
                        return_dict=False,
                        output_hidden_states=False,
                        use_cache=False,
                        compute_logits=False,
                    )
                    hidden_states = outputs[1]
                else:
                    outputs = self.encoder(
                        **input,
                        return_dict=True,
                        output_hidden_states=True,
                        use_cache=False,
                        compute_logits=False,
                    )
                    mlvl_hidden_states = []
                    for lvl in self.multi_level:
                        assert 0 < lvl <= len(outputs.hidden_states), f"multi_level {self.multi_level} exceeds the model depth {len(outputs.hidden_states)}"
                        mlvl_hidden_states.append(outputs.hidden_states[lvl - 1])
                    hidden_states = torch.cat(mlvl_hidden_states, dim=-1)
            else:
                outputs = self.encoder(**input, return_dict=True, output_hidden_states=True)
                if self.multi_level is not None:
                    mlvl_hidden_states = []
                    for lvl in self.multi_level:
                        assert 0 < lvl <= len(outputs.hidden_states), f"multi_level {self.multi_level} exceeds the model depth {len(outputs.hidden_states)}"
                        mlvl_hidden_states.append(outputs.hidden_states[lvl-1])
                    hidden_states = torch.cat(mlvl_hidden_states, dim=-1)  # concated multi-level hidden states
                else:
                    hidden_states = outputs.hidden_states[-1]  # last hidden states

            kwargs = {}
            if 'mlp_idx' in input:
                kwargs["mlp_idx"] = input['mlp_idx']
            if 'cls_indices' in input:
                kwargs["cls_indices"] = input['cls_indices']
            # Support dynamic target dimension for evaluation
            if hasattr(self, 'target_dim') and self.target_dim is not None:
                kwargs["target_dim"] = self.target_dim
            # Support head selection for multi-head projector (eval mode only)
            if self.pooling == 'multi_head_mlp' and hasattr(self, 'eval_head_name') and self.eval_head_name is not None:
                kwargs["head_name"] = self.eval_head_name

            pooled_output = self._pooling(hidden_states, input['attention_mask'], **kwargs)

            # For multi-head projector in eval mode with specified head, return only that head's embeddings
            if self.pooling == 'multi_head_mlp' and hasattr(self, 'eval_head_name') and self.eval_head_name is not None:
                reps, chorus_tokens = pooled_output
                pooled_output = (reps[self.eval_head_name], chorus_tokens)

            return pooled_output

    def _pooling(self, last_hidden_state, attention_mask, **kwargs):
        chorus_tokens = None

        cls_indices = kwargs.get('cls_indices')

        def _get_chrous_tokens(last_hidden_state, attention_mask, cls_indices=None):
            batch_size = last_hidden_state.shape[0]
            if cls_indices is not None:
                chorus_tokens = last_hidden_state[torch.arange(batch_size).unsqueeze(1), cls_indices, :]
            else:
                left_padding = (attention_mask[:, -1].sum() == attention_mask.shape[0])
                if left_padding:
                    # Get the vectors at the chorus position
                    chorus_tokens = last_hidden_state[torch.arange(batch_size), -TOTAL_COMPRESS_TOKENS:, :]
                else:
                    # Calculate chorus position in the original tensor
                    eos_indices = attention_mask.sum(dim=1, keepdim=True)
                    token_indices = torch.arange(TOTAL_COMPRESS_TOKENS, device=last_hidden_state.device).unsqueeze(0)  # [1, T]
                    token_indices = token_indices + eos_indices - TOTAL_COMPRESS_TOKENS  # [B, T]
                    batch_indices = torch.arange(batch_size, device=last_hidden_state.device).unsqueeze(1).expand(-1, TOTAL_COMPRESS_TOKENS)  # [B, T]
                    # Get the vectors at the chorus position of each attention mask
                    chorus_tokens = last_hidden_state[batch_indices, token_indices].contiguous()  # [B, T, D]
            return chorus_tokens

        if self.pooling == 'last' or self.pooling == 'eos':
            left_padding = (attention_mask[:, -1].sum() == attention_mask.shape[0])
            batch_size = last_hidden_state.shape[0]
            if left_padding:
                # Get the vectors at the last position
                reps = last_hidden_state[torch.arange(batch_size), -1, :]
            else:
                # Calculate last 1 position in the original tensor
                eos_indices = attention_mask.sum(dim=1) - 1
                # Get the vectors at the last 1 position of each attention mask
                reps = last_hidden_state[
                    torch.arange(batch_size, device=last_hidden_state.device), eos_indices]
        elif self.pooling == 'hidden':
            expanded_mask = attention_mask.unsqueeze(-1).expand_as(last_hidden_state).float()
            masked_embeddings = last_hidden_state * expanded_mask
            reps = masked_embeddings.sum(dim=1) / attention_mask.sum(dim=1, keepdim=True).float()
        elif self.pooling in {'avg', 'linear', 'gated', 'attn', 'mlp', 'multi_head_mlp', 'ret_head', 'ret_head_tte'}:
            assert self.projector is not None or self.pooling == 'avg', f"Projector must be provided for {self.pooling} fusion"
            chorus_tokens = _get_chrous_tokens(last_hidden_state, attention_mask, cls_indices=cls_indices)
            projector_input = chorus_tokens
            if self.normalize and self.pooling in {'linear', 'mlp', 'multi_head_mlp'}:
                projector_input = torch.nn.functional.normalize(projector_input, p=2, dim=-1)
                chorus_tokens = projector_input
            if self.pooling in {'ret_head', 'ret_head_tte'}:
                assert "mlp_idx" in kwargs, "mlp_idx must be provided when pooling is 'ret_head'"
                reps = self.projector(chorus_tokens, mlp_idx=kwargs["mlp_idx"])
            elif self.pooling == 'multi_head_mlp':
                # Multi-head MLP returns dict of embeddings for all heads
                head_name = kwargs.get('head_name')
                reps = self.projector(projector_input, head_name=head_name)
            else:
                # Support dynamic target_dim for flexible evaluation
                target_dim = kwargs.get('target_dim')
                if target_dim is not None and self.pooling in {'mlp', 'linear'}:
                    reps = self.projector(projector_input, target_dim=target_dim)
                else:
                    reps = self.projector(projector_input) if self.projector is not None else chorus_tokens.mean(dim=1)
        elif self.pooling == 'concat':
            batch_size = last_hidden_state.shape[0]
            chorus_tokens = _get_chrous_tokens(last_hidden_state, attention_mask, cls_indices=cls_indices)
            if self.projector is not None and self.projector_apply_to_tokens:
                chorus_tokens = self.projector(chorus_tokens)
            reps = chorus_tokens.view(batch_size, -1)  # [B, T * D]
        elif self.pooling == 'none':
            chorus_tokens = _get_chrous_tokens(last_hidden_state, attention_mask, cls_indices=cls_indices)
            if self.projector is not None and self.projector_apply_to_tokens:
                chorus_tokens = self.projector(chorus_tokens)
            reps = chorus_tokens
        else:
            raise NotImplementedError
        if self.normalize:
            if isinstance(reps, dict):
                reps = {name: torch.nn.functional.normalize(rep, p=2, dim=-1) for name, rep in reps.items()}
            else:
                reps = torch.nn.functional.normalize(reps, p=2, dim=-1)
            if chorus_tokens is not None:
                chorus_tokens = torch.nn.functional.normalize(chorus_tokens, p=2, dim=-1)
        return reps, chorus_tokens

    def extract_slot_indices(self, sep_indices=None, cls_indices=None, device=None):
        if cls_indices is not None:
            return cls_indices.long().to(device=device if device is not None else cls_indices.device)
        if sep_indices is None:
            return None
        batch_size = sep_indices.shape[0]
        slot_counts = (sep_indices[:, 1] - sep_indices[:, 0]).long()
        if slot_counts.numel() == 0:
            return None
        if torch.any(slot_counts <= 0):
            return None
        first_slot_count = int(slot_counts[0].item())
        if not torch.equal(slot_counts, slot_counts.new_full(slot_counts.shape, first_slot_count)):
            raise ValueError(
                f"OpenQA batch contains inconsistent slot counts: {slot_counts.detach().cpu().tolist()}"
            )
        slot_count = first_slot_count
        if slot_count <= 0:
            return None
        offsets = torch.arange(slot_count, device=sep_indices.device).unsqueeze(0).expand(batch_size, -1)
        indices = sep_indices[:, 0].unsqueeze(1) + offsets
        return indices.long().to(device=device if device is not None else indices.device)

    def extract_slot_tokens(self, hidden_states, sep_indices=None, cls_indices=None):
        slot_indices = self.extract_slot_indices(sep_indices=sep_indices, cls_indices=cls_indices, device=hidden_states.device)
        if slot_indices is None:
            return None
        batch_indices = torch.arange(hidden_states.shape[0], device=hidden_states.device).unsqueeze(1).expand_as(slot_indices)
        return hidden_states[batch_indices, slot_indices].contiguous()

    def extract_slot_tokens_by_layer(self, hidden_states, layers, sep_indices=None, cls_indices=None):
        if hidden_states is None:
            return {}
        layer_slots = {}
        for layer_idx in layers:
            if layer_idx < 0 or layer_idx >= len(hidden_states):
                continue
            layer_hidden = hidden_states[layer_idx]
            layer_slots[int(layer_idx)] = self.extract_slot_tokens(
                layer_hidden,
                sep_indices=sep_indices,
                cls_indices=cls_indices,
            )
        return layer_slots

    def pool_slot_tokens(self, slot_tokens, mlp_idx=None, cls_indices=None, head_name=None, target_dim=None):
        if slot_tokens is None:
            return None
        if self.pooling in {"avg", "linear", "gated", "attn", "mlp", "multi_head_mlp", "ret_head", "ret_head_tte"}:
            assert self.projector is not None or self.pooling == "avg", f"Projector must be provided for {self.pooling} fusion"
            projector_input = slot_tokens
            if self.normalize and self.pooling in {"linear", "mlp", "multi_head_mlp"}:
                projector_input = torch.nn.functional.normalize(projector_input, p=2, dim=-1)
                slot_tokens = projector_input
            if self.pooling in {"ret_head", "ret_head_tte"}:
                assert mlp_idx is not None, "mlp_idx must be provided when pooling is 'ret_head'"
                reps = self.projector(slot_tokens, mlp_idx=mlp_idx)
            elif self.pooling == "multi_head_mlp":
                reps = self.projector(projector_input, head_name=head_name if head_name is not None else self.eval_head_name)
            else:
                current_target_dim = target_dim if target_dim is not None else self.target_dim
                if current_target_dim is not None and self.pooling in {"mlp", "linear"}:
                    reps = self.projector(projector_input, target_dim=current_target_dim)
                else:
                    reps = self.projector(projector_input) if self.projector is not None else slot_tokens.mean(dim=1)
        elif self.pooling == "concat":
            batch_size = slot_tokens.shape[0]
            if self.projector is not None and self.projector_apply_to_tokens:
                slot_tokens = self.projector(slot_tokens)
            reps = slot_tokens.view(batch_size, -1)
        elif self.pooling == "none":
            if self.projector is not None and self.projector_apply_to_tokens:
                slot_tokens = self.projector(slot_tokens)
            reps = slot_tokens
        else:
            reps = slot_tokens.mean(dim=1)
        if self.normalize and reps is not None:
            if isinstance(reps, dict):
                reps = {name: torch.nn.functional.normalize(rep, p=2, dim=-1) for name, rep in reps.items()}
            else:
                reps = torch.nn.functional.normalize(reps, p=2, dim=-1)
        return reps

    @classmethod
    def build(cls, model_args: ModelArguments, **kwargs):
        try:
            config = AutoConfig.from_pretrained(model_args.model_name, trust_remote_code=True)
        except:
            # 如果无法识别，需要在后面不同模型类型分别处理
            config = None
        model_backbone = get_backbone_name(hf_config=config, model_type=model_args.model_type)
        projector = None
        print_master(f'Loading backbone [{model_backbone}] from {model_args.model_name}')
        if model_args.compression_mode:
            print_master(f"** Total Compress Tokens: {TOTAL_COMPRESS_TOKENS} **")
        # Loading the base model
        if model_backbone == PHI3V:
            config._attn_implementation = "eager"
            config.padding_side = "right"
            config.use_cache = False
            base_model = Phi3VForCausalLM.from_pretrained(
                model_args.model_name,
                config=config,
                torch_dtype=torch.bfloat16,
                low_cpu_mem_usage=True,
            )
        elif model_backbone == LLAVA_NEXT:
            config.use_cache = False
            config.padding_side = "left"
            config._attn_implementation = "sdpa"
            # config._attn_implementation = "flash_attention_2"
            assert model_args.split_layer <= config.text_config.num_hidden_layers, f"split_layer {model_args.split_layer} should be less than or equal to num_hidden_layers {config.text_config.num_hidden_layers}"
            config.text_config.split_layer = model_args.split_layer
            base_model = LlavaNextForConditionalGeneration.from_pretrained(
                model_args.model_name,
                config=config,
                torch_dtype=torch.bfloat16,
                low_cpu_mem_usage=True,
            )
            base_model.padding_side = "right"  # set padding side to right for training
        elif model_backbone in [QWEN2_VL, QWEN2_5_VL]:
            # config._attn_implementation = "flash_attention_2"
            config._attn_implementation = "sdpa"
            config.padding_side = "left"
            config.use_cache = False
            assert model_args.split_layer <= config.num_hidden_layers, f"split_layer {model_args.split_layer} should be less than or equal to num_hidden_layers {config.num_hidden_layers}"
            config.split_layer = model_args.split_layer
            base_model = backbone2model[model_backbone].from_pretrained(
                model_args.model_name,
                config=config,
                torch_dtype=torch.bfloat16,
                low_cpu_mem_usage=True,
            )
            if not model_args.lora:
                print_master(f'** Training MLP and LLM for {model_backbone} **')
                for p in base_model.visual.parameters():
                    p.requires_grad = False  # freeze vision encoder
                for p in base_model.visual.merger.parameters():
                    p.requires_grad = True  # projector
                for p in base_model.model.parameters():
                    p.requires_grad = True  # llm
                base_model.lm_head.requires_grad = True  # llm head
        elif model_backbone == QWEN2_5_OMNI:
            from src.model.vlm_backbone.qwen2_5_omni import Qwen2_5OmniThinkerConfig, Qwen2_5OmniThinkerForConditionalGeneration
            if config is not None:
                # config._attn_implementation = "flash_attention_2"
                config._attn_implementation = "sdpa"
                # config.padding_side = "left"
                config.use_cache = False
                assert model_args.split_layer <= config.thinker_config.text_config.num_hidden_layers, f"split_layer {model_args.split_layer} should be less than or equal to num_hidden_layers {config.num_hidden_layers}"
                assert model_args.break_layer <= config.thinker_config.text_config.num_hidden_layers, f"break_layer {model_args.break_layer} should be less than or equal to num_hidden_layers {config.num_hidden_layers}"
                config.split_layer = model_args.split_layer
                config.thinker_config.split_layer = model_args.split_layer
                config.thinker_config.text_config.split_layer = model_args.split_layer
                config.break_layer = model_args.break_layer
                config.thinker_config.break_layer = model_args.break_layer
                config.thinker_config.text_config.break_layer = model_args.break_layer
                base_model = backbone2model[model_backbone].from_pretrained(
                    model_args.model_name,
                    config=config,
                    torch_dtype=torch.bfloat16,
                    low_cpu_mem_usage=True,
                )
                base_model = base_model.thinker
            else:
                config = Qwen2_5OmniThinkerConfig.from_pretrained(model_args.model_name, trust_remote_code=True)
                config._attn_implementation = "sdpa"
                # config.padding_side = "left"
                config.use_cache = False
                assert model_args.split_layer <= config.text_config.num_hidden_layers, f"split_layer {model_args.split_layer} should be less than or equal to num_hidden_layers {config.num_hidden_layers}"
                assert model_args.break_layer <= config.text_config.num_hidden_layers, f"break_layer {model_args.break_layer} should be less than or equal to num_hidden_layers {config.num_hidden_layers}"
                config.split_layer = model_args.split_layer
                config.text_config.split_layer = model_args.split_layer
                config.break_layer = model_args.break_layer
                config.text_config.break_layer = model_args.break_layer
                base_model = Qwen2_5OmniThinkerForConditionalGeneration.from_pretrained(
                    model_args.model_name,
                    config=config,
                    torch_dtype=torch.bfloat16,
                    low_cpu_mem_usage=True,
                )
                print_master(f"Loaded model from {model_args.model_name}")

            # config = base_model.thinker_config
            if not model_args.lora:
                print_master(f'** Training MLP and LLM for {model_backbone} **')
                for p in base_model.visual.parameters():
                    p.requires_grad = False  # freeze vision encoder
                for p in base_model.audio_tower.parameters():
                    p.requires_grad = False  # freeze vision encoder
                for p in base_model.visual.merger.parameters():
                    p.requires_grad = True  # projector
                for p in base_model.audio_tower.ln_post.parameters():
                    p.requires_grad = True  # projector
                for p in base_model.audio_tower.proj.parameters():
                    p.requires_grad = True  # projector
                for p in base_model.model.parameters():
                    p.requires_grad = True  # llm
                base_model.lm_head.requires_grad = True  # llm head

        elif model_backbone in [QWEN2_VL_TOKENSELECTION, QWEN2_5_VL_TOKENSELECTION]:
            config._attn_implementation = "flash_attention_2"
            config.padding_side = "left"
            config.use_cache = False

            from .utils import parse_layer_type
            lm_qwen_layer = 28
            vis_qwen_layer = 32
            lm_skip_layer = parse_layer_type(model_args.lm_skip_layer, lm_qwen_layer)
            vis_skip_layer = parse_layer_type(model_args.vis_skip_layer, vis_qwen_layer)

            base_model = backbone2model[model_backbone].from_pretrained(
                model_args.model_name,
                config=config,
                torch_dtype=torch.bfloat16,
                low_cpu_mem_usage=True,
                lm_skip_layer=lm_skip_layer,
                vis_skip_layer=vis_skip_layer,
            )
        elif model_backbone == KEYE_VL_1_5:
            # config._attn_implementation = "flash_attention_2"
            config._attn_implementation = "sdpa"
            config.padding_side = "left"
            config.use_cache = False
            assert model_args.split_layer <= config.num_hidden_layers, f"split_layer {model_args.split_layer} should be less than or equal to num_hidden_layers {config.num_hidden_layers}"
            config.split_layer = model_args.split_layer
            base_model = backbone2model[model_backbone].from_pretrained(
                model_args.model_name,
                config=config,
                torch_dtype=torch.bfloat16,
                low_cpu_mem_usage=True,
            )
        else:
            config.use_cache = False
            base_model = cls.TRANSFORMER_CLS.from_pretrained(
                model_args.model_name, **kwargs, config=config,
                attn_implementation="flash_attention_2",
                torch_dtype=torch.bfloat16,
                trust_remote_code=True)

        hidden_size = base_model.config.text_config.hidden_size

        if model_args.pooling in {'gated', 'attn', 'avg', 'linear', 'mlp', 'multi_head_mlp', 'ret_head', 'ret_head_tte'}:
            num_scales = len(model_args.multi_level) if model_args.multi_level else 1
            projector_output_dim = model_args.projector_output_dim if model_args.projector_output_dim and model_args.projector_output_dim > 0 else hidden_size
            projector_hidden_dim = model_args.projector_hidden_dim if model_args.projector_hidden_dim and model_args.projector_hidden_dim > 0 else (num_scales * hidden_size)
            if model_args.pooling == 'gated':
                projector = GatedPooling(hidden_size, num_scales=num_scales)
            elif model_args.pooling == 'attn':
                projector = AttentionPooling(hidden_size, num_scales=num_scales)
            elif model_args.pooling == 'avg':
                projector = AveragePooling(hidden_size, num_scales=num_scales)
            elif model_args.pooling == 'linear':
                projector = AveragePooling(hidden_size, num_scales=num_scales, mode='linear', output_dim=projector_output_dim)
            elif model_args.pooling == 'mlp':
                projector = AveragePooling(
                    hidden_size,
                    num_scales=num_scales,
                    mode='mlp',
                    output_dim=projector_output_dim,
                    mlp_hidden_dim=projector_hidden_dim,
                )
            elif model_args.pooling == 'multi_head_mlp':
                # Multi-head MLP projector for simultaneous training of multiple output dimensions
                projector = _build_multi_head_projector(hidden_size, model_args, num_scales=num_scales)
                print_master(f'Building Multi-head MLP projector with heads {projector.output_dims}')
            elif model_args.pooling == 'ret_head':
                assert model_args.mlp_head_num > 0, f'mlp_head_num must be greater than 0 when pooling is ret_head: {model_args.mlp_head_num}'
                projector = RetHead(
                    num_heads=model_args.mlp_head_num,
                    num_tokens=TOTAL_COMPRESS_TOKENS // len(model_args.cls_types) if model_args.split_cls_tokens_by_task else TOTAL_COMPRESS_TOKENS,
                    hidden_size=hidden_size,
                    num_layers=2,
                )
                print_master(f'Building {model_args.mlp_head_num} MLP heads for retrieval finetuning: {projector}')
            elif model_args.pooling == 'ret_head_tte':
                assert not model_args.lora, f'lora is not supported when pooling is ret_head_tte'
                assert model_args.mlp_head_num > 0, f'mlp_head_num must be greater than 0 when pooling is ret_head: {model_args.mlp_head_num}'
                projector = RetHead_TTE(
                    num_heads=model_args.mlp_head_num,
                    # TODO: for other archs
                    layers=base_model.model.layers,
                    last_n_layers=8,
                    norm=base_model.model.norm,
                    pooler=AveragePooling(hidden_size, num_scales=num_scales),
                    update_causal_mask_fn=base_model.model._update_causal_mask,
                    rotary_emb_fn=base_model.model.rotary_emb,
                )
                print_master(f'Building {model_args.mlp_head_num} TTE Retrieval Heads: {projector}')
            else:
                raise ValueError(f'Unknown pooling: {model_args.pooling}')

            print_master(f'Building projector for pooling: {projector}')

        # TODO: 目前只支持 cls_indices 连续
        total_cls_indices = np.arange(TOTAL_COMPRESS_TOKENS)
        if model_args.split_cls_tokens_by_task:
            # 将 TOTAL_COMPRESS_TOKENS 根据 training_args.task_types 均分
            cls_type_to_indices = {
                cls_type: indices.tolist()
                for cls_type, indices in zip(model_args.cls_types, np.array_split(total_cls_indices, len(model_args.cls_types)))
            }
        else:
            cls_type_to_indices = {
                cls_type: total_cls_indices.tolist()
                for cls_type in model_args.cls_types
            }
        print_master(f"Building cls_type_to_indices: {cls_type_to_indices}")

        if model_args.lora:
            print_master(f'Loading lora adapter from {base_model}')
            lora_config = LoraConfig(
                r=model_args.lora_r,
                lora_alpha=model_args.lora_alpha,
                target_modules=model_args.lora_target_modules.split(',') if "," in model_args.lora_target_modules else model_args.lora_target_modules,
                lora_dropout=model_args.lora_dropout,
                modules_to_save=["embed_tokens"] if model_args.compression_mode else None,  # finetune embeddings
                init_lora_weights="gaussian",
                use_dora=True,
                inference_mode=False
            )
            lora_model = get_peft_model(base_model, lora_config)
            if model_args.compression_mode and config.tie_word_embeddings:
                tie_model_word_embeddings(lora_model.model, model_backbone)
            lora_model.print_trainable_parameters()
            model = cls(
                encoder=lora_model,
                projector=projector,
                pooling=model_args.pooling,
                normalize=model_args.normalize,
                temperature=model_args.temperature,
                multi_level=model_args.multi_level,
                cls_type_to_indices=cls_type_to_indices,
                projector_apply_to_tokens=model_args.projector_apply_to_tokens,
                target_dim=model_args.projector_output_dim if model_args.projector_output_dim and model_args.projector_output_dim > 0 else None,
                multi_head_loss_weights=model_args.multi_head_weights if model_args.pooling == 'multi_head_mlp' else None,
                eval_head_name=model_args.eval_head_name,
            )
        else:
            model = cls(
                encoder=base_model,
                projector=projector,
                pooling=model_args.pooling,
                normalize=model_args.normalize,
                temperature=model_args.temperature,
                multi_level=model_args.multi_level,
                cls_type_to_indices=cls_type_to_indices,
                projector_apply_to_tokens=model_args.projector_apply_to_tokens,
                target_dim=model_args.projector_output_dim if model_args.projector_output_dim and model_args.projector_output_dim > 0 else None,
                multi_head_loss_weights=model_args.multi_head_weights if model_args.pooling == 'multi_head_mlp' else None,
                eval_head_name=model_args.eval_head_name,
            )

        model.model_backbone = model_backbone

        if model_args.projector_grad_only:
            if model_args.lora:
                raise ValueError(f'lora is not supported when projector_only is True')

            print_master(f'Projector only mode, freezing all parameters of base model')
            for p in model.encoder.parameters():
                p.requires_grad = False

        print_master(f"Building model: {get_parameter_number(model)}")

        return model


    @classmethod
    def load(cls, model_args: ModelArguments, is_trainable=True, **kwargs):
        retrv_only = kwargs.pop('retrv_only', False)

        # Loading the base model
        if model_args.lora:
            model_name_or_path = model_args.model_name
        else:
            model_name_or_path = model_args.checkpoint_path if model_args.checkpoint_path else model_args.model_name
        try:
            config = AutoConfig.from_pretrained(model_name_or_path, trust_remote_code=True)
        except:
            config = None
        projector = None
        if not hasattr(model_args, "model_backbone") or not model_args.model_backbone:
            model_backbone = get_backbone_name(hf_config=config, model_type=model_args.model_type)
            setattr(model_args, 'model_backbone', model_backbone)
        else:
            model_backbone = model_args.model_backbone
        print_master(f'Loading backbone [{model_args.model_backbone}] from {model_name_or_path}')
        if model_args.compression_mode:
            print_master(f"** Total Compress Tokens: {TOTAL_COMPRESS_TOKENS} **")
        if model_args.model_backbone in {LLAVA_NEXT, QWEN2_VL, QWEN2_5_VL, KEYE_VL_1_5, QWEN2_VL_TOKENSELECTION, QWEN2_5_VL_TOKENSELECTION}:
            config = AutoConfig.from_pretrained(model_args.model_name, trust_remote_code=True)
            # TODO: flash for retrv only
            if retrv_only:
                # config._attn_implementation = "flash_attention_2"
                config._attn_implementation = "sdpa"
            else:
                config._attn_implementation = "sdpa"
            config.vision_config.attn_implementation = "flash_attention_2"
            config.audio_config.attn_implementation = "flash_attention_2"
            base_model = backbone2model[model_args.model_backbone].from_pretrained(
                model_args.model_name,
                torch_dtype=torch.bfloat16,
                low_cpu_mem_usage=True,
                config=config
            )
        elif model_args.model_backbone == QWEN2_5_OMNI:
            from src.model.vlm_backbone.qwen2_5_omni import Qwen2_5OmniThinkerConfig, Qwen2_5OmniThinkerForConditionalGeneration
            config = Qwen2_5OmniThinkerConfig.from_pretrained(model_name_or_path, trust_remote_code=True)
            # config._attn_implementation = "flash_attention_2"
            config._attn_implementation = "sdpa"
            config.vision_config.attn_implementation = "flash_attention_2"
            config.audio_config.attn_implementation = "flash_attention_2"
            config.split_layer = model_args.split_layer
            config.text_config.split_layer = model_args.split_layer
            base_model = Qwen2_5OmniThinkerForConditionalGeneration.from_pretrained(
                model_name_or_path,
                torch_dtype=torch.bfloat16,
                low_cpu_mem_usage=True,
                config=config
            )
        elif model_args.model_backbone == PHI3V:
            config = AutoConfig.from_pretrained(model_args.model_name, trust_remote_code=True)
            config.use_cache = False
            config.padding_side = "right"
            base_model = Phi3VForCausalLM.from_pretrained(model_args.model_name, **kwargs, config=config,
                                                          torch_dtype=torch.bfloat16, trust_remote_code=True)
            base_model.padding_side = "right"
        elif model_args.model_backbone == INTERNVIDEO2:
            print_master(f'Loading backbone [{model_args.model_backbone}] from {"src/model/vlm_backbone/internvideo2/"}')
            config = AutoConfig.from_pretrained("src/model/vlm_backbone/internvideo2/",
                                                trust_remote_code=True)
            base_model = backbone2model[model_args.model_backbone].from_pretrained("src/model/vlm_backbone/internvideo2/", config=config,
                                                                                   trust_remote_code=True)
        elif model_args.model_backbone == GME:
            base_model = GmeQwen2VL(model_args.model_name, processor=kwargs['processor'])
            setattr(base_model, 'config', config)
        elif model_args.model_backbone == LamRA:
            base_model = LamRAQwen2VL(model_args.model_name)
            setattr(base_model, 'config', config)
        elif model_args.model_backbone == LamRA_QWEN2_5:
            base_model = LamRAQwen25VL(model_args.model_name)
            setattr(base_model, 'config', config)
        elif model_args.model_backbone == COLPALI:
            base_model = ColPali.from_pretrained(model_args.model_name)
            setattr(base_model, 'config', config)
        else:
            # Loading external base model from HF
            config = AutoConfig.from_pretrained(model_args.model_name, trust_remote_code=True)
            config.use_cache = False
            base_model = cls.TRANSFORMER_CLS.from_pretrained(
                model_name_or_path, **kwargs, config=config,
                torch_dtype=torch.bfloat16,
                trust_remote_code=True)

        hidden_size = base_model.config.text_config.hidden_size

        # TODO: 目前只支持 cls_indices 连续
        if hasattr(config, "cls_type_to_indices"):
            # 将 TOTAL_COMPRESS_TOKENS 根据 training_args.task_types 均分
            cls_type_to_indices = config.cls_type_to_indices
            print_master(f"Loading cls_type_to_indices: {cls_type_to_indices}")
        else:
            total_cls_indices = np.arange(TOTAL_COMPRESS_TOKENS)
            if model_args.split_cls_tokens_by_task:
                # 将 TOTAL_COMPRESS_TOKENS 根据 training_args.task_types 均分
                cls_type_to_indices = {
                    cls_type: indices.tolist()
                    for cls_type, indices in zip(model_args.cls_types, np.array_split(total_cls_indices, len(model_args.cls_types)))
                }
            else:
                cls_type_to_indices = {
                    cls_type: total_cls_indices.tolist()
                    for cls_type in model_args.cls_types
                }
            print_master(f"Initiliazing cls_type_to_indices: {cls_type_to_indices}")

        if model_args.pooling in {'gated', 'attn', 'avg', 'linear', 'mlp', 'multi_head_mlp', 'ret_head', 'ret_head_tte'}:
            num_scales = len(model_args.multi_level) if model_args.multi_level is not None else 1
            projector_output_dim = model_args.projector_output_dim if model_args.projector_output_dim and model_args.projector_output_dim > 0 else hidden_size
            projector_hidden_dim = model_args.projector_hidden_dim if model_args.projector_hidden_dim and model_args.projector_hidden_dim > 0 else (num_scales * hidden_size)
            projector_path = model_args.projector_path if model_args.projector_path else os.path.join(model_args.checkpoint_path if model_args.checkpoint_path is not None else model_args.model_name, 'projector.pth')
            projector_state_dict_path = get_projector_state_dict_path(projector_path)
            projector_state_dict = torch.load(projector_state_dict_path, map_location='cpu') if os.path.exists(projector_state_dict_path) else None
            if model_args.pooling == 'gated':
                projector = GatedPooling(hidden_size, num_scales=num_scales)
            elif model_args.pooling == 'attn':
                projector = AttentionPooling(hidden_size, num_scales=num_scales)
            elif model_args.pooling == 'avg':
                projector = AveragePooling(hidden_size, num_scales=num_scales)
            elif model_args.pooling == 'linear':
                projector = AveragePooling(hidden_size, num_scales=num_scales, mode='linear', output_dim=projector_output_dim)
            elif model_args.pooling == 'mlp':
                projector = AveragePooling(
                    hidden_size,
                    num_scales=num_scales,
                    mode='mlp',
                    output_dim=projector_output_dim,
                    mlp_hidden_dim=projector_hidden_dim,
                )
            elif model_args.pooling == 'multi_head_mlp':
                projector = _build_multi_head_projector(
                    hidden_size,
                    model_args,
                    num_scales=num_scales,
                    state_dict=projector_state_dict,
                )
            elif model_args.pooling == 'ret_head':
                projector = RetHead(
                    num_heads=model_args.mlp_head_num,
                    num_layers=2,
                    num_tokens=TOTAL_COMPRESS_TOKENS // len(cls_type_to_indices),
                    hidden_size=hidden_size,
                )
            elif model_args.pooling == 'ret_head_tte':
                projector = RetHead_TTE(
                    num_heads=model_args.mlp_head_num,
                    # TODO: for other archs
                    layers=base_model.model.layers,
                    norm=base_model.model.norm,
                    pooler=AveragePooling(hidden_size, num_scales=num_scales),
                    update_causal_mask_fn=base_model.model._update_causal_mask,
                    rotary_emb_fn=base_model.model.rotary_emb,
                )
            if projector_state_dict is not None:
                projector.load_state_dict(projector_state_dict)
                print_master(f'[Projector] Loading {model_args.pooling} projector for pooling: {projector}')
            else:
                projector = None
                print_master(f'[Projector] {model_args.pooling} not found, set to None: {projector_state_dict_path}')

        # Building the model on top of the base
        if model_args.lora:
            print_master(f'Loading LoRA from {base_model}')
            lora_config = LoraConfig.from_pretrained(model_args.checkpoint_path)
            lora_model = PeftModel.from_pretrained(base_model, model_args.checkpoint_path, config=lora_config, is_trainable=is_trainable)
            if config.tie_word_embeddings:
                tie_model_word_embeddings(lora_model.model, model_args.model_backbone)
            if not is_trainable:
                lora_model = lora_model.merge_and_unload()
                if config.tie_word_embeddings:
                    tie_model_word_embeddings(lora_model, model_args.model_backbone)
            model = cls(
                encoder=lora_model,
                projector=projector,
                pooling=model_args.pooling,
                normalize=model_args.normalize,
                temperature=model_args.temperature,
                multi_level=model_args.multi_level,
                cls_type_to_indices=cls_type_to_indices,
                projector_apply_to_tokens=model_args.projector_apply_to_tokens,
                target_dim=model_args.projector_output_dim if model_args.projector_output_dim and model_args.projector_output_dim > 0 else None,
                multi_head_loss_weights=model_args.multi_head_weights if model_args.pooling == 'multi_head_mlp' else None,
                eval_head_name=model_args.eval_head_name,
            )
        else:
            model = cls(
                encoder=base_model,
                projector=projector,
                pooling=model_args.pooling,
                normalize=model_args.normalize,
                temperature=model_args.temperature,
                multi_level=model_args.multi_level,
                cls_type_to_indices=cls_type_to_indices,
                projector_apply_to_tokens=model_args.projector_apply_to_tokens,
                target_dim=model_args.projector_output_dim if model_args.projector_output_dim and model_args.projector_output_dim > 0 else None,
                multi_head_loss_weights=model_args.multi_head_weights if model_args.pooling == 'multi_head_mlp' else None,
                eval_head_name=model_args.eval_head_name,
            )

        model.model_backbone = model_backbone
        return model

    def save(self, output_dir: str):
        self.encoder.save_pretrained(output_dir)

    def forward(self, qry: Dict[str, Tensor] = None, tgt: Dict[str, Tensor] = None, neg: Dict[str, Tensor] = None, *args, **kwargs):
        if qry is None and tgt is None and neg is None:
            return self.encoder(*args, **kwargs)  # openqa

        # Handle multi-head projector
        if self.pooling == 'multi_head_mlp':
            return self._forward_multi_head(qry, tgt, neg)

        qry_reps = self.encode_input(qry) if qry else None  # (bsz_per_device, dim)
        tgt_reps = self.encode_input(tgt) if tgt else None # (bsz_per_device, dim)
        neg_reps = self.encode_input(neg) if neg else None # (bsz_per_device * num_neg, dim)

        if qry_reps is None or tgt_reps is None:
            return {"qry_reps": qry_reps, "tgt_reps": tgt_reps, 'neg_reps': neg_reps}

        if self.is_ddp:
            all_qry_reps = self._dist_gather_tensor(qry_reps)
            all_tgt_reps = self._dist_gather_tensor(tgt_reps)
            all_neg_reps = self._dist_gather_tensor(neg_reps) if neg_reps else None
        else:
            all_qry_reps = qry_reps
            all_tgt_reps = tgt_reps
            all_neg_reps = neg_reps

        scores = self.compute_similarity(all_qry_reps, all_tgt_reps)
        scores = scores.view(all_qry_reps.size(0), -1)
        if all_neg_reps is not None:
            neg_scores = self.compute_similarity(all_qry_reps, all_neg_reps, with_neg=True)
            scores = torch.cat([scores, neg_scores], dim=-1)  # Nx(N+1)
        target = torch.arange(scores.size(0), device=scores.device, dtype=torch.long)
        target = target * (all_qry_reps.size(0) // all_tgt_reps.size(0))
        loss = self.cross_entropy(scores / self.temperature, target)
        if self.is_ddp:
            loss = loss * self.world_size


        if self.process_rank == 0:
            acc_dict = compute_accuracy(scores, target, topk=(1, 3, 5))
            return loss, acc_dict
        else:
            return loss

    def _forward_multi_head(self, qry, tgt, neg):
        """Forward pass for multi-head projector, computing loss for all heads."""
        # Encode with multi-head projector (returns dict of embeddings)
        qry_encoded = self.encode_input(qry) if qry else None
        tgt_encoded = self.encode_input(tgt) if tgt else None
        neg_encoded = self.encode_input(neg) if neg else None
        qry_reps_dict = qry_encoded[0] if isinstance(qry_encoded, tuple) else qry_encoded
        tgt_reps_dict = tgt_encoded[0] if isinstance(tgt_encoded, tuple) else tgt_encoded
        neg_reps_dict = neg_encoded[0] if isinstance(neg_encoded, tuple) else neg_encoded

        if qry_reps_dict is None or tgt_reps_dict is None:
            return {"qry_reps": qry_encoded, "tgt_reps": tgt_encoded, 'neg_reps': neg_encoded}
        if not isinstance(qry_reps_dict, dict) or not isinstance(tgt_reps_dict, dict):
            raise ValueError("multi_head_mlp training expects dict outputs. Did you set eval_head_name during training?")

        # Get head names from projector
        head_names = list(self.projector.output_dims.keys())
        loss_weights = self.multi_head_loss_weights or [1.0] * len(head_names)
        is_ddp = dist.is_initialized()
        process_rank = dist.get_rank() if is_ddp else self.process_rank
        world_size = dist.get_world_size() if is_ddp else self.world_size

        total_loss = None
        all_acc_dicts = {}

        for idx, head_name in enumerate(head_names):
            qry_reps = qry_reps_dict[head_name]
            tgt_reps = tgt_reps_dict[head_name]
            neg_reps = neg_reps_dict[head_name] if neg_reps_dict else None

            # Gather across ranks
            if is_ddp:
                all_qry_reps = self._dist_gather_tensor(qry_reps)
                all_tgt_reps = self._dist_gather_tensor(tgt_reps)
                all_neg_reps = self._dist_gather_tensor(neg_reps) if neg_reps is not None else None
            else:
                all_qry_reps = qry_reps
                all_tgt_reps = tgt_reps
                all_neg_reps = neg_reps

            # Compute similarity and loss for this head
            scores = self.compute_similarity(all_qry_reps, all_tgt_reps)
            scores = scores.view(all_qry_reps.size(0), -1)
            if all_neg_reps is not None:
                neg_scores = self.compute_similarity(all_qry_reps, all_neg_reps, with_neg=True)
                scores = torch.cat([scores, neg_scores], dim=-1)

            target = torch.arange(scores.size(0), device=scores.device, dtype=torch.long)
            target = target * (all_qry_reps.size(0) // all_tgt_reps.size(0))
            head_loss = self.cross_entropy(scores / self.temperature, target)

            # Apply loss weight
            weight = loss_weights[idx] if idx < len(loss_weights) else 1.0
            weighted_loss = weight * head_loss
            total_loss = weighted_loss if total_loss is None else total_loss + weighted_loss

            # Compute accuracy for monitoring (only on rank 0)
            if process_rank == 0:
                acc_dict = compute_accuracy(scores, target, topk=(1, 3, 5))
                for k, v in acc_dict.items():
                    all_acc_dicts[f"head_{head_name}_{k}"] = v

        if is_ddp:
            total_loss = total_loss * world_size

        if process_rank == 0:
            all_acc_dicts['total_loss'] = total_loss.item()
            return total_loss, all_acc_dicts
        else:
            return total_loss


    def _dist_gather_tensor(self, t: Tensor):
        t = t.contiguous()
        world_size = dist.get_world_size() if dist.is_initialized() else self.world_size
        process_rank = dist.get_rank() if dist.is_initialized() else self.process_rank
        all_tensors = [torch.empty_like(t) for _ in range(world_size)]
        dist.all_gather(all_tensors, t)
        all_tensors[process_rank] = t
        all_tensors = torch.cat(all_tensors, dim=0)
        return all_tensors

    def compute_similarity(self, q_reps, p_reps, with_neg=False):
        if q_reps.dim() == 3 or p_reps.dim() == 3:
            if q_reps.dim() == 2:
                q_reps = q_reps.unsqueeze(1)
            if p_reps.dim() == 2:
                p_reps = p_reps.unsqueeze(1)
            if with_neg:
                scores = torch.einsum("btd,bsd->bts", q_reps, p_reps)
                return scores.flatten(start_dim=-2).amax(dim=-1, keepdim=True)
            scores = torch.einsum("btd,nsd->bnts", q_reps, p_reps)
            return scores.flatten(start_dim=-2).amax(dim=-1)
        if with_neg:
            return (q_reps * p_reps).sum(-1, keepdim=True)
        return torch.matmul(q_reps, p_reps.transpose(0, 1))

    def gradient_checkpointing_enable(self, *args, **kwargs):
        self.encoder.gradient_checkpointing_enable(*args, **kwargs)

    def gradient_checkpointing_disable(self):
        self.encoder.gradient_checkpointing_disable()


def tie_model_word_embeddings(model_to_tie, model_backbone):
    if model_backbone in {QWEN2_VL, QWEN2_5_VL, QWEN2_5_OMNI}:
        print_master(f'Tying weights for {model_backbone} model')
        model_to_tie.lm_head._parameters['weight'] = model_to_tie.model.embed_tokens.weight  # HACK: tie weights manually
        assert model_to_tie.lm_head.weight.data_ptr() == model_to_tie.model.embed_tokens.weight.data_ptr(), "Failed to tie weights"
    elif model_backbone == LLAVA_NEXT:
        print_master(f'Tying weights for {model_backbone} model')
        model_to_tie.language_model.lm_head._parameters['weight'] = model_to_tie.language_model.model.embed_tokens.weight
        assert model_to_tie.language_model.lm_head.weight.data_ptr() == model_to_tie.language_model.model.embed_tokens.weight.data_ptr(), "Failed to tie weights"
    else:
        raise NotImplementedError(f"Tying weights not implemented for {model_backbone} model")
