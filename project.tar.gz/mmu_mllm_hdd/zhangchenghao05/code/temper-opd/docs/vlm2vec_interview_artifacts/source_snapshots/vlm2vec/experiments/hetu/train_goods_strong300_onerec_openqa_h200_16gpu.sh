#!/bin/bash
set -euo pipefail

REPO_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_DIR"

export http_proxy=[REDACTED_PROXY]
export https_proxy=[REDACTED_PROXY]
export no_proxy=[REDACTED_NO_PROXY]

NNODES="${1:-${NNODES:-1}}"
NODE_RANK="${2:-${NODE_RANK:-0}}"
export NNODES NODE_RANK

export NCCL_IB_QPS_PER_CONNECTION=4
export NCCL_IB_DISABLE=0
export NCCL_IB_GID_INDEX=3
export NCCL_IB_HCA=mlx5
export NCCL_DEBUG=WARN
export NCCL_NET_OVERHEAD=1000
export NCCL_PROTO=^LL128
export TORCH_NCCL_BLOCKING_WAIT=1
export TORCH_NCCL_ASYNC_ERROR_HANDLING=1
export TORCH_NCCL_TIMEOUT=6000
export NCCL_COMM_TIMEOUT=6000
export LD_LIBRARY_PATH=/usr/local/nvidia/lib:/usr/local/nvidia/lib64
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

GPUS_PER_NODE="${GPUS_PER_NODE:-8}"
if [ "$NNODES" -eq 1 ]; then
    MASTER_ADDR=localhost
else
    MASTER_ADDR="${MASTER_ADDR:-10.82.121.98}"
fi
MASTER_PORT="${MASTER_PORT:-2207}"

MODEL_NAME="${MODEL_NAME:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/LLaMA-Factory/saves/qwen2_5omni-3b/sft_datav2/merge/}"
MODEL_TYPE="${MODEL_TYPE:-qwen2_5_omni}"
TORCHRUN="${TORCHRUN:-/mmu_mllm_hdd/zhangchenghao05/envs/vlm2vec/bin/torchrun}"
TRAIN_YAML="${TRAIN_YAML:-$REPO_DIR/experiments/hetu/train_goods_strong300_onerec_openqa.yaml}"
EVAL_SCRIPT="${EVAL_SCRIPT:-$REPO_DIR/experiments/hetu/eval_goods_inference_items_emb.sh}"

TOTAL_RETRV_BATCH_SIZE="${TOTAL_RETRV_BATCH_SIZE:-1024}"
TOTAL_QA_BATCH_SIZE="${TOTAL_QA_BATCH_SIZE:-128}"
QA_ACC_STEP="${QA_ACC_STEP:-2}"
NUM_WORKERS="${NUM_WORKERS:-1}"
INTERLEAVE_BATCH_SIZE="${INTERLEAVE_BATCH_SIZE:-8}"
QA_INTERLEAVE_BATCH_SIZE="${QA_INTERLEAVE_BATCH_SIZE:-1}"
LR="${LR:-5e-5}"
MAX_STEPS="${MAX_STEPS:-1000}"
SAVE_STEPS="${SAVE_STEPS:-500}"
WARMUP_STEPS="${WARMUP_STEPS:-100}"
ORTHO_W="${ORTHO_W:-0.5}"
ORTHO_M="${ORTHO_M:-0}"
ORTHO_WARMUP_STEPS="${ORTHO_WARMUP_STEPS:-100}"
OPENQA_LOSS_WEIGHT="${OPENQA_LOSS_WEIGHT:-0.5}"
MAXSIM_TOPK="${MAXSIM_TOPK:-4}"
MODE="${MODE:-train}"
RESUME_FROM="${RESUME_FROM:-none}"
CKPT_SUBDIR="${CKPT_SUBDIR:-checkpoint-$MAX_STEPS}"
EVAL_CKPT_SUBDIRS="${EVAL_CKPT_SUBDIRS:-checkpoint-$MAX_STEPS}"
POOLING="${POOLING:-avg}"
SIMILARITY_TYPE="${SIMILARITY_TYPE:-dense}"

WORLD_SIZE=$((GPUS_PER_NODE * NNODES))
PER_DEVICE_RETRV_BATCH_SIZE=$((TOTAL_RETRV_BATCH_SIZE / WORLD_SIZE))
PER_DEVICE_QA_BATCH_SIZE=$((TOTAL_QA_BATCH_SIZE / (WORLD_SIZE * QA_ACC_STEP)))
GRAD_ACC_STEPS=$((QA_ACC_STEP + 1))

export TOTAL_COMPRESS_TOKENS="${TOTAL_COMPRESS_TOKENS:-8}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface/datasets}"
export WANDB_DISABLED="${WANDB_DISABLED:-false}"
export WANDB_PROJECT="${WANDB_PROJECT:-VLM2Vec}"
export WANDB_API_KEY=[REDACTED_WANDB_API_KEY]
if [ "$WANDB_DISABLED" = "true" ]; then
    REPORT_TO="${REPORT_TO:-none}"
else
    REPORT_TO="${REPORT_TO:-wandb}"
fi
OUTPUT_ROOT="${OUTPUT_ROOT:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_strong300_onerec_openqa_h200}"
CUDA_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"
RUN_NAME="${RUN_NAME:-goods_strong300_onerec_openqa_${SIMILARITY_TYPE}_${POOLING}_step${MAX_STEPS}}"

if [ ! -x "$TORCHRUN" ]; then
    echo "[ERR] torchrun not found or not executable: $TORCHRUN" >&2
    exit 1
fi
if [ ! -e "$MODEL_NAME" ]; then
    echo "[ERR] model path not found: $MODEL_NAME" >&2
    exit 1
fi
if [ ! -f "$TRAIN_YAML" ]; then
    echo "[ERR] train yaml not found: $TRAIN_YAML" >&2
    exit 1
fi
if [ ! -f "$EVAL_SCRIPT" ]; then
    echo "[ERR] eval script not found: $EVAL_SCRIPT" >&2
    exit 1
fi
if [[ "$MODE" != "train" && "$MODE" != "eval" && "$MODE" != "train_eval" ]]; then
    echo "[ERR] invalid MODE=$MODE, expected one of: train, eval, train_eval" >&2
    exit 1
fi
if [ "$WORLD_SIZE" -le 0 ]; then
    echo "[ERR] invalid world size: GPUS_PER_NODE=$GPUS_PER_NODE NNODES=$NNODES" >&2
    exit 1
fi
if [ $((TOTAL_RETRV_BATCH_SIZE % WORLD_SIZE)) -ne 0 ]; then
    echo "[ERR] TOTAL_RETRV_BATCH_SIZE=$TOTAL_RETRV_BATCH_SIZE must be divisible by world size=$WORLD_SIZE" >&2
    exit 1
fi
if [ $((TOTAL_QA_BATCH_SIZE % (WORLD_SIZE * QA_ACC_STEP))) -ne 0 ]; then
    echo "[ERR] TOTAL_QA_BATCH_SIZE=$TOTAL_QA_BATCH_SIZE must be divisible by world size * QA_ACC_STEP = $((WORLD_SIZE * QA_ACC_STEP))" >&2
    exit 1
fi
if [ "$PER_DEVICE_RETRV_BATCH_SIZE" -le 0 ] || [ "$PER_DEVICE_QA_BATCH_SIZE" -le 0 ]; then
    echo "[ERR] invalid per-device batch size: retrv=$PER_DEVICE_RETRV_BATCH_SIZE qa=$PER_DEVICE_QA_BATCH_SIZE" >&2
    exit 1
fi

mkdir -p "$OUTPUT_ROOT"
EXP_DIR="$OUTPUT_ROOT/$RUN_NAME"
mkdir -p "$EXP_DIR"

CMD=(
    env CUDA_VISIBLE_DEVICES="$CUDA_DEVICES"
    "$TORCHRUN"
    --nproc-per-node "$GPUS_PER_NODE"
    --nnodes "$NNODES"
    --max-restarts 0
    --rdzv-backend c10d
    --rdzv-id "goods-openqa-${RUN_NAME}"
    --rdzv-endpoint "$MASTER_ADDR:$MASTER_PORT"
    --node-rank "$NODE_RANK"
    train.py
    --seed 42
    --compression_mode
    --max_grad_norm 0.5
    --task_types retrieval_goods openqa
    --split_cls_tokens_by_task False
    --cls_types video goods
    --dataset_config "$TRAIN_YAML"
    --pooling "$POOLING"
    --similarity_type "$SIMILARITY_TYPE"
    --maxsim_topk "$MAXSIM_TOPK"
    --normalize True
    --temperature 0.02
    --native_prob 0.0
    --bf16
    --deepspeed experiments/zero1.json
    --split_layer 36
    --gradient_accumulation_steps "$GRAD_ACC_STEPS"
    --data_weights 1 "$QA_ACC_STEP"
    --loss_weights 1 "$OPENQA_LOSS_WEIGHT"
    --orthogonal_loss "$ORTHO_W"
    --orthogonal_loss_openqa "$ORTHO_W"
    --orthogonal_margin "$ORTHO_M"
    --orthogonal_warmup_steps "$ORTHO_WARMUP_STEPS"
    --model_name "$MODEL_NAME"
    --model_type "$MODEL_TYPE"
    --grad_cache
    --gc_q_chunk_size 4
    --gc_p_chunk_size 4
    --dataloader_num_workers "$NUM_WORKERS"
    --dataloader_pin_memory False
    --dataloader_persistent_workers False
    --run_name "$RUN_NAME"
    --project_name "$WANDB_PROJECT"
    --output_dir "$EXP_DIR"
    --max_len 8192
    --resize_min_pixels $((32*32))
    --resize_max_pixels $((512*512))
    --per_device_train_batch_size 1
    --per_device_retrv_train_batch_size "$PER_DEVICE_RETRV_BATCH_SIZE"
    --per_device_openqa_train_batch_size "$PER_DEVICE_QA_BATCH_SIZE"
    --interleave_batch_size "$INTERLEAVE_BATCH_SIZE"
    --qa_interleave_batch_size "$QA_INTERLEAVE_BATCH_SIZE"
    --lr_scheduler_type cosine
    --learning_rate "$LR"
    --projector_lr "$LR"
    --weight_decay 0
    --warmup_steps "$WARMUP_STEPS"
    --max_steps "$MAX_STEPS"
    --save_steps "$SAVE_STEPS"
    --logging_steps 1
    --save_safetensors True
    --remove_unused_columns False
    --resume_from "$RESUME_FROM"
    --report_to "$REPORT_TO"
)

if [ "$MODE" != "eval" ]; then
    printf "CMD: "
    printf "%q " "${CMD[@]}"
    printf "\n"
    "${CMD[@]}"
fi

if [ "$MODE" != "train" ]; then
    EVAL_CMD=(
        env
        RUN_NAME="$RUN_NAME"
        POOLING="$POOLING"
        SIMILARITY_TYPE="$SIMILARITY_TYPE"
        CKPT_SUBDIR="$CKPT_SUBDIR"
        CKPT_SUBDIRS="$EVAL_CKPT_SUBDIRS"
        OUTPUT_ROOT="$OUTPUT_ROOT"
        MODEL_NAME="$MODEL_NAME"
        MODEL_TYPE="$MODEL_TYPE"
        TORCHRUN="$TORCHRUN"
        GPUS_PER_NODE="$GPUS_PER_NODE"
        CUDA_VISIBLE_DEVICES="$CUDA_DEVICES"
        TOTAL_COMPRESS_TOKENS="$TOTAL_COMPRESS_TOKENS"
        HF_ENDPOINT="$HF_ENDPOINT"
        HF_HOME="$HF_HOME"
        HF_DATASETS_CACHE="$HF_DATASETS_CACHE"
        MAXSIM_TOPK="$MAXSIM_TOPK"
        NUM_WORKERS="$NUM_WORKERS"
        ENCODE_DIR_NAME="${ENCODE_DIR_NAME:-goods_embs}"
        bash
        "$EVAL_SCRIPT"
        "$NNODES"
        "$NODE_RANK"
    )

    printf "EVAL CMD: "
    printf "%q " "${EVAL_CMD[@]}"
    printf "\n"
    "${EVAL_CMD[@]}"
fi
