import json
import os
from dataclasses import dataclass, field
from typing import Optional

import torch
import torch.distributed as dist
import yaml


@dataclass
class CacheArguments:
    cache_dir: str = field(metadata={"help": "Directory to write rankNNN_shardXXXXXX.pt files."})
    cache_max_steps: int = field(default=4000, metadata={"help": "Number of retrieval batches to encode per rank."})
    cache_shard_size: int = field(default=4096, metadata={"help": "Rows per cache shard."})
    cache_dtype: str = field(default="bfloat16", metadata={"help": "float32, float16, or bfloat16."})
    cache_start_shard: int = field(default=0, metadata={"help": "Shard index offset for resume/manual appends."})


def init_distributed():
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    if world_size <= 1:
        return False, 0, 0, 1
    if not dist.is_initialized():
        dist.init_process_group(backend="nccl")
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    torch.cuda.set_device(local_rank)
    return True, local_rank, dist.get_rank(), dist.get_world_size()


def cache_dtype(name: str):
    if name == "float32":
        return torch.float32
    if name == "float16":
        return torch.float16
    if name == "bfloat16":
        return torch.bfloat16
    raise ValueError(f"Unsupported cache_dtype={name}")


def extract_reps(value):
    if isinstance(value, tuple):
        return value[0]
    return value


def append_meta(meta_acc, qry, tgt):
    meta_acc.setdefault("qry_id", []).extend([str(x) for x in qry.get("id", [])])
    meta_acc.setdefault("tgt_id", []).extend([str(x) for x in tgt.get("id", [])])
    meta_acc.setdefault("qry_text", []).extend(qry.get("text", []))
    meta_acc.setdefault("tgt_text", []).extend(tgt.get("text", []))
    meta_acc.setdefault("global_dataset_name", []).extend(qry.get("global_dataset_name", []))
    meta_acc.setdefault("task_type", []).extend(qry.get("task_type", []))
    meta_acc.setdefault("cls_type", []).extend(qry.get("cls_type", []))


def save_shard(cache_dir: str, rank: int, shard_idx: int, qry_rows, tgt_rows, metadata, dtype: torch.dtype):
    if not qry_rows:
        return None
    qry = torch.cat(qry_rows, dim=0).to(dtype=dtype).cpu().contiguous()
    tgt = torch.cat(tgt_rows, dim=0).to(dtype=dtype).cpu().contiguous()
    if qry.shape != tgt.shape:
        raise ValueError(f"qry/tgt cache shape mismatch: {tuple(qry.shape)} vs {tuple(tgt.shape)}")
    path = os.path.join(cache_dir, f"rank{rank:03d}_shard{shard_idx:06d}.pt")
    torch.save(
        {
            "format_version": 1,
            "qry": qry,
            "tgt": tgt,
            "metadata": metadata,
        },
        path,
    )
    return path


def main():
    from transformers import HfArgumentParser
    from transformers.trainer_utils import set_seed

    from src.arguments import DataArguments, ModelArguments, TrainingArguments
    from src.data.collator.train_collator import MultimodalDataCollator
    from src.data.loader.mixed_dataset import init_mixed_dataset
    from src.model.model import MMEBModel
    from src.model.processor import get_backbone_name, load_processor
    from src.utils import batch_to_device, print_rank

    parser = HfArgumentParser((ModelArguments, DataArguments, TrainingArguments, CacheArguments))
    model_args, data_args, training_args, cache_args = parser.parse_args_into_dataclasses()
    is_dist, local_rank, rank, world_size = init_distributed()
    device = torch.device(f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu")

    set_seed(training_args.seed)
    os.makedirs(cache_args.cache_dir, exist_ok=True)

    model = MMEBModel.build(model_args).to(device)
    model.eval()
    model_backbone = get_backbone_name(hf_config=model.config, model_type=model_args.model_type)
    setattr(model_args, "model_backbone", model_backbone)
    setattr(training_args, "model_backbone", model_backbone)
    processor = load_processor(model_args, data_args)
    setattr(model, "processor", processor)

    collator = MultimodalDataCollator(
        processor=processor,
        model_args=model_args,
        data_args=data_args,
        training_args=training_args,
        model_func_get_rope_index=model.encoder.get_rope_index,
        cls_type_to_indices=model.config.cls_type_to_indices,
    )
    with open(data_args.dataset_config, "r", encoding="utf-8") as f:
        dataset_config = yaml.safe_load(f)
    dataloader = init_mixed_dataset(dataset_config, model_args, data_args, training_args, collator)

    dtype = cache_dtype(cache_args.cache_dtype)
    qry_rows = []
    tgt_rows = []
    metadata = {}
    shard_idx = int(cache_args.cache_start_shard)
    total_rows = 0
    steps = 0

    print_rank(
        f"cached projector build_cache start cache_dir={cache_args.cache_dir} "
        f"rank={rank}/{world_size} max_steps={cache_args.cache_max_steps}"
    )
    with torch.no_grad():
        for batch in dataloader:
            if isinstance(batch, dict) or len(batch) < 2:
                continue
            qry, tgt = batch[0], batch[1]
            qry_dev = batch_to_device(qry, device)
            tgt_dev = batch_to_device(tgt, device)
            qry_rep = extract_reps(model.encode_input(qry_dev)).detach().cpu()
            tgt_rep = extract_reps(model.encode_input(tgt_dev)).detach().cpu()
            qry_rows.append(qry_rep)
            tgt_rows.append(tgt_rep)
            append_meta(metadata, qry, tgt)
            total_rows += int(qry_rep.shape[0])
            steps += 1

            while total_rows >= cache_args.cache_shard_size:
                merged_q = torch.cat(qry_rows, dim=0)
                merged_t = torch.cat(tgt_rows, dim=0)
                shard_q = [merged_q[: cache_args.cache_shard_size]]
                shard_t = [merged_t[: cache_args.cache_shard_size]]
                shard_meta = {k: v[: cache_args.cache_shard_size] for k, v in metadata.items()}
                path = save_shard(cache_args.cache_dir, rank, shard_idx, shard_q, shard_t, shard_meta, dtype)
                print_rank(json.dumps({"event": "cache_shard_saved", "path": path, "rows": cache_args.cache_shard_size}))
                shard_idx += 1
                remain_q = merged_q[cache_args.cache_shard_size :]
                remain_t = merged_t[cache_args.cache_shard_size :]
                qry_rows = [remain_q] if remain_q.numel() else []
                tgt_rows = [remain_t] if remain_t.numel() else []
                metadata = {k: v[cache_args.cache_shard_size :] for k, v in metadata.items()}
                total_rows = int(remain_q.shape[0]) if remain_q.numel() else 0

            if steps >= cache_args.cache_max_steps:
                break

    if qry_rows:
        path = save_shard(cache_args.cache_dir, rank, shard_idx, qry_rows, tgt_rows, metadata, dtype)
        print_rank(json.dumps({"event": "cache_shard_saved", "path": path, "rows": total_rows}))

    if dist.is_available() and dist.is_initialized():
        dist.barrier()
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
