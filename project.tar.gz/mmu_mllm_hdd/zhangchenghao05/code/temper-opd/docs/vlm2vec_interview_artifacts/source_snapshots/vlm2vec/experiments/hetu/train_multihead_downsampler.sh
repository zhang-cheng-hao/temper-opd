#!/bin/bash
set -euo pipefail

# 多输出头降维模块训练脚本
# 同时训练64/32/16三个维度的降维模块，共享VLM产出的emb
# 冻结VLM部分，只训练projector

REPO_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_DIR"

export http_proxy=[REDACTED_PROXY]
export https_proxy=[REDACTED_PROXY]
export no_proxy=[REDACTED_NO_PROXY]

NNODES="${1:-${NNODES:-1}}"
NODE_RANK="${2:-${NODE_RANK:-0}}"
shift $(( $# >= 2 ? 2 : $# ))
export NNODES NODE_RANK

for arg in "$@"; do
    case "$arg" in
        *=*)
            export "$arg"
            ;;
        *)
            echo "[WARN] ignore non key=value arg: $arg"
            ;;
    esac
done

export NCCL_IB_QPS_PER_CONNECTION=4
export NCCL_IB_DISABLE=0
export NCCL_IB_GID_INDEX=3
export NCCL_IB_HCA=mlx5
export NCCL_DEBUG=WARN
export NCCL_NET_OVERHEAD=1000
export NCCL_PROTO=^LL128
export TORCH_NCCL_BLOCKING_WAIT=1
export TORCH_NCCL_ASYNC_ERROR_HANDLING=1
export TORCH_NCCL_TIMEOUT=6000
export NCCL_COMM_TIMEOUT=6000
export LD_LIBRARY_PATH=/usr/local/nvidia/lib:/usr/local/nvidia/lib64
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

GPUS_PER_NODE="${GPUS_PER_NODE:-8}"
WORLD_SIZE=$((GPUS_PER_NODE * NNODES))
if [ "$NNODES" -eq 1 ]; then
    MASTER_ADDR=localhost
else
    MASTER_ADDR="${MASTER_ADDR:-10.82.121.98}"
fi
MASTER_PORT="${MASTER_PORT:-2207}"

# 默认对齐 goods_0402_maxtop4_ortho_t4_stage2_v2 的训练设置；也可通过 DOWNsampler_STAGE=stage1
# 或显式覆盖 MODEL_NAME/STAGE_YAML/RUN_NAME/MAX_STEPS 跑 stage1 downsampler。
DEFAULT_STAGE2_V2_ROOT="${DEFAULT_STAGE2_V2_ROOT:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0402_twostage/goods_0402_maxtop4_ortho_t4_stage2_v2}"
DEFAULT_STAGE1_ROOT="${DEFAULT_STAGE1_ROOT:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0402_twostage/goods_0402_maxtop4_ortho_t4}"
DOWNSAMPLER_STAGE="${DOWNSAMPLER_STAGE:-stage2}"
case "$DOWNSAMPLER_STAGE" in
    stage1)
        DEFAULT_MODEL_NAME="$DEFAULT_STAGE1_ROOT/stage1"
        DEFAULT_STAGE_YAML="$REPO_DIR/experiments/hetu/train_goods_0402_stage1.yaml"
        DEFAULT_RUN_NAME="goods_0402_maxtop4_ortho_t4_stage1_downsampler_64_32_16"
        DEFAULT_MAX_STEPS=10000
        ;;
    stage2)
        DEFAULT_MODEL_NAME="$DEFAULT_STAGE2_V2_ROOT/stage2"
        DEFAULT_STAGE_YAML="$REPO_DIR/experiments/hetu/train_goods_0402_stage2.yaml"
        DEFAULT_RUN_NAME="goods_0402_maxtop4_ortho_t4_stage2_v2_downsampler_64_32_16"
        DEFAULT_MAX_STEPS=4000
        ;;
    *)
        echo "[ERR] unsupported DOWNSAMPLER_STAGE=$DOWNSAMPLER_STAGE, expected stage1 or stage2" >&2
        exit 1
        ;;
esac
MODEL_NAME="${MODEL_NAME:-$DEFAULT_MODEL_NAME}"
MODEL_TYPE="${MODEL_TYPE:-qwen2_5_omni}"
TORCHRUN="${TORCHRUN:-/mmu_mllm_hdd/zhangchenghao05/envs/vlm2vec/bin/torchrun}"

# 训练配置
TOTAL_RETRV_BATCH_SIZE="${TOTAL_RETRV_BATCH_SIZE:-1024}"
CONTRASTIVE_SCOPE="${CONTRASTIVE_SCOPE:-global}"
NUM_WORKERS="${NUM_WORKERS:-2}"
LR="${LR:-1e-3}"  # projector用更大的学习率
WARMUP_STEPS="${WARMUP_STEPS:-100}"
MAX_STEPS="${MAX_STEPS:-$DEFAULT_MAX_STEPS}"
SAVE_STEPS="${SAVE_STEPS:-500}"
MAX_LEN="${MAX_LEN:-4096}"
MIN_PIXELS="${MIN_PIXELS:-3136}"
MAX_IMAGE_TOKENS="${MAX_IMAGE_TOKENS:-200}"
MAX_PIXELS="${MAX_PIXELS:-$((28 * 28 * MAX_IMAGE_TOKENS))}"
RESUME_FROM="${RESUME_FROM:-auto}"
MODE="${MODE:-train}"

# 多输出头配置
MULTI_HEAD_DIMS="${MULTI_HEAD_DIMS:-64 32 16}"
MULTI_HEAD_WEIGHTS="${MULTI_HEAD_WEIGHTS:-1.0 1.0 1.0}"
SAVE_MULTI_HEAD_STANDALONE_HEADS="${SAVE_MULTI_HEAD_STANDALONE_HEADS:-True}"
SIMILARITY_TYPE="${SIMILARITY_TYPE:-maxsim_topk}"
MAXSIM_TOPK="${MAXSIM_TOPK:-4}"
ORTHOGONAL_LOSS="${ORTHOGONAL_LOSS:-${ORTHO_W:-0.5}}"
ORTHOGONAL_BASE_DIM="${ORTHOGONAL_BASE_DIM:-2048}"
ORTHOGONAL_BASE_WEIGHT="${ORTHOGONAL_BASE_WEIGHT:-$ORTHOGONAL_LOSS}"
MULTI_HEAD_ORTHOGONAL_SCALE="${MULTI_HEAD_ORTHOGONAL_SCALE:-linear_dim}"
if [ -z "${MULTI_HEAD_ORTHOGONAL_WEIGHTS:-}" ]; then
    case "$MULTI_HEAD_ORTHOGONAL_SCALE" in
        linear_dim)
            # Keep the expected random orthogonal penalty comparable to a 2048-dim head.
            MULTI_HEAD_ORTHOGONAL_WEIGHTS="$(for dim in $MULTI_HEAD_DIMS; do awk -v dim="$dim" -v base_dim="$ORTHOGONAL_BASE_DIM" -v base_weight="$ORTHOGONAL_BASE_WEIGHT" 'BEGIN { printf "%.10g ", base_weight * dim / base_dim }'; done)"
            ;;
        fixed)
            MULTI_HEAD_ORTHOGONAL_WEIGHTS="$(for _ in $MULTI_HEAD_DIMS; do awk -v base_weight="$ORTHOGONAL_BASE_WEIGHT" 'BEGIN { printf "%.10g ", base_weight }'; done)"
            ;;
        none|off|zero)
            MULTI_HEAD_ORTHOGONAL_WEIGHTS="$(for _ in $MULTI_HEAD_DIMS; do printf "0 "; done)"
            ;;
        *)
            echo "[ERR] unsupported MULTI_HEAD_ORTHOGONAL_SCALE=$MULTI_HEAD_ORTHOGONAL_SCALE, expected linear_dim, fixed, or none" >&2
            exit 1
            ;;
    esac
fi
ORTHOGONAL_MARGIN="${ORTHOGONAL_MARGIN:-${ORTHO_M:-0.0}}"
ORTHOGONAL_WARMUP_STEPS="${ORTHOGONAL_WARMUP_STEPS:-${ORTHO_WARMUP_STEPS:-100}}"
ORTHOGONAL_DIAG_STEPS="${ORTHOGONAL_DIAG_STEPS:-50}"
LOAD_DIAG_STEPS="${LOAD_DIAG_STEPS:-50}"
GC_Q_CHUNK_SIZE="${GC_Q_CHUNK_SIZE:-4}"
GC_P_CHUNK_SIZE="${GC_P_CHUNK_SIZE:-2}"

export TOTAL_COMPRESS_TOKENS="${TOTAL_COMPRESS_TOKENS:-4}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface/datasets}"
export WANDB_DISABLED="${WANDB_DISABLED:-false}"
export WANDB_PROJECT="${WANDB_PROJECT:-VLM2Vec}"
export WANDB_API_KEY="${WANDB_API_KEY:-[REDACTED_WANDB_API_KEY]}"

if [ "$WANDB_DISABLED" = "true" ]; then
    REPORT_TO="${REPORT_TO:-none}"
else
    REPORT_TO="${REPORT_TO:-wandb}"
fi

if [ ! -x "$TORCHRUN" ]; then
    echo "[ERR] torchrun not found or not executable: $TORCHRUN" >&2
    exit 1
fi
if [ ! -e "$MODEL_NAME" ]; then
    echo "[ERR] base model path not found: $MODEL_NAME" >&2
    exit 1
fi
if [ "$WORLD_SIZE" -le 0 ]; then
    echo "[ERR] invalid world size: GPUS_PER_NODE=$GPUS_PER_NODE NNODES=$NNODES" >&2
    exit 1
fi
case "$CONTRASTIVE_SCOPE" in
    global)
        LOCAL_CONTRASTIVE_LOSS=False
        if [ $((TOTAL_RETRV_BATCH_SIZE % WORLD_SIZE)) -ne 0 ]; then
            echo "[ERR] TOTAL_RETRV_BATCH_SIZE=$TOTAL_RETRV_BATCH_SIZE must be divisible by world size=$WORLD_SIZE" >&2
            exit 1
        fi
        PER_DEVICE_RETRV_BATCH_SIZE=$((TOTAL_RETRV_BATCH_SIZE / WORLD_SIZE))
        EFFECTIVE_RETRV_BATCH_SIZE="$TOTAL_RETRV_BATCH_SIZE"
        ;;
    local)
        LOCAL_CONTRASTIVE_LOSS=True
        PER_DEVICE_RETRV_BATCH_SIZE="$TOTAL_RETRV_BATCH_SIZE"
        EFFECTIVE_RETRV_BATCH_SIZE=$((TOTAL_RETRV_BATCH_SIZE * WORLD_SIZE))
        ;;
    *)
        echo "[ERR] unsupported CONTRASTIVE_SCOPE=$CONTRASTIVE_SCOPE, expected global or local" >&2
        exit 1
        ;;
esac

OUTPUT_ROOT="${OUTPUT_ROOT:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/multihead_downsampler}"
RUN_NAME="${RUN_NAME:-$DEFAULT_RUN_NAME}"
EXP_DIR="$OUTPUT_ROOT/$RUN_NAME"
CUDA_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"

mkdir -p "$EXP_DIR"

STAGE_YAML="${STAGE_YAML:-$DEFAULT_STAGE_YAML}"
if [ ! -f "$STAGE_YAML" ]; then
    echo "[ERR] stage yaml not found: $STAGE_YAML" >&2
    exit 1
fi

STRICT_TARGET_MATCH="${STRICT_TARGET_MATCH:-True}"
strict_target_match="$(printf '%s' "$STRICT_TARGET_MATCH" | tr '[:upper:]' '[:lower:]')"
if [ "$strict_target_match" != "false" ] && [ "$strict_target_match" != "0" ]; then
    if [[ "$RUN_NAME $MODEL_NAME" == *maxtop4* ]]; then
        if [ "$SIMILARITY_TYPE" != "maxsim_topk" ] || [ "$MAXSIM_TOPK" != "4" ]; then
            echo "[ERR] maxtop4 run must use SIMILARITY_TYPE=maxsim_topk and MAXSIM_TOPK=4, got $SIMILARITY_TYPE topk=$MAXSIM_TOPK" >&2
            exit 1
        fi
    fi
    if [[ "$RUN_NAME" == *stage2* && "$MODEL_NAME" == */stage1 ]]; then
        echo "[ERR] RUN_NAME looks like stage2 but MODEL_NAME points to stage1: $MODEL_NAME" >&2
        echo "      Use the trained stage2 directory for downsampler training." >&2
        exit 1
    fi
    if [[ "$RUN_NAME" == *stage2* && "$STAGE_YAML" == *stage1* ]]; then
        echo "[ERR] RUN_NAME looks like stage2 but STAGE_YAML points to stage1: $STAGE_YAML" >&2
        exit 1
    fi
fi

echo "=========================================="
echo "Multi-head Downsampler Training"
echo "Stage: $DOWNSAMPLER_STAGE"
echo "Model: $MODEL_NAME"
echo "Data: $STAGE_YAML"
echo "Steps: $MAX_STEPS"
echo "Contrastive scope: $CONTRASTIVE_SCOPE per_device_batch=$PER_DEVICE_RETRV_BATCH_SIZE effective_global_batch=$EFFECTIVE_RETRV_BATCH_SIZE"
echo "Heads: $MULTI_HEAD_DIMS"
echo "Weights: $MULTI_HEAD_WEIGHTS"
echo "Similarity: $SIMILARITY_TYPE topk=$MAXSIM_TOPK"
echo "Orthogonal: base_weight=$ORTHOGONAL_BASE_WEIGHT base_dim=$ORTHOGONAL_BASE_DIM scale=$MULTI_HEAD_ORTHOGONAL_SCALE margin=$ORTHOGONAL_MARGIN warmup=$ORTHOGONAL_WARMUP_STEPS"
echo "Orthogonal weights: $MULTI_HEAD_ORTHOGONAL_WEIGHTS"
echo "=========================================="

cmd=(
    env CUDA_VISIBLE_DEVICES="$CUDA_DEVICES"
    "$TORCHRUN"
    --nproc-per-node "$GPUS_PER_NODE"
    --nnodes "$NNODES"
    --max-restarts 0
    --rdzv-backend c10d
    --rdzv-id "${RUN_NAME}"
    --rdzv-endpoint "$MASTER_ADDR:$MASTER_PORT"
    --node-rank "$NODE_RANK"
    train.py
    --seed 42
    --compression_mode
    --max_grad_norm 0.5
    --task_types retrieval_goods
    --split_cls_tokens_by_task False
    --cls_types goods
    --dataset_config "$STAGE_YAML"
    --pooling multi_head_mlp
    --similarity_type "$SIMILARITY_TYPE"
    --maxsim_topk "$MAXSIM_TOPK"
    --normalize True
    --temperature 0.02
    --orthogonal_loss "$ORTHOGONAL_LOSS"
    --bf16
    --deepspeed experiments/zero1.json
    --split_layer 36
    --gradient_accumulation_steps 1
    --data_weights 1
    --loss_weights 1
    --model_name "$MODEL_NAME"
    --model_type "$MODEL_TYPE"
    --grad_cache
    --gc_q_chunk_size "$GC_Q_CHUNK_SIZE"
    --gc_p_chunk_size "$GC_P_CHUNK_SIZE"
    --dataloader_num_workers "$NUM_WORKERS"
    --dataloader_pin_memory False
    --dataloader_persistent_workers False
    --run_name "$RUN_NAME"
    --project_name "$WANDB_PROJECT"
    --output_dir "$EXP_DIR"
    --max_len "$MAX_LEN"
    --resize_min_pixels "$MIN_PIXELS"
    --resize_max_pixels "$MAX_PIXELS"
    --per_device_train_batch_size 1
    --per_device_retrv_train_batch_size "$PER_DEVICE_RETRV_BATCH_SIZE"
    --per_device_openqa_train_batch_size 1
    --interleave_batch_size 1
    --lr_scheduler_type cosine
    --learning_rate "$LR"
    --projector_lr "$LR"
    --weight_decay 0
    --warmup_steps "$WARMUP_STEPS"
    --max_steps "$MAX_STEPS"
    --save_steps "$SAVE_STEPS"
    --logging_steps 1
    --orthogonal_margin "$ORTHOGONAL_MARGIN"
    --orthogonal_warmup_steps "$ORTHOGONAL_WARMUP_STEPS"
    --multi_head_orthogonal_weights $MULTI_HEAD_ORTHOGONAL_WEIGHTS
    --orthogonal_diag_steps "$ORTHOGONAL_DIAG_STEPS"
    --load_diag_steps "$LOAD_DIAG_STEPS"
    --save_safetensors True
    --remove_unused_columns False
    --resume_from "$RESUME_FROM"
    --report_to "$REPORT_TO"
    --local_contrastive_loss "$LOCAL_CONTRASTIVE_LOSS"
    --projector_grad_only True
    --multi_head_dims $MULTI_HEAD_DIMS
    --multi_head_weights $MULTI_HEAD_WEIGHTS
    --save_multi_head_standalone_heads "$SAVE_MULTI_HEAD_STANDALONE_HEADS"
)

printf "\n[TRAIN] CMD: "
printf "%q " "${cmd[@]}"
printf "\n"

if [ "$MODE" = "train" ]; then
    {
        printf "\n[TRAIN] CMD: "
        printf "%q " "${cmd[@]}"
        printf "\n"
        "${cmd[@]}"
    } 2>&1 | tee -a "$EXP_DIR/train.log"
else
    echo "[INFO] MODE=$MODE, print command only."
fi
