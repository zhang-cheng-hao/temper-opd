"""Cached projector training utilities."""
