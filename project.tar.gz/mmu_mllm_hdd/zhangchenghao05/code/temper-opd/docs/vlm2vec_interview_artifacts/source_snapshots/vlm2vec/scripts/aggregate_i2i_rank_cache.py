import argparse
import json
import os
import pickle
import re
from collections import OrderedDict

import numpy as np
import torch


def parse_args():
    parser = argparse.ArgumentParser(description="Aggregate eval_i2i rank cache files into final pickle/jsonl outputs.")
    parser.add_argument("--cache_dir", required=True, help="Directory containing cache_<rank>_<world>.pkl and cache_info_<rank>_<world>.jsonl")
    parser.add_argument("--item_embed_path", default=None, help="Output pickle path. Defaults to <parent>/<dataset_name>.pickle")
    parser.add_argument("--item_meta_info_path", default=None, help="Output jsonl path. Defaults to <parent>/<dataset_name>_info.jsonl")
    parser.add_argument("--dtype", default="float32", choices=["float32", "float16"], help="Output embedding dtype")
    parser.add_argument("--strict", action="store_true", help="Fail if any rank cache file is missing")
    return parser.parse_args()


def infer_rank_files(cache_dir: str):
    pattern = re.compile(r"^cache_(\d+)_(\d+)\.pkl$")
    rank_info = []
    for filename in os.listdir(cache_dir):
        match = pattern.match(filename)
        if not match:
            continue
        rank = int(match.group(1))
        world_size = int(match.group(2))
        rank_info.append((rank, world_size, os.path.join(cache_dir, filename)))
    if not rank_info:
        raise FileNotFoundError(f"No rank cache files found in: {cache_dir}")

    world_sizes = sorted({world_size for _, world_size, _ in rank_info})
    if len(world_sizes) != 1:
        raise ValueError(f"Inconsistent world sizes in cache_dir={cache_dir}: {world_sizes}")
    world_size = world_sizes[0]

    rank_to_embed = {rank: embed_path for rank, _, embed_path in rank_info}
    rank_to_meta = {
        rank: os.path.join(cache_dir, f"cache_info_{rank}_{world_size}.jsonl")
        for rank in rank_to_embed
    }
    return world_size, rank_to_embed, rank_to_meta


def convert_embed(item_embed, dtype: str):
    if torch.is_tensor(item_embed):
        item_embed = item_embed.cpu().numpy()
    else:
        item_embed = np.asarray(item_embed)

    if dtype == "float16":
        return item_embed.astype(np.float16, copy=False)
    return item_embed.astype(np.float32, copy=False)


def main():
    args = parse_args()

    cache_dir = os.path.abspath(args.cache_dir)
    if not os.path.isdir(cache_dir):
        raise NotADirectoryError(f"cache_dir not found: {cache_dir}")

    dataset_name = os.path.basename(cache_dir.rstrip("/"))
    output_dir = os.path.dirname(cache_dir.rstrip("/"))
    item_embed_path = args.item_embed_path or os.path.join(output_dir, f"{dataset_name}.pickle")
    item_meta_info_path = args.item_meta_info_path or os.path.join(output_dir, f"{dataset_name}_info.jsonl")

    world_size, rank_to_embed, rank_to_meta = infer_rank_files(cache_dir)

    if args.strict:
        missing = []
        for rank in range(world_size):
            if rank not in rank_to_embed:
                missing.append(f"cache_{rank}_{world_size}.pkl")
            if not os.path.exists(os.path.join(cache_dir, f"cache_info_{rank}_{world_size}.jsonl")):
                missing.append(f"cache_info_{rank}_{world_size}.jsonl")
        if missing:
            raise FileNotFoundError(f"Missing rank cache files: {missing}")

    merged_embeds = OrderedDict()
    merged_meta_infos = []

    for rank in range(world_size):
        cache_embed_path = rank_to_embed.get(rank)
        cache_meta_path = rank_to_meta.get(rank)
        if cache_embed_path is None or cache_meta_path is None or not os.path.exists(cache_meta_path):
            print(f"[WARN] skip missing rank={rank} cache files")
            continue

        print(f"[INFO] loading rank={rank}: {cache_embed_path}")
        with open(cache_embed_path, "rb") as f:
            cache_embeds = pickle.load(f)
        with open(cache_meta_path, "r") as f:
            cache_meta_infos = [json.loads(line) for line in f]

        if len(cache_embeds) != len(cache_meta_infos):
            raise ValueError(
                f"Rank cache length mismatch for rank={rank}: "
                f"embeds={len(cache_embeds)} metas={len(cache_meta_infos)}"
            )

        added = 0
        for meta_info, item_embed in zip(cache_meta_infos, cache_embeds):
            item_id = str(meta_info["id"])
            if item_id in merged_embeds:
                continue
            merged_embeds[item_id] = convert_embed(item_embed, args.dtype)
            merged_meta_infos.append(meta_info)
            added += 1
        print(f"[INFO] rank={rank} added={added} total={len(merged_embeds)}")

    with open(item_embed_path, "wb") as f:
        pickle.dump(dict(merged_embeds), f)
    with open(item_meta_info_path, "w") as f:
        for meta_info in merged_meta_infos:
            f.write(json.dumps(meta_info, ensure_ascii=False) + "\n")

    print(f"[DONE] saved embeddings: {item_embed_path}")
    print(f"[DONE] saved metas: {item_meta_info_path}")
    print(f"[DONE] total unique items: {len(merged_embeds)}")


if __name__ == "__main__":
    main()
