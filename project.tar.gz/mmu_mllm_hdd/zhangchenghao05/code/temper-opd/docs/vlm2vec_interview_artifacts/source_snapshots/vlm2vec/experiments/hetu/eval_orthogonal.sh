#!/bin/bash
set -euo pipefail

# ======================
# Proxy / NCCL / Env
# ======================
export http_proxy=[REDACTED_PROXY]
export https_proxy=[REDACTED_PROXY]
export no_proxy=[REDACTED_NO_PROXY]

NNODES="${1:-${NNODES:-1}}"
NODE_RANK="${2:-${NODE_RANK:-0}}"

export NCCL_IB_QPS_PER_CONNECTION=4
export NCCL_IB_DISABLE=0
export NCCL_IB_GID_INDEX=3
export NCCL_IB_HCA=mlx5
export NCCL_DEBUG=WARN
export NCCL_NET_OVERHEAD=1000
export NCCL_PROTO=^LL128
export LD_LIBRARY_PATH=/usr/local/nvidia/lib:/usr/local/nvidia/lib64

export CUDA_LAUNCH_BLOCKING=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

GPUS_PER_NODE=8

if [ "$NNODES" -eq 1 ]; then
  MASTER_ADDR="localhost"
else
  MASTER_ADDR="${MASTER_ADDR:-10.82.121.98}"
fi
MASTER_PORT="${MASTER_PORT:-2207}"

export MASTER_ADDR MASTER_PORT

echo "MASTER_ADDR=[$MASTER_ADDR]"
echo "MASTER_PORT=[$MASTER_PORT]"
echo "NNODES=[$NNODES] NODE_RANK=[$NODE_RANK] GPUS_PER_NODE=[$GPUS_PER_NODE]"

# ======================
# HF / WandB (按需保留)
# ======================
export HF_ENDPOINT='https://hf-mirror.com'
export HF_HOME='/mmu_mllm_hdd_2/luoyuxiao/.cache/huggingface'
export HF_DATASETS_CACHE='/mmu_mllm_hdd_2/luoyuxiao/.cache/huggingface/datasets'
export HUGGING_FACE_HUB_TOKEN=[REDACTED_HF_TOKEN]

export WANDB_DISABLED=false
export WANDB_PROJECT=VLM2Vec
export WANDB_RUN_GROUP=korus
# export WANDB_API_KEY=...

echo "conda location: $(which conda)"
echo "Python location: $(which python)"
echo "Python version: $(python --version)"

# ======================
# Fixed Eval Args
# ======================
TORCHRUN=/mmu_mllm_hdd_2/luoyuxiao/miniconda3/envs/vlm2vec/bin/torchrun

MODEL_TYPE="qwen2_5_omni"
MODEL_NAME="/mmu_mllm_hdd/zhangchenghao05/hetu_next/LLaMA-Factory/saves/qwen2_5omni-3b/sft_datav2/merge/"
DATASET_CFG="experiments/hetu/eval_hetu_hetu_video_v3.yaml"

# 你训练里也有这个（eval 未必需要，但保留无害）
export TOTAL_COMPRESS_TOKENS=8

# 分布式参数（只传一次 node_rank）
DISTRIBUTED_ARGS=(
  --nproc_per_node "$GPUS_PER_NODE"
  --nnodes "$NNODES"
  --max_restarts 0
  --master_addr "$MASTER_ADDR"
  --master_port "$MASTER_PORT"
  --node_rank "$NODE_RANK"
)

# ======================
# Helper: run one eval
# ======================
run_one_ckpt () {
  local exp_dir="$1"      # e.g. /mmu.../outputs/xxx.run
  local ckpt_step="$2"    # e.g. 1000
  local ckpt_dir="${exp_dir}/checkpoint-${ckpt_step}"

  if [ ! -d "$ckpt_dir" ]; then
    echo "[WARN] missing ckpt_dir, skip: $ckpt_dir"
    return 0
  fi

  # 每个 exp 单独一套 logs；每个 ckpt 一个 log 文件
  local logs_dir="${exp_dir}/logs_eval_i2i"
  mkdir -p "$logs_dir"

  local tag
  tag="$(basename "$exp_dir")_ckpt-${ckpt_step}"
  local log_file="${logs_dir}/${tag}.log"

  echo "============================================================"
  echo "RUN: exp_dir=$exp_dir"
  echo "RUN: ckpt_dir=$ckpt_dir"
  echo "RUN: log_file=$log_file"
  echo "============================================================"

  # 用 env 前缀，避免污染后续命令
  CMD=(
    env CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
    "$TORCHRUN" "${DISTRIBUTED_ARGS[@]}"
    eval_i2i.py
      --compression_mode
      --cls_types video
      --split_cls_tokens_by_task False
      --task_types retrieval
      --model_type "$MODEL_TYPE"
      --model_name "$MODEL_NAME"
      --checkpoint_path "$ckpt_dir"
      --encode_output_path "${ckpt_dir}/"
      --bf16
      --split_layer 36
      --normalize True
      --temperature 0.02
      --native_prob 0.0
      --per_device_eval_batch_size 16
      --dataloader_num_workers 2
      --dataloader_pin_memory False
      --dataloader_persistent_workers False
      --dataset_config "$DATASET_CFG"
      --max_len 10240
      --resize_min_pixels $((32*32))
      --resize_max_pixels $((512*512))
  )

  # 打印成可复制格式
  printf "CMD: "
  printf "%q " "${CMD[@]}"
  printf "\n"

  # 跑，并把 stdout/stderr 同时 tee 到 log
  "${CMD[@]}" 2>&1 | tee "$log_file"

  echo "DONE: $tag"
}

# ======================
# EXP + CKPT table (你的清单)
# ======================
EXP_1="/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/Korus_Qwen2moni_3B.hetu_hetu.BSr1024.BSg32.full.videoonly.re.ortho_m0.0_w0.5_abs.v3.steps5k.run"
CKPTS_1=(1000)

EXP_2="/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/Korus_Qwen2moni_3B.hetu_hetu.BSr1024.BSg32.full.videoonly.re.ortho_m0.0_w0.00_abs.v3.steps5k.run"
CKPTS_2=(1000 2500)

EXP_3="/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/Korus_Qwen2moni_3B.hetu_hetu.BSr1024.BSg32.full.videoonly.re.ortho_m0.2_w0.01_abs.v3.steps5k.run"
CKPTS_3=(2500 1000)

EXP_4="/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/Korus_Qwen2moni_3B.hetu_hetu.BSr1024.BSg32.full.videoonly.re.ortho_m0.2_w0.03_abs.v3.steps5k.run"
CKPTS_4=(1000)

# ======================
# Serial execution (一个跑完再跑一个)
# ======================
run_exp () {
  local exp_dir="$1"; shift
  local -a ckpts=("$@")

  echo "===================="
  echo "START EXP: $exp_dir"
  echo "CKPTS: ${ckpts[*]}"
  echo "===================="

  # 可选：每个 exp 设一个 wandb name/group
  export WANDB_DIR="$exp_dir"
  export WANDB_NAME="$(basename "$exp_dir")"

  for step in "${ckpts[@]}"; do
    run_one_ckpt "$exp_dir" "$step"
  done

  echo "===================="
  echo "FINISH EXP: $exp_dir"
  echo "===================="
}

run_exp "$EXP_1" "${CKPTS_1[@]}"
run_exp "$EXP_2" "${CKPTS_2[@]}"
run_exp "$EXP_3" "${CKPTS_3[@]}"
run_exp "$EXP_4" "${CKPTS_4[@]}"

echo "ALL EVAL DONE."
