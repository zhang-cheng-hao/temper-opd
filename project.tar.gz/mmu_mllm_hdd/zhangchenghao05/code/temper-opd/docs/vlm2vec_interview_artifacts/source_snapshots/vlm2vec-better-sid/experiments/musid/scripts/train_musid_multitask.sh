#!/bin/bash

set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"

NNODES="${1:-${NNODES:-2}}"
NODE_RANK="${2:-${NODE_RANK:-0}}"
export NNODES NODE_RANK

export http_proxy="${http_proxy:-[REDACTED_PROXY]}"
export https_proxy="${https_proxy:-[REDACTED_PROXY]}"
export no_proxy="${no_proxy:-[REDACTED_NO_PROXY]}"

export NCCL_IB_QPS_PER_CONNECTION="${NCCL_IB_QPS_PER_CONNECTION:-4}"
export NCCL_IB_DISABLE="${NCCL_IB_DISABLE:-0}"
export NCCL_IB_GID_INDEX="${NCCL_IB_GID_INDEX:-3}"
export NCCL_IB_HCA="${NCCL_IB_HCA:-mlx5}"
export NCCL_DEBUG="${NCCL_DEBUG:-WARN}"
export NCCL_NET_OVERHEAD="${NCCL_NET_OVERHEAD:-1000}"
export NCCL_PROTO="${NCCL_PROTO:-^LL128}"
export NCCL_TIMEOUT="${NCCL_TIMEOUT:-6000}"
export TORCH_NCCL_BLOCKING_WAIT=1
export TORCH_NCCL_ASYNC_ERROR_HANDLING=1
export TORCH_NCCL_TIMEOUT="${TORCH_NCCL_TIMEOUT:-6000}"
export NCCL_COMM_TIMEOUT="${NCCL_COMM_TIMEOUT:-6000}"
export NCCL_DEBUG_SUBSYS="${NCCL_DEBUG_SUBSYS:-COLL}"

export CUDA_HOME="${CUDA_HOME:-/usr/local/cuda}"
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="${LD_LIBRARY_PATH:-/usr/local/nvidia/lib:/usr/local/nvidia/lib64}"
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

GPUS_PER_NODE="${GPUS_PER_NODE:-8}"
CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"
WORLD_SIZE=$((NNODES * GPUS_PER_NODE))

MASTER_ADDR="${MASTER_ADDR:-10.86.17.226}"
MASTER_PORT="${MASTER_PORT:-2207}"
RDZV_ID="${RDZV_ID:-musid_multitask}"

TOTAL_RETRV_BATCH_SIZE="${TOTAL_RETRV_BATCH_SIZE:-1024}"
TOTAL_QA_BATCH_SIZE="${TOTAL_QA_BATCH_SIZE:-1536}"
PER_DEVICE_RETRV_BATCH_SIZE="${PER_DEVICE_RETRV_BATCH_SIZE:-64}"
PER_DEVICE_QA_BATCH_SIZE="${PER_DEVICE_QA_BATCH_SIZE:-1}"
RETRV_ACC_STEP="${RETRV_ACC_STEP:-$((TOTAL_RETRV_BATCH_SIZE / (WORLD_SIZE * PER_DEVICE_RETRV_BATCH_SIZE)))}"
QA_ACC_STEP="${QA_ACC_STEP:-$((TOTAL_QA_BATCH_SIZE / (WORLD_SIZE * PER_DEVICE_QA_BATCH_SIZE)))}"
NUM_WORKERS="${NUM_WORKERS:-4}"
INTERLEAVE_BATCH_SIZE="${INTERLEAVE_BATCH_SIZE:-64}"
QA_INTERLEAVE_BATCH_SIZE="${QA_INTERLEAVE_BATCH_SIZE:-1}"
LR="${LR:-5e-5}"
MAX_STEPS="${MAX_STEPS:-150}"
SAVE_STEPS="${SAVE_STEPS:-50}"
LOGGING_STEPS="${LOGGING_STEPS:-1}"
WARMUP_STEPS="${WARMUP_STEPS:-50}"
ORTHO_W="${ORTHO_W:-0.5}"
ORTHO_M="${ORTHO_M:-0.0}"
O_WARMUP_STEPS="${O_WARMUP_STEPS:-50}"
REPORT_TO="${REPORT_TO:-wandb}"

export TOTAL_COMPRESS_TOKENS="${TOTAL_COMPRESS_TOKENS:-4}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-/mmu_mllm_hdd_2/luoyuxiao/.cache/huggingface}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-/mmu_mllm_hdd_2/luoyuxiao/.cache/huggingface/datasets}"
export WANDB_DISABLED="${WANDB_DISABLED:-false}"
export WANDB_PROJECT="${WANDB_PROJECT:-VLM2Vec}"
export WANDB_API_KEY="${WANDB_API_KEY:-[REDACTED_WANDB_API_KEY]}"
export WANDB_RUN_GROUP="${WANDB_RUN_GROUP:-korus}"

MODEL_NAME="${MODEL_NAME:-/mmu_mllm_hdd_2/wangyan/hetu_next/hetu_next_0116/outputs/Korus_Qwen2moni_3B.hetu_hetu.BSr1024.BSg128.full.videoonly.v3.steps2w.run/checkpoint-20000}"
OUTPUT_ROOT="${OUTPUT_ROOT:-/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs}"
TASK_TYPES="${TASK_TYPES:?TASK_TYPES is required}"
DATASET_CONFIG="${DATASET_CONFIG:?DATASET_CONFIG is required}"
DATA_WEIGHTS="${DATA_WEIGHTS:?DATA_WEIGHTS is required}"
LOSS_WEIGHTS="${LOSS_WEIGHTS:?LOSS_WEIGHTS is required}"
GRADIENT_ACCUMULATION_STEPS="${GRADIENT_ACCUMULATION_STEPS:?GRADIENT_ACCUMULATION_STEPS is required}"
EXP_NAME="${EXP_NAME:?EXP_NAME is required}"
XSEQ_ARGS="${XSEQ_ARGS:-}"
ENABLE_GRAD_CACHE="${ENABLE_GRAD_CACHE:-false}"

if [ "$GPUS_PER_NODE" -le 0 ]; then
    echo "GPUS_PER_NODE must be > 0, got $GPUS_PER_NODE" >&2
    exit 1
fi

if [ "$NNODES" -le 0 ]; then
    echo "NNODES must be > 0, got $NNODES" >&2
    exit 1
fi

if [ ! -e "$MODEL_NAME" ]; then
    echo "MODEL_NAME does not exist: $MODEL_NAME" >&2
    exit 1
fi

if [ ! -f "$DATASET_CONFIG" ]; then
    echo "DATASET_CONFIG does not exist: $DATASET_CONFIG" >&2
    exit 1
fi

if [[ " $TASK_TYPES " == *" retrieval "* ]]; then
    if [ $((TOTAL_RETRV_BATCH_SIZE % (WORLD_SIZE * PER_DEVICE_RETRV_BATCH_SIZE))) -ne 0 ]; then
        echo "TOTAL_RETRV_BATCH_SIZE=$TOTAL_RETRV_BATCH_SIZE must be divisible by WORLD_SIZE*PER_DEVICE_RETRV_BATCH_SIZE=$((WORLD_SIZE * PER_DEVICE_RETRV_BATCH_SIZE))" >&2
        exit 1
    fi
    if [ $((TOTAL_RETRV_BATCH_SIZE / (WORLD_SIZE * PER_DEVICE_RETRV_BATCH_SIZE))) -ne "$RETRV_ACC_STEP" ]; then
        echo "RETRV_ACC_STEP=$RETRV_ACC_STEP does not match TOTAL_RETRV_BATCH_SIZE/(WORLD_SIZE*PER_DEVICE_RETRV_BATCH_SIZE)" >&2
        exit 1
    fi
fi

if [[ " $TASK_TYPES " == *" openqa "* ]] || [[ " $TASK_TYPES " == *" xseq_openqa "* ]]; then
    if [ $((TOTAL_QA_BATCH_SIZE % (WORLD_SIZE * PER_DEVICE_QA_BATCH_SIZE))) -ne 0 ]; then
        echo "TOTAL_QA_BATCH_SIZE=$TOTAL_QA_BATCH_SIZE must be divisible by WORLD_SIZE*PER_DEVICE_QA_BATCH_SIZE=$((WORLD_SIZE * PER_DEVICE_QA_BATCH_SIZE))" >&2
        exit 1
    fi
    if [ $((TOTAL_QA_BATCH_SIZE / (WORLD_SIZE * PER_DEVICE_QA_BATCH_SIZE))) -ne "$QA_ACC_STEP" ]; then
        echo "QA_ACC_STEP=$QA_ACC_STEP does not match TOTAL_QA_BATCH_SIZE/(WORLD_SIZE*PER_DEVICE_QA_BATCH_SIZE)" >&2
        exit 1
    fi
fi

if [ "$ENABLE_GRAD_CACHE" = "true" ]; then
    EXTRA_GC_ARGS="--grad_cache --gc_q_chunk_size 4 --gc_p_chunk_size 4"
else
    EXTRA_GC_ARGS=""
fi

EXP_DIR="${EXP_DIR:-$OUTPUT_ROOT/$EXP_NAME}"
export WANDB_NAME="$EXP_NAME"
export WANDB_DIR="$EXP_DIR"
mkdir -p "$EXP_DIR/wandb"

TORCHRUN=$(command -v torchrun)

echo "conda location: $(which conda || true)"
echo "Python location: $(which python)"
echo "Python version: $(python --version)"
echo "torchrun: $TORCHRUN"
echo "NNODES: $NNODES"
echo "NODE_RANK: $NODE_RANK"
echo "MASTER_ADDR: $MASTER_ADDR"
echo "MASTER_PORT: $MASTER_PORT"
echo "RDZV_ID: $RDZV_ID"
echo "WORLD_SIZE: $WORLD_SIZE"
echo "CUDA_VISIBLE_DEVICES: $CUDA_VISIBLE_DEVICES"
echo "TASK_TYPES: $TASK_TYPES"
echo "DATASET_CONFIG: $DATASET_CONFIG"
echo "MODEL_NAME: $MODEL_NAME"
echo "TOTAL_COMPRESS_TOKENS: $TOTAL_COMPRESS_TOKENS"
echo "TOTAL_RETRV_BATCH_SIZE: $TOTAL_RETRV_BATCH_SIZE"
echo "TOTAL_QA_BATCH_SIZE: $TOTAL_QA_BATCH_SIZE"
echo "PER_DEVICE_RETRV_BATCH_SIZE: $PER_DEVICE_RETRV_BATCH_SIZE"
echo "PER_DEVICE_QA_BATCH_SIZE: $PER_DEVICE_QA_BATCH_SIZE"
echo "RETRV_ACC_STEP: $RETRV_ACC_STEP"
echo "QA_ACC_STEP: $QA_ACC_STEP"
echo "GRADIENT_ACCUMULATION_STEPS: $GRADIENT_ACCUMULATION_STEPS"
echo "DATA_WEIGHTS: $DATA_WEIGHTS"
echo "LOSS_WEIGHTS: $LOSS_WEIGHTS"
echo "ENABLE_GRAD_CACHE: $ENABLE_GRAD_CACHE"
echo "EXP_DIR: $EXP_DIR"

cmd="CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES \
    $TORCHRUN \
    --nproc_per_node=$GPUS_PER_NODE \
    --nnodes=$NNODES \
    --max_restarts=0 \
    --rdzv_backend=c10d \
    --rdzv_id=$RDZV_ID \
    --rdzv_endpoint=$MASTER_ADDR:$MASTER_PORT \
    --node_rank=$NODE_RANK \
    train.py \
    --seed 42 \
    --compression_mode \
    --max_grad_norm 0.5 \
    --task_types $TASK_TYPES \
    --split_cls_tokens_by_task False \
    --cls_types video goods \
    --dataset_config $DATASET_CONFIG \
    --pooling none \
    --similarity_type slot_aligned \
    --normalize True \
    --temperature 0.02 \
    --native_prob 0.0 \
    --bf16 \
    --deepspeed experiments/zero1.json \
    --split_layer 36 \
    --gradient_accumulation_steps $GRADIENT_ACCUMULATION_STEPS \
    --data_weights $DATA_WEIGHTS \
    --loss_weights $LOSS_WEIGHTS \
    --orthogonal_loss $ORTHO_W \
    --orthogonal_loss_openqa $ORTHO_W \
    --orthogonal_margin $ORTHO_M \
    --orthogonal_warmup_steps $O_WARMUP_STEPS \
    --hsic_loss 0.0 \
    --hsic_diag_steps 20 \
    --model_name $MODEL_NAME \
    --model_type qwen2_5_omni \
    $EXTRA_GC_ARGS \
    --dataloader_num_workers $NUM_WORKERS \
    --dataloader_pin_memory False \
    --dataloader_persistent_workers False \
    --run_name $EXP_NAME \
    --output_dir $EXP_DIR \
    --max_len 8192 \
    --resize_min_pixels 1024 \
    --resize_max_pixels 262144 \
    --per_device_train_batch_size 1 \
    --per_device_retrv_train_batch_size $PER_DEVICE_RETRV_BATCH_SIZE \
    --per_device_openqa_train_batch_size $PER_DEVICE_QA_BATCH_SIZE \
    --interleave_batch_size $INTERLEAVE_BATCH_SIZE \
    --qa_interleave_batch_size $QA_INTERLEAVE_BATCH_SIZE \
    --lr_scheduler_type cosine \
    --learning_rate $LR \
    --projector_lr $LR \
    --weight_decay 0 \
    --warmup_steps $WARMUP_STEPS \
    --max_steps $MAX_STEPS \
    --save_steps $SAVE_STEPS \
    --logging_steps $LOGGING_STEPS \
    --save_safetensors True \
    --remove_unused_columns False \
    --resume_from none \
    --report_to $REPORT_TO \
    $XSEQ_ARGS"

echo "$cmd"
eval "$cmd"
