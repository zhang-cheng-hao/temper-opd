import datetime
import logging
import json
import random
import time

import numpy as np
import os
import pickle
import sys
import torch
import torch.distributed as dist
import torch.nn.functional as F
import yaml
from collections import defaultdict

from torch.utils.data import DataLoader, Subset
from tqdm import tqdm
from concurrent.futures import ProcessPoolExecutor, as_completed
from transformers import HfArgumentParser, AutoConfig
from datasets import Dataset, concatenate_datasets
from datasets.distributed import split_dataset_by_node

from src.arguments import ModelArguments, DataArguments, TrainingArguments
from src.data.collator.eval_collator import MultimodalI2IDataCollator
from src.data.eval_dataset.base_i2i_dataset import AutoEvalI2IDataset
from src.eval_utils.metrics import RankingMetrics
from src.loss import _maxsim_logits, _maxsim_topk_logits, _slot_aligned_logits
from src.model.model import MMEBModel
from src.model.processor import get_backbone_name, load_processor, COLPALI
from src.utils import batch_to_device, print_rank, print_master
import multiprocessing
from multiprocessing import Pool, cpu_count
logging.basicConfig(level=logging.INFO, format='[%(asctime)s] %(levelname)s [%(name)s:%(lineno)s] %(message)s')
logger = logging.getLogger(__name__)

from collections import OrderedDict

def RED(x): return f'\033[1;31m{x}\033[0m'
def GREEN(x): return f'\033[1;32m{x}\033[0m'
def YELLOW(x): return f'\033[1;33m{x}\033[0m'

def pad_dataset_to_divisible(dataset, world_size):
    num_samples = len(dataset)
    if num_samples % world_size == 0:
        return dataset, num_samples

    num_to_add = world_size - (num_samples % world_size)
    padded_size = num_samples + num_to_add

    padding_data = dataset.select([i % len(dataset) for i in range(num_to_add)])
    padded_dataset = concatenate_datasets([dataset, padding_data])
    return padded_dataset, padded_size


def _build_tail_loader(loader: DataLoader, resume_count: int) -> DataLoader:
    dataset = loader.dataset
    if resume_count >= len(dataset):
        return loader

    if hasattr(dataset, "select"):
        tail_dataset = dataset.select(range(resume_count, len(dataset)))
    else:
        tail_dataset = Subset(dataset, range(resume_count, len(dataset)))

    return DataLoader(
        tail_dataset,
        batch_size=loader.batch_size,
        collate_fn=loader.collate_fn,
        num_workers=loader.num_workers,
        pin_memory=loader.pin_memory,
        persistent_workers=loader.persistent_workers,
    )

def load_pred_dicts(pred_path, k=100):
    pred_ids_set = set()
    pred_dicts = []
    with open(pred_path, "r") as f:
        for line in f:
            item = json.loads(line)
            if (item.get("group"), item["id"]) in pred_ids_set:
                continue
            pred_ids_set.add((item.get("group"), item["id"]))
            item["prediction"] = item["prediction"][:k]
            item["scores"] = item["scores"][:k]
            pred_dicts.append(item)
    return pred_dicts

def evaluate_metrics(pred_dicts, metrics_to_report):
    """用于多进程评估的 Worker 函数"""
    metrics = RankingMetrics(metrics_to_report, k_list=[1, 5, 10, 20, 50, 100])
    return metrics.evaluate(pred_dicts)

def encode_embeddings(
    model: MMEBModel,
    loader: DataLoader,
    training_args: TrainingArguments,
    data_args: DataArguments,
    model_args: ModelArguments,
    full_dataset: Dataset,
    cache_dir: str=None,
    description: str = "Encoding",
    gather_full: bool = True,
) -> tuple[np.ndarray, list]:
    """
    Encodes embeddings for a given dataset using the model, handling both standard and
    late-interaction models in a DDP-safe manner.
    """
    local_rank = dist.get_rank() if dist.is_initialized() else 0
    world_size = dist.get_world_size() if dist.is_initialized() else 1

    cache_embed_path = os.path.join(cache_dir, f"cache_{local_rank}_{world_size}.pkl") if cache_dir else None
    cache_meta_path = os.path.join(cache_dir, f"cache_info_{local_rank}_{world_size}.jsonl") if cache_dir else None
    if not data_args.ignore_cache and cache_embed_path is not None and os.path.exists(cache_embed_path):
        print_rank(f"Loading embeddings from cache: {cache_embed_path}")
        try:
            with open(cache_embed_path, "rb") as f:
                cache_embeds = pickle.load(f)
            print_rank(f"Loaded embeddings: {cache_embeds.shape}")
        except Exception as e:
            print_rank(f"Failed to load embeddings from cache: {e}")
            cache_embeds = None
    else:
        cache_embeds = None
    if cache_meta_path is not None and os.path.exists(cache_meta_path):
        print_rank(f"Loading metas from cache: {cache_meta_path}")
        with open(cache_meta_path, "r") as f:
            cache_meta = [json.loads(line) for line in f]
        print_rank(f"Loaded metas: {len(cache_meta)}")
    else:
        cache_meta = None

    if cache_embeds is not None and cache_meta is not None and len(cache_embeds) != len(cache_meta):
        print_rank(
            RED(
                f"Local cache length mismatch, ignoring stale cache: "
                f"embeds={len(cache_embeds)} metas={len(cache_meta)}"
            )
        )
        cache_embeds = None
        cache_meta = None

    # Check if the model is a late-interaction type
    is_late_interaction = (model_args.model_backbone == COLPALI)

    local_embeds = []
    local_gt_infos = []
    local_max_len = 0

    expected_local_rows = len(full_dataset) // world_size if dist.is_initialized() else len(full_dataset)
    resume_count = 0

    if (cache_embeds is not None and len(cache_embeds) >= expected_local_rows) \
        and (cache_meta is not None and len(cache_meta) >= expected_local_rows):
        # np 转 tensor
        print_rank(GREEN(f"Skipping..."))
        embeds_tensor = cache_embeds.contiguous()
        local_gt_infos = cache_meta
    else:
        if cache_embeds is not None and cache_meta is not None and len(cache_embeds) > 0:
            resume_count = min(len(cache_embeds), len(cache_meta))
            if torch.is_tensor(cache_embeds):
                local_embeds.append(cache_embeds[:resume_count].cpu().contiguous())
            else:
                local_embeds.append(torch.as_tensor(cache_embeds[:resume_count], dtype=torch.float32))
            local_gt_infos.extend(cache_meta[:resume_count])
            loader = _build_tail_loader(loader, resume_count)
            print_rank(
                YELLOW(
                    f"Resuming from local cache: cached_rows={resume_count} "
                    f"remaining_rows={expected_local_rows - resume_count}"
                )
            )

        model.eval()
        with torch.no_grad():
            for i, (inputs, dataset_infos) in enumerate(tqdm(loader, desc=f"[{local_rank}] {description}", position=local_rank % 8)):
                # todo: 检索不需要mask
                # del inputs["sep_indices"]
                inputs = batch_to_device(inputs, training_args.device)
                with torch.autocast(enabled=True, dtype=torch.bfloat16, device_type="cuda"):
                    output = model(qry=inputs)
                    reps = output["qry_reps"][0].detach()
                if cache_dir is not None:
                    reps = reps.cpu()

                if is_late_interaction and reps.dim() == 3:
                    local_max_len = max(local_max_len, reps.shape[1])

                local_embeds.append(reps)
                local_gt_infos.extend(dataset_infos)
            
                if (i + 1) % 64 == 0:
                    if cache_embed_path is not None:
                        with open(cache_embed_path, "wb") as f:
                            pickle.dump(torch.cat(local_embeds, dim=0), f)
                        with open(cache_meta_path, "w") as f:
                            for info in local_gt_infos:
                                f.write(json.dumps(info, ensure_ascii=False) + "\n")

        if cache_embed_path is not None:
            with open(cache_embed_path, "wb") as f:
                pickle.dump(torch.cat(local_embeds, dim=0), f)
            with open(cache_meta_path, "w") as f:
                for info in local_gt_infos:
                    f.write(json.dumps(info, ensure_ascii=False) + "\n")

        if not local_embeds:
            # Handle cases where a rank gets no data
            return np.array([]), []

        # === DDP Synchronization and Padding for Late-Interaction Models ===
        if is_late_interaction:
            if dist.is_initialized():
                # 1. Find the global maximum sequence length across all ranks
                local_max_len_tensor = torch.tensor(local_max_len, device=training_args.device)
                dist.all_reduce(local_max_len_tensor, op=dist.ReduceOp.MAX)
                global_max_len = local_max_len_tensor.item()
            else:
                global_max_len = local_max_len

            # 2. Pad all local embeddings to the global max length
            padded_embeds = []
            for reps_batch in local_embeds:
                if reps_batch.dim() == 3:
                    B, L, H = reps_batch.shape
                    padding_size = global_max_len - L
                    padded_batch = F.pad(reps_batch, (0, 0, 0, padding_size), "constant", 0)
                    padded_embeds.append(padded_batch)
                else: # Should not happen if model is consistently late-interaction
                    padded_embeds.append(reps_batch)

            embeds_tensor = torch.cat(padded_embeds, dim=0).contiguous()
        else: # Standard dense models
            embeds_tensor = torch.cat(local_embeds, dim=0).contiguous()


    if not gather_full:
        return embeds_tensor.cpu().float().numpy(), local_gt_infos

    # === Gather embeddings and keys from all ranks ===
    if dist.is_initialized() and full_dataset.num_rows >= world_size:
        print_master(f"Gathering embeddings across all ranks...")
        embeds_tensor = embeds_tensor.to(training_args.device)
        print_rank(f"embeds_tensor: {embeds_tensor.shape}")

        # Gather metadata, for which all_gather_object is appropriate
        gathered_gt_infos = [None for _ in range(world_size)]
        dist.all_gather_object(gathered_gt_infos, local_gt_infos)
        all_gt_infos = [key for rank_keys in gathered_gt_infos for key in rank_keys]

        if cache_dir is not None:
            dist.barrier()
            if local_rank == 0:
                # 直接 cache file 里读取其他 rank 的向量
                all_cache_embeds = []
                for other_rank in tqdm(range(1, world_size), desc="Loading cache from other ranks"):
                    cache_path = os.path.join(cache_dir, f"cache_{other_rank}_{world_size}.pkl")
                    with open(cache_path, "rb") as f:
                        cache_embeds = pickle.load(f)
                    all_cache_embeds.append(cache_embeds.cpu().float().numpy())
                final_embeddings = np.concatenate([embeds_tensor.cpu().float().numpy(), *all_cache_embeds], axis=0)
            else:
                final_embeddings = np.array([])
            dist.barrier()
        else:
            output_shape = list(embeds_tensor.shape)
            output_shape[0] = full_dataset.num_rows
            gathered_embeds_tensor = torch.empty(output_shape, dtype=embeds_tensor.dtype, device=training_args.device)
            print_rank(f"gathered_embeds_tensor: {gathered_embeds_tensor.shape}")
            # if dist.get_rank() == 0:
            #     breakpoint()
            # dist.barrier()
            dist.all_gather_into_tensor(gathered_embeds_tensor, embeds_tensor)
            final_embeddings = gathered_embeds_tensor.cpu().float().numpy()
    else:
        all_gt_infos = local_gt_infos
        final_embeddings = embeds_tensor.cpu().float().numpy()

    return final_embeddings, all_gt_infos


def compute_similarity_logits(
    q_embeds: torch.Tensor,
    d_embeds: torch.Tensor,
    similarity_type: str = "dense",
    maxsim_topk: int = 4,
):
    q_embeds = F.normalize(q_embeds, p=2, dim=-1)
    d_embeds = F.normalize(d_embeds, p=2, dim=-1)
    if similarity_type == "maxsim":
        return _maxsim_logits(q_embeds, d_embeds)
    if similarity_type == "maxsim_topk":
        return _maxsim_topk_logits(q_embeds, d_embeds, topk=maxsim_topk)
    if similarity_type == "slot_aligned":
        return _slot_aligned_logits(q_embeds, d_embeds)
    return torch.matmul(q_embeds.to(torch.float32), d_embeds.transpose(0, 1).to(torch.float32))


def save_smoke_report(
    item_embeds: np.ndarray,
    item_meta_infos: list[dict],
    full_eval_dataset: Dataset,
    dataset_name: str,
    output_dir: str,
    data_args: DataArguments,
    training_args: TrainingArguments,
    model_args: ModelArguments,
):
    top_k = min(data_args.smoke_top_k, max(0, len(item_meta_infos) - 1))
    item_embeds_t = torch.from_numpy(item_embeds).to(training_args.device)

    if len(item_meta_infos) == 0:
        raise ValueError(f"Smoke report received empty item_meta_infos for {dataset_name}")
    if len(item_embeds_t) != len(item_meta_infos):
        raise ValueError(
            f"Smoke report length mismatch for {dataset_name}: "
            f"{len(item_embeds_t)} vs {len(item_meta_infos)}"
        )

    sim_matrix = compute_similarity_logits(
        q_embeds=item_embeds_t,
        d_embeds=item_embeds_t,
        similarity_type=training_args.similarity_type,
        maxsim_topk=training_args.maxsim_topk,
    ).cpu()

    pred_dicts = compute_scores_fast(
        q_embeds=item_embeds_t,
        d_embeds=item_embeds_t,
        q_meta_infos=item_meta_infos,
        d_meta_infos=item_meta_infos,
        q_chunk_size=min(64, len(item_meta_infos)),
        d_chunk_size=min(4096, len(item_meta_infos)),
        is_self_retrieval=True,
        top_k=top_k,
        similarity_type=training_args.similarity_type,
        maxsim_topk=training_args.maxsim_topk,
    )
    pred_map = {pred["id"]: pred for pred in pred_dicts}

    report_path = data_args.smoke_report_path
    if report_path is None:
        report_path = os.path.join(output_dir, f"{dataset_name}_smoke.json")

    report = {
        "dataset_name": dataset_name,
        "num_items": len(item_meta_infos),
        "embedding_shape": list(item_embeds.shape),
        "similarity_type": training_args.similarity_type,
        "maxsim_topk": training_args.maxsim_topk,
        "pooling": model_args.pooling,
        "pairwise_similarity_matrix": sim_matrix.numpy().tolist(),
        "items": [],
    }

    for idx, meta_info in enumerate(item_meta_infos):
        row = full_eval_dataset[idx]
        text_preview = row["texts"][0] if row.get("texts") else ""
        pred_info = pred_map.get(meta_info["id"], {"prediction": [], "scores": []})
        emb = item_embeds[idx]
        if emb.ndim == 1:
            emb_summary = {
                "shape": list(emb.shape),
                "norm": float(np.linalg.norm(emb)),
                "preview": emb[:8].tolist(),
            }
        else:
            emb_summary = {
                "shape": list(emb.shape),
                "token_norms": np.linalg.norm(emb, axis=1).tolist(),
                "preview": emb[0, :8].tolist() if emb.shape[0] > 0 else [],
            }
        report["items"].append({
            "index": idx,
            "id": meta_info["id"],
            "labels": meta_info.get("labels", []),
            "text_preview": text_preview[:data_args.smoke_text_preview_chars],
            "embedding": emb_summary,
            "top_neighbors": [
                {"id": pid, "score": float(score)}
                for pid, score in zip(pred_info["prediction"], pred_info["scores"])
            ],
        })

    with open(report_path, "w") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print_master(f"Saved smoke report to {report_path}")


def merge_rank_caches_to_output(
    cache_dir: str,
    item_embed_path: str,
    item_meta_info_path: str,
    world_size: int,
    target_num_items: int,
    expected_local_rows: int | None = None,
):
    merged_embeds = OrderedDict()
    merged_meta_infos = []
    rank_counts = []

    for rank in range(world_size):
        cache_embed_path = os.path.join(cache_dir, f"cache_{rank}_{world_size}.pkl")
        cache_meta_path = os.path.join(cache_dir, f"cache_info_{rank}_{world_size}.jsonl")

        if not os.path.exists(cache_embed_path) or not os.path.exists(cache_meta_path):
            raise FileNotFoundError(f"Missing rank cache files: {cache_embed_path}, {cache_meta_path}")

        with open(cache_embed_path, "rb") as f:
            cache_embeds = pickle.load(f)
        with open(cache_meta_path, "r") as f:
            cache_meta_infos = [json.loads(line) for line in f]

        if len(cache_embeds) != len(cache_meta_infos):
            raise ValueError(
                f"Rank cache length mismatch for rank={rank}: "
                f"embeds={len(cache_embeds)} metas={len(cache_meta_infos)}"
            )

        rank_counts.append((rank, len(cache_embeds)))

    if expected_local_rows is not None:
        incomplete = [(rank, count) for rank, count in rank_counts if count < expected_local_rows]
        if incomplete:
            incomplete_msg = ", ".join(
                f"rank{rank}={count}/{expected_local_rows}" for rank, count in incomplete
            )
            raise ValueError(
                "Rank caches are incomplete; skip merge until all ranks finish: "
                f"{incomplete_msg}"
            )

    for rank in range(world_size):
        cache_embed_path = os.path.join(cache_dir, f"cache_{rank}_{world_size}.pkl")
        cache_meta_path = os.path.join(cache_dir, f"cache_info_{rank}_{world_size}.jsonl")

        with open(cache_embed_path, "rb") as f:
            cache_embeds = pickle.load(f)
        with open(cache_meta_path, "r") as f:
            cache_meta_infos = [json.loads(line) for line in f]

        for meta_info, item_embed in zip(cache_meta_infos, cache_embeds):
            item_id = str(meta_info["id"])
            if item_id in merged_embeds:
                continue

            if torch.is_tensor(item_embed):
                item_embed = item_embed.cpu().float().numpy()
            else:
                item_embed = np.asarray(item_embed, dtype=np.float32)

            merged_embeds[item_id] = item_embed
            merged_meta_infos.append(meta_info)

            if len(merged_embeds) >= target_num_items:
                break

        if len(merged_embeds) >= target_num_items:
            break

    if len(merged_embeds) != target_num_items:
        raise ValueError(
            f"Merged item count mismatch: merged={len(merged_embeds)} target={target_num_items}"
        )

    with open(item_embed_path, "wb") as f:
        pickle.dump(dict(merged_embeds), f)
    with open(item_meta_info_path, "w") as f:
        for meta_info in merged_meta_infos:
            f.write(json.dumps(meta_info) + "\n")

    print_master(f"Saved item embeddings to {item_embed_path}")

def compute_scores(
    q_embeds: torch.Tensor, 
    d_embeds: torch.Tensor, 
    q_meta_infos: list[dict],
    d_meta_infos: list[dict],
    q_chunk_size: int = 64,
    is_self_retrieval: bool = False,
    top_k: int = 1000,
    dim: int = -1,  # 取前多少维度算分
    similarity_type: str = "dense",
    maxsim_topk: int = 4,
):
    local_rank = dist.get_rank() if dist.is_initialized() else 0
    world_size = dist.get_world_size() if dist.is_initialized() else 1
    pred_dicts = []

    d_item_keys = [d_meta_info["id"] for d_meta_info in d_meta_infos]

    if dim > 0:
        q_embeds = q_embeds[..., :dim]
        d_embeds = d_embeds[..., :dim]

    print_rank(f"q_embeds: {q_embeds.shape}, d_embeds: {d_embeds.shape}")

    group = f"#{dim}" if dim > 0 else None

    for i, bi in enumerate(tqdm(range(0, len(q_embeds), q_chunk_size), desc=f"[{local_rank}] Scoring Batches (#{group})", position=local_rank % 8)):
                
        if i % world_size != local_rank:
            continue

        batch_q_embeds = q_embeds[bi : bi + q_chunk_size]
        batch_meta_infos = q_meta_infos[bi : bi + q_chunk_size]
        cosine_scores = compute_similarity_logits(
            q_embeds=batch_q_embeds,
            d_embeds=d_embeds,
            similarity_type=similarity_type,
            maxsim_topk=maxsim_topk,
        )

        # 如果是 self retrieval，需要把自己（对角线）掩码掉
        if is_self_retrieval:
            global_indices = torch.arange(bi, bi + len(batch_q_embeds))   # 这批样本在全局 item_embeds 中的 index
            cosine_scores[torch.arange(len(batch_q_embeds)), global_indices] = -1e9

        ranked_item_indices = torch.argsort(-cosine_scores, dim=1).cpu().tolist()
        cosine_scores = cosine_scores.cpu().float().tolist()
                    
        for i, (ranked_item_idx, item_scores, meta_info) in enumerate(zip(
            ranked_item_indices, 
            cosine_scores, 
            batch_meta_infos
        )):
                        
            pid = meta_info["id"]
            
            pred_dicts.append({
                "id": pid,
                "prediction": [d_item_keys[i] for i in ranked_item_idx[:top_k]],
                "scores": [item_scores[i] for i in ranked_item_idx[:top_k]],
                "label": meta_info['labels'],
                "group": f"#{dim}" if dim > 0 else None,
            })
    return pred_dicts

def compute_scores_fast(
    q_embeds: torch.Tensor, 
    d_embeds: torch.Tensor, 
    q_meta_infos: list[dict],
    d_meta_infos: list[dict],
    q_chunk_size: int = 64,
    d_chunk_size: int = 4096,
    is_self_retrieval: bool = False,
    top_k: int = 1000,
    dim: int = -1,  # 取前多少维度算分
    similarity_type: str = "dense",
    maxsim_topk: int = 4,
):
    local_rank = dist.get_rank() if dist.is_initialized() else 0
    world_size = dist.get_world_size() if dist.is_initialized() else 1
    pred_dicts = []

    d_item_keys = [d_meta_info["id"] for d_meta_info in d_meta_infos]

    if dim > 0:
        q_embeds = q_embeds[..., :dim]
        d_embeds = d_embeds[..., :dim]

    print_rank(f"q_embeds: {q_embeds.shape}, d_embeds: {d_embeds.shape}")

    group = f"#{dim}" if dim > 0 else None
    device = q_embeds.device
    d_embeds = d_embeds.to('cpu')

    search_k = top_k + 5 if is_self_retrieval else top_k
    for i, bi in enumerate(tqdm(range(0, len(q_embeds), q_chunk_size), desc=f"[{local_rank}] Scoring Batches (#{group})", position=local_rank % 8)):
                
        if i % world_size != local_rank:
            continue

        batch_q_embeds = q_embeds[bi : bi + q_chunk_size]
        batch_meta_infos = q_meta_infos[bi : bi + q_chunk_size]

        # 初始化用于存储每个查询的 top-k 结果的张量
        batch_top_scores = torch.zeros((batch_q_embeds.shape[0], 0), device=device, dtype=torch.float32)
        batch_top_indices = torch.zeros((batch_q_embeds.shape[0], 0), device=device, dtype=torch.long)

        d_embeds_gpu = d_embeds.to(device)
        # 分块遍历文档向量，避免一次性计算所有分数
        for j in range(0, d_embeds_gpu.shape[0], d_chunk_size):
            d_chunk = d_embeds_gpu[j : j + d_chunk_size]

            chunk_scores = compute_similarity_logits(
                q_embeds=batch_q_embeds,
                d_embeds=d_chunk,
                similarity_type=similarity_type,
                maxsim_topk=maxsim_topk,
            )
            chunk_indices = torch.arange(j, j + d_chunk.shape[0], device=device).repeat(batch_q_embeds.shape[0], 1)

            # 合并当前的 top-k 和新块的分数
            combined_scores = torch.cat((batch_top_scores, chunk_scores), dim=1)
            combined_indices = torch.cat((batch_top_indices, chunk_indices), dim=1)

            # 从合并后的候选项中选出新的 top-k
            batch_top_scores, combined_indices_indices = torch.topk(combined_scores, k=min(search_k, combined_scores.shape[1]), dim=1)
            batch_top_scores = torch.gather(combined_scores, 1, combined_indices_indices)
            batch_top_indices = torch.gather(combined_indices, 1, combined_indices_indices)

        # 在所有块都处理完毕后，对最终的 top-k 结果进行排序
        final_sorted_indices = torch.argsort(batch_top_scores, dim=1, descending=True)
        ranked_item_indices = torch.gather(batch_top_indices, 1, final_sorted_indices)
        ranked_item_scores = torch.gather(batch_top_scores, 1, final_sorted_indices)

        # 将结果移至 CPU
        ranked_item_indices = ranked_item_indices.cpu().tolist()
        ranked_item_scores = ranked_item_scores.cpu().float().tolist()

        for i, (ranked_idx, item_scores, meta_info) in enumerate(zip(
            ranked_item_indices, 
            ranked_item_scores, 
            batch_meta_infos
        )):
                        
            pid = meta_info["id"]

            # 如果是 self retrieval，需要过滤掉自己
            if is_self_retrieval:
                predictions, scores = [], []
                global_query_idx = bi + i
                for idx, score in zip(ranked_idx, item_scores):
                    if idx != global_query_idx:
                        predictions.append(d_item_keys[idx])
                        scores.append(score)
                    if len(predictions) == top_k:
                        break
            else:
                predictions = [d_item_keys[i] for i in ranked_idx[:top_k]]
                scores = item_scores[:top_k]
            
            pred_dicts.append({
                "id": pid,
                "prediction": predictions,
                "scores": scores,
                "label": meta_info['labels'],
                "group": f"#{dim}" if dim > 0 else None,
            })
    return pred_dicts

def test_score_func():
    import random
    from time import time
    import math
    from copy import deepcopy
    random.seed(42)
    torch.manual_seed(42)
    
    n = 1024
    q_embeds = torch.randn(n, 2048, dtype=torch.float32).to('cuda:0')
    q_meta_infos = [
        {
            "id": i,
            "labels": random.sample(list(range(n)), random.randint(1, 5)),
        }
        for i in range(n)
    ]
    d_meta_infos = deepcopy(q_meta_infos)
    
    now = time()
    pred_dicts1 = compute_scores(
        q_embeds=q_embeds, 
        d_embeds=q_embeds.clone(),
        q_meta_infos=q_meta_infos, 
        d_meta_infos=d_meta_infos, 
        top_k=100, 
        q_chunk_size=32, 
        is_self_retrieval=True,
    )
    done1 = time()
    pred_dicts2 = compute_scores_fast(
        q_embeds=q_embeds, 
        d_embeds=q_embeds.clone(), 
        q_meta_infos=q_meta_infos, 
        d_meta_infos=d_meta_infos, 
        top_k=100, 
        q_chunk_size=32, 
        d_chunk_size=64,
        is_self_retrieval=True,
    )
    done2 = time()
    pred_dicts3 = compute_scores(
        q_embeds=q_embeds, 
        d_embeds=q_embeds.clone(),
        q_meta_infos=q_meta_infos, 
        d_meta_infos=d_meta_infos, 
        top_k=100, 
        q_chunk_size=32, 
        is_self_retrieval=True,
    )
    done3 = time()

    print_rank(f"Time: {done1 - now} {done2 - done1} {done3 - done2}")
    for i, (pred_dict1, pred_dict2) in enumerate(zip(pred_dicts1, pred_dicts2)):
        assert pred_dict1['prediction'] == pred_dict2['prediction'], (pred_dict1['prediction'], pred_dict2['prediction'], breakpoint())
        assert all(math.fabs(score1 - score2) < 1e-5 for score1, score2 in zip(pred_dict1['scores'], pred_dict2['scores'])), (pred_dict1['scores'], pred_dict2['scores'], breakpoint())
    print_master(GREEN("Test compute_scores passed"))

def main():
    if "RANK" in os.environ and dist.is_available() and not dist.is_initialized():
        dist.init_process_group(backend="nccl", timeout=datetime.timedelta(minutes=600))
    local_rank = dist.get_rank() if dist.is_initialized() else 0
    world_size = dist.get_world_size() if dist.is_initialized() else 1
    # DEBUG PRINTS for Distributed Setup
    print_master("Distributed init debug info:")
    print_master(f"RANK: {os.environ.get('RANK')}")
    print_master(f"LOCAL_RANK: {os.environ.get('LOCAL_RANK')}")
    print_master(f"WORLD_SIZE: {os.environ.get('WORLD_SIZE')}")
    print_master(f"MASTER_ADDR: {os.environ.get('MASTER_ADDR')}")
    print_master(f"MASTER_PORT: {os.environ.get('MASTER_PORT')}")
    if dist.is_initialized():
        print_rank(f"dist.get_rank(): {dist.get_rank()}")
        print_rank(f"dist.get_world_size(): {dist.get_world_size()}")

    for arg in sys.argv:
        if arg.startswith("--local-rank="):
            rank = arg.split("=")[1]
            sys.argv.remove(arg)
            sys.argv.append('--local_rank')
            sys.argv.append(rank)
    parser = HfArgumentParser((ModelArguments, DataArguments, TrainingArguments))
    model_args, data_args, training_args = parser.parse_args_into_dataclasses()
    model_args: ModelArguments
    data_args: DataArguments
    training_args: TrainingArguments
    os.makedirs(data_args.encode_output_path, exist_ok=True)

    with open(data_args.dataset_config, 'r') as yaml_file:
        dataset_configs = yaml.safe_load(yaml_file)

    # Lazy
    model = None

    # --- Main Evaluation Loop ---
    for dataset_idx, (dataset_name, task_config) in enumerate(dataset_configs.items()):

        task_type = task_config.get("task_type", "retrieval")
        if task_type not in training_args.task_types:
            continue

        # 0. load dataset
        if dist.is_initialized():
            dist.barrier()
        print_master(f"--- Evaluating {task_type}/{dataset_name} ---")

        output_dir = os.path.join(data_args.encode_output_path, "emb")
        os.makedirs(output_dir, exist_ok=True)

        cache_dir = os.path.join(output_dir, dataset_name)
        os.makedirs(cache_dir, exist_ok=True)

        item_embed_path = os.path.join(output_dir, f"{dataset_name}.pickle")
        item_meta_info_path = os.path.join(output_dir, f"{dataset_name}_info.jsonl")

        do_encode = data_args.ignore_cache or data_args.smoke_report or not (os.path.exists(item_embed_path) and os.path.exists(item_meta_info_path))

        # --- 1. Compute Item Embeddings ---
        if do_encode:
            if model is None:
                # --- Model Loading ---
                print_rank("Loading models...")
                hf_config = AutoConfig.from_pretrained(model_args.model_name, trust_remote_code=True)
                if not getattr(model_args, "model_backbone", None):
                    model_backbone = get_backbone_name(hf_config=hf_config, model_type=model_args.model_type)
                    setattr(model_args, 'model_backbone', model_backbone)
                    setattr(training_args, 'model_backbone', model_backbone)
                print_master(f'Model Backbone: {model_args.model_backbone}')
                # --- DDP-Safe Model Loading ---
                # Step 1: Only the master process (rank 0) downloads the model.
                if local_rank == 0:
                    processor = load_processor(model_args, data_args)
                    model = MMEBModel.load(model_args, is_trainable=False, processor=processor, retrv_only=True)
                    print_master(f"[rank=0] Loading the model from Huggingface: {model_args.model_name}...")
                # Step 2: All processes wait here. The non-master processes will pause
                # until the master process (rank 0) finishes downloading and exits this barrier.
                if torch.distributed.is_initialized():
                    torch.distributed.barrier()
                # Step 3: Now that the model is cached, the non-master processes load it from the local cache.
                if local_rank != 0:
                    print_rank(f"Loading the model from cache...")
                    processor = load_processor(model_args, data_args)
                    time.sleep(random.randint(2 * local_rank, 3 * local_rank))
                    model = MMEBModel.load(model_args, is_trainable=False, processor=processor, retrv_only=True)
                model.eval()
                model = model.to(training_args.device, dtype=torch.bfloat16)

            print_master("Encoding items...")

            if data_args.data_basedir is not None:
                # Construct full paths for data files if --data_basedir is provided
                for key in ["image_dir", "audio_dir"]:
                    if data_args.data_basedir and task_config.get(key):
                        task_config[key] = os.path.join(data_args.data_basedir, task_config[key])

            full_eval_dataset = AutoEvalI2IDataset.instantiate(model_args=model_args, data_args=data_args, training_args=training_args, **task_config)

            # Pad datasets to be divisible by world_size before splitting
            if dist.is_initialized():
                padded_eval_dataset, _ = pad_dataset_to_divisible(full_eval_dataset, world_size)
                eval_dataset = split_dataset_by_node(padded_eval_dataset, rank=local_rank, world_size=world_size)
            else:
                padded_eval_dataset = full_eval_dataset
                eval_dataset = full_eval_dataset

            eval_collator = MultimodalI2IDataCollator(
                processor=processor, 
                model_args=model_args, 
                data_args=data_args, 
                training_args=training_args, 
                model_func_get_rope_index=model.encoder.get_rope_index,
                cls_type_to_indices=model.config.cls_type_to_indices,
            )
            eval_loader = DataLoader(
                eval_dataset, 
                batch_size=training_args.per_device_eval_batch_size, 
                collate_fn=eval_collator, 
                num_workers=training_args.dataloader_num_workers,
                pin_memory=training_args.pin_memory,
                persistent_workers=training_args.persistent_workers,
            )
            item_embeds, item_meta_infos = encode_embeddings(
                model, 
                eval_loader, 
                training_args, 
                data_args, 
                model_args, 
                full_dataset=padded_eval_dataset, 
                cache_dir=cache_dir,
                description=f"Encoding for {dataset_name}",
                gather_full=not task_config.get("encode_only", False),
            )

            if task_config.get("encode_only", False):
                if dist.is_initialized():
                    dist.barrier()
                if local_rank == 0:
                    merge_rank_caches_to_output(
                        cache_dir=cache_dir,
                        item_embed_path=item_embed_path,
                        item_meta_info_path=item_meta_info_path,
                        world_size=world_size,
                        target_num_items=len(full_eval_dataset),
                        expected_local_rows=len(padded_eval_dataset) // world_size if dist.is_initialized() else len(full_eval_dataset),
                    )
                if dist.is_initialized():
                    dist.barrier()
            else:
                if local_rank == 0:
                    assert len(item_embeds) == len(item_meta_infos), f"Embedding and meta info lengths do not match: {len(item_embeds)} vs {len(item_meta_infos)}"
                    item_embeds = item_embeds[:len(full_eval_dataset)]  # world_size>1, trim the padded data points
                    item_meta_infos = item_meta_infos[:len(full_eval_dataset)]
                    
                    with open(item_embed_path, 'wb') as f:
                        pickle.dump({
                            meta_info["id"]: item_embed
                            for meta_info, item_embed in zip(item_meta_infos, item_embeds)
                        }, f)
                    print_master(f"Saved item embeddings to {item_embed_path}")
                    with open(item_meta_info_path, 'w') as f:
                        for meta_info in item_meta_infos:
                            f.write(json.dumps(meta_info) + '\n')
                if dist.is_initialized():
                    dist.barrier()

        if local_rank == 0 and data_args.smoke_report:
            with open(item_embed_path, 'rb') as f:
                smoke_item_embeds_dict = pickle.load(f)
            with open(item_meta_info_path, 'r') as f:
                smoke_item_meta_infos = [json.loads(line) for line in f]

            smoke_item_embeds_dict = {str(k): v for k, v in smoke_item_embeds_dict.items()}
            smoke_item_keys = [str(meta_info["id"]) for meta_info in smoke_item_meta_infos if str(meta_info["id"]) in smoke_item_embeds_dict]
            assert len(smoke_item_keys) > 0, f"No overlapping ids found for smoke report on {dataset_name}"
            smoke_item_embeds = np.stack([smoke_item_embeds_dict[key] for key in smoke_item_keys])
            smoke_item_key_set = set(smoke_item_keys)
            smoke_item_meta_infos = [meta_info for meta_info in smoke_item_meta_infos if str(meta_info["id"]) in smoke_item_key_set]

            save_smoke_report(
                item_embeds=smoke_item_embeds,
                item_meta_infos=smoke_item_meta_infos,
                full_eval_dataset=full_eval_dataset.select(range(len(smoke_item_meta_infos))),
                dataset_name=dataset_name,
                output_dir=output_dir,
                data_args=data_args,
                training_args=training_args,
                model_args=model_args,
            )
        if dist.is_initialized():
            dist.barrier()

        if task_config.get("encode_only", False):
            print_master(f"Encode-only mode enabled for {dataset_name}, skipping scoring.")
            if dist.is_initialized():
                dist.barrier()
            continue


        # --- 2. Compute Scores (on master rank only) ---
        score_path = os.path.join(output_dir, f"{dataset_name}_score.json")
        if not data_args.ignore_cache and os.path.exists(score_path):
            with open(score_path, "r") as f:
                try:
                    score_dict = json.load(f)
                    print_master(f"Score of {dataset_name} (loaded from previous run): {score_path}")
                    formatted = {k: f"{v:.4f}" for k, v in score_dict.items()}
                    print_master(formatted)
                    continue
                except Exception as e:
                    print_master(f"Failed to load score for {dataset_name}, skipping {dataset_name}")
            
        rank_pred_path = os.path.join(cache_dir, f"cache_pred_{local_rank}_{world_size}.jsonl")

        if not data_args.ignore_cache and os.path.exists(rank_pred_path):
            with open(rank_pred_path, 'r') as f:
                pred_dicts = [json.loads(line) for line in f]
            print_rank(f"Loaded {len(pred_dicts)} pred_dicts")
        else:
            # 每个 rank 分别计算
            with open(item_embed_path, 'rb') as f: 
                item_embeds_dict = pickle.load(f)

            with open(item_meta_info_path, 'r') as f:
                item_meta_infos = [json.loads(line) for line in f]
            
            # TODO: 都转成 str，防止不兼容
            item_embeds_dict = {str(k): v for k, v in item_embeds_dict.items()}

            item_meta_infos_dict = OrderedDict(
                (str(meta_info["id"]), meta_info | { 
                    'id': str(meta_info["id"]),
                    'labels': [str(label) for label in meta_info['labels']]
                })
                for meta_info in item_meta_infos
            )
                
            # assert len(item_embeds_dict) == len(item_meta_infos), f"Embedding and meta info lengths do not match: {len(item_embeds_dict)} vs {len(item_meta_infos)}"
            if len(item_embeds_dict) != len(item_meta_infos_dict):
                print_rank(f"Embedding and meta info lengths do not match: {len(item_embeds_dict)} vs {len(item_meta_infos)}")

            print_master(f"Loaded {len(item_embeds_dict)} item_embeds_dict")
            print_master(f"--- Scoring {dataset_name} ---")
                
            # item_keys = list(set(item_meta_infos_dict.keys()) & set(item_embeds_dict.keys()))
            item_keys = [k for k in item_meta_infos_dict.keys() if k in item_embeds_dict]

            # item_embeds = np.stack([item_embeds_dict[key] for key in item_embeds_dict])
            item_embeds = torch.stack([torch.from_numpy(item_embeds_dict[key]) for key in item_keys]).to(training_args.device)
            item_meta_infos = [item_meta_infos_dict[key] for key in item_keys]

            q_embeds_lst, d_embeds_lst = [], []
            q_meta_infos, d_meta_infos = [], []
            for item_embed, item_meta_info in zip(item_embeds, item_meta_infos):
                if len(item_meta_info["labels"]) == 0:
                    d_embeds_lst.append(item_embed)
                    d_meta_infos.append(item_meta_info)
                else:
                    q_embeds_lst.append(item_embed)
                    q_meta_infos.append(item_meta_info)
            
            q_embeds = torch.stack(q_embeds_lst).to(training_args.device)
            if len(d_embeds_lst) == 0:
                print_master("Self retrieval")
                d_embeds = q_embeds.clone()
                d_meta_infos = q_meta_infos
            else:
                d_embeds = torch.stack(d_embeds_lst).to(training_args.device)
            print_master(f"q_embeds.shape={q_embeds.shape}, d_embeds.shape={d_embeds.shape}")

            # batch 计算
            pred_dicts = []

            pred_dicts = compute_scores_fast(
                q_embeds=q_embeds,
                d_embeds=d_embeds,
                q_meta_infos=q_meta_infos,
                d_meta_infos=d_meta_infos,
                q_chunk_size=512,
                top_k=1000,
                is_self_retrieval=len(d_embeds_lst) == 0,
                similarity_type=training_args.similarity_type,
                maxsim_topk=training_args.maxsim_topk,
            )

            for dim in training_args.matryoshkas:
                if dim < 0 or dim == q_embeds.shape[1]:
                    continue
                dim_pred_dicts = compute_scores_fast(
                    dim=dim,
                    q_embeds=q_embeds,
                    d_embeds=d_embeds,
                    q_meta_infos=q_meta_infos,
                    d_meta_infos=d_meta_infos,
                    q_chunk_size=512,
                    top_k=1000,
                    is_self_retrieval=len(d_embeds_lst) == 0,
                    similarity_type=training_args.similarity_type,
                    maxsim_topk=training_args.maxsim_topk,
                )
                pred_dicts.extend(dim_pred_dicts)
            
            with open(rank_pred_path, "w") as f:
                for pred_dict in pred_dicts:
                    json.dump(pred_dict, f, ensure_ascii=False)
                    f.write("\n")

        if dist.is_initialized():
            dist.barrier()

        if local_rank == 0:
            all_pred_dicts = [[] for rank in range(world_size)]

            with ProcessPoolExecutor(max_workers=min(os.cpu_count(), world_size)) as executor:
                futures = { 
                    executor.submit(load_pred_dicts, os.path.join(cache_dir, f"cache_pred_{rank}_{world_size}.jsonl"), k=1000): rank
                    for rank in range(world_size)
                }
                for future in tqdm(as_completed(futures), total=len(futures), desc="Gathering pred_dicts"):
                    all_pred_dicts[futures[future]] = future.result()
            all_pred_dicts = [pred_dicts for rank_pred_dicts in all_pred_dicts for pred_dicts in rank_pred_dicts]
            print_master(f"Gathered {len(all_pred_dicts)} pred_dicts")

            # 将 all_pred_dicts 按 group 分组计算指标
            grouped_all_pred_dicts = defaultdict(list)
            for item in all_pred_dicts:
                grouped_all_pred_dicts[item.get("group")].append(item)

            score_dict = {}

            # 使用多进程并行评估各个组
            with ProcessPoolExecutor(max_workers=min(os.cpu_count(), len(grouped_all_pred_dicts))) as executor:
                futures = { 
                    executor.submit(
                        evaluate_metrics, 
                        group_pred_dicts,
                        task_config["metrics"] if task_config.get("metrics", None) is not None else ["hit"]
                    ): group
                    for group, group_pred_dicts in grouped_all_pred_dicts.items()
                }
                for future in tqdm(as_completed(futures), total=len(futures), desc="Evaluating groups"):
                    group = futures[future]
                    score_dict.update({
                        f"{group}_{k}" if group is not None else k: v
                        for k, v in future.result().items()
                    })

            formatted = {k: f"{v:.4f}" for k, v in score_dict.items()}
            score_dict["num_pred"] = len(all_pred_dicts)
            score_dict["num_data"] = len(all_pred_dicts)
            print_master(f"Score of {dataset_name}:")
            print_master(formatted)
            print_master(f"Outputting final score to: {score_path}")
            with open(score_path, "w") as f:
                json.dump(score_dict, f, indent=4)

            pred_path = os.path.join(output_dir, f"{dataset_name}_pred.jsonl")
            with open(pred_path, "w") as f:
                for pred in all_pred_dicts:
                    f.write(json.dumps(pred) + '\n')
        
        if dist.is_initialized():
            dist.barrier()


if __name__ == "__main__":
    # test_score_func()

    main()
