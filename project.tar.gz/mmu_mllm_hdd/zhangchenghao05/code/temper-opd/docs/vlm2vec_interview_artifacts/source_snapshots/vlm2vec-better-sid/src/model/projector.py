import json
import os
from typing import Any, Dict, List, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F


PROJECTOR_WEIGHTS_NAME = "projector.pth"
PROJECTOR_CONFIG_NAME = "projector_config.json"


class SwiGLUFFN(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int):
        super().__init__()
        self.w12 = nn.Linear(input_dim, hidden_dim * 2)
        self.w3 = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        x12 = self.w12(x)
        x1, x2 = x12.chunk(2, dim=-1)
        hidden = F.silu(x1) * x2
        return self.w3(hidden)


class MLP(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        x = F.gelu(self.fc1(x))
        x = self.fc2(x)
        return x


class GatedPooling(nn.Module):
    def __init__(self, hidden_dim: int, num_scales: int = 1):
        super().__init__()
        self.num_scales = num_scales
        self.gate_proj = nn.Linear(num_scales * hidden_dim, 1)
        self.out_proj = nn.Linear(num_scales * hidden_dim, hidden_dim)

    def forward(self, x):
        """
        x: (B, N, D)
        return: (B, D)
        """
        # Normalize tokens first
        gate_logits = self.gate_proj(x).squeeze(-1)  # (B, N)
        gate_weights = torch.sigmoid(gate_logits)  # (B, N)
        norm_weights = gate_weights / (torch.sum(gate_weights, dim=-1, keepdim=True) + 1e-8)
        pooled = torch.einsum("bn,bnd->bd", norm_weights, x)  # (B, D)
        pooled = self.out_proj(pooled)  # (B, D)

        return pooled


class AttentionPooling(nn.Module):
    """
    Multi-Head Attention Pooling (MHAP)
    Input: tokens [B, N, D]
    Output: pooled embedding [B, D]
    """
    def __init__(self, hidden_dim: int, num_heads: int = 12, num_scales: int = 1):
        super().__init__()
        assert hidden_dim % num_heads == 0, "hidden_dim must be divisible by num_heads"
        self.num_heads = num_heads
        self.num_scales = num_scales
        self.head_dim = hidden_dim // num_heads

        # Each head has its own learnable query vector
        self.query = nn.Parameter(torch.randn(num_heads, self.head_dim))

        # Linear projections for keys and values
        self.key_proj = nn.Linear(num_scales * hidden_dim, hidden_dim)
        self.value_proj = nn.Linear(num_scales * hidden_dim, hidden_dim)

        # Output projection
        self.out_proj = nn.Linear(hidden_dim, hidden_dim)
        self.scale = self.head_dim ** -0.5

    def forward(self, x):
        B, N, D = x.shape
        K = self.key_proj(x).view(B, N, self.num_heads, -1).permute(0, 2, 1, 3)
        V = self.value_proj(x).view(B, N, self.num_heads, -1).permute(0, 2, 1, 3)
        # Q: expand learnable queries to batch -> [B, H, 1, d]
        Q = self.query.unsqueeze(0).unsqueeze(2).expand(B, -1, 1, -1)
        attn = torch.matmul(Q, K.transpose(-1, -2)) * self.scale
        attn = F.softmax(attn, dim=-1)
        pooled = torch.matmul(attn, V).squeeze(2)
        pooled = pooled.reshape(B, D)
        pooled = self.out_proj(pooled)
        return pooled


class AveragePooling(nn.Module):
    def __init__(self, hidden_dim: int, num_scales: int = 1, mode: str = None, output_dim: int = None, mlp_hidden_dim: int = None):
        super().__init__()
        assert num_scales >= 1
        self.hidden_dim = hidden_dim
        self.num_scales = num_scales
        output_dim = output_dim or hidden_dim
        self.output_dim = output_dim
        self.mode = mode
        self.mlp_hidden_dim = mlp_hidden_dim
        if mode == 'linear':
            self.out_proj = nn.Linear(num_scales * hidden_dim, output_dim)
        elif mode == 'mlp':
            mlp_hidden_dim = mlp_hidden_dim or (num_scales * hidden_dim)
            self.mlp_hidden_dim = mlp_hidden_dim
            self.out_proj = MLP(num_scales * hidden_dim, mlp_hidden_dim, output_dim)

    def forward(self, x: torch.Tensor, target_dim: int = None) -> torch.Tensor:
        """
        Args:
            x: (B, N, D) tokens
            target_dim: optional dynamic output dimension (for evaluation with different dims)
        """
        pooled = x.mean(dim=1)  # (B, D)
        if hasattr(self, 'out_proj'):
            pooled = self.out_proj(pooled)

        # Support dynamic dimension reduction via truncation
        if target_dim is not None and target_dim < pooled.shape[-1]:
            pooled = pooled[..., :target_dim]

        return pooled


class MultiHeadMLPProjector(nn.Module):
    """
    Multi-head MLP projector for simultaneous training of multiple output dimensions.
    Shares the same VLM token hidden states but produces independent per-token outputs.

    Args:
        hidden_dim: Input dimension from VLM
        output_dims: Dict mapping head name to output dimension, e.g., {"64": 64, "32": 32, "16": 16}
        hidden_dims: Optional dict mapping head name to hidden dimension. If None, uses input_dim for all.
        mode: 'mlp' or 'linear' for each head
    """
    def __init__(
        self,
        hidden_dim: int,
        output_dims: Dict[str, int],
        hidden_dims: Dict[str, int] = None,
        mode: str = 'mlp',
        num_scales: int = 1,
    ):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_scales = num_scales
        self.input_dim = num_scales * hidden_dim
        self.output_dims = output_dims
        self.hidden_dims = hidden_dims
        self.mode = mode
        self.heads = nn.ModuleDict()

        for name, out_dim in output_dims.items():
            mlp_hidden = hidden_dims.get(name, self.input_dim) if hidden_dims else self.input_dim
            if mode == 'mlp':
                self.heads[name] = MLP(self.input_dim, mlp_hidden, out_dim)
            else:  # linear
                self.heads[name] = nn.Linear(self.input_dim, out_dim)

    def forward(self, x: torch.Tensor, head_name: str = None) -> Dict[str, torch.Tensor]:
        """
        Args:
            x: (B, N, D) tokens from VLM
            head_name: If specified, only compute this head. Otherwise compute all heads.

        Returns:
            Dict mapping head name to embeddings tensor of shape (B, N, output_dim)
        """
        if head_name is not None:
            if head_name not in self.heads:
                raise KeyError(f"Unknown multi-head projector head `{head_name}`. Available heads: {list(self.heads.keys())}")
            # Compute single head
            return {head_name: self.heads[head_name](x)}

        # Compute all heads
        results = {}
        for name, head in self.heads.items():
            results[name] = head(x)
        return results

    def get_head(self, name: str):
        """Get a specific head by name."""
        return self.heads[name]


def _get_state_dict_path(path: str) -> str:
    if os.path.isdir(path):
        return os.path.join(path, PROJECTOR_WEIGHTS_NAME)
    return path


def get_projector_state_dict_path(path: str) -> str:
    return _get_state_dict_path(path)


def _get_config_path(path: str) -> str:
    if os.path.isdir(path):
        return os.path.join(path, PROJECTOR_CONFIG_NAME)
    return os.path.join(os.path.dirname(path), PROJECTOR_CONFIG_NAME)


def _infer_multi_head_config(state_dict: Dict[str, torch.Tensor]) -> Dict[str, Any]:
    output_dims = {}
    hidden_dims = {}
    input_dim = None
    mode = "mlp"
    for key, value in state_dict.items():
        parts = key.split(".")
        if len(parts) >= 4 and parts[0] == "heads" and parts[-2:] == ["fc1", "weight"]:
            hidden_dims[parts[1]] = int(value.shape[0])
            input_dim = int(value.shape[1])
        elif len(parts) >= 4 and parts[0] == "heads" and parts[-2:] == ["fc2", "weight"]:
            output_dims[parts[1]] = int(value.shape[0])
        elif len(parts) == 3 and parts[0] == "heads" and parts[-1] == "weight":
            mode = "linear"
            output_dims[parts[1]] = int(value.shape[0])
            input_dim = int(value.shape[1])

    if input_dim is None or not output_dims:
        raise ValueError("Unable to infer multi-head projector config from state_dict.")

    return {
        "pooling": "multi_head_mlp",
        "projector_type": "multi_head_mlp",
        "hidden_dim": input_dim,
        "num_scales": 1,
        "output_dims": output_dims,
        "hidden_dims": hidden_dims or None,
        "mode": mode,
        "input_normalize": True,
        "output_normalize": True,
    }


def _infer_average_pooling_config(state_dict: Dict[str, torch.Tensor]) -> Dict[str, Any]:
    if "out_proj.fc1.weight" in state_dict and "out_proj.fc2.weight" in state_dict:
        fc1 = state_dict["out_proj.fc1.weight"]
        fc2 = state_dict["out_proj.fc2.weight"]
        return {
            "pooling": "mlp",
            "projector_type": "average_pooling",
            "hidden_dim": int(fc1.shape[1]),
            "num_scales": 1,
            "mode": "mlp",
            "output_dim": int(fc2.shape[0]),
            "mlp_hidden_dim": int(fc1.shape[0]),
            "input_normalize": True,
            "output_normalize": True,
        }
    if "out_proj.weight" in state_dict:
        weight = state_dict["out_proj.weight"]
        return {
            "pooling": "linear",
            "projector_type": "average_pooling",
            "hidden_dim": int(weight.shape[1]),
            "num_scales": 1,
            "mode": "linear",
            "output_dim": int(weight.shape[0]),
            "input_normalize": True,
            "output_normalize": True,
        }
    raise ValueError("Unable to infer average-pooling projector config from state_dict.")


def infer_projector_config_from_state_dict(state_dict: Dict[str, torch.Tensor]) -> Dict[str, Any]:
    if any(key.startswith("heads.") for key in state_dict):
        return _infer_multi_head_config(state_dict)
    return _infer_average_pooling_config(state_dict)


def projector_config(
    projector: nn.Module,
    pooling: str,
    input_normalize: bool = False,
    output_normalize: bool = True,
) -> Dict[str, Any]:
    if isinstance(projector, MultiHeadMLPProjector):
        return {
            "pooling": pooling,
            "projector_type": "multi_head_mlp",
            "hidden_dim": int(projector.hidden_dim),
            "num_scales": int(projector.num_scales),
            "output_dims": {name: int(dim) for name, dim in projector.output_dims.items()},
            "hidden_dims": projector.hidden_dims,
            "mode": projector.mode,
            "input_normalize": bool(input_normalize),
            "output_normalize": bool(output_normalize),
        }
    if isinstance(projector, AveragePooling):
        return {
            "pooling": pooling,
            "projector_type": "average_pooling",
            "hidden_dim": int(projector.hidden_dim),
            "num_scales": int(projector.num_scales),
            "mode": projector.mode,
            "output_dim": int(projector.output_dim),
            "mlp_hidden_dim": projector.mlp_hidden_dim,
            "input_normalize": bool(input_normalize),
            "output_normalize": bool(output_normalize),
        }
    raise ValueError(f"Standalone projector export is not supported for {type(projector).__name__}.")


def build_projector_from_config(config: Dict[str, Any]) -> nn.Module:
    projector_type = config.get("projector_type")
    if projector_type == "multi_head_mlp" or config.get("pooling") == "multi_head_mlp":
        return MultiHeadMLPProjector(
            hidden_dim=int(config["hidden_dim"]),
            output_dims={str(name): int(dim) for name, dim in config["output_dims"].items()},
            hidden_dims=config.get("hidden_dims"),
            mode=config.get("mode", "mlp"),
            num_scales=int(config.get("num_scales", 1)),
        )
    if projector_type == "average_pooling" or config.get("pooling") in {"linear", "mlp"}:
        return AveragePooling(
            hidden_dim=int(config["hidden_dim"]),
            num_scales=int(config.get("num_scales", 1)),
            mode=config.get("mode"),
            output_dim=config.get("output_dim"),
            mlp_hidden_dim=config.get("mlp_hidden_dim"),
        )
    raise ValueError(f"Unsupported standalone projector config: {config}")


def save_projector_artifacts(
    projector: nn.Module,
    output_dir: str,
    pooling: str,
    input_normalize: bool = False,
    output_normalize: bool = True,
) -> Dict[str, Any]:
    os.makedirs(output_dir, exist_ok=True)
    torch.save(projector.state_dict(), os.path.join(output_dir, PROJECTOR_WEIGHTS_NAME))
    config = projector_config(
        projector,
        pooling=pooling,
        input_normalize=input_normalize,
        output_normalize=output_normalize,
    )
    with open(os.path.join(output_dir, PROJECTOR_CONFIG_NAME), "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, sort_keys=True)
        f.write("\n")
    return config


def save_projector_state_dict_artifacts(
    state_dict: Dict[str, torch.Tensor],
    output_dir: str,
    config: Dict[str, Any] = None,
    config_overrides: Dict[str, Any] = None,
) -> Dict[str, Any]:
    os.makedirs(output_dir, exist_ok=True)
    torch.save(state_dict, os.path.join(output_dir, PROJECTOR_WEIGHTS_NAME))
    if config is None:
        config = infer_projector_config_from_state_dict(state_dict)
    config = dict(config)
    if config_overrides:
        config.update(config_overrides)
    with open(os.path.join(output_dir, PROJECTOR_CONFIG_NAME), "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, sort_keys=True)
        f.write("\n")
    return config


def load_projector_artifacts(path: str, map_location: str = "cpu") -> Tuple[nn.Module, Dict[str, Any]]:
    state_dict_path = _get_state_dict_path(path)
    config_path = _get_config_path(path)
    state_dict = torch.load(state_dict_path, map_location=map_location)
    if os.path.exists(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
    else:
        config = infer_projector_config_from_state_dict(state_dict)
    projector = build_projector_from_config(config)
    projector.load_state_dict(state_dict)
    projector.eval()
    return projector, config


def apply_projector(
    projector: nn.Module,
    embeddings: torch.Tensor,
    config: Dict[str, Any],
    head_name: str = None,
    normalize_input: bool = None,
    normalize_output: bool = None,
):
    if normalize_input is None:
        normalize_input = bool(config.get("input_normalize", False))
    if normalize_output is None:
        normalize_output = bool(config.get("output_normalize", True))

    x = F.normalize(embeddings, p=2, dim=-1) if normalize_input else embeddings
    if isinstance(projector, MultiHeadMLPProjector):
        output = projector(x, head_name=head_name)
        if normalize_output:
            output = {name: F.normalize(value, p=2, dim=-1) for name, value in output.items()}
        return output

    if isinstance(projector, AveragePooling) and x.dim() == 2:
        x = x.unsqueeze(1)
    output = projector(x)
    if normalize_output:
        output = F.normalize(output, p=2, dim=-1)
    return output
