# VLM2Vec Goods / Unified Embedding & Better SID 项目总结

本文按旧版项目总结文档的结构，重新梳理当前 VLM2Vec goods 统一 embedding 与 Better SID / XSeq 两条线。内容来源包括：

- 当前线上拉取后的本地代码核对。
- 已有交接摘要中的历史实验信息。
- 当前代码缺失但历史摘要明确提到的本地实验资产。

需要特别注意：原 code 目录曾被误删，现在 `/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec` 是重新从线上拉取并切回 `goods-strong300-emb-compare` 的版本，因此部分历史本地实验文件仍不在当前 checkout 中。本文对这类内容统一标为“待恢复”或“历史摘要记录”，避免误认为当前文件已经存在。

## 一、探索：检索 + 生成联合训练

### 1.1 Overview

本项目基于 VLM2Vec 技术路线，在 Qwen2.5-Omni / Qwen-VL 系列多模态模型上训练压缩 token 表征。当前主线不是单纯图文检索，而是把 goods 检索、OpenQA/SID 式生成压缩、多槽位 embedding 和低维 projector 放到同一个 codebase 中联合探索。

核心目标：

- goods 检索表征：通过 `retrieval_goods` 对比学习训练 item/item、item/photo 等 pair 数据。
- 压缩生成能力：通过 `openqa` 任务，让少量 compression tokens 承载可生成、可还原的多模态信息。
- 多槽位 embedding：支持 `avg`、`none + slot_aligned`、`maxsim_topk`、`attn`、`flatten_mlp64`、`multi_head_mlp` 等 pooling / similarity / projector 变体。
- Better SID / XSeq：参考 Revela 的 in-batch attention 思路，在 OpenQA/SID 训练时把相似样本作为可注意的上下文，让生成 loss 沿样本相似度 / slot 相似度路径回传，给 embedding 学习提供额外梯度。
- 二阶段训练和 projector 重训：先训练主模型与压缩表征，再快速训练低维输出 head。

参考路线：

- VLM2Vec paper: `https://arxiv.org/pdf/2410.05160`
- 原始代码: `https://github.com/TIGER-AI-Lab/VLM2Vec/tree/main`
- MMEB benchmark: `https://huggingface.co/spaces/TIGER-Lab/MMEB-Leaderboard`
- MMEB train: `https://huggingface.co/datasets/TIGER-Lab/MMEB-train`
- MMEB test: `https://huggingface.co/datasets/ziyjiang/MMEB_Test_Instruct`

当前本地代码状态：

- Goods / unified embedding repo: `/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec`
- 当前分支: `goods-strong300-emb-compare`
- 当前 HEAD: `dd65a1f repeat set`
- 当前状态: 跟踪 `origin/goods-strong300-emb-compare`；已恢复 0429 curated yaml，并让 goods two-stage 脚本支持 ret+OpenQA 参数透传。
- Better SID / XSeq repo: `/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec-better-sid`
- 当前分支: `musid`
- 当前 HEAD: `4e25f06 feat: configure xseq token scopes`
- 当前状态: 工作树干净。

历史交接摘要与当前 checkout 未对齐的点：

- `goods-strong300-emb-compare` 已经切回，HEAD 与 `origin/goods-strong300-emb-compare` 均为 `dd65a1f repeat set`。
- 摘要中提到的 `AGENTS.md` 当前 repo 根目录不存在。
- 摘要中提到的 `src/cached_projector/`、`experiments/hetu/cached_projector/` 当前 `vlm2vec` checkout 中不存在。
- `experiments/hetu/train_goods_0429_stage1_retqa_curated.yaml` 和 `train_goods_0429_stage2_retqa_curated.yaml` 已恢复；`run_goods_0429_distinct_slotalign_retqa_twostage_4node_commands.txt` 当前仍不存在。
- 摘要中提到的 `experiments/hetu/sp_padding_selected3_emb_analysis_report.txt` 当前 checkout 中不存在。

当前可确认存在的关键文件：

- Goods two-stage: `experiments/hetu/train_goods_0402_twostage.sh`
- Goods strong300 yaml: `experiments/hetu/train_goods_strong300_omni.yaml`
- Goods strong300 + OneRec OpenQA yaml: `experiments/hetu/train_goods_strong300_onerec_openqa.yaml`
- Goods 0429 stage1 curated ret+OpenQA yaml: `experiments/hetu/train_goods_0429_stage1_retqa_curated.yaml`
- Goods 0429 stage2 curated ret+OpenQA yaml: `experiments/hetu/train_goods_0429_stage2_retqa_curated.yaml`
- Goods embedding inference: `experiments/hetu/eval_goods_inference_items_emb.sh`
- Multi-head downsampler: `experiments/hetu/train_multihead_downsampler.sh`
- Better SID multitask script: `/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec-better-sid/experiments/musid/scripts/train_musid_multitask.sh`
- XSeq 3-task / 2-task / baseline scripts: `/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec-better-sid/experiments/musid/scripts/`
- XSeq implementation: `/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec-better-sid/src/xseq.py`

### 1.2 详细实现

#### 1.2.1 环境与路径

Goods / unified embedding:

- Repo: `/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec`
- 推荐 torchrun: `/mmu_mllm_hdd/zhangchenghao05/envs/vlm2vec/bin/torchrun`
- Base model 默认路径: `/mmu_mllm_hdd/zhangchenghao05/hetu_next/LLaMA-Factory/saves/qwen2_5omni-3b/sft_datav2/merge/`
- HF cache: `/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface`
- HF endpoint: `https://hf-mirror.com`
- 默认输出根目录: `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs`

Better SID / XSeq:

- Repo: `/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec-better-sid`
- 推荐先激活 VLM2Vec 训练环境，再运行脚本。
- 多机默认 master: `10.86.17.226`
- 默认 `NNODES=2`，`GPUS_PER_NODE=8`
- 默认输出根目录: `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs`

#### 1.2.2 数据配置

Goods strong300 pair:

```yaml
Goods_Strong300:
  dataset_parser: hetu_ret
  dataset_name: Goods_Strong300
  task_type: retrieval_goods
  cls_type: goods
  dataset_path: /mmu_vcg_wjc_hdd/duyong/code/llm_rec_embedding/product_pair_select/train_info_pair/train/强强300.jsonl
```

当前存在文件：

- `experiments/hetu/train_goods_strong300_omni.yaml`
- `experiments/hetu/train_goods_strong300_onerec_openqa.yaml`

已恢复的 0429 二阶段 goods curated 数据配置：

- Stage1 yaml: `experiments/hetu/train_goods_0429_stage1_retqa_curated.yaml`
- Stage1 retrieval: `IA_Pair_0429`
- Stage1 OpenQA: `Hetu_Goods_Compress_seed`、`Hetu_Goods_Compress_self`、`Hetu_Goods_Compress_gpt_caption_short`、`Hetu_Goods_Compress_gpt_caption_long`、`ParallelSID_Item_*`、`ParallelSID_Photo_Item_*`、`ParallelSID_Photo_Author_Item_*`、`ParallelSID_Photo_*`
- Stage2 yaml: `experiments/hetu/train_goods_0429_stage2_retqa_curated.yaml`
- Stage2 retrieval: `IA_Pair_0429`、`LF_Pair_0429`、`XL_Pair_0429`、`LF_I2P_Pair_0429`
- Stage2 OpenQA: 同 Stage1 curated OpenQA，继续保留检索强相关和中等同域部分。
- 排除项: `Hetu_Videos_Compress_*` 泛短视频理解数据，以及纯 `ParallelSID_Author_*` 主播画像数据。

OpenQA / SID 数据来源：

- `/mmu_mllm_hdd_2/luoyuxiao/Data/hetu_v5/...`
- `/mmu_mllm_hdd/zhangzejian/parallel_sid/scripts/gemini_client/gemini_results/...`
- `/mmu_mllm_hdd/zhangchenghao05/data/onerec-think-v2/...`

Better SID / XSeq yaml:

- `experiments/musid/yaml/musid_openqa.yaml`
- `experiments/musid/yaml/musid_xseq_openqa.yaml`
- `experiments/musid/yaml/musid_xseq_openqa_mix.yaml`
- `experiments/musid/yaml/musid_xseq_ret_openqa.yaml`
- `experiments/musid/yaml/musid_train_hetu_orthogonal.yaml`

#### 1.2.3 Compression Tokens

Goods 主线默认使用 4 个 compression tokens:

```bash
TOTAL_COMPRESS_TOKENS=4
VLM_COMPRESS_TOKEN_MODE=distinct
```

当前代码中 `TOTAL_COMPRESS_TOKENS` 由环境变量控制，processor 在 `src/model/processor.py` 中读取。历史实验中也做过 `repeat_first` / `distinct` 的 SP padding 对比。

注意：

- 旧版 public/MMEB 训练中默认 compression tokens 可能是 16。
- 当前 goods 和 musid 主线多用 4。
- `VLM_COMPRESS_TOKEN_MODE=distinct` 是 0429 goods 主线推荐。当前代码合法值是 `distinct` 或 `repeat_first`；历史记录里写的 `different` 应按 `distinct` 理解。

#### 1.2.4 检索 + OpenQA 混训

历史 goods 主线配置：

```bash
TASK_TYPES="retrieval_goods openqa"
CLS_TYPES="video goods"
DATA_WEIGHTS="1 4"
LOSS_WEIGHTS="1 0.5"
GRADIENT_ACCUMULATION_STEPS=5
```

语义：

- retrieval batch 用 goods pair 训练 contrastive loss。
- openqa batch 用 Hetu / OneRec / ParallelSID 数据训练生成压缩。
- `DATA_WEIGHTS` 控制任务 batch 读取比例。
- `LOSS_WEIGHTS` 控制检索 loss 与 OpenQA loss 的相对权重。

当前 `experiments/hetu/train_goods_0402_twostage.sh` 默认仍是 `retrieval_goods`，但已恢复 `TASK_TYPES`、`CLS_TYPES`、`DATA_WEIGHTS`、`LOSS_WEIGHTS`、`GRADIENT_ACCUMULATION_STEPS`、`TOTAL_QA_BATCH_SIZE`、`QA_INTERLEAVE_BATCH_SIZE` 的环境变量透传；因此可用同一脚本跑 0429 ret+OpenQA curated yaml。

Better SID 主脚本 `train_musid_multitask.sh` 支持：

- `retrieval`
- `openqa`
- `xseq_openqa`

默认使用：

```bash
--pooling none
--similarity_type slot_aligned
--split_layer 36
--orthogonal_loss $ORTHO_W
--orthogonal_loss_openqa $ORTHO_W
--hsic_loss 0.0
```

#### 1.2.5 Pooling / Similarity 变体

Goods two-stage 当前脚本支持：

- `VARIANT=mean`
  - `POOLING=avg`
  - `SIMILARITY_TYPE=dense`
  - orthogonal loss 关闭
- `VARIANT=maxtop4_ortho`
  - `POOLING=none`
  - `SIMILARITY_TYPE=maxsim_topk`
  - `MAXSIM_TOPK=4`
  - orthogonal loss 开启
- `VARIANT=slotalign_ortho`
  - `POOLING=none`
  - `SIMILARITY_TYPE=slot_aligned`
  - orthogonal loss 开启

历史摘要记录但当前需核对/恢复的变体：

- `attnpool_ortho`
- `flatten_mlp64`
- `multi_head_mlp` 的完整 stage2 命令包

当前代码中可确认 `multi_head_mlp`、`multi_head_dims`、`multi_head_weights`、standalone head 保存、multi-head orthogonal / volume 权重等参数存在。

当前代码也支持 MRL / Matryoshka 表征学习，但它是独立于 `multi_head_mlp` 的前缀维度截断训练，不是独立多 head projector。详见下文 `1.2.8`。

#### 1.2.6 Orthogonal / Volume / HSIC

Goods 历史主线常用：

```bash
ORTHO_W=0.5
ORTHO_M=0.0
ORTHO_WARMUP_STEPS=100
ORTHOGONAL_DIAG_STEPS=50
LOAD_DIAG_STEPS=50
```

Better SID 默认：

```bash
ORTHO_W=0.5
ORTHO_M=0.0
O_WARMUP_STEPS=50
--hsic_loss 0.0
--hsic_diag_steps 20
```

注意：

- HSIC 在当前 musid 主线脚本里默认是诊断相关，不是训练约束。
- 如果要启用 HSIC 训练，需要显式调整 `--hsic_loss`。
- monitor-only retrieval 实验如果 `LOSS_WEIGHTS="0 0.5"`，仍需要确认 retrieval batch 是否会引入 auxiliary loss，避免 ablation 不干净。

#### 1.2.7 Better SID / XSeq

Better SID / XSeq 的目标不是在推理期依赖外部样本做生成增强，也不只是让 slot “可借鉴”。更准确的目标是：参考 Revela 的 in-batch attention 思路，在训练期把 batch 内或 memory 中的相似样本作为 attention context，让 OpenQA/SID 的 token loss 通过 `sample_gate` / `sample_cos` 等相似度权重回传到当前样本的 embedding / slot 表征，从而给检索 embedding 提供额外的相似度梯度。

直观理解：

- 对比学习只在 embedding 空间直接拉近正样本、推远负样本。
- XSeq 希望让“哪些样本应该相似”也参与生成路径：当前样本对相似样本的 hidden slots 做 attention，生成 loss 会惩罚错误的相似度分配。
- 最终要服务的是静态 embedding / slot 表征；推理时不应默认要求外部 memory 或跨样本 attention。

核心实现：

- Memory bank: `src/xseq.py`
- Trainer 集成: `src/trainer.py`
- Qwen2.5-Omni attention 注入: `src/model/vlm_backbone/qwen2_5_omni/modeling_qwen2_5_omni.py`

当前 XSeq 训练流程：

1. 当前 batch 正常 forward，得到 local loss、pooled embedding、4 个 slot tokens 和指定层 hidden slots。
2. 用当前样本 embedding / slot 与候选样本计算相似度；当前实现从本地 memory bank 取 top-k，设计目标上更接近 Revela 的 BxB in-batch attention。
3. 构造 `xseq_state`，包括 `sample_gate`、`sample_cos`、`external_slots`、`token_mask`、`cls_indices`。其中 `sample_gate/sample_cos` 是把生成 loss 接回 embedding 相似度的关键路径。
4. 在指定 decoder layers 注入 external slots attention，再跑一次 forward，使用 xseq loss 作为训练 loss。
5. 记录 local-vs-xseq loss delta、bank size、candidate count、slot 相关性、相似度分布等诊断。
6. 将当前样本 embedding / slot 写入 memory bank，作为后续样本的 stop-grad 候选上下文。

当前限制：

- 当前代码是 memory-bank 版本，不是严格的纯 in-batch attention；bank 是本地进程级，不是跨 rank / 跨节点全局共享。
- bank entries 是 stop-grad，top-k 选择也是离散的；梯度主要回到当前 query 分支的 embedding / slot，以及由 `sample_gate/sample_cos` 控制的 attention 注入路径。
- xseq 会多一次 local forward 和一次 xseq forward，训练成本高。
- 是否能稳定提升最终静态 embedding，需要用离线 retrieval 指标验证；SID/OpenQA 生成质量可以作为辅助观察，但不是这条线的唯一目标。

Token scope:

```bash
--xseq_apply_to q
```

当前支持：

- `c` / `chorus` / `slot`
- `q` / `question` / `query`
- `a` / `answer`
- `none` / `off` / `false`

#### 1.2.8 MRL / Matryoshka

当前 `goods-strong300-emb-compare` 分支支持 MRL / Matryoshka Representation Learning。

参数入口：

```bash
--matryoshkas 2048 1024 512 256 128 64 32 16 8
```

核心实现：

- 参数定义在 `src/arguments.py` 的 `TrainingArguments.matryoshkas`。
- `src/trainer.py` 会把 `self.args.matryoshkas` 传给 `SimpleContrastiveLoss` / `DistributedContrastiveLoss`。
- `src/loss.py` 中先计算完整维度 contrastive loss，再对每个 `dim` 做 `x[..., :dim]`、`y[..., :dim]`、`neg[..., :dim]` 的前缀截断并累加 CE loss。
- `eval_i2i.py` 支持按 `--matryoshkas` 中的维度截断 embedding 后重新计算检索结果。

已有脚本：

- 训练: `experiments/hetu/train_korus-qwen2omni-3B_hetu_hetu_videoonly_matryoshkas.sh`
- 训练: `experiments/hetu/train_goodonly_v2.sh`
- 训练: `experiments/hetu/train_goodonly_v2_4node.sh`
- 评测: `experiments/hetu/eval_mrl.sh`
- 评测透传: `experiments/hetu/eval_korus_qwen2omni.sh`

当前限制：

- `experiments/hetu/train_goods_0402_twostage.sh` 未默认启用 `--matryoshkas`。
- MRL 当前是多维度 loss 等权累加，没有 per-dim loss weight。
- 现有 MRL 脚本主要用于 `pooling=avg` 的 dense 单向量路线。
- `pooling=none + slot_aligned/maxsim` 理论上也会按最后一维截断，但当前没有针对 goods 4-slot 主线固化过 MRL 命令和评测表。
- `multi_head_mlp` 是独立多 head 低维 projector，不等同于 MRL；前者各 head 独立参数，后者共享前缀维度。

#### 1.2.9 Cached Projector

历史摘要记录新增路径：

```text
src/cached_projector/
experiments/hetu/cached_projector/
```

目标：

1. 冻结模型，用 `--pooling none` 缓存 pre-projector chorus tokens。
2. 从缓存读取 `[query_tokens, target_tokens]`，只训练低维 projector。
3. 快速比较 64/32/16 维输出质量。

当前恢复状态：

- 上述目录在当前线上拉取版 `vlm2vec` 中不存在。
- 需要从历史本地副本、远程分支、日志或同事机器恢复。
- 恢复后应补一张 compute-quality 表：cache 大小、训练耗时、64/32/16 维指标、与端到端 projector 差距。

#### 1.2.10 模型训练入口

Goods two-stage:

```bash
cd /mmu_mllm_hdd/zhangchenghao05/code/vlm2vec
bash experiments/hetu/train_goods_0402_twostage.sh <NNODES> <NODE_RANK> \
  STAGE=full \
  VARIANT=slotalign_ortho \
  TOTAL_COMPRESS_TOKENS=4
```

脚本负责：

- 多机 torchrun 参数。
- NCCL 参数。
- base model / output root / yaml 配置。
- `VARIANT` 到 pooling / similarity / orthogonal 的映射。
- stage1 / stage2 / full 三种执行模式。
- batch size 与 world size 校验。

MRL / Matryoshka 训练示例：

```bash
cd /mmu_mllm_hdd/zhangchenghao05/code/vlm2vec
bash experiments/hetu/train_korus-qwen2omni-3B_hetu_hetu_videoonly_matryoshkas.sh <NNODES> <NODE_RANK>
```

Goods-only MRL 训练示例：

```bash
cd /mmu_mllm_hdd/zhangchenghao05/code/vlm2vec
bash experiments/hetu/train_goodonly_v2.sh <NNODES> <NODE_RANK>
```

这些脚本会传入 `--matryoshkas 2048 1024 512 256 128 64 32 16 8`，但它们不是 0402/0429 goods two-stage 主线默认入口。

Better SID 三任务:

```bash
cd /mmu_mllm_hdd/zhangchenghao05/code/vlm2vec-better-sid
MASTER_ADDR=10.86.17.226 NODE_RANK=<0_or_1> CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 \
bash experiments/musid/scripts/train_musid_xseq_ret_openqa_3task.sh
```

Better SID 两任务:

```bash
cd /mmu_mllm_hdd/zhangchenghao05/code/vlm2vec-better-sid
MASTER_ADDR=10.86.17.226 NODE_RANK=<0_or_1> CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 \
bash experiments/musid/scripts/train_musid_xseq_openqa_2task.sh
```

Better SID baseline:

```bash
cd /mmu_mllm_hdd/zhangchenghao05/code/vlm2vec-better-sid
MASTER_ADDR=10.86.17.226 NODE_RANK=<0_or_1> CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 \
bash experiments/musid/scripts/train_musid_baseline_ret_openqa_ortho1.sh
```

注意：本文只是整理命令，不代表已经启动训练。启动训练前需要确认机器、数据路径、base model、HF cache、NCCL 环境和输出目录。

#### 1.2.11 模型评测 / 推理入口

Goods embedding 推理:

```bash
cd /mmu_mllm_hdd/zhangchenghao05/code/vlm2vec
RUN_NAME=<run_name> POOLING=<pooling> SIMILARITY_TYPE=<similarity_type> \
bash experiments/hetu/eval_goods_inference_items_emb.sh
```

小样本 smoke:

```bash
SMOKE_REPORT=true NUM_SAMPLE_PER_SUBSET=10 \
RUN_NAME=<run_name> POOLING=<pooling> SIMILARITY_TYPE=<similarity_type> \
bash experiments/hetu/eval_goods_inference_items_emb.sh
```

脚本要求显式指定：

- `RUN_NAME`
- `POOLING`
- `SIMILARITY_TYPE`

MRL / Matryoshka 评测:

```bash
cd /mmu_mllm_hdd/zhangchenghao05/code/vlm2vec
bash experiments/hetu/eval_mrl.sh <NNODES> <NODE_RANK>
```

该脚本通过 `matryoshkas="512 128"` 透传给 `eval_korus_qwen2omni.sh`，最终由 `eval_i2i.py` 对 embedding 做前缀维度截断并重算检索结果。

Better SID 当前主要依赖训练过程中的 proxy 与诊断指标：

- `retrieval_Acc@1`
- `retrieval_Acc@2`
- `retrieval_Acc@3`
- `retrieval_Acc@4`
- `retrieval_Acc@5`
- `retrieval_false_neg_rate`
- `xseq/bank_size`
- `xseq/candidate_count_mean`
- `xseq/sample_gate_mean`
- `xseq/sample_cos_mean`
- `xseq/loss_local_only`
- `xseq/loss_with_xseq`
- `xseq/loss_delta_*`
- `xseq/layer_*_hsic_mean`
- `xseq/layer_*_slot_offdiag_abs_mean`
- `xseq/layer_*_cca_mean`
- `xseq/layer_*_conditional_entropy`

待补齐：

- OpenQA/SID 生成质量离线评测脚本。
- goods 全量离线 recall / NDCG / AUC。
- xseq vs baseline 的正式指标表。

#### 1.2.12 重要代码模块

训练入口：

- `train.py`
- `src/trainer.py`

模型与 processor：

- `src/model/model.py`
- `src/model/processor.py`
- `src/model/projector.py`
- `src/model/utils.py`
- `src/model/vlm_backbone/qwen2_5_omni/`
- `src/model/vlm_backbone/qwen2_5_vl_compression/`

数据：

- `src/data/dataset/hetu_ret_dataset.py`
- `src/data/dataset/hetu_compress_dataset.py`
- `src/data/loader/mixed_dataset.py`
- `src/data/collator/train_collator.py`
- `src/data/collator/eval_collator.py`

损失与相似度：

- `src/loss.py`
- dense contrastive
- `maxsim`
- `maxsim_topk`
- `slot_aligned`
- orthogonal / HSIC 辅助逻辑

GradCache：

- `src/grad_cache/grad_cache.py`
- `src/grad_cache/loss.py`

Better SID / XSeq：

- `/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec-better-sid/src/xseq.py`
- `/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec-better-sid/src/trainer.py`
- `/mmu_mllm_hdd/zhangchenghao05/code/vlm2vec-better-sid/src/model/vlm_backbone/qwen2_5_omni/modeling_qwen2_5_omni.py`

### 1.3 模型结果

#### 1.3.1 已确认的 embedding 几何结论

以下来自历史摘要中记录的 `experiments/hetu/sp_padding_selected3_emb_analysis_report.txt`。该报告文件当前 checkout 中待恢复。

- `repeat0_ia checkpoint-400` 在健康实验中 sample-level similarity 最低，平均 `pooled=0.1328`、`maxsim=0.3984`。
- `distinct_ia checkpoint-400` token decorrelation 最强，平均 `same-token=0.0043`、`internal-max=0.0351`。
- `repeat0_4src checkpoint-200` 明显 collapse，平均 `same-token=0.3781`、`internal-max=0.9954`。
- `repeat0_4src checkpoint-400` 修复了 within-sample collapse，但 sample-level similarity 仍较高，平均 `pooled=0.2875`、`maxsim=0.5967`。
- 历史报告推荐默认使用 `repeat0_ia checkpoint-400`；如果更重视 token-slot 正交性，则考虑 `distinct_ia checkpoint-400`。

#### 1.3.2 已探索实验轴

Goods / unified embedding:

- SP padding: `repeat_first` vs `distinct`
- 数据源: IA only vs IA/LF/XL/LF_I2P 混合
- similarity: `maxsim_topk` vs `slot_aligned`
- pooling: `avg`、`none`、`attn`、`flatten_mlp64`
- auxiliary loss: orthogonal / volume / HSIC
- projector: 端到端 projector vs cached projector
- stage 策略: from base stage2、stage1+stage2 full、stage2-only

Better SID / XSeq:

- baseline: `retrieval + openqa`
- 2-task xseq: `openqa + xseq_openqa`
- 3-task xseq: `retrieval + openqa + xseq_openqa`
- openqa-only + retrieval Acc monitor
- `ORTHO_W=0.5`、`ORTHO_W=0.8`、baseline 默认 `ORTHO_W=1.0`
- xseq layers: `16 18 20 22`、`28 32 36`
- xseq topk: `4`
- memory bank: `512`、`2048`

#### 1.3.3 当前最大结果缺口

当前最大的 gap 是没有形成稳定的结果闭环：

```text
训练配置 -> checkpoint -> 固定评测 -> 指标表 -> 推荐版本 -> 推理/服务形态
```

待补齐：

- 0429 goods 主线最终推荐 checkpoint。
- 0429 stage2 候选 checkpoint 路径已在输出目录确认，但尚未形成最终推荐版本。
- goods 全量离线 recall / NDCG / AUC / 业务指标。
- `avg` / `slot_aligned` / `attnpool` / `flatten_mlp64` 的统一评测表。
- cached projector 64/32/16 维输出质量表。
- 2-task xseq、3-task xseq、baseline 的 retrieval / embedding 指标对比，用来验证相似度梯度是否真的有效。
- `retrieval_Acc@K` 的数值表。
- xseq 是否稳定改善最终 embedding，而不是只改善训练期 xseq loss；OpenQA/SID 生成质量作为辅助观察。
- 是否已有最终模型上线，以及模型 ID / 服务 / 工作流。

### 1.4 迭代与扩展

#### 1.4.1 代码恢复优先级

P0: 恢复本地实验资产索引

- 找回或重建 `docs/plan`。
- 0429 retqa curated yaml 已恢复；仍需找回或重建完整 4 节点命令文件。
- 找回 `sp_padding_selected3_emb_analysis_report.txt`。
- 当前继续开发基线已明确为 `goods-strong300-emb-compare` / `dd65a1f repeat set`；后续补救文件应落在该分支或从该分支新建恢复分支。

P1: 恢复 cached projector

- 找回 `src/cached_projector/`。
- 找回 `experiments/hetu/cached_projector/`。
- 历史 cache 和 projector 输出已在 `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/cached_projector/` 找到，但当前 checkout 缺源码和实验入口。
- 跑 smoke test，确认 cache feature 与 projector train 能通。
- 写 compute-quality 表。

P2: 固化统一评测

- goods 全量 inference items 固定一份。
- 每个 checkpoint 统一跑 `avg` / `slot_aligned` / `maxsim_topk` / low-dim projector。
- 统一输出指标和 embedding 几何统计。

P3: Better SID 正式化

- 对 baseline / 2-task xseq / 3-task xseq 做统一 OpenQA/SID 生成评测。
- 对 `xseq_layers`、`xseq_apply_to`、`xseq_topk`、`xseq_bank_size` 做 ablation。
- 分析 xseq loss delta 的样本级收益和负收益。

#### 1.4.2 添加新数据集

建议流程：

1. 将数据处理为 jsonl 或 parquet，字段尽量对齐当前 `hetu_ret` / `hetu_compress` / MMEB 格式。
2. 在 `src/data/dataset/` 下增加或复用 dataset parser。
3. 在 `experiments/hetu/` 或 `experiments/musid/yaml/` 创建 yaml。
4. 明确任务类型：`retrieval_goods`、`retrieval`、`openqa`、`xseq_openqa`。
5. 明确 `cls_type`，特别是 goods / video 混训时是否要共享 compression token slot。

#### 1.4.3 添加新模型

建议流程：

1. 在 `src/model/vlm_backbone/` 加入新模型 config / model / processor。
2. 在 `src/model/model.py` 中加入 build 和 load 逻辑。
3. 在 `src/model/processor.py` 中加入 compression processor 处理逻辑。
4. 确认 `sep_indices`、`position_ids`、compression mask、纯文本/多模态混 batch 逻辑。
5. 如果要支持 xseq，需要模型 text decoder 支持 `configure_xseq` 和 attention 层 `xseq_state`。

## 二、业务：LLM Embedding 落地应用

### 2.1 Goods 统一 embedding

本线对应业务侧 goods embedding，而不是旧版单纯 MMEB 图文检索。目标是给商品、商品图、商品描述等构建统一 embedding，支持 item/item、item/photo、info restore 和后续低维向量服务。

#### 2.1.1 离线数据

当前强相关 pair:

- `/mmu_vcg_wjc_hdd/duyong/code/llm_rec_embedding/product_pair_select/train_info_pair/train/强强300.jsonl`

历史 0429 数据:

- IA pair
- LF pair
- XL pair
- LF I2P pair
- goods compression seed/self/gpt caption
- ParallelSID goods 数据

待补齐：

- 每份数据的规模、来源、过滤规则。
- false negative 过滤规则。
- hard negative 构造规则。
- train/eval/test split 的固定版本。

#### 2.1.2 模型训练

当前可用入口:

```bash
bash experiments/hetu/train_goods_0402_twostage.sh
```

历史推荐配置:

```bash
STAGE=full
VARIANT=slotalign_ortho
TOTAL_COMPRESS_TOKENS=4
VLM_COMPRESS_TOKEN_MODE=distinct
TASK_TYPES="retrieval_goods openqa"
CLS_TYPES="video goods"
TOTAL_RETRV_BATCH_SIZE=1024
TOTAL_QA_BATCH_SIZE=128
DATA_WEIGHTS="1 4"
LOSS_WEIGHTS="1 0.5"
GRADIENT_ACCUMULATION_STEPS=5
INTERLEAVE_BATCH_SIZE=1
QA_INTERLEAVE_BATCH_SIZE=1
STAGE1_MAX_STEPS=10000
STAGE2_MAX_STEPS=4000
LR=5e-5
WARMUP_STEPS=100
ORTHO_W=0.5
ORTHO_M=0.0
ORTHO_WARMUP_STEPS=100
```

`INTERLEAVE_BATCH_SIZE=1` 和 `QA_INTERLEAVE_BATCH_SIZE=1` 在当前实现里表示按对应任务的 global batch size 分块 interleave。也就是说，stage2 的 `IA/LF/XL/LF_I2P` 四个 retrieval 源会以整批为单位抽取；同一个 retrieval micro-batch 内样本来自同一个数据源。OpenQA 多源也同理。

当前恢复状态：

- `train_goods_0402_twostage.sh` 存在。
- 0429 stage1/stage2 curated yaml 已恢复。
- 历史 0429 retqa full 4 节点命令文件仍待恢复，但 node0 的实际命令可从输出目录里的 `effective_config.txt` 反查。

0402 SP padding ablation 训练命令定位：

- 这组命令是 0402 goods 的短训 ablation，不是 0429 ret+OpenQA 主线。
- 入口仍是 `experiments/hetu/train_goods_0402_twostage.sh`，但使用 `STAGE=stage2` 从 base merge model 启动；`STAGE2_INIT_MODEL_NAME` 指向 `/mmu_mllm_hdd/zhangchenghao05/hetu_next/LLaMA-Factory/saves/qwen2_5omni-3b/sft_datav2/merge/`。
- 训练规模是 2 节点 16 卡，`TOTAL_RETRV_BATCH_SIZE=1024`，`STAGE2_MAX_STEPS=400`，`SAVE_STEPS_STAGE2=200`，保存 `checkpoint-200` 和 `checkpoint-400`。
- `VARIANT=maxtop4_ortho`，对应 `pooling=none`、`similarity_type=maxsim_topk`、`MAXSIM_TOPK=4`、`ORTHO_W=0.5`。
- `TOTAL_COMPRESS_TOKENS=4`，对比 `VLM_COMPRESS_TOKEN_MODE=repeat_first` 与 `distinct`。

0402 SP padding ablation 四个 run：

1. `sp_repeat0_ia_frombase_maxtop4_ortho_aligned_s400`
   - token: `<SP0><SP0><SP0><SP0>`
   - data: `experiments/hetu/train_goods_0402_stage1.yaml`，IA pair only
   - max_len: `4096`

2. `sp_repeat0_4src_frombase_maxtop4_ortho_aligned_s400`
   - token: `<SP0><SP0><SP0><SP0>`
   - data: `experiments/hetu/train_goods_0402_stage2.yaml`，IA/LF/XL/LF_I2P 四源
   - max_len: `5120`

3. `sp_distinct_ia_frombase_maxtop4_ortho_aligned_s400`
   - token: `<SP0><SP1><SP2><SP3>`
   - data: `experiments/hetu/train_goods_0402_stage1.yaml`，IA pair only
   - max_len: `4096`

4. `sp_distinct_4src_frombase_maxtop4_ortho_aligned_s400`
   - token: `<SP0><SP1><SP2><SP3>`
   - data: `experiments/hetu/train_goods_0402_stage2.yaml`，IA/LF/XL/LF_I2P 四源
   - max_len: `5120`

这组 ablation 的目的，是比较 repeat padding vs distinct padding，以及 IA-only vs 四源混合，对 slot collapse 和 embedding 几何的影响。它不包含 OpenQA 混训，也不代表 0429 release 配置。

已在输出目录确认的 0429 候选 checkpoint：

1. `slot_aligned` 多槽位主线候选
   - run: `goods_0429_distinct_slotalign_ortho_retqa_bsr1024_bsq128_t4_s1-10000_s2-4000`
   - stage1: `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0429_twostage/goods_0429_distinct_slotalign_ortho_retqa_bsr1024_bsq128_t4_s1-10000_s2-4000/stage1/checkpoint-10000`
   - stage2: `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0429_twostage/goods_0429_distinct_slotalign_ortho_retqa_bsr1024_bsq128_t4_s1-10000_s2-4000/stage2/checkpoint-4000`
   - service shape: `pooling=none`、`similarity_type=slot_aligned`，语义是 4 个 slot 的多向量相似度。

2. `attn + dense` 单向量候选
   - run: `goods_0429_distinct_attnpool_ortho_retqa_bsr1024_bsq128_t4_s1-10000_s2-4000`
   - stage1: `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0429_twostage/goods_0429_distinct_attnpool_ortho_retqa_bsr1024_bsq128_t4_s1-10000_s2-4000/stage1/checkpoint-10000`
   - stage2: `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0429_twostage/goods_0429_distinct_attnpool_ortho_retqa_bsr1024_bsq128_t4_s1-10000_s2-4000/stage2/checkpoint-4000`
   - service shape: `pooling=attn`、`similarity_type=dense`，语义是 attention pooling 后单向量 dense 相似度。

3. 从 `slot_aligned` stage1 接出的 64 维 attention-pool stage2 候选
   - run: `goods_0429_distinct_attnpool_ortho_retqa_bsr1024_bsq128_t4_s2-4000`
   - stage2: `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0429_twostage/goods_0429_distinct_attnpool_ortho_retqa_bsr1024_bsq128_t4_s2-4000/stage2/checkpoint-4000`
   - service shape: `pooling=attn`、`similarity_type=dense`、`projector_output_dim=64`。

上述 checkpoint 都只是“已完成训练的候选”。当前未发现训练过程写出的 `best_model_checkpoint` 或正式 release note，因此不能直接称为最终上线 checkpoint。

#### 2.1.3 模型推理

当前可用入口:

```bash
bash experiments/hetu/eval_goods_inference_items_emb.sh
```

输入配置:

- `experiments/hetu/eval_goods_inference_items_emb.yaml`

核心参数:

- `RUN_NAME`
- `POOLING`
- `SIMILARITY_TYPE`
- `CKPT_SUBDIR`
- `ENCODE_DIR_NAME`

待补齐：

- 每个推荐 checkpoint 对应的最终 `POOLING` / `SIMILARITY_TYPE` 决策。
- low-dim projector 输出格式与指标。
- 是否需要 PCA / projector 后归一化。

已确认的 0429 encode 命令形态：

```bash
OUTPUT_ROOT=/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0429_twostage \
RUN_NAME=goods_0429_distinct_slotalign_ortho_retqa_bsr1024_bsq128_t4_s1-10000_s2-4000 \
CKPT_SUBDIR=stage2/checkpoint-4000 \
POOLING=none \
SIMILARITY_TYPE=slot_aligned \
bash experiments/hetu/eval_goods_inference_items_emb.sh
```

```bash
OUTPUT_ROOT=/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0429_twostage \
RUN_NAME=goods_0429_distinct_attnpool_ortho_retqa_bsr1024_bsq128_t4_s1-10000_s2-4000 \
CKPT_SUBDIR=stage2/checkpoint-4000 \
POOLING=attn \
SIMILARITY_TYPE=dense \
bash experiments/hetu/eval_goods_inference_items_emb.sh
```

已确认的 embedding 输出路径：

- `slot_aligned` stage2: `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0429_twostage/goods_0429_distinct_slotalign_ortho_retqa_bsr1024_bsq128_t4_s1-10000_s2-4000/stage2/checkpoint-4000/goods_embs/emb`
- `attn+dense` stage2: `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0429_twostage/goods_0429_distinct_attnpool_ortho_retqa_bsr1024_bsq128_t4_s1-10000_s2-4000/stage2/checkpoint-4000/goods_embs/emb`

当前输出 schema：

- `<Dataset>.pickle`: Python pickle，内容为 `{id: embedding}`。`slot_aligned` 候选应按多槽位 embedding 使用；`attn+dense` 候选应按单向量 embedding 使用。
- `<Dataset>_info.jsonl`: 每行 JSON，当前全量 encode-only 样例为 `{"id": 23453020375286, "labels": []}`。
- `cache_*.pkl` / `cache_info_*.jsonl`: 分 rank 临时缓存，合并后可生成 `<Dataset>.pickle` 和 `<Dataset>_info.jsonl`。
- 全量商品分片包括 `Items_Infer_Part0` 到 `Items_Infer_Part4`；小样本/分析集包括 `IA_Test_Swing_Items`、`IA_Test_Swing_Photos`、`XL_Test_Items`、`XL_Test_Cate_Items` 等。

注意：当前 0429 goods inference yaml 是 `encode_only: true`，日志明确显示 `Encode-only mode enabled ... skipping scoring`。因此该命令只产出 embedding，不会产出 recall / NDCG / AUC。

0402 SP padding selected eval 命令定位：

- 这组命令是单机 8 卡 eval-only / encode-only，用于上面的 SP padding ablation 小样本 embedding 分析。
- 评测目标是 3 个 run，刻意排除 `sp_distinct_4src_frombase_maxtop4_ortho_aligned_s400`：
  - `sp_repeat0_ia_frombase_maxtop4_ortho_aligned_s400`
  - `sp_repeat0_4src_frombase_maxtop4_ortho_aligned_s400`
  - `sp_distinct_ia_frombase_maxtop4_ortho_aligned_s400`
- 每个 run 评估 `stage2/checkpoint-200` 和 `stage2/checkpoint-400`。
- `POOLING=none`、`SIMILARITY_TYPE=maxsim_topk`、`MAXSIM_TOPK=4`，与训练语义保持一致。
- `NUM_SAMPLE_PER_SUBSET=100`，目标是小样本几何分析，不是全量离线 recall / NDCG / AUC。
- 历史命令希望使用 `experiments/hetu/eval_goods_0402_test3_emb.yaml`。当前 `eval_goods_inference_items_emb.sh` 内部默认写死 `DATASET_CFG="$REPO_DIR/experiments/hetu/eval_goods_inference_items_emb.yaml"`；如果要让环境变量 `DATASET_CFG=experiments/hetu/eval_goods_0402_test3_emb.yaml` 生效，需要先把脚本改成 `${DATASET_CFG:-...}` 形式，或显式改脚本。

历史日志目录：

- `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/goods_0402_twostage/sp_padding_selected3_eval100_single_node_logs`

该 eval 产物用于计算 `same-token`、`internal-max`、`diff-token`、`pooled`、`maxsim` 等 embedding 几何指标。

#### 2.1.4 模型结果与上线状态

当前已从本地输出确认：

- 0429 已完成训练的 stage2 候选 checkpoint 路径见 `2.1.2`。
- 0429 已完成 encode-only 的 embedding 输出路径见 `2.1.3`。
- `slot_aligned` 多槽位服务形态、`attn+dense` 单向量服务形态、`attn+dense 64d` 服务形态都存在候选，但尚未决策哪个是 release candidate。
- 0402 SP padding ablation 的 3 组 selected eval 日志用于 embedding 几何报告，不属于 0429 业务 release 指标。

0402 SP padding selected eval 的历史结论口径：

- `repeat0_ia checkpoint-400` 在健康实验中 sample-level similarity 最低，报告均值 `pooled=0.1328`、`maxsim=0.3984`。
- `distinct_ia checkpoint-400` token decorrelation 最强，报告均值 `same-token=0.0043`、`internal-max=0.0351`。
- `repeat0_4src checkpoint-200` 明显 collapse，报告均值 `same-token=0.3781`、`internal-max=0.9954`。
- `repeat0_4src checkpoint-400` 修复了 within-sample collapse，但 sample-level similarity 仍偏高，报告均值 `pooled=0.2875`、`maxsim=0.5967`。
- 这些指标是 embedding 几何诊断，不是 goods 全量 recall / NDCG / AUC，也不能直接作为上线指标。

当前未从 repo / 输出目录确认：

- 0429 主线最终推荐 checkpoint。
- goods 全量离线 recall / NDCG / AUC 指标表。
- 线上模型 ID / KML 记录。
- 服务代码路径与分支。
- 工作流 ID。
- 下游使用方式、落表路径、更新策略。

业务落地前必须补齐：

- release note。
- 训练命令。当前可从 `effective_config.txt` 恢复 node0 命令，但还需要整理成 4 节点可复制命令包。
- checkpoint 路径。候选路径已找到，但需要标注最终推荐版本。
- eval 命令。encode 命令已找到；正式 recall / NDCG / AUC 命令仍缺。
- 指标表。
- 推理输出 schema。当前 pickle/jsonl schema 已确认；服务输出 schema 仍缺。
- 服务形态：单向量 dense、低维 projector，还是多槽位相似度。当前三种候选都有产物，尚未决策。

### 2.2 Better SID / XSeq 迁移到 goods

Better SID 当前更偏 research，但目标是迁移回 goods / unified embedding 主线。

可迁移点：

- `slot_aligned` 多槽位对齐相似度。
- orthogonal loss 降低 slot collapse。
- HSIC / CCA / conditional entropy 等 slot 诊断。
- xseq / in-batch attention 机制，用相似样本 attention 把 OpenQA/SID token loss 接到 embedding / slot 相似度上，作为额外训练梯度。

迁移前必须回答：

- xseq 是否提升最终静态 embedding，而不是只改善训练期 xseq loss。
- 当前 memory-bank stop-grad 实现是否足够，还是需要改成更贴近 Revela 的纯 BxB in-batch attention。
- SID/OpenQA 生成质量是否同步改善，作为辅助指标记录。
- xseq 训练成本相对收益是否可接受。
- memory bank 本地 rank 限制是否影响多机结果。
- 是否需要跨 rank 同步或离线 global memory。

### 2.3 Cached Projector / 低维输出

业务侧通常需要低维、可服务的 embedding。cached projector 的目标是用冻结 encoder 的 slot feature 快速训练低维 head。

当前 repo 中 `src/cached_projector/` 仍缺失，但历史输出产物已在本机找到：

- `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/cached_projector/goods_0429_distinct_slotalign_stage1_cache`，约 `313G`
- `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/cached_projector/goods_0429_distinct_slotalign_stage2_cache`，约 `126G`
- `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/cached_projector/goods_0429_distinct_attnpool_stage2_cache`，约 `126G`
- `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/cached_projector/goods_0429_distinct_slotalign_stage2_projector_64_32_16`
- `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/cached_projector/goods_0429_distinct_attnpool_stage2_projector_64_32_16`
- `/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/cached_projector/goods_0429_distinct_attnpool_stage2_projector_256_128_64`

已确认 projector train config：

- `head_dims=[64, 32, 16]` 或 `[256, 128, 64]`
- `hidden_dim=2048`
- `token_count=4`
- `world_size=32`
- `learning_rate=0.001`
- `max_steps=4000`
- `temperature=0.02`
- `normalize_input=true`
- `normalize_output=true`
- `orthogonal_loss=0.5`
- `save_multi_head_standalone_heads=true`

源码恢复后建议固定三组：

- 64 维 projector
- 32 维 projector
- 16 维 projector

评测必须包含：

- 原始多槽位相似度指标。
- projector 后 dense 指标。
- 低维 ANN 近似指标。
- 推理耗时。
- cache 体积。
- 训练耗时。
- 是否归一化。

### 2.4 业务落地 gap

当前 goods / unified embedding 与旧版线上 i2i 项目相比，业务落地文档缺少：

- 模型 ID。
- KML 上传记录。
- 服务代码仓库与分支。
- 服务名称。
- 工作流 ID。
- 数据源与落表路径。
- 增量/全量更新策略。
- 监控看板。
- misskey / BTQ 流程。
- bad case 分析链接。

如果当前项目还没有上线，这些应标为待补充；如果已经上线，需要从业务侧平台补回。

## 三、其他内容

### 3.1 已知问题与坑

- 当前 `vlm2vec` 已切回 `goods-strong300-emb-compare`，但历史本地实验文件仍缺失。
- 当前线上拉取版已恢复 0429 curated yaml 和 two-stage 脚本 ret+OpenQA 参数透传；cached projector 历史输出已找到，但源码入口、0429 完整命令文件和 embedding analysis report 仍待恢复。
- 多机训练强依赖绝对路径、conda、HF cache、NCCL 参数。
- `TASK_TYPES`、`DATA_WEIGHTS`、`LOSS_WEIGHTS`、`GRADIENT_ACCUMULATION_STEPS` 必须对齐。
- `TOTAL_RETRV_BATCH_SIZE` 必须能被 `NNODES * GPUS_PER_NODE` 整除。
- `TOTAL_QA_BATCH_SIZE` 必须能被 `WORLD_SIZE * PER_DEVICE_QA_BATCH_SIZE` 整除。
- `pooling` 与 `similarity_type` 必须和 checkpoint 语义匹配。
- `POOLING=none` 通常表示多 token 输出，不能误当单向量 dense embedding。
- MRL / Matryoshka 当前是前缀维度截断 loss，现有脚本主要服务 `pooling=avg` dense 路线；不要和 `multi_head_mlp` 独立 head projector 混为一谈。
- `split_layer=36` 是当前 Qwen2.5-Omni 压缩训练常用配置，改动会影响 OpenQA 压缩可见性。
- xseq memory bank 是本地 rank 级，不是跨节点全局共享。
- `retrieval_Acc@K` 是 in-batch proxy，不等于离线全库 recall。
- cached projector cache 体积大，不要放进 repo。
- false negative 会严重影响 in-batch contrastive loss，goods 场景必须单独处理。

### 3.2 当前最重要 gap

按优先级排序：

1. 代码/文件恢复 gap：本地实验脚本、报告、cached projector 源码入口缺失；历史 cached projector 输出产物已找到。
2. 结果闭环 gap：缺统一 eval 表和最终 checkpoint 决策。
3. 服务形态 gap：多槽位相似度、低维 projector、单向量 dense 三者未决策。
4. Better SID 评测 gap：没有正式 retrieval / embedding 指标证明 xseq 相似度梯度有效；OpenQA/SID 生成质量也需要作为辅助评测补齐。
5. false negative gap：goods pair 训练缺固定过滤/采样策略。
6. auxiliary loss ablation gap：retrieval/openqa 的正交/HSIC 影响需要拆开。
7. 业务交付 gap：模型 ID、服务、工作流、落表和监控尚未写入本项目 release 文档。

### 3.3 建议下一步

第一阶段：恢复工程状态

- 在 `vlm2vec` 新建恢复分支，例如 `recover-goods-summary`.
- 从历史机器、同事本地或远程分支找回缺失文件。
- 将本文件作为当前交接入口。

第二阶段：补结果表

- 固定 eval 数据和指标。
- 按 checkpoint / pooling / similarity / projector_dim 生成统一表。
- 选出 release candidate。

第三阶段：补业务 release note

- 写清模型路径、训练命令、推理命令、输出 schema。
- 明确是否上线。
- 若上线，补模型 ID / 服务 / 工作流 / 落表。

第四阶段：继续研究

- 对 xseq 做正式 ablation。
- 将有效的 Better SID 配置迁移到 goods。
- 做 cached projector compute-quality tradeoff。
