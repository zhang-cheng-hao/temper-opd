import os
import re

import datasets
from src.data.eval_dataset.base_infer_dataset import AutoInferDataset, add_metainfo_hook, MULTIMODAL_FEATURES, \
    RESOLUTION_MAPPING
from src.model.processor import VLM_IMAGE_TOKENS, VLM_COMPRESS_TOKENS, TOTAL_COMPRESS_TOKENS, ENCODE_PROMPT
from src.utils import print_master

def process_conversations(conversations, image_token, prompt):
    if TOTAL_COMPRESS_TOKENS <= 0:
        raise ValueError("hetu_compress requires TOTAL_COMPRESS_TOKENS > 0")
    encode_query = conversations[0]["value"].replace('<image>', image_token).replace('<audio>', '<|AUDIO|>')
    encode_answer = "".join(VLM_COMPRESS_TOKENS)
    decode_query = conversations[1]["value"].replace('<image>', image_token)
    if prompt:
        encode_query = encode_query + prompt
    
    return encode_query, encode_answer, decode_query

@add_metainfo_hook
def data_prepare(batch_dict, *args, **kwargs):
    model_backbone = kwargs['model_backbone']
    image_resolution = kwargs['image_resolution']
    image_dir = kwargs['image_dir']
    audio_dir = kwargs['audio_dir']
    batch_size = len(batch_dict['id'])
    data_ids, encode_queries, encode_answers, encode_images, encode_audios, decode_queries = [], [], [], [], [], []
    categorys = []
    for data_idx, (data_id, conversations, images_path, audios_path, category) in enumerate(zip(
        batch_dict['id'], 
        batch_dict['conversations'], 
        batch_dict['images'], 
        batch_dict['audios'],
        batch_dict.get('category', batch_size * [None])
    )):
        try:
            # * image may not exist

            encode_query, encode_answer, decode_query = process_conversations(conversations, image_token=VLM_IMAGE_TOKENS[model_backbone], prompt=None)
            encode_image = {"bytes": len(images_path) * [None], "paths": [os.path.join(image_dir, path) for path in images_path], "resolutions": len(images_path) * [RESOLUTION_MAPPING.get(image_resolution, None)]}
            encode_audio = {"bytes": len(audios_path) * [None], "paths": [os.path.join(audio_dir, path) for path in audios_path], "resolutions": len(audios_path) * [None]}
            encode_queries.append(encode_query)
            encode_answers.append(encode_answer)
            encode_images.append(encode_image)
            encode_audios.append(encode_audio)
            decode_queries.append(decode_query)
            categorys.append(category)
            data_ids.append(data_id)
        except Exception as e:
            print(f'Error in processing {DATASET_PARSER_NAME}: \n\t\tdata id: {data_id} \n\t\tconversations: {conversations}')
            print(e)
            raise e
    # print_rank(f"global_dataset_name={kwargs.get('global_dataset_name', DATASET_PARSER_NAME)}, batch_size={batch_size}, processed_batch_size={len(query_texts)}")
    return {"id": data_ids, "encode_query": encode_queries, "encode_answer": encode_answers, "encode_image": encode_images, "encode_audio": encode_audios,
            "decode_query": decode_queries, "category": categorys }

DATASET_PARSER_NAME = "hetu_compress"
@AutoInferDataset.register(DATASET_PARSER_NAME)
def load_hetu_compress_dataset(model_args, data_args, *args, **kwargs):
    if TOTAL_COMPRESS_TOKENS <= 0:
        raise ValueError("hetu_compress dataset requires TOTAL_COMPRESS_TOKENS > 0")
    dataset_name = kwargs.get("dataset_name", DATASET_PARSER_NAME)
    assert "dataset_path" in kwargs, "`dataset_path` should be given for loading llava instruct dataset."
    dataset_path = kwargs["dataset_path"]
    dataset = datasets.load_dataset('json', data_files=dataset_path, streaming=False)['train']

    if kwargs.get("max_samples") is not None:
        dataset = dataset.select(range(kwargs["max_samples"]))
    
    num_sample_per_subset = kwargs.get("num_sample_per_subset", getattr(data_args, "num_sample_per_subset", None))
    if num_sample_per_subset is not None and num_sample_per_subset < dataset.num_rows:
        num_rows = int(num_sample_per_subset)
        dataset = dataset.select(range(num_rows))
    num_rows = dataset.num_rows

    kwargs['model_backbone'] = model_args.model_backbone
    kwargs['image_resolution'] = data_args.image_resolution
    kwargs['image_dir'] = kwargs.get("image_dir", "/")
    kwargs['audio_dir'] = kwargs.get("audio_dir", "/")
    kwargs['global_dataset_name'] = f'{DATASET_PARSER_NAME}/{dataset_name}'
    dataset = dataset.map(lambda x: data_prepare(x, **kwargs), batched=True, batch_size=128, drop_last_batch=True)
    dataset = dataset.select_columns(["id", "category", "encode_query", "encode_answer", "encode_image", "encode_audio", "decode_query", "global_dataset_name", "task_type"])
    dataset = dataset.cast(MULTIMODAL_FEATURES)
    print_master(f"Loaded {DATASET_PARSER_NAME}/{dataset_name} dataset with {num_rows} samples")

    return dataset
