#!/bin/bash
set -euo pipefail

REPO_DIR="$(cd "$(dirname "$0")/../../.." && pwd)"
cd "$REPO_DIR"

NNODES="${NNODES:-1}"
NODE_RANK="${NODE_RANK:-0}"
if [ $# -gt 0 ] && [[ "$1" =~ ^[0-9]+$ ]]; then
  NNODES="$1"
  shift
fi
if [ $# -gt 0 ] && [[ "$1" =~ ^[0-9]+$ ]]; then
  NODE_RANK="$1"
  shift
fi

export TOTAL_COMPRESS_TOKENS="${TOTAL_COMPRESS_TOKENS:-4}"
export VLM_COMPRESS_TOKEN_MODE="${VLM_COMPRESS_TOKEN_MODE:-distinct}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-/mmu_mllm_hdd/zhangchenghao05/.cache/huggingface/datasets}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

GPUS_PER_NODE="${GPUS_PER_NODE:-8}"
MASTER_ADDR="${MASTER_ADDR:-localhost}"
MASTER_PORT="${MASTER_PORT:-2217}"
RDZV_ID="${RDZV_ID:-cached-projector-cache}"
TORCHRUN="${TORCHRUN:-/mmu_mllm_hdd/zhangchenghao05/envs/vlm2vec/bin/torchrun}"
MODE="${MODE:-run}"

CACHE_DIR="${CACHE_DIR:-}"
HAS_CACHE_DIR=0
HAS_OUTPUT_DIR=0
HAS_SEED=0
HAS_REPORT_TO=0
PASSTHRU=()

normalize_cache_dtype() {
  case "$1" in
    bf16|bfloat16) echo "bfloat16" ;;
    fp16|float16) echo "float16" ;;
    fp32|float32) echo "float32" ;;
    *) echo "$1" ;;
  esac
}

while [ $# -gt 0 ]; do
  case "$1" in
    --cache_dir)
      CACHE_DIR="$2"
      HAS_CACHE_DIR=1
      PASSTHRU+=(--cache_dir "$2")
      shift 2
      ;;
    --max_batches)
      PASSTHRU+=(--cache_max_steps "$2")
      shift 2
      ;;
    --shard_size)
      PASSTHRU+=(--cache_shard_size "$2")
      shift 2
      ;;
    --cache_dtype)
      PASSTHRU+=(--cache_dtype "$(normalize_cache_dtype "$2")")
      shift 2
      ;;
    --encode_chunk_size)
      echo "[WARN] --encode_chunk_size is ignored by src.cached_projector.build_cache" >&2
      shift 2
      ;;
    --output_dir)
      HAS_OUTPUT_DIR=1
      PASSTHRU+=(--output_dir "$2")
      shift 2
      ;;
    --seed)
      HAS_SEED=1
      PASSTHRU+=(--seed "$2")
      shift 2
      ;;
    --report_to)
      HAS_REPORT_TO=1
      PASSTHRU+=(--report_to "$2")
      shift 2
      ;;
    *=*)
      export "$1"
      shift
      ;;
    *)
      PASSTHRU+=("$1")
      shift
      ;;
  esac
done

if [ -z "$CACHE_DIR" ]; then
  CACHE_DIR="/mmu_mllm_hdd/zhangchenghao05/hetu_next/outputs/cached_projector/goods_0429_distinct_slotalign_stage2_cache"
fi
if [ "$HAS_CACHE_DIR" -eq 0 ]; then
  PASSTHRU+=(--cache_dir "$CACHE_DIR")
fi
if [ "$HAS_OUTPUT_DIR" -eq 0 ]; then
  PASSTHRU+=(--output_dir "$CACHE_DIR/runtime")
fi
if [ "$HAS_SEED" -eq 0 ]; then
  PASSTHRU+=(--seed 42)
fi
if [ "$HAS_REPORT_TO" -eq 0 ]; then
  PASSTHRU+=(--report_to none)
fi

if [ ! -x "$TORCHRUN" ]; then
  echo "[ERR] torchrun not found: $TORCHRUN" >&2
  exit 1
fi

cmd=(
  "$TORCHRUN"
  --nproc-per-node "$GPUS_PER_NODE"
  --nnodes "$NNODES"
  --max-restarts 0
  --rdzv-backend c10d
  --rdzv-id "$RDZV_ID"
  --rdzv-endpoint "$MASTER_ADDR:$MASTER_PORT"
  --node-rank "$NODE_RANK"
  -m src.cached_projector.build_cache
  "${PASSTHRU[@]}"
)

printf "[CACHE_FEATURES] CMD: "
printf "%q " "${cmd[@]}"
printf "\n"
if [ "$MODE" = "print" ]; then
  exit 0
fi
mkdir -p "$CACHE_DIR"
"${cmd[@]}" 2>&1 | tee "$CACHE_DIR/build_cache.log"
