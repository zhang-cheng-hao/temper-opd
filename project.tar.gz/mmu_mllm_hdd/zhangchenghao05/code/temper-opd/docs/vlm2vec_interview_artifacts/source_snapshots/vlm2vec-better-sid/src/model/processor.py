import os
import logging
import random

import PIL
from transformers.image_utils import ChannelDimension
from transformers.processing_utils import ProcessorMixin

from src.model.baseline_backbone.colpali import ColPaliProcessor

# TODO:
from PIL import ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

logger = logging.getLogger(__name__)

import torch
import numpy as np
from torch.nn.utils.rnn import pad_sequence
from src.utils import print_master
from src.model.utils import (get_rope_index_2, get_rope_index_25, get_rope_index_keye, 
                             pad_and_cat, shift_sep_indices)

from src.model.baseline_backbone.llava_next import LlavaNextForConditionalGeneration
from src.model.baseline_backbone.llava_next import LlavaNextProcessor
from src.model.baseline_backbone.phi3_v.modeling_phi3_v import Phi3VForCausalLM
from src.model.vlm_backbone.qwen2_vl import Qwen2VLForConditionalGeneration, Qwen2VLProcessor
from src.model.vlm_backbone.qwen2_vl_tokenselection import \
    Qwen2VLForConditionalGeneration as Qwen2VLTokenSelectionForConditionalGeneration, \
    Qwen2VLProcessor as Qwen2VLTokenSelectionProcessor
from src.model.baseline_backbone.internvideo2.modeling_internvideo2 import InternVideo2_Stage2
from src.model.vlm_backbone.qwen2_5_vl import Qwen2_5_VLForConditionalGeneration
from src.model.vlm_backbone.qwen2_5_vl.processing_qwen2_5_vl import Qwen2_5_VLProcessor
from src.model.vlm_backbone.qwen2_5_vl_tokenselection import \
    Qwen2_5_VLForConditionalGeneration as Qwen2_5_VL_TokenSelectionForConditionalGeneration
from src.model.vlm_backbone.keye_vl import KeyeVL1_5ForConditionalGeneration, KeyeVL1_5Processor

from src.model.vlm_backbone.qwen2_5_omni.modeling_qwen2_5_omni import Qwen2_5OmniThinkerForConditionalGeneration, Qwen2_5OmniForConditionalGeneration
from src.model.vlm_backbone.qwen2_5_omni.processing_qwen2_5_omni import Qwen2_5OmniProcessor
import librosa

from typing import Union
import traceback

PHI_IMAGE_TOKEN_MAX_INPUT_ID = int(1e9)
LLAVA_IMAGE_TOKEN_ID = 32000
IGNORE_INDEX = -100

PHI3V = 'phi3_v'
LLAVA_NEXT = 'llava_next'
QWEN2_VL = 'qwen2_vl'
QWEN2_VL_TOKENSELECTION = 'qwen2_vl'
QWEN2_5_VL = 'qwen2_5_vl'
QWEN2_5_OMNI = 'qwen2_5_omni'
QWEN2_VL_TOKENSELECTION = 'qwen2_vl_tokenselection'
QWEN2_5_VL_TOKENSELECTION = 'qwen2_5_vl_tokenselection'
KEYE_VL_1_5 = 'keye_vl_1_5'
INTERNVIDEO2 = 'internvideo2'
GME = 'gme'  # QWEN2-VL
LamRA = 'lamra'  # QWEN2-VL
LamRA_QWEN2_5 = 'lamra_qwen25'  # QWEN2.5-VL
COLPALI = 'colpali'  # PaliGemma-3B
KORUS = 'korus'  # compression-based model
KORUS_OMNI = 'korus_omni'
MODEL2BACKBONE = {  # keys are from hf_config.model_type or manually added if not provided
    'phi3_v': PHI3V,
    'llava_next': LLAVA_NEXT,
    'qwen2_vl': QWEN2_VL,
    'qwen2_vl_tokenselection': QWEN2_VL,
    'qwen2_5_vl': QWEN2_5_VL,
    'qwen2_5_omni': QWEN2_5_OMNI,
    'qwen2_vl_tokenselection': QWEN2_VL_TOKENSELECTION,
    'qwen2_5_vl_tokenselection': QWEN2_5_VL_TOKENSELECTION,
    'keye_vl_1_5': KEYE_VL_1_5,
    'internvideo2': INTERNVIDEO2,
    'gme': GME,
    'lamra': LamRA,
    'lamra_qwen25': LamRA,
    'colpali': COLPALI,
    'korus': KORUS,
}
SUPPORTED_MODELS = set(MODEL2BACKBONE.keys())

VLM_IMAGE_TOKENS = {
    PHI3V: "<|image_1|>",
    LLAVA_NEXT: "<image>",
    # QWEN2_VL: "<|image_pad|>",
    QWEN2_VL: "<|vision_start|><|image_pad|><|vision_end|>",  # add vision start and end token for mrope
    # QWEN2_5_VL: "<|image_pad|>",
    QWEN2_5_VL: "<|vision_start|><|image_pad|><|vision_end|>",  # add vision start and end token for mrope
    #QWEN2_5_OMNI: "<|vision_start|><|image_pad|><|vision_end|>",  # add vision start and end token for mrope
    QWEN2_5_OMNI: "<|IMAGE|>",
    QWEN2_VL_TOKENSELECTION: "<|image_pad|>",
    QWEN2_5_VL_TOKENSELECTION: "<|image_pad|>",
    # KEYE_VL_1_5: "<|image_pad|>",
    KEYE_VL_1_5: "<|vision_start|><|image_pad|><|vision_end|>",
    GME: "<|image_pad|>",
    LamRA: "<|image_pad|>",
    LamRA_QWEN2_5: "<|image_pad|>",
    INTERNVIDEO2: "",
    COLPALI: "",
}

VLM_AUDIO_TOKENS = {
    QWEN2_5_OMNI: "<|AUDIO|>",
}

TOTAL_COMPRESS_TOKENS = int(os.getenv('TOTAL_COMPRESS_TOKENS', 0))
VLM_COMPRESS_TOKENS = [f"<|ctoken_pad_{i}|>" for i in range(TOTAL_COMPRESS_TOKENS)]
ENCODE_PROMPT = " Represent the given image."
IGNORE_STR = ENCODE_PROMPT + "".join(VLM_COMPRESS_TOKENS)

VLM_VIDEO_TOKENS = {
    LLAVA_NEXT: "<image>",
    QWEN2_VL: "<|video_pad|>",
    QWEN2_5_VL: "<|video_pad|>",
    QWEN2_5_OMNI: "<|video_pad|>",
    QWEN2_VL_TOKENSELECTION: "<|video_pad|>",
    QWEN2_5_VL_TOKENSELECTION: "<|video_pad|>",
    KEYE_VL_1_5: "<|video_pad|>",
    GME: "<|video_pad|>",
    LamRA: "<|video_pad|>",
    LamRA_QWEN2_5: "<|video_pad|>",
    INTERNVIDEO2: "",
    COLPALI: "",
}


def _trim_text_keep_suffix_marker(
    text,
    tokenizer,
    max_length,
    suffix_marker,
    fallback_marker=None,
    safety_tokens=32,
):
    if max_length is None:
        return text

    budget = max_length - safety_tokens
    if budget <= 0:
        return text

    token_ids = tokenizer(text, add_special_tokens=False, truncation=False)["input_ids"]
    if len(token_ids) <= budget:
        return text

    suffix_pos = text.rfind(suffix_marker) if suffix_marker else -1
    if suffix_pos < 0 and fallback_marker:
        suffix_pos = text.rfind(fallback_marker)
    if suffix_pos < 0:
        suffix_pos = max(len(text) - 512, 0)

    prefix_text = text[:suffix_pos]
    suffix_text = text[suffix_pos:]
    suffix_ids = tokenizer(suffix_text, add_special_tokens=False, truncation=False)["input_ids"]

    def fits(candidate_text: str) -> bool:
        candidate_ids = tokenizer(candidate_text, add_special_tokens=False, truncation=False)["input_ids"]
        return len(candidate_ids) <= budget

    if len(suffix_ids) >= budget:
        lo, hi = 0, len(suffix_text)
        while lo < hi:
            mid = (lo + hi) // 2
            if fits(suffix_text[mid:]):
                hi = mid
            else:
                lo = mid + 1
        return suffix_text[lo:]

    lo, hi = 0, len(prefix_text)
    while lo < hi:
        mid = (lo + hi) // 2
        candidate = prefix_text[mid:] + suffix_text
        if fits(candidate):
            hi = mid
        else:
            lo = mid + 1
    return prefix_text[lo:] + suffix_text


def _remove_last_n_occurrences(text: str, marker: str, count: int) -> str:
    if not marker or count <= 0:
        return text
    for _ in range(count):
        pos = text.rfind(marker)
        if pos < 0:
            break
        text = text[:pos] + text[pos + len(marker):]
    return text


def _estimate_omni_mm_token_overhead(processor, inputs, feature_attention_mask=None):
    overhead = 0

    image_grid_thw = inputs.get("image_grid_thw", None)
    if image_grid_thw is not None and getattr(processor, "image_processor", None) is not None:
        merge_length_image = processor.image_processor.merge_size**2
        image_grid_thw = torch.as_tensor(image_grid_thw)
        image_seq_lens = torch.prod(image_grid_thw, dim=-1) // merge_length_image
        overhead += int(torch.clamp(image_seq_lens - 1, min=0).sum().item())

    video_grid_thw = inputs.get("video_grid_thw", None)
    if video_grid_thw is not None and getattr(processor, "video_processor", None) is not None:
        merge_length_video = processor.video_processor.merge_size**2
        video_grid_thw = torch.as_tensor(video_grid_thw)
        video_seq_lens = torch.prod(video_grid_thw, dim=-1) // merge_length_video
        overhead += int(torch.clamp(video_seq_lens - 1, min=0).sum().item())

    if feature_attention_mask is not None:
        feature_attention_mask = feature_attention_mask.to(torch.long)
        input_lengths = (feature_attention_mask.sum(-1) - 1) // 2 + 1
        audio_seq_lens = (input_lengths - 2) // 2 + 1
        overhead += int(torch.clamp(audio_seq_lens - 1, min=0).sum().item())

    return overhead


def _get_compression_token_state(input_ids, ctoken_start_id):
    if TOTAL_COMPRESS_TOKENS <= 0 or ctoken_start_id is None:
        return [0], True, TOTAL_COMPRESS_TOKENS

    flat_input_ids = input_ids.squeeze()
    ctoken_indices = torch.where(flat_input_ids == ctoken_start_id)[0]
    if len(ctoken_indices) == 0:
        return ctoken_indices, False, 0

    tail_span = int(flat_input_ids.shape[0] - ctoken_indices[0].item())
    return ctoken_indices, tail_span == TOTAL_COMPRESS_TOKENS, tail_span

backbone2model = {
    PHI3V: Phi3VForCausalLM,
    LLAVA_NEXT: LlavaNextForConditionalGeneration,
    QWEN2_VL: Qwen2VLForConditionalGeneration,
    QWEN2_5_VL: Qwen2_5_VLForConditionalGeneration,
    QWEN2_5_OMNI: Qwen2_5OmniForConditionalGeneration,
    QWEN2_VL_TOKENSELECTION: Qwen2VLTokenSelectionForConditionalGeneration,
    QWEN2_5_VL_TOKENSELECTION: Qwen2_5_VL_TokenSelectionForConditionalGeneration,
    KEYE_VL_1_5: KeyeVL1_5ForConditionalGeneration,
    INTERNVIDEO2: InternVideo2_Stage2,
}


def load_processor(model_args, data_args=None):
    """
    Load processor based on VLM backbone.
    Note: due to this change, https://github.com/huggingface/transformers/commit/9215cc62d4366072aacafa4e44028c1ca187167b#diff-6505546ec5a9ab74b2ce6511681dd31194eb91e9fa3ce26282e487a5e61f9356L1102
    """
    model_name_or_path = model_args.checkpoint_path if model_args.checkpoint_path else model_args.model_name
    print_master(f'Loading processor from: {model_name_or_path}')
    if model_args.model_backbone == PHI3V:
        from src.model.baseline_backbone.phi3_v.processing_phi3_v import Phi3VProcessor
        processor = Phi3VProcessor.from_pretrained(
            model_name_or_path,
            trust_remote_code=True,
            num_crops=model_args.num_crops
        )
        processor.tokenizer.padding_side = "right"
    elif model_args.model_backbone == LLAVA_NEXT:
        from src.model.baseline_backbone.llava_next import LlavaNextProcessor
        processor = LlavaNextProcessor.from_pretrained(
            model_name_or_path,
            trust_remote_code=True
        )
    elif model_args.model_backbone in [QWEN2_VL, GME, LamRA]:
        from src.model.vlm_backbone.qwen2_vl.processing_qwen2_vl import Qwen2VLProcessor
        from src.model.vlm_backbone.qwen2_vl.image_processing_qwen2_vl import Qwen2VLImageProcessor
        from src.model.vlm_backbone.qwen2_vl.tokenization_qwen2_fast import Qwen2TokenizerFast
        min_pixels, max_pixels = None, None
        if data_args is not None:
            min_pixels, max_pixels = data_args.resize_min_pixels, data_args.resize_max_pixels
        size = {"shortest_edge": min_pixels, "longest_edge": max_pixels}
        image_processor = Qwen2VLImageProcessor.from_pretrained(model_name_or_path, size=size)
        tokenizer = Qwen2TokenizerFast.from_pretrained(model_name_or_path, padding_size="right")  # NOTE: right padding side
        processor = Qwen2VLProcessor.from_pretrained(
            model_name_or_path,
            image_processor=image_processor, tokenizer=tokenizer, size=size
        )
    elif model_args.model_backbone in [QWEN2_5_OMNI]:
        from src.model.vlm_backbone.qwen2_5_omni.processing_qwen2_5_omni import Qwen2_5OmniProcessor
        from src.model.vlm_backbone.qwen2_vl.image_processing_qwen2_vl import Qwen2VLImageProcessor
        from src.model.vlm_backbone.qwen2_vl.tokenization_qwen2_fast import Qwen2TokenizerFast
        min_pixels, max_pixels = None, None
        if data_args is not None:
            min_pixels, max_pixels = data_args.resize_min_pixels, data_args.resize_max_pixels
        size = {"shortest_edge": min_pixels, "longest_edge": max_pixels}
        image_processor = Qwen2VLImageProcessor.from_pretrained(model_name_or_path, size=size)
        tokenizer = Qwen2TokenizerFast.from_pretrained(model_name_or_path, padding_size="right")
        processor = Qwen2_5OmniProcessor.from_pretrained(
            model_name_or_path,
            image_processor=image_processor, tokenizer=tokenizer, size=size
        )

    elif model_args.model_backbone == QWEN2_VL_TOKENSELECTION:
        from src.model.vlm_backbone.qwen2_vl_tokenselection.processing_qwen2_vl import Qwen2VLProcessor
        from src.model.vlm_backbone.qwen2_vl_tokenselection.image_processing_qwen2_vl import Qwen2VLImageProcessor
        from src.model.vlm_backbone.qwen2_vl_tokenselection.tokenization_qwen2_fast import Qwen2TokenizerFast
        image_processor = Qwen2VLImageProcessor.from_pretrained(model_name_or_path)
        if data_args is not None:
            image_processor.do_resize = data_args.resize_use_processor
            image_processor.min_pixels = data_args.resize_min_pixels
            image_processor.max_pixels = data_args.resize_max_pixels
        tokenizer = Qwen2TokenizerFast.from_pretrained(model_name_or_path)
        processor = Qwen2VLProcessor.from_pretrained(
            model_name_or_path,
            image_processor=image_processor, tokenizer=tokenizer,
            uigraph_use=model_args.uigraph_use,
            uigraph_diff=model_args.uigraph_diff,  uigraph_rand=model_args.uigraph_rand,
            uimask_ratio=model_args.uimask_ratio, uimask_rand=model_args.uimask_rand
        )
    elif model_args.model_backbone in [QWEN2_5_VL, LamRA_QWEN2_5]:
        from src.model.vlm_backbone.qwen2_5_vl.processing_qwen2_5_vl import Qwen2_5_VLProcessor
        from src.model.vlm_backbone.qwen2_5_vl.image_processing_qwen2_5_vl import Qwen2_5_VLImageProcessor
        from src.model.vlm_backbone.qwen2_vl.tokenization_qwen2_fast import Qwen2TokenizerFast
        min_pixels, max_pixels = None, None
        if data_args is not None:
            min_pixels, max_pixels = data_args.resize_min_pixels, data_args.resize_max_pixels
        size = {"shortest_edge": min_pixels, "longest_edge": max_pixels, "min_pixels": min_pixels, "max_pixels": max_pixels}
        image_processor = Qwen2_5_VLImageProcessor.from_pretrained(model_name_or_path, size=size)
        tokenizer = Qwen2TokenizerFast.from_pretrained(model_name_or_path)
        processor = Qwen2_5_VLProcessor.from_pretrained(model_name_or_path, image_processor=image_processor, tokenizer=tokenizer)
    elif model_args.model_backbone == QWEN2_5_VL_TOKENSELECTION:
        # TODO: qwen2.5 token selection not working yet
        from src.model.vlm_backbone.qwen2_5_vl_tokenselection.processing_qwen2_5_vl import Qwen2_5_VLProcessor
        from src.model.vlm_backbone.qwen2_5_vl_tokenselection.image_processing_qwen2_5_vl import Qwen2_5_VLImageProcessor
        from src.model.vlm_backbone.qwen2_vl_tokenselection.tokenization_qwen2_fast import Qwen2TokenizerFast
        min_pixels, max_pixels = None, None
        if data_args is not None:
            min_pixels, max_pixels = data_args.resize_min_pixels, data_args.resize_max_pixels
        size = {"shortest_edge": min_pixels, "longest_edge": max_pixels, "min_pixels": min_pixels, "max_pixels": max_pixels}
        image_processor = Qwen2_5_VLImageProcessor.from_pretrained(model_name_or_path, size=size)
        tokenizer = Qwen2TokenizerFast.from_pretrained(model_name_or_path)
        processor = Qwen2_5_VLProcessor.from_pretrained(
            model_name_or_path,
            image_processor=image_processor, tokenizer=tokenizer,
            uigraph_use=model_args.uigraph_use,
            uigraph_diff=model_args.uigraph_diff,  uigraph_rand=model_args.uigraph_rand,
            uimask_ratio=model_args.uimask_ratio, uimask_rand=model_args.uimask_rand
        )
    elif model_args.model_backbone == KEYE_VL_1_5:
        from src.model.vlm_backbone.keye_vl.processing_keye_vl_1_5 import KeyeVL1_5Processor
        from src.model.vlm_backbone.keye_vl.image_processing_keye_vl_1_5 import KeyeVL1_5ImageProcessor
        from src.model.vlm_backbone.qwen2_vl.tokenization_qwen2_fast import Qwen2TokenizerFast
        min_pixels, max_pixels = None, None
        if data_args is not None:
            min_pixels, max_pixels = data_args.resize_min_pixels, data_args.resize_max_pixels
        size = {"shortest_edge": min_pixels, "longest_edge": max_pixels, "min_pixels": min_pixels, "max_pixels": max_pixels}
        image_processor = KeyeVL1_5ImageProcessor.from_pretrained(model_name_or_path, size=size, min_pixels=min_pixels, max_pixels=max_pixels)
        tokenizer = Qwen2TokenizerFast.from_pretrained(model_name_or_path)
        processor = KeyeVL1_5Processor.from_pretrained(model_name_or_path, image_processor=image_processor, tokenizer=tokenizer)
    elif model_args.model_backbone == INTERNVIDEO2:
        return None
    elif model_args.model_backbone == COLPALI:
        from transformers import AutoProcessor
        processor = ColPaliProcessor.from_pretrained(model_args.model_name)
    else:
        raise NotImplementedError(f"Processor for backbone {model_args.model_backbone} is not implemented yet.")
        # from transformers import AutoProcessor
        # processor = AutoProcessor.from_pretrained(
        #     model_args.processor_name if model_args.processor_name else model_args.model_name,
        #     trust_remote_code=True,
        # )
        
    # Compression Mode
    if model_args.compression_mode:
        processor.tokenizer.add_tokens(VLM_COMPRESS_TOKENS, special_tokens=True)  # add VLM_COMPRESS_TOKENS
        if model_args.model_backbone in {QWEN2_VL, QWEN2_5_VL, KEYE_VL_1_5}:
            # ignore system prompt
            processor.chat_template = "{% set image_count = namespace(value=0) %}{% set video_count = namespace(value=0) %}{% for message in messages %}<|im_start|>{{ message['role'] }}\n{% if message['content'] is string %}{{ message['content'] }}<|im_end|>\n{% else %}{% for content in message['content'] %}{% if content['type'] == 'image' or 'image' in content or 'image_url' in content %}{% set image_count.value = image_count.value + 1 %}{% if add_vision_id %}Picture {{ image_count.value }}: {% endif %}<|vision_start|><|image_pad|><|vision_end|>{% elif content['type'] == 'video' or 'video' in content %}{% set video_count.value = video_count.value + 1 %}{% if add_vision_id %}Video {{ video_count.value }}: {% endif %}<|vision_start|><|video_pad|><|vision_end|>{% elif 'text' in content %}{{ content['text'] }}{% endif %}{% endfor %}<|im_end|>\n{% endif %}{% endfor %}{% if add_generation_prompt %}<|im_start|>assistant\n{% endif %}"
        if model_args.model_backbone in {QWEN2_VL, QWEN2_5_VL, KEYE_VL_1_5, LLAVA_NEXT, QWEN2_5_OMNI}:
            processor.tokenizer.padding_side = "right"  # set right padding for openqa training

    return processor


def get_backbone_name(hf_config, model_type=None):
    if model_type is not None:
        if hf_config is not None:
            setattr(hf_config, 'model_type', model_type)
    assert model_type in SUPPORTED_MODELS, f"Unknown backbone name {model_type}.Supported models are {SUPPORTED_MODELS}"
    return MODEL2BACKBONE[model_type]


def Llava_NEXT_process_fn(model_inputs: dict, processor, max_length=None):
    # TODO: NOT FINISHED YET!
    input_ids, pixel_values, image_sizes = [], [], []
    texts, visual_inputs = model_inputs['text'], model_inputs['images']
    image_exists = False
    # 1. iterate each pair and process (since processors do not support batch processing)
    for text, images in zip(texts, visual_inputs):
        # in theory, each batch item should contain a list of frames, but we still check for exceptions here
        # if no images as input (not likely to happen in mmeb pro cases)
        if images is None or (type(images)==list and any(i is None for i in images)):
            inputs = processor(images=None, text=text, return_tensors="np", max_length=max_length, truncation=True)
            input_id = inputs["input_ids"].squeeze().tolist()
            if isinstance(input_id, int):
                # in case of empty string, only BOS is included
                input_id = [input_id]
            input_ids.append(input_id)
            pixel_values.append(None)
            image_sizes.append(None)
            # image_grid_thw.append(None)
        else:
            image_exists = True
            # in theory, valid images should be a list of frames
            assert isinstance(images, list), f"images should be a list, but got {type(images)}"
            inputs = processor(images=images, text=text, return_tensors="np", max_length=max_length, truncation=True)
            input_ids.append(inputs["input_ids"].squeeze().tolist())
            pixel_values.append(inputs['pixel_values'])
            image_sizes.append(inputs['image_sizes'])

    # 2. padding inputs
    batch_encoding = processor.tokenizer.pad({'input_ids': input_ids}, return_tensors="pt")
    input_ids, attention_mask = batch_encoding['input_ids'], batch_encoding['attention_mask']
    inputs = {
        'input_ids': input_ids.long(),
        'attention_mask': attention_mask,
        # 'texts': texts,
        # 'images': visual_inputs,
    }
    image_exists = any([p is not None for p in pixel_values])
    if image_exists:
        # dummy image inputs based on the first valid data point
        pixel_value_shape_for_padding = list(v.shape for v in pixel_values if v is not None)[0]
        image_size_for_padding = torch.from_numpy(list(v for v in image_sizes if v is not None)[0])
        # make the batch full tensors
        pixel_values = [torch.from_numpy(v) if v is not None else torch.zeros(pixel_value_shape_for_padding) for v in pixel_values]
        pixel_values = torch.cat(pixel_values, dim=0)
        image_sizes = [torch.from_numpy(v) if v is not None else image_size_for_padding for v in image_sizes]
        image_sizes = torch.cat(image_sizes, dim=0)
        inputs['pixel_values'] = pixel_values.float()
        inputs['image_sizes'] = image_sizes.long()
    else:
        inputs['pixel_values'] = torch.zeros(input_ids.shape[0], 1)
        inputs['image_sizes'] = torch.ones(input_ids.shape[0], 1)

    return inputs


def Llava_NEXT_Compression_process_fn(model_inputs: dict, processor, max_length=None, task_type="retrieval", prob=0.0):
    # TODO: NOT FINISHED YET!
    input_ids, labels, pixel_values, sep_indices, image_sizes = [], [], [], [], []
    texts, visual_inputs = model_inputs['text'], model_inputs['images']
    image_exists = False
    # 1. iterate each pair and process (since processors do not support batch processing)
    for text, images in zip(texts, visual_inputs):
        # in theory, each batch item should contain a list of frames, but we still check for exceptions here
        # if no images as input (not likely to happen in mmeb pro cases)
        if images is None or (type(images)==list and any(i is None for i in images)):
            inputs = processor(images=None, text=text, return_tensors="np", max_length=max_length, truncation=True)
            input_id = inputs["input_ids"].squeeze().tolist()
            if isinstance(input_id, int):
                # in case of empty string, only BOS is included
                input_id = [input_id]
            input_ids.append(input_id)
            pixel_values.append(None)
            image_sizes.append(None)
            # image_grid_thw.append(None)
        else:
            image_exists = True
            # in theory, valid images should be a list of frames
            assert isinstance(images, list), f"images should be a list, but got {type(images)}"
            if task_type == "openqa" and prob != 0 and random.random() < prob:
                text = text.replace(IGNORE_STR, "")  # HACK: remove drop compression token with 50% prob
            inputs = processor(images=images, text=text, return_tensors="np", max_length=max_length, truncation=True)
            input_ids.append(inputs["input_ids"].squeeze().tolist())
            pixel_values.append(inputs['pixel_values'])
            image_sizes.append(inputs['image_sizes'])
        
        # labels & seq_indices
        ctoken_start_id = processor.tokenizer.encode(VLM_COMPRESS_TOKENS[0], add_special_tokens=False)[0] if TOTAL_COMPRESS_TOKENS > 0 else None
        ctoken_indices = np.where(inputs["input_ids"].squeeze() == ctoken_start_id)[0] if ctoken_start_id is not None else [0]
        assert len(ctoken_indices) == 1, f"Expected 1 ctoken indices, but got {len(ctoken_indices)}, text: {text}"
        if task_type == "openqa":
            target = inputs["input_ids"].squeeze()
            assert text.count("[/INST]") == 1, f"Expected 1 instruction in text, but got {text.count('[INST]')} in {text}"
            answer_ids = processor.tokenizer.encode(text.split('[/INST]')[-1], add_special_tokens=False)
            target[:-len(answer_ids)] = IGNORE_INDEX  # ignore all tokens before decode answer
            labels.append(torch.tensor(target))
            if len(ctoken_indices) > 0:
                sep_indices.append([ctoken_indices[0], ctoken_indices[0] + TOTAL_COMPRESS_TOKENS, len(input_ids[-1]) - len(answer_ids), len(input_ids[-1])])  # add indices for openqa
            elif len(ctoken_indices) == 0:
                sep_indices.append([0, 0, len(input_ids[-1]) - len(answer_ids), len(input_ids[-1])])
        if task_type == "retrieval":
            assert TOTAL_COMPRESS_TOKENS == 0 or len(input_ids[-1]) - ctoken_indices[0] == TOTAL_COMPRESS_TOKENS, f"Expected compression tokens to be appended at the end of the input sequence. text: {text}"
            sep_indices.append([ctoken_indices[0], ctoken_indices[0] + TOTAL_COMPRESS_TOKENS, 0, 0])  # add dummy index for retrv_flag

    # 2. padding inputs
    inputs_len = [len(ids) for ids in input_ids]
    padding_side = processor.tokenizer.padding_side
    batch_encoding = processor.tokenizer.pad({'input_ids': input_ids}, return_tensors="pt")
    input_ids, attention_mask = batch_encoding['input_ids'], batch_encoding['attention_mask']
    sep_indices = torch.tensor(sep_indices, dtype=torch.long)
    sep_indices = shift_sep_indices(sep_indices, inputs_len, padding_side=padding_side)
    assert sep_indices.shape[0] == input_ids.shape[0]
    inputs = {
        'input_ids': input_ids.long(),
        'attention_mask': attention_mask,
        'sep_indices': sep_indices,
        # 'texts': texts,
        # 'images': visual_inputs,
    }

    if len(labels) > 0:
        labels = pad_sequence(labels, batch_first=True, padding_value=IGNORE_INDEX, padding_side=padding_side)
        inputs['labels'] = labels.long()
    
    image_exists = any([p is not None for p in pixel_values])
    if image_exists:
        # dummy image inputs based on the first valid data point
        pixel_value_shape_for_padding = list(v.shape for v in pixel_values if v is not None)[0]
        image_size_for_padding = torch.from_numpy(list(v for v in image_sizes if v is not None)[0])
        # make the batch full tensors
        pixel_values = [torch.from_numpy(v) if v is not None else torch.zeros(pixel_value_shape_for_padding) for v in pixel_values]
        pixel_values = torch.cat(pixel_values, dim=0)
        image_sizes = [torch.from_numpy(v) if v is not None else image_size_for_padding for v in image_sizes]
        image_sizes = torch.cat(image_sizes, dim=0)
        inputs['pixel_values'] = pixel_values.float()
        inputs['image_sizes'] = image_sizes.long()
    else:
        inputs['pixel_values'] = torch.zeros(input_ids.shape[0], 1)
        inputs['image_sizes'] = torch.ones(input_ids.shape[0], 1)

    return inputs


def Phi3V_process_fn(model_inputs: dict, processor, max_length=None):
    input_ids, pixel_values, image_sizes, image_grid_thw = [], [], [], []
    texts, images = model_inputs['text'], model_inputs['images']
    image_exists = False
    # 1. iterate each pair and process (since processors do not support batch processing)
    for text, image in zip(texts, images):
        if image is None:
            inputs = processor(text, None, return_tensors="np", max_length=max_length, truncation=True)
            input_id = inputs["input_ids"].squeeze().tolist()
            if isinstance(input_id, int):
                # in case of empty string, only BOS is included
                input_id = [input_id]
            input_ids.append(input_id)
            pixel_values.append(None)
            image_sizes.append(None)
            image_grid_thw.append(None)
        else:
            image_exists = True
            inputs = processor(text=text, images=[image], return_tensors="np", max_length=max_length, truncation=True)
            input_ids.append(inputs["input_ids"].squeeze().tolist())
            pixel_values.append(inputs['pixel_values'])
            if 'image_sizes' in inputs:
                image_sizes.append(inputs['image_sizes'])
            if 'image_grid_thw' in inputs:
                image_grid_thw.append(inputs['image_grid_thw'])

    # 2. padding inputs
    batch_encoding = processor.tokenizer.pad({'input_ids': input_ids}, return_tensors="pt")
    input_ids, attention_mask = batch_encoding['input_ids'], batch_encoding['attention_mask']
    inputs = {
        'input_ids': input_ids,
        'attention_mask': attention_mask,
        'texts': texts,
        'images': images,
    }
    # 3. special postcare for mixed batch (examples w/ and w/o images in the same batch)
    if image_exists:
        # add them to inputs
        inputs['pixel_values'] = pixel_values
        inputs['image_sizes'] = image_sizes
    else:
        inputs['pixel_values'] = torch.zeros(input_ids.shape[0], 1)
        inputs['image_sizes'] = torch.ones(input_ids.shape[0], 1)

    return inputs


def Qwen2_VL_process_fn(model_inputs: dict, processor: Qwen2VLProcessor, max_length=None):
    # TODO: set separate max_len for text/visual inputs, currently max_length is only applied to text-only data
    input_ids, pixel_values, image_grid_thw, pixel_values_videos, video_grid_thw = [], [], [], [], []
    texts, visual_inputs = model_inputs['text'], model_inputs['images']
    image_exists = False
    vlm_image_token, vlm_video_token = VLM_IMAGE_TOKENS[QWEN2_VL], VLM_VIDEO_TOKENS[QWEN2_VL]

    # 1. iterate each pair and process, since processors do not support processing for mixed batch (contains data w/ and w/o visual inputs)
    for text, images in zip(texts, visual_inputs):
        if images is None or (type(images)==list and any(i is None for i in images)):
            # all images must be valid
            inputs = processor(text=[text], images=None, return_tensors="np", max_length=max_length, truncation=True)
            input_id = inputs["input_ids"].squeeze().tolist()
            if isinstance(input_id, int):
                # in case of empty string, only BOS is included
                input_id = [input_id]
            input_ids.append(input_id)
            pixel_values.append(None)
            image_grid_thw.append(None)
            pixel_values_videos.append(None)
            video_grid_thw.append(None)
        else:
            try:
                if vlm_image_token in text:
                    if isinstance(images, PIL.Image.Image):
                        # images is a single image
                        images = [images]
                    for iid, image in enumerate(images):
                        # rare case in MMEB eval: resize to 28*28 if either w or h is smaller than 28
                        if image.size[0] < 28 or image.size[1] < 28:
                            image = image.resize((56, 56))
                            images[iid] = image
                    inputs = processor(text=[text], images=images, return_tensors="np", max_length=None, truncation=False, input_data_format=ChannelDimension.LAST)
                elif vlm_video_token in text:
                    # TODO: check text/video data validity
                    inputs = processor(text=[text], videos=[images], return_tensors="np", max_length=None, truncation=False, input_data_format=ChannelDimension.LAST)
                else:
                    raise NotImplementedError(f"No visual token found ({vlm_image_token} or {vlm_video_token}) in the text: {text}")
            except Exception as e:
                for i in images:
                    print(i.filename)
                raise e
            input_ids.append(inputs["input_ids"].squeeze().tolist())
            image_pixels = inputs.get('pixel_values', None)
            video_pixels = inputs.get('pixel_values_videos', None)
            if image_pixels is not None:
                pixel_values.append(image_pixels)
                image_grid_thw.append(inputs.get('image_grid_thw', None))
                pixel_values_videos.append(None)
                video_grid_thw.append(None)
            elif video_pixels is not None:
                pixel_values.append(None)
                image_grid_thw.append(None)
                pixel_values_videos.append(video_pixels)
                video_grid_thw.append(inputs.get('video_grid_thw', None))
            else:
                raise KeyError(f"Omni processor returned no vision tensors. keys={list(inputs.keys())}")

    # 2. padding inputs
    batch_encoding = processor.tokenizer.pad({'input_ids': input_ids}, return_tensors="pt")
    input_ids, attention_mask = batch_encoding['input_ids'], batch_encoding['attention_mask']
    # manually enforce long type due to:
    # (1) [rank7]: RuntimeError: Expected tensor for argument #1 'indices' to have one of the following scalar types: Long, Int; but got torch.cuda.FloatTensor instead (while checking arguments for embedding)
    # (2) [rank7]:   File "/fsx/home/ruimeng/project/VLM2Vec/src/model.py", line 45, in _pooling
    #     [rank7]:     reps = last_hidden_state[
    #     [rank7]: IndexError: tensors used as indices must be long, int, byte or bool tensors
    inputs = {
        'input_ids': input_ids.long(),
        'attention_mask': attention_mask.long(), 
        'texts': texts,
        'images': visual_inputs,
    }
    inputs['pixel_values'] = pixel_values
    inputs['image_grid_thw'] = image_grid_thw
    inputs['pixel_values_videos'] = pixel_values_videos
    inputs['video_grid_thw'] = video_grid_thw

    return inputs

def Gme_process_fn(model_inputs: dict, processor: Qwen2VLProcessor, max_length=None):
    inputs = {
        'texts': model_inputs['text'],
        'images': model_inputs['images'],
    }
    return inputs


def Qwen2_VL_TokenSelection_process_fn(model_inputs: dict, processor: Qwen2VLTokenSelectionProcessor, max_length=None):
    # TODO: set separate max_len for text/visual inputs, currently max_length is only applied to text-only data
    input_ids, pixel_values, image_grid_thw, pixel_values_videos, video_grid_thw = [], [], [], [], []
    patch_pos, select_mask = [], []
    texts, visual_inputs = model_inputs['text'], model_inputs['images']
    image_exists = False
    # 1. iterate each pair and process (since processors do not support batch processing)
    for text, images in zip(texts, visual_inputs):
        if images is None or (type(images)==list and any(i is None for i in images)):
            # all images must be valid
            inputs = processor(text=[text], images=None, return_tensors="np", max_length=max_length, truncation=True)
            input_id = inputs["input_ids"].squeeze().tolist()
            if isinstance(input_id, int):
                # in case of empty string, only BOS is included
                input_id = [input_id]
            input_ids.append(input_id)
            pixel_values.append(None)
            image_grid_thw.append(None)
            patch_pos.append(None)
            select_mask.append(None)
            pixel_values_videos.append(None)
            video_grid_thw.append(None)
        else:
            image_exists = True
            # TODO only
            # handling multi-image data from videos, cannot deal with mixed image + video data
            if VLM_IMAGE_TOKENS[QWEN2_VL] in text:
                inputs = processor(text=[text], images=[images], return_tensors="np", max_length=None, truncation=False, input_data_format=ChannelDimension.LAST)
            elif VLM_VIDEO_TOKENS[QWEN2_VL] in text:
                assert len(images) > 1, f"Video data must have more than 1 frame, got {len(images)}"
                inputs = processor(text=[text], videos=[images], return_tensors="np", max_length=None, truncation=False, input_data_format=ChannelDimension.LAST)
            else:
                raise NotImplementedError(f"Unsupported visual token in text: {text}")
            input_ids.append(inputs["input_ids"].squeeze().tolist())
            if 'pixel_values' in inputs:
                pixel_values.append(inputs['pixel_values'])
                image_grid_thw.append(inputs['image_grid_thw'])
                pixel_values_videos.append(None)
                video_grid_thw.append(None)
                if 'patch_pos' in inputs:
                    patch_pos.append(inputs['patch_pos'])
                if 'select_mask' in inputs:
                    select_mask.append(inputs['select_mask'])
            else:
                pixel_values.append(None)
                image_grid_thw.append(None)
                patch_pos.append(None)
                select_mask.append(None)
                pixel_values_videos.append(inputs['pixel_values_videos'])
                video_grid_thw.append(inputs['video_grid_thw'])

    # 2. padding inputs
    batch_encoding = processor.tokenizer.pad({'input_ids': input_ids}, return_tensors="pt")
    input_ids, attention_mask = batch_encoding['input_ids'], batch_encoding['attention_mask']

    if image_exists:
        if patch_pos:
            patch_pos_shape_for_padding = list(v.shape for v in patch_pos if v is not None)[0]
            key_tmp = [torch.from_numpy(v) if v is not None else (torch.zeros(patch_pos_shape_for_padding) - 1) for v in patch_pos]
            max_length = input_ids.size(1)
            padded_key = [torch.nn.functional.pad(pos, (0, max_length - pos.size(1)), value=-1) for pos in key_tmp]
            patch_pos = torch.cat(padded_key, dim=0)
        if select_mask:
            select_mask_shape_for_padding = list(v.shape for v in select_mask if v is not None)[0]
            key_tmp = [torch.from_numpy(v) if v is not None else torch.ones(select_mask_shape_for_padding).bool() for v in select_mask]
            max_length = input_ids.size(1)
            padded_key = [torch.nn.functional.pad(pos, (0, max_length - pos.size(1)), value=True) for pos in key_tmp]
            select_mask = torch.cat(padded_key, dim=0)

    # manually enforce long type due to:
    # (1) [rank7]: RuntimeError: Expected tensor for argument #1 'indices' to have one of the following scalar types: Long, Int; but got torch.cuda.FloatTensor instead (while checking arguments for embedding)
    # (2) [rank7]:   File "/fsx/home/ruimeng/project/VLM2Vec/src/model.py", line 45, in _pooling
    #     [rank7]:     reps = last_hidden_state[
    #     [rank7]: IndexError: tensors used as indices must be long, int, byte or bool tensors
    inputs = {
        'input_ids': input_ids.long(),
        'attention_mask': attention_mask.long()
    }
    inputs['pixel_values'] = pixel_values
    inputs['image_grid_thw'] = image_grid_thw
    inputs['pixel_values_videos'] = pixel_values_videos
    inputs['video_grid_thw'] = video_grid_thw
    inputs['patch_pos'] = patch_pos
    inputs['select_mask'] = select_mask

    return inputs


def VLM_Compression_process_fn(model_inputs: dict, processor: ProcessorMixin, max_length=None, task_type="retrieval", prob=0.0):
    input_ids, position_ids, labels, sep_indices, pixel_values, image_grid_thw, pixel_values_videos, video_grid_thw = [], [], [], [], [], [], [], []
    texts, visual_inputs = model_inputs['text'], model_inputs['images']
    image_exists = False

    # dynamic parse processor type
    if isinstance(processor, Qwen2VLProcessor):
        model_name = QWEN2_VL
        position_index_fn = get_rope_index_2
    elif isinstance(processor, Qwen2_5_VLProcessor):
        model_name = QWEN2_VL
        position_index_fn = get_rope_index_25
    elif isinstance(processor, KeyeVL1_5Processor):
        model_name = KEYE_VL_1_5
        position_index_fn = get_rope_index_keye
    elif isinstance(processor, LlavaNextProcessor):
        # fallback to llava-next process function
        return Llava_NEXT_Compression_process_fn(model_inputs, processor, max_length=max_length, task_type=task_type, prob=prob)
    else:
        raise NotImplementedError(f"Unsupported VLM processor type for compression: {type(processor)}")

    vlm_image_token, vlm_video_token = VLM_IMAGE_TOKENS[model_name], VLM_VIDEO_TOKENS[model_name]

    # 1. iterate each pair and process, since processors do not support processing for mixed batch (contains data w/ and w/o visual inputs)
    for text, images in zip(texts, visual_inputs):
        ignore_openqa_compression = (task_type == 'openqa' and prob != 0 and random.random() < prob)
        compress_suffix = VLM_COMPRESS_TOKENS[0] if TOTAL_COMPRESS_TOKENS > 0 else None
        if images is None or (type(images)==list and any(i is None for i in images)):
            # all images must be valid
            inputs = processor(text=[text], images=None, return_tensors="pt", max_length=max_length, truncation=True)
            if task_type == "openqa":
                target = inputs["input_ids"].squeeze()
                eos_token_id = processor.tokenizer.eos_token_id
                if int((target == eos_token_id).sum().item()) < 1:
                    trimmed_text = _trim_text_keep_suffix_marker(
                        text,
                        processor.tokenizer,
                        max_length=max_length,
                        suffix_marker=compress_suffix,
                        fallback_marker=vlm_image_token,
                    )
                    inputs = processor(text=[trimmed_text], images=None, return_tensors="pt", max_length=max_length, truncation=True)
            input_id = inputs["input_ids"].squeeze().tolist()
            if isinstance(input_id, int):
                # in case of empty string, only BOS is included
                input_id = [input_id]
            input_ids.append(input_id)
            pixel_values.append(None)
            image_grid_thw.append(None)
            pixel_values_videos.append(None)
            video_grid_thw.append(None)
            position_ids.append(
                torch.arange(0, inputs["input_ids"].size(1))
                .view(1, -1)
                .unsqueeze(0)
                .expand(3, -1, -1)
            )
        else:
            try:
                if vlm_image_token in text:
                    if isinstance(images, PIL.Image.Image):
                        # images is a single image
                        images = [images]
                    for iid, image in enumerate(images):
                        # rare case in MMEB eval: resize to 28*28 if either w or h is smaller than 28
                        if image.size[0] < 28 or image.size[1] < 28:
                            image = image.resize((56, 56))
                            images[iid] = image
                    if task_type == "openqa":
                        if ignore_openqa_compression:
                            text = text.replace(ENCODE_PROMPT, "")  # HACK: remove drop compression token with prob
                        inputs = processor(text=[text], images=images, return_tensors="pt", max_length=max_length, truncation=True, input_data_format=ChannelDimension.LAST)
                    elif task_type == "retrieval":
                        inputs = processor(text=[text], images=images, return_tensors="pt", max_length=None, truncation=False, input_data_format=ChannelDimension.LAST)
                elif vlm_video_token in text:
                    # TODO: check text/video data validity
                    if task_type == "openqa":
                        inputs = processor(text=[text], videos=[images], return_tensors="pt", max_length=max_length, truncation=True, input_data_format=ChannelDimension.LAST)
                    elif task_type == "retrieval":
                        inputs = processor(text=[text], videos=[images], return_tensors="pt", max_length=None, truncation=False, input_data_format=ChannelDimension.LAST)
                else:
                    raise NotImplementedError(f"No visual token found ({vlm_image_token} or {vlm_video_token}) in the text: {text} and image: {images}")
            except Exception as e:
                for i in images:
                    print(i.filename)
                raise e
            input_ids.append(inputs["input_ids"].squeeze().tolist())
            if 'pixel_values' in inputs:
                pixel_values.append(inputs['pixel_values'])
                image_grid_thw.append(inputs['image_grid_thw'])
                pixel_values_videos.append(None)
                video_grid_thw.append(None)
            else:
                pixel_values.append(None)
                image_grid_thw.append(None)
                pixel_values_videos.append(inputs['pixel_values_videos'])
                video_grid_thw.append(inputs['video_grid_thw'])

            # rope position ids
            pos_ids, _ = position_index_fn(
                processor.image_processor.merge_size,
                inputs["input_ids"],
                image_grid_thw=inputs.get("image_grid_thw", None),
                video_grid_thw=inputs.get("video_grid_thw", None),
                second_per_grid_ts=inputs.get("second_per_grid_ts", None),
            )
            position_ids.append(pos_ids)

        # labels & seq_indices
        ctoken_start_id = processor.tokenizer.encode(VLM_COMPRESS_TOKENS[0])[0] if TOTAL_COMPRESS_TOKENS > 0 else None
        ctoken_indices = torch.where(inputs["input_ids"].squeeze() == ctoken_start_id)[0] if ctoken_start_id is not None else [0]
        if task_type == "openqa":
            target = inputs["input_ids"].squeeze()
            eos_token_id = processor.tokenizer.eos_token_id  # split by eos token
            eos_indices = torch.where(target == eos_token_id)[0] + 2  # <|im_end|>\n
            assert len(eos_indices) >= 1, f"Expected eos indices, but got {len(eos_indices)}, text: {text}"  # might be truncated
            target[:eos_indices[0] + 3] = IGNORE_INDEX  # ignore all tokens before decode answer, include '<|im_start|>assistant\n'
            labels.append(target)
            if len(ctoken_indices) > 0 and not ignore_openqa_compression :
                sep_indices.append([ctoken_indices[0], ctoken_indices[0] + TOTAL_COMPRESS_TOKENS, eos_indices[0], len(input_ids[-1])])  # add indices for openqa
            else:
                sep_indices.append([0, 0, eos_indices[0], len(input_ids[-1])])  # add indices for openqa
        if task_type == "retrieval":
            assert TOTAL_COMPRESS_TOKENS == 0 or len(input_ids[-1]) - ctoken_indices[0] == TOTAL_COMPRESS_TOKENS, f"Expected compression tokens to be appended at the end of the input sequence. text: {text}"
            sep_indices.append([ctoken_indices[0], ctoken_indices[0] + TOTAL_COMPRESS_TOKENS, 0, 0])  # add dummy index for retrv_flag

    # 2. padding inputs
    batch_encoding = processor.tokenizer.pad({'input_ids': input_ids}, return_tensors="pt")
    input_ids, attention_mask = batch_encoding['input_ids'], batch_encoding['attention_mask']
    position_ids = pad_and_cat(position_ids)
    sep_indices = torch.tensor(sep_indices, dtype=torch.long)
    assert sep_indices.shape[0] == input_ids.shape[0]
    # manually enforce long type due to:
    # (1) [rank7]: RuntimeError: Expected tensor for argument #1 'indices' to have one of the following scalar types: Long, Int; but got torch.cuda.FloatTensor instead (while checking arguments for embedding)
    # (2) [rank7]:   File "/fsx/home/ruimeng/project/VLM2Vec/src/model.py", line 45, in _pooling
    #     [rank7]:     reps = last_hidden_state[
    #     [rank7]: IndexError: tensors used as indices must be long, int, byte or bool tensors
    inputs = {
        'input_ids': input_ids.long(),
        'position_ids': position_ids.long(),
        'attention_mask': attention_mask.long(),
        'sep_indices': sep_indices,
        'texts': texts,
        'images': visual_inputs,
    }

    if len(labels) > 0:
        labels = pad_sequence(labels, batch_first=True, padding_value=IGNORE_INDEX)
        inputs['labels'] = labels.long()

    inputs['pixel_values'] = pixel_values
    inputs['image_grid_thw'] = image_grid_thw
    inputs['pixel_values_videos'] = pixel_values_videos
    inputs['video_grid_thw'] = video_grid_thw

    return inputs


def InternVL_process_fn(model_inputs: dict, processor, max_length=None):
    # TODO not working yet
    input_ids, pixel_values, image_sizes, image_grid_thw = [], [], [], []
    texts, images = model_inputs['text'], model_inputs['images']
    image_exists = False
    # 1. iterate each pair and process (since processors do not support batch processing)
    for text, image in zip(texts, images):
        if image is None:
            inputs = processor(text, None, return_tensors="np", max_length=max_length, truncation=True)
            input_id = inputs["input_ids"].squeeze().tolist()
            if isinstance(input_id, int):
                # in case of empty string, only BOS is included
                input_id = [input_id]
            input_ids.append(input_id)
            pixel_values.append(None)
            image_sizes.append(None)
            image_grid_thw.append(None)
        else:
            image_exists = True
            inputs = processor(text=text, images=[image], return_tensors="np", max_length=max_length, truncation=True)
            input_ids.append(inputs["input_ids"].squeeze().tolist())
            pixel_values.append(inputs['pixel_values'])
            if 'image_sizes' in inputs:
                image_sizes.append(inputs['image_sizes'])
            if 'image_grid_thw' in inputs:
                image_grid_thw.append(inputs['image_grid_thw'])

    # 2. padding inputs
    batch_encoding = processor.tokenizer.pad({'input_ids': input_ids}, return_tensors="pt")
    input_ids, attention_mask = batch_encoding['input_ids'], batch_encoding['attention_mask']
    inputs = {
        'input_ids': input_ids,
        'attention_mask': attention_mask,
        'texts': texts,
        'images': images,
    }
    # 3. special postcare for mixed batch (examples w/ and w/o images in the same batch)
    if image_exists:
        # add them to inputs
        inputs['pixel_values'] = pixel_values
        inputs['image_sizes'] = image_sizes
    else:
        inputs['pixel_values'] = torch.zeros(input_ids.shape[0], 1)
        inputs['image_sizes'] = torch.ones(input_ids.shape[0], 1)

    return inputs


def ColPali_process_fn(model_inputs: dict, processor, max_length=None):
    texts, images = model_inputs['text'], model_inputs['images']
    if images is None or all(i is None for i in images):
        inputs = processor.process_queries(texts)
    else:
        inputs = processor.process_images(images)
    return inputs


def InternVideo2_process_fn(model_inputs: dict, processor, max_length=None):
    if all(x is None for x in model_inputs["images"]):
        # Text side
        from src.model.baseline_backbone.internvideo2.modeling_internvideo2 import BertTokenizer
        tokenizer = BertTokenizer.from_pretrained("bert-large-uncased")
        inputs = tokenizer(
            model_inputs["text"],
            padding="max_length",
            truncation=True,
            max_length=40,
            return_tensors="pt")
    else:
        # Video side
        from torchvision import transforms
        preprocess = transforms.Compose([
            transforms.Lambda(lambda img: img.convert("RGB") if img.mode != "RGB" else img),
            transforms.Resize((224, 224)),  # Resize to 224x224
            transforms.ToTensor(),  # Convert from PIL image to tensor (C, H, W)
            transforms.Normalize(mean=[0.485, 0.456, 0.406],  # ImageNet mean
                                 std=[0.229, 0.224, 0.225])  # ImageNet std
        ])
        frame_list = model_inputs["images"]
        # to make image inputs be exact 4 frames
        # Case 1: frame_list is flat (not a list of lists), e.g., [PIL, PIL, ...]
        if type(frame_list[0]) is not list:
            frame_list = [[img.copy() for _ in range(4)] for img in frame_list]
        # Case 2: frame_list is already a list of lists, ensure each has exactly 4 images
        elif type(frame_list[0]) is list and len(frame_list[0]) != 4:
            new_list = []
            for frames in frame_list:
                if len(frames) < 4:
                    frames = frames + [frames[-1].copy() for _ in range(4 - len(frames))]
                elif len(frames) > 4:
                    # Sample 4 indices uniformly across the sequence
                    indices = np.linspace(0, len(frames) - 1, num=4, dtype=int)
                    frames = [frames[i] for i in indices]
                new_list.append(frames)
            frame_list = new_list
        pixel_values = [
            torch.stack([preprocess(img) for img in frames], dim=0)  # (num_frames, C, H, W)
            for frames in frame_list
        ]

        pixel_values = torch.stack(pixel_values, dim=0)  # (B, num_frames, C, H, W)
        inputs = {'pixel_values': pixel_values}

    return inputs



def VLM_Omni_Compression_process_fn(
    model_inputs: dict, 
    processor: ProcessorMixin, 
    max_length=None, 
    task_type="retrieval", 
    prob=0.0, 
    get_rope_func=None, 
    needs_label=True, 
    cls_sep_indices=[0, TOTAL_COMPRESS_TOKENS],
):
    import re

    feature_extractor = getattr(processor, "feature_extractor", None)
    
    assert get_rope_func is not None, "Please provide get_rope_func for VLM_Omni_Compression_process_fn"

    input_ids, position_ids, labels, sep_indices, pixel_values, image_grid_thw, pixel_values_videos, video_grid_thw = [], [], [], [], [], [], [], []
    cls_indices = []
    # texts, visual_inputs = model_inputs['text'], model_inputs['images']
    texts = model_inputs['text']
    visual_inputs = model_inputs['images'] if 'images' in model_inputs else [None] * len(texts)
    audio_inputs = model_inputs['audios'] if 'audios' in model_inputs else [None] * len(texts)

    image_exists = False

    # dynamic parse processor type
    if isinstance(processor, Qwen2_5OmniProcessor):
        model_name = QWEN2_5_OMNI
        position_index_fn = get_rope_func
    else:
        raise NotImplementedError(f"Unsupported VLM processor type for compression: {type(processor)}")

    vlm_image_token, vlm_video_token, vlm_audio_token = VLM_IMAGE_TOKENS[model_name], VLM_VIDEO_TOKENS[model_name], VLM_AUDIO_TOKENS[model_name]
    compress_suffix = VLM_COMPRESS_TOKENS[0] if TOTAL_COMPRESS_TOKENS > 0 else None

    # 1. iterate each pair and process, since processors do not support processing for mixed batch (contains data w/ and w/o visual inputs)

    # from ipdb import set_trace; set_trace()

    for text, images, audios, cls_idx in zip(texts, visual_inputs, audio_inputs, model_inputs.get("cls_indices", len(texts) * [None])):
        # TODO: omni 会自动加一个 system
        text = re.sub(r"<\|im_start\|>system\n.*?<\|im_end\|>\n", "", text)

        ignore_openqa_compression = (task_type == 'openqa' and prob != 0 and random.random() < prob)

        mm_inputs = {}
        has_image_token = vlm_image_token in text
        has_audio_token = vlm_audio_token in text
        invalid_image_count = 0
        if has_image_token:
            if images is None:
                invalid_image_count = text.count(vlm_image_token)
            elif isinstance(images, list):
                valid_images = [image for image in images if image is not None]
                invalid_image_count = len(images) - len(valid_images)
                images = valid_images or None

            if invalid_image_count > 0:
                text = _remove_last_n_occurrences(text, vlm_image_token, invalid_image_count)
            if images is None:
                text = text.replace(vlm_image_token, "")
            has_image_token = vlm_image_token in text

        invalid_audio_count = 0
        if has_audio_token:
            if audios is None:
                invalid_audio_count = text.count(vlm_audio_token)
            else:
                if not isinstance(audios, list):
                    audios = [audios]
                valid_audios = [audio for audio in audios if audio is not None]
                invalid_audio_count = len(audios) - len(valid_audios)
                audios = valid_audios or None

            if invalid_audio_count > 0:
                text = _remove_last_n_occurrences(text, vlm_audio_token, invalid_audio_count)
            if audios is None:
                text = text.replace(vlm_audio_token, "")
            has_audio_token = vlm_audio_token in text

        if not has_image_token and not has_audio_token:
            # Pure text inputs skip multimodal processing.
            inputs = processor(text=[text], images=None, return_tensors="pt", max_length=max_length, truncation=True)
            input_id = inputs["input_ids"].squeeze().tolist()
            if isinstance(input_id, int):
                # in case of empty string, only BOS is included
                input_id = [input_id]
            input_ids.append(input_id)
            pixel_values.append(None)
            image_grid_thw.append(None)
            pixel_values_videos.append(None)
            video_grid_thw.append(None)
            position_ids.append(
                torch.arange(0, inputs["input_ids"].size(1))
                .view(1, -1)
                .unsqueeze(0)
                .expand(3, -1, -1)
            )
            # print(f'position_id.shape: {position_ids[-1].shape}')
        else:
            inputs = None
            try:
                if has_image_token or has_audio_token:
                    # images, audios = None, None

                    if has_image_token:
                        if isinstance(images, PIL.Image.Image):
                            # images is a single image
                            images = [images]
                        for iid, image in enumerate(images):
                            # rare case in MMEB eval: resize to 28*28 if either w or h is smaller than 28
                            if image.size[0] < 28 or image.size[1] < 28:
                                image = image.resize((56, 56))
                                images[iid] = image
                    else:
                        images = None

                    if has_audio_token:
                        # fliter broken audio files


                        audios = _regularize_audios(
                            audios,
                            sampling_rate=getattr(processor, "audio_sampling_rate", 16000),
                        )["audios"]
                        mm_inputs.update(
                            feature_extractor(
                                audios,
                                sampling_rate=getattr(processor, "audio_sampling_rate", 16000),
                                return_attention_mask=True,
                                padding="max_length",
                                return_tensors="pt",
                            )
                        )
                            
                        mm_inputs["feature_attention_mask"] = mm_inputs.pop("attention_mask")  # prevent conflicts
                    else:
                        audios = None


                    if task_type == "openqa":
                        if ignore_openqa_compression:
                            text = text.replace(ENCODE_PROMPT, "")  # HACK: remove drop compression token with prob
                        # from ipdb import set_trace; set_trace()
                        inputs = processor(text=[text], images=images, audio=audios, return_tensors="pt", max_length=max_length, truncation=True, input_data_format=ChannelDimension.LAST)
                        target = inputs["input_ids"].squeeze()
                        eos_token_id = processor.tokenizer.eos_token_id
                        if int((target == eos_token_id).sum().item()) < 1:
                            effective_max_length = max_length
                            if max_length is not None and TOTAL_COMPRESS_TOKENS > 0:
                                effective_max_length = max(max_length - _estimate_omni_mm_token_overhead(processor, inputs, mm_inputs.get("feature_attention_mask", None)), 32)
                            trimmed_text = _trim_text_keep_suffix_marker(
                                text,
                                processor.tokenizer,
                                max_length=effective_max_length,
                                suffix_marker=compress_suffix,
                                fallback_marker=vlm_image_token,
                            )
                            inputs = processor(text=[trimmed_text], images=images, audio=audios, return_tensors="pt", max_length=max_length, truncation=True, input_data_format=ChannelDimension.LAST)
                    elif task_type == "retrieval":
                        try:
                            inputs = processor(text=[text], images=images, audio=audios, return_tensors="pt", max_length=max_length, truncation=True, input_data_format=ChannelDimension.LAST)
                            if TOTAL_COMPRESS_TOKENS > 0:
                                ctoken_start_id = processor.tokenizer.encode(VLM_COMPRESS_TOKENS[0], add_special_tokens=False)[0]
                                ctoken_indices, has_complete_suffix, _ = _get_compression_token_state(inputs["input_ids"], ctoken_start_id)
                                if not has_complete_suffix:
                                    effective_max_length = max_length
                                    if max_length is not None:
                                        effective_max_length = max(max_length - _estimate_omni_mm_token_overhead(processor, inputs, mm_inputs.get("feature_attention_mask", None)), 32)
                                    trimmed_text = _trim_text_keep_suffix_marker(
                                        text,
                                        processor.tokenizer,
                                        max_length=effective_max_length,
                                        suffix_marker=compress_suffix,
                                        fallback_marker=vlm_image_token,
                                    )
                                    inputs = processor(text=[trimmed_text], images=images, audio=audios, return_tensors="pt", max_length=max_length, truncation=True, input_data_format=ChannelDimension.LAST)
                        except Exception as e:
                            print(traceback.format_exc())
                            print(f"[{torch.distributed.get_rank()}] {text}")
                            print(f"[{torch.distributed.get_rank()}] {images}")
                            if inputs is not None:
                                print(f"[{torch.distributed.get_rank()}] {inputs}")
                            text = text.replace(vlm_image_token, "")
                            inputs = processor(text=[text], images=None, audio=audios, return_tensors="pt", max_length=max_length, truncation=True, input_data_format=ChannelDimension.LAST)

                elif vlm_video_token in text:
                    raise NotImplementedError("Video input not supported yet in VLM_Omni_Compression_process_fn")
                    # # TODO: check text/video data validity
                    # if task_type == "openqa":
                    #     inputs = processor(text=[text], videos=[images], return_tensors="pt", max_length=max_length, truncation=True, input_data_format=ChannelDimension.LAST)
                    # elif task_type == "retrieval":
                    #     inputs = processor(text=[text], videos=[images], return_tensors="pt", max_length=None, truncation=False, input_data_format=ChannelDimension.LAST)
                else:
                    raise NotImplementedError(f"No visual token found ({vlm_image_token} or {vlm_video_token}) in the text: {text} and image: {images}")
            except Exception as e:
                print(traceback.format_exc())
                if isinstance(images, list):
                    for i in images:
                        if hasattr(i, "filename"):
                            print(i.filename)
                        else:
                            print(repr(i))
                raise e

            input_ids.append(inputs["input_ids"].squeeze().tolist())

            image_pixels = inputs.get("pixel_values")
            video_pixels = inputs.get("pixel_values_videos")
            if image_pixels is not None:
                pixel_values.append(image_pixels)
                image_grid_thw.append(inputs.get("image_grid_thw"))
                pixel_values_videos.append(None)
                video_grid_thw.append(None)
            elif video_pixels is not None:
                pixel_values.append(None)
                image_grid_thw.append(None)
                pixel_values_videos.append(video_pixels)
                video_grid_thw.append(inputs.get("video_grid_thw"))
            else:
                pixel_values.append(None)
                image_grid_thw.append(None)
                pixel_values_videos.append(None)
                video_grid_thw.append(None)

            # rope position ids

            rope_index_kwargs = {
                "input_ids": inputs["input_ids"],
                "image_grid_thw": inputs.get("image_grid_thw", None),
                "video_grid_thw": inputs.get("video_grid_thw", None),
                # "second_per_grid_ts": inputs.get("second_per_grid_ts", None),
                # "attention_mask": (features["attention_mask"] >= 1).float(),
            }

            rope_index_kwargs["use_audio_in_video"] = getattr(processor, "use_audio_in_video", False)
            feature_attention_mask = mm_inputs.get("feature_attention_mask", None)
            if feature_attention_mask is not None:  # FIXME: need to get video image lengths
                audio_feature_lengths = torch.sum(feature_attention_mask, dim=1)
                rope_index_kwargs["audio_seqlens"] = audio_feature_lengths  # prepare for input

            position_id, rope_delta = position_index_fn(**rope_index_kwargs)

            # print(f'position_id.shape: {position_id.shape}')

            # rope_deltas = rope_deltas - (1 - rope_index_kwargs["attention_mask"]).sum(dim=-1).unsqueeze(-1)

            # print(f'len(position_id): {len(position_id)}')
            # print(f'position_id[0].shape: {position_id[0].shape}')

            position_ids.append(position_id)

            # FIXME: check why rope_deltas is not used

        # labels & seq_indices
        ctoken_start_id = processor.tokenizer.encode(VLM_COMPRESS_TOKENS[0], add_special_tokens=False)[0] if TOTAL_COMPRESS_TOKENS > 0 else None
        ctoken_indices, has_complete_suffix, tail_span = _get_compression_token_state(inputs["input_ids"], ctoken_start_id)
        if task_type == "openqa":
            target = inputs["input_ids"].squeeze()
            eos_token_id = processor.tokenizer.eos_token_id  # split by eos token
            eos_indices = torch.where(target == eos_token_id)[0] + 2  # <|im_end|>\n
            assert len(eos_indices) >= 1, f"Expected eos indices, but got {len(eos_indices)}, text: {text}"  # might be truncated
            if needs_label:
                if not len(eos_indices) > 1:
                    print(f"[WARN] training but only 1 eos token: {text}")
                target[:eos_indices[0] + 3] = IGNORE_INDEX  # ignore all tokens before decode answer, include '<|im_start|>assistant\n'
                labels.append(target)
            if len(ctoken_indices) > 0 and not ignore_openqa_compression:
                # sep_idx = []
                # for cls_sep_idx in cls_sep_indices:
                #     sep_idx.append(ctoken_indices[0] + cls_sep_idx)
                # assert sep_idx[0] == ctoken_indices[0], f"sep_idx: {sep_idx} doesn't start with {ctoken_indices[0]}"
                # assert sep_idx[-1] == ctoken_indices[0] + TOTAL_COMPRESS_TOKENS, f"sep_idx: {sep_idx} doesn't end with {ctoken_indices[0] + TOTAL_COMPRESS_TOKENS}"
                
                sep_idx = [ctoken_indices[0], ctoken_indices[0] + TOTAL_COMPRESS_TOKENS]
                sep_idx.extend([eos_indices[0], len(input_ids[-1])])  # add indices for openqa
            else:
                sep_idx = [0, 0, eos_indices[0], len(input_ids[-1])]  # add indices for openqa
        if task_type == "retrieval":
            assert len(ctoken_indices) > 0 or TOTAL_COMPRESS_TOKENS == 0, (
                f"Compression tokens missing after tokenization/truncation. "
                f"max_length={max_length}, text_tail={text[-256:]}"
            )
            assert TOTAL_COMPRESS_TOKENS == 0 or has_complete_suffix, (
                f"Expected {TOTAL_COMPRESS_TOKENS} compression tokens at the end of the input sequence, "
                f"but got tail_span={tail_span}. text: {text}"
            )
            # I C1 C2 ...
            # sep_idx = []
            # for cls_sep_idx in cls_sep_indices:
            #     sep_idx.append(ctoken_indices[0] + cls_sep_idx)
            # assert sep_idx[0] == ctoken_indices[0], f"sep_idx: {sep_idx} doesn't start with {ctoken_indices[0]}"
            # assert sep_idx[-1] == ctoken_indices[0] + TOTAL_COMPRESS_TOKENS, f"sep_idx: {sep_idx} doesn't end with {ctoken_indices[0] + TOTAL_COMPRESS_TOKENS}"
            sep_idx = [ctoken_indices[0], ctoken_indices[0] + TOTAL_COMPRESS_TOKENS]
            sep_idx.extend([0, 0])  # add dummy index for retrv_flag

        sep_indices.append(sep_idx)
        if cls_idx is not None:
            cls_indices.append([i + ctoken_indices[0] for i in cls_idx])
    #* end for loop

    padding_side = processor.tokenizer.padding_side

    sep_indices = torch.tensor(sep_indices, dtype=torch.long)

    inputs_len = [len(input_id) for input_id in input_ids]
    sep_indices = shift_sep_indices(sep_indices, inputs_len, padding_side=padding_side)

    # 2. padding inputs
    batch_encoding = processor.tokenizer.pad({'input_ids': input_ids}, return_tensors="pt", return_attention_mask=True,)
    input_ids, attention_mask = batch_encoding['input_ids'], batch_encoding['attention_mask']
    assert sep_indices.shape[0] == input_ids.shape[0]

    # print('!!!!!!!!!!!!')
    # print([a.shape for a in position_ids])
    position_ids = pad_and_cat(position_ids, padding_side=padding_side)
    # manually enforce long type due to:
    # (1) [rank7]: RuntimeError: Expected tensor for argument #1 'indices' to have one of the following scalar types: Long, Int; but got torch.cuda.FloatTensor instead (while checking arguments for embedding)
    # (2) [rank7]:   File "/fsx/home/ruimeng/project/VLM2Vec/src/model.py", line 45, in _pooling
    #     [rank7]:     reps = last_hidden_state[
    #     [rank7]: IndexError: tensors used as indices must be long, int, byte or bool tensors
    inputs = {
        'input_ids': input_ids.long(),
        'position_ids': position_ids.long(),
        'attention_mask': attention_mask.long(),
        'sep_indices': sep_indices,
        # 'texts': texts,
        # 'images': visual_inputs,
    }

    if len(cls_indices) > 0:
        cls_indices = torch.tensor(cls_indices, dtype=torch.long)
        assert cls_indices.shape[0] == input_ids.shape[0]
        cls_indices = shift_sep_indices(cls_indices, inputs_len, padding_side=padding_side)
        inputs["cls_indices"] = cls_indices

    if len(labels) > 0:
        assert processor.tokenizer.padding_side == 'right', "Only support right padding"
        labels = pad_sequence(labels, batch_first=True, padding_value=IGNORE_INDEX)
        inputs['labels'] = labels.long()

    inputs['pixel_values'] = pixel_values
    inputs['image_grid_thw'] = image_grid_thw
    # inputs['pixel_values_videos'] = None # FIXME: hard code
    inputs['video_grid_thw'] = video_grid_thw

    return inputs

def process_input_text(instruction, model_backbone, text=None, add_video_token=False, add_image_token=False):
    # Formulate input text based on text, special token and instruction.
    # TBD: Reorganize the hard-code part for baselines such as internvideo2
    if model_backbone == "internvideo2":
        return text
    elif model_backbone in [GME, LamRA, LamRA_QWEN2_5]:
        if text:
            return instruction + " " + text # GME and LamRA do not need special tokens
        else:
            return instruction + " "
    prompt = instruction
    if text:
        prompt = prompt + " " + text
    if add_video_token:
        video_token = VLM_VIDEO_TOKENS[model_backbone]
        prompt = video_token + " " + prompt
    if add_image_token:
        image_token = VLM_IMAGE_TOKENS[model_backbone]
        prompt = image_token + " " + prompt
    return prompt


def postprocess_input_text(query_texts, cand_texts, model_backbone):
    if TOTAL_COMPRESS_TOKENS > 0:
        summarize_prompt = "".join(VLM_COMPRESS_TOKENS)
        query_texts = [[query + summarize_prompt for query in queries] for queries in query_texts]
        cand_texts = [[cand + summarize_prompt for cand in cands] for cands in cand_texts]
    return query_texts, cand_texts

def _regularize_audios(
    audios: list["AudioInput"], sampling_rate: float, **kwargs
) -> dict[str, Union[list["NDArray"], list[float]]]:
    r"""Regularizes audios to avoid error. Including reading and resampling."""
    if audios is None:
        return {"audios": [], "sampling_rates": []}
    if not isinstance(audios, (list, tuple)):
        audios = [audios]

    results, sampling_rates = [], []
    for audio in audios:
        if audio is None:
            audio = np.zeros(1600)
        if not isinstance(audio, np.ndarray):
            try:
                audio, sampling_rate = librosa.load(audio, sr=sampling_rate)
                audio_duration = len(audio) / sampling_rate
                if audio_duration < 0.1:
                    # a fake audio
                    audio = np.zeros(1600)
                    logger.warning(f"Audio duration is too short: {audio_duration}s, replaced with a silent audio.")
            except Exception as e:
                audio = np.zeros(1600)
                # log trackback
                logger.warning(f"Error loading audio: {e}, replaced with a silent audio.")
                logger.warning(traceback.format_exc())


        results.append(audio)
        sampling_rates.append(sampling_rate)

    return {"audios": results, "sampling_rates": sampling_rates}


process_vlm_inputs_fns = {
    PHI3V: Phi3V_process_fn,
    LLAVA_NEXT: Llava_NEXT_process_fn,
    QWEN2_VL: Qwen2_VL_process_fn,
    QWEN2_5_VL: Qwen2_VL_process_fn,
    QWEN2_VL_TOKENSELECTION: Qwen2_VL_TokenSelection_process_fn,
    QWEN2_5_VL_TOKENSELECTION: Qwen2_VL_TokenSelection_process_fn,
    INTERNVIDEO2: InternVideo2_process_fn,
    GME: Gme_process_fn,
    LamRA: Gme_process_fn,
    LamRA_QWEN2_5: Gme_process_fn,
    COLPALI: ColPali_process_fn,
    KORUS: VLM_Compression_process_fn,
    KORUS_OMNI: VLM_Omni_Compression_process_fn,
}
