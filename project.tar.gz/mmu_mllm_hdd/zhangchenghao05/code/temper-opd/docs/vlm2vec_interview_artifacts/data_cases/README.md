# VLM2Vec Data Cases

这些 case 用于面试复盘本地 VLM2Vec / Goods / Better SID 数据流。它们保留字段结构、任务类型和多模态占位符，不保存完整训练集。

## Files

- `retrieval_goods_pair.schema.json`: `hetu_ret` / `retrieval_goods` pair 样例。
- `hetu_goods_openqa_long.case.json`: 商品长分析 OpenQA / compression 样例。
- `hetu_goods_short_title.case.json`: 商品短标题结构化抽取样例。
- `parallel_sid_photo_item.case.json`: 视频/图片 + 商品 SID 样例。
- `hetu_items_encode_only.schema.json`: `hetu_items` encode-only 推理样例。

## Source Pointers

- Goods OpenQA: `/mmu_mllm_hdd_2/luoyuxiao/Data/hetu_v5/infer_seed/output/goods_output_compression_len2048_train.jsonl`
- Goods short title: `/mmu_mllm_hdd_2/luoyuxiao/Data/hetu_v5/infer_sft/goods/v2_short/qa_train.jsonl`
- ParallelSID item/photo: `/mmu_mllm_hdd/zhangzejian/parallel_sid/scripts/gemini_client/gemini_results/photo_item_postprocessed.jsonl.shuf`
- Retrieval pair paths are referenced by the copied `experiments/hetu/train_goods_0429_*_retqa_curated.yaml`; several `/mmu_vcg_wjc_hdd/...` raw jsonl paths were not mounted when this snapshot was made.
